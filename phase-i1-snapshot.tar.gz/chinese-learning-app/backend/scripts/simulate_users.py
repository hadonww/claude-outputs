"""
Четыре сценария ученика поверх настоящей базы курса (Phase I). Проверяют поведение
планировщика и SRS через те же сервисы, что и фронтенд, а не число элементов:

  A — новый: 0 знакомых слов, проходит HSK 1 с начала (scripts/validate_hsk1_course.py):
      ни одного неизвестного слова, новые слова понемногу, повторение с каждым уроком;
  B — слабый: у части пройденных слов точность ниже 70 %: такие слова идут в урок раньше
      остальных (по сроку — в повторение, до срока — на закрепление) и получают больше шагов;
      после новых ошибок урок не разрастается (повторов после ошибок — не больше лимита);
  C — долг повторений: у всех пройденных слов срок прошёл: повторений в уроке больше
      (до BACKLOG_REVIEW_CAP), новых слов временно меньше, долг убывает, а когда он ушёл —
      новые слова снова полной порцией;
  D — сильный: весь HSK 1 освоен (интервал ≥ 21 дня): урок даёт следующий материал,
      проверка удержания берёт по одному давнему слову и не крутит одно и то же.

    python3 scripts/simulate_users.py [--db app.db]
Выход 1 — какое-то ожидание не выполнилось.
"""

import argparse
import json
import sys
import tempfile
from collections import Counter
from datetime import date, timedelta
from pathlib import Path
from random import Random

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.simulate_course import _answer, _known_ids, _patch_today
from scripts.validate_hsk1_course import validate


def _prepare(db_src: Path, lessons: int, name: str) -> tuple[Path, date]:
    """База ученика, прошедшего первые lessons уроков HSK 1 без ошибок, и следующий день."""
    path = Path(tempfile.mkdtemp()) / f"{name}.db"
    report = validate(db_src, max_lessons=lessons, keep=path)
    return path, date.fromisoformat(report["last_day"]) + timedelta(days=1)


def _use(path: Path, day: date):
    import app.config as cfg
    import app.db as dbm

    cfg.DB_PATH = path
    dbm.DB_PATH = path
    _patch_today(day)


def _run(conn, plan, rng: Random, accuracy: float = 1.0, wrong_ids: set[int] = frozenset()) -> list[dict]:
    """Проходит урок (сессия уже создана); wrong_ids — слова, на которые ученик отвечает неверно."""
    from app.repositories import lesson_sessions_repo
    from app.services import lesson_service

    sid, i, done = plan["session_id"], 0, []
    while True:
        steps = lesson_sessions_repo.get(conn, sid)["steps"]
        if i >= len(steps):
            break
        step = steps[i]
        ok = step["word_id"] not in wrong_ids and rng.random() < accuracy
        lesson_service.record_session_attempt(conn, sid, i, _answer(step, ok))
        done.append(step)
        i += 1
    lesson_service.complete_session(conn, sid)
    return done


def _start(conn):
    from app.services import learning_path_service, lesson_service

    module_id = learning_path_service.get_learning_path(conn)["recommended_module_id"]
    return lesson_service.start_lesson(conn, module_id)


def _script_new_count(conn) -> int | None:
    """Сколько слов сценария текущего урока ещё не видены (полная порция без долга)."""
    from app.repositories import modules_repo, progress_repo, users_repo
    from app.services import learning_path_service, lesson_service
    from engine import lesson_script

    module = modules_repo.get_module(conn, learning_path_service.get_learning_path(conn)["recommended_module_id"])
    script, _ = lesson_service._module_script(conn, module, users_repo.get_current_user_id(conn))
    return len(lesson_script.lesson_new_ids(script, progress_repo.seen_word_ids(conn))) if script else None


def _steps_range(values: list[int]) -> dict:
    v = sorted(values)
    return {"min": v[0], "median": v[len(v) // 2], "max": v[-1]}


def user_a(db_src: Path) -> dict:
    report = validate(db_src)
    log = report["lesson_log"]
    steps = _steps_range([r["steps"] for r in log])
    checks = {
        "без неизвестных слов": report["violation_count"] == 0,
        "все сценарии HSK 1 по порядку": report["scripted_lessons"] == report["expected_scripted"],
        "новые слова понемногу (≤5 за урок)": report["max_new_per_lesson"] <= 5,
        "повторение в каждом уроке после первого": all(r["review"] > 0 for r in log[1:]),
        "весь HSK 1 пройден": not report["unseen_hsk1_words"],
        "обычный урок 15–25 шагов (медиана), без длинных хвостов": 15 <= steps["median"] <= 25 and steps["max"] <= 30,
    }
    return {"checks": checks, "lessons": report["lessons"], "review_sessions": report["review_sessions"],
            "days": report["days"], "steps": steps, "new_per_lesson": dict(Counter(r["new"] for r in log)),
            "avg_review_per_lesson": round(sum(r["review"] for r in log) / len(log), 1),
            "avg_steps": report["avg_steps"]}


def user_b(db_src: Path) -> dict:
    from engine.lesson_planner import MAX_RETRIES_PER_LESSON

    path, day = _prepare(db_src, 12, "weak")
    _use(path, day)
    from app.db import get_db

    with get_db() as conn:
        seen = sorted(_known_ids(conn))
        weak_due, weak_later, normal_due = seen[:2], seen[2:4], seen[4:8]
        later = (day + timedelta(days=3)).isoformat()
        for wid in weak_due + weak_later:   # 3 из 10 верно — слабое слово
            conn.execute("UPDATE progress SET total_attempts = 10, total_correct = 3, due_date = ? WHERE word_id = ?",
                         (day.isoformat() if wid in weak_due else later, wid))
        for wid in normal_due:              # обычные слова, срок которых сегодня
            conn.execute("UPDATE progress SET total_attempts = 10, total_correct = 10, due_date = ? WHERE word_id = ?",
                         (day.isoformat(), wid))
        others = [w for w in seen if w not in weak_due + weak_later + normal_due]
        conn.execute(f"UPDATE progress SET due_date = ? WHERE word_id IN ({','.join('?' * len(others))})",
                     (later, *others))
        recent_today = {r[0] for r in conn.execute("SELECT word_id FROM progress WHERE last_reviewed = ?",
                                                     (day.isoformat(),))}
        plan = _start(conn)
        review = [w["id"] for w in plan["review_words"]]
        roles = {s["word_id"]: s["role"] for s in plan["steps"] if s["role"] in ("weak", "due")}
        steps_per = Counter(s["word_id"] for s in plan["steps"])
        # ученик снова ошибается на слабых словах и ещё в каждом третьем задании
        done = _run(conn, plan, Random(1), accuracy=0.67, wrong_ids=set(weak_due + weak_later))
    weak_steps = [steps_per[w] for w in weak_due + weak_later if w in steps_per]
    due_steps = [steps_per[w] for w in normal_due if w in steps_per]
    checks = {
        "слабые по сроку — первыми в повторении": review[:2] == weak_due,
        "слабые до срока — на закреплении": all(roles.get(w) == "weak" for w in weak_later),
        "после слабых — обычные по сроку": bool(review[2:]) and set(review[2:]) <= set(normal_due),
        "слабое слово по сроку — 2 шага, обычное — не больше": bool(due_steps) and min(weak_steps[:2]) >= 2
            and max(due_steps) <= 2,
        "слабые до срока получают лишнее закрепление, обычные до срока — нет":
            not set(steps_per) & set(others) - set(recent_today),
        "после ошибок урок не разрастается (повторов ≤ лимита, шагов ≤ 35)":
            len(done) - len(plan["steps"]) <= MAX_RETRIES_PER_LESSON and len(done) <= 35,
    }
    return {"checks": checks, "review_order": review, "weak_due": weak_due, "weak_later": weak_later,
            "steps_per_weak_word": weak_steps, "steps_per_due_word": due_steps,
            "planned_steps": len(plan["steps"]), "steps_with_mistakes": len(done)}


def user_c(db_src: Path) -> dict:
    from engine.lesson_planner import BACKLOG_REVIEW_CAP, BACKLOG_THRESHOLD

    path, day = _prepare(db_src, 16, "backlog")
    _use(path, day)
    from app.db import get_db
    from app.repositories import progress_repo
    from app.services import lesson_service

    with get_db() as conn:
        conn.execute(f"UPDATE progress SET due_date = ? WHERE word_id IN ({','.join('?' * len(_known_ids(conn)))})",
                     ((day - timedelta(days=2)).isoformat(), *_known_ids(conn)))
        due_before = progress_repo.count_due_review_words(conn, day.isoformat())
        full_portion = _script_new_count(conn)
        plan = _start(conn)
        first = {"new": len(plan["new_words"]), "full_portion": full_portion,
                 "review": len(plan["review_words"]), "review_cap": plan["mix"]["review_cap"],
                 "review_steps": sum(1 for s in plan["steps"] if s["role"] in ("weak", "due")),
                 "new_steps": sum(1 for s in plan["steps"] if s["role"] == "new"), "steps": len(plan["steps"])}
        _run(conn, plan, Random(2), accuracy=0.9)
    dues, later = [due_before], None
    for d in range(1, 9):              # дальше — по два урока в день и повторение, если урок его предлагает
        _use(path, day + timedelta(days=d))
        with get_db() as conn:
            for k in range(2):
                due_now = progress_repo.count_due_review_words(conn, (day + timedelta(days=d)).isoformat())
                portion = _script_new_count(conn)
                if later is None and due_now <= BACKLOG_THRESHOLD and (portion or 0) >= 3:
                    plan = _start(conn)        # первый урок нового сценария после долга
                    later = {"due": due_now, "new": len(plan["new_words"]), "full_portion": portion}
                else:
                    plan = _start(conn)
                _run(conn, plan, Random(d * 10 + k), accuracy=0.9)
                if due_now > BACKLOG_THRESHOLD:
                    review = lesson_service.start_review(conn)
                    if review["steps"]:
                        _run(conn, review, Random(100 + d * 10 + k), accuracy=0.9)
            dues.append(progress_repo.count_due_review_words(conn, (day + timedelta(days=d)).isoformat()))
    checks = {
        "при долге — больше слов повторения (до BACKLOG_REVIEW_CAP)": first["review"] == min(BACKLOG_REVIEW_CAP, due_before),
        "повторение получает больше слов, чем новое": first["review"] >= first["new"],
        "новых слов временно меньше обычной порции": 1 <= first["new"] < first["full_portion"],
        "урок не превращается в сплошное повторение": first["new_steps"] > 0 and first["steps"] <= 30,
        "долг убывает": dues[-1] < dues[0],
        "когда долг ушёл — новые слова полной порцией": later is not None and later["new"] == later["full_portion"],
    }
    return {"checks": checks, "due_before": due_before, "first_lesson": first, "due_by_day": dues,
            "after_backlog": later}


def user_d(db_src: Path) -> dict:
    path, day = _prepare(db_src, 200, "strong")
    _use(path, day)
    from app.db import get_db
    from app.services import learning_path_service

    with get_db() as conn:
        seen = sorted(_known_ids(conn))
        conn.execute(
            f"""UPDATE progress SET repetitions = 6, interval_days = 60, ease_factor = 2.7, due_date = ?,
                last_reviewed = ?, total_attempts = 8, total_correct = 8
                WHERE word_id IN ({','.join('?' * len(seen))})""",
            ((day + timedelta(days=30)).isoformat(), (day - timedelta(days=40)).isoformat(), *seen))
        path_info = learning_path_service.get_learning_path(conn)
        rec = next(m for m in path_info["modules"] if m["id"] == path_info["recommended_module_id"])
    retention, new_counts, review_counts = [], [], []
    for d in range(6):                           # 6 дней по уроку
        _use(path, day + timedelta(days=d))
        with get_db() as conn:
            plan = _start(conn)
            retention += [s["word_id"] for s in plan["steps"] if s["role"] == "retention"]
            new_counts.append(len(plan["new_words"]))
            review_counts.append(sum(1 for w in plan["review_words"] if w["id"] in seen))
            _run(conn, plan, Random(d))
    with get_db() as conn:
        fresh = conn.execute("SELECT word_id FROM progress WHERE total_attempts > 0 AND repetitions <= 2").fetchall()
        mastered_new = conn.execute(
            f"""SELECT COUNT(*) FROM progress WHERE word_id NOT IN ({','.join('?' * len(seen))})
                AND interval_days >= 21""", seen).fetchone()[0]
    checks = {
        "после HSK 1 — следующий материал (HSK 2)": rec["hsk_level"] == 2,
        "каждый урок даёт новые слова": all(n > 0 for n in new_counts),
        "освоенные слова не повторяются без срока": sum(review_counts) == 0,
        "проверка удержания — не больше одного слова за урок": len(retention) <= 6,
        "проверка удержания не крутит одно и то же слово": len(retention) == len(set(retention)),
        "новые слова не становятся освоенными сразу": mastered_new == 0 and len(fresh) > 0,
    }
    return {"checks": checks, "next_module": rec["title"], "next_level": rec["hsk_level"],
            "new_per_lesson": new_counts, "retention_words": retention, "mastered_review_per_lesson": review_counts}


def run_all(db_src: Path) -> dict:
    result = {}
    for name, fn in (("A_new", user_a), ("B_weak", user_b), ("C_backlog", user_c), ("D_strong", user_d)):
        result[name] = fn(db_src)
        result[name]["ok"] = all(result[name]["checks"].values())
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", type=Path, default=Path(__file__).resolve().parent.parent / "app.db")
    args = parser.parse_args()
    result = run_all(args.db)
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    sys.exit(0 if all(r["ok"] for r in result.values()) else 1)


if __name__ == "__main__":
    main()
