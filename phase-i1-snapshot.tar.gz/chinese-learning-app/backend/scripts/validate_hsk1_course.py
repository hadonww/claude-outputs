"""
Последовательная проверка курса HSK 1 (Phase I): новый ученик проходит маршрут от
первого урока до последнего через настоящие сервисы (lesson_service — то же, что
делает фронтенд), а проверка смотрит каждый шаг каждого урока.

Ученик начинает без единого знакомого слова; после каждого урока его состояние (SRS,
mastery, пройденные сценарии) меняется как обычно, дни идут вперёд (по два урока в
день), повторения наступают по расписанию. Шаг нарушает правило, если требует слова,
которого ученик к этому моменту не видел:
  * слово шага (word_id) — должно быть знакомо или уже представлено в этом уроке
    (исключение — сама карточка знакомства и проверка «я это уже знаю»);
  * все слова фразы/примера/диалога/перевода/сопоставления/группы pinyin_error
    (payload.used_word_ids) — знакомы или представлены раньше в этом уроке.
Знакомые = слова, которые уже были в SRS до урока (progress), и слова повторения урока.
Дистракторы-слова в recognition/listening/word_choice знания не требуют (ответ — по цели)
и не проверяются; там, где ошибка может быть в любом слове (matching, pinyin_error),
они входят в used_word_ids и проверяются.

Дополнительно: уроки темы идут по сценариям (data/lessons) строго по порядку маршрута,
каждый сценарий проходится один раз, в уроке не больше 5 новых слов, к концу все слова
модулей HSK 1 пройдены, а в каждом уроке после первого есть повторение.

    python3 scripts/validate_hsk1_course.py [--db app.db] [--accuracy 1.0] [--seed 1]
Выход 1 — найдены нарушения.
"""

import argparse
import json
import shutil
import sys
import tempfile
from collections import Counter
from datetime import date, timedelta
from pathlib import Path
from random import Random

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.simulate_course import _answer, _known_ids, _patch_today

MAX_NEW_PER_LESSON = 5
SCRIPT_TYPES = {"translate_cn_ru", "sentence_listening", "dialogue_scene", "translation_build", "speaking"}


def expected_script_keys(level: int = 1) -> list[str]:
    """Ключи сценариев уровня в порядке маршрута (раздел → тема → порядок в файле)."""
    from app.curriculum import ROUTE_SECTIONS
    from app.repositories import lesson_scripts_repo

    keys = []
    for section in ROUTE_SECTIONS:
        for category in section.categories:
            module = {"hsk_level": level, "category": category}
            keys += [b["key"] for b in lesson_scripts_repo.blueprints_for_module(module)]
    return keys


def _quartiles(values: list[int]) -> dict:
    v = sorted(values)
    if not v:
        return {}
    return {"min": v[0], "p25": v[len(v) // 4], "median": v[len(v) // 2], "p75": v[3 * len(v) // 4], "max": v[-1]}


def validate(db_src: Path, accuracy: float = 1.0, seed: int = 1, per_day: int = 2,
             start: date = date(2026, 1, 5), max_lessons: int = 200, keep: Path | None = None,
             follow_review: bool = True) -> dict:
    """
    keep — путь, куда сохранить базу ученика после проверки (для симуляций поверх неё).
    follow_review — ученик делает то, что предлагает итог урока: если там «Сначала
    повторение» (долг повторений), он проходит сессию «Только повторение» перед
    следующим уроком (её шаги проверяются так же).
    """
    tmp = keep or Path(tempfile.mkdtemp()) / "hsk1.db"
    shutil.copy(db_src, tmp)
    import app.config as cfg
    import app.db as dbm

    cfg.DB_PATH = tmp
    dbm.DB_PATH = tmp
    dbm.init_db()
    from app.db import get_db
    from app.repositories import lesson_sessions_repo, words_repo
    from app.services import learning_path_service, lesson_service

    rng = Random(seed)
    violations, lessons, reviews, types, mismatches = [], [], [], Counter(), []

    def run_session(conn, plan, record) -> dict:
        sid = plan["session_id"]
        known = _known_ids(conn) | {w["id"] for w in plan["review_words"]}
        introduced: set[int] = set()
        i = 0
        while True:
            steps = lesson_sessions_repo.get(conn, sid)["steps"]
            if i >= len(steps):
                break
            step = steps[i]
            types[step["type"]] += 1
            record["types"][step["type"]] += 1
            record["retries"] += bool(step.get("retry"))
            allowed = known | introduced
            own_ok = (step["word_id"] in allowed or step["type"] == "introduction"
                      or step.get("role") == "verify")
            used = (step.get("payload") or {}).get("used_word_ids") or []
            bad = sorted({w for w in used if w not in allowed and w != step["word_id"]})
            if step["word_id"] not in allowed and step["type"] != "introduction" \
                    and step.get("role") != "verify" and used and step["word_id"] in used:
                bad.append(step["word_id"])
            if not own_ok or bad:
                names = {w["id"]: w["hanzi"] for w in
                         (words_repo.word_row_to_dict(words_repo.get_word_by_id(conn, x))
                          for x in set(bad) | {step["word_id"]})}
                violations.append({"lesson": record["n"], "key": record["key"], "step": i,
                                   "type": step["type"], "word": names[step["word_id"]],
                                   "unknown": [names[x] for x in bad] or [names[step["word_id"]]]})
            if step["type"] == "introduction":
                introduced.add(step["word_id"])
            right = rng.random() < accuracy
            res = lesson_service.record_session_attempt(conn, sid, i, _answer(step, right))
            # верный ответ ученика сервер обязан принять (проверка упражнений на реальном контенте)
            if right and step["type"] not in ("introduction", "speaking") and not res["correct"]:
                mismatches.append({"lesson": record["n"], "type": step["type"], "expected": res.get("expected")})
            i += 1
        record["steps"] = i
        record["types"] = dict(record["types"])
        return lesson_service.complete_session(conn, sid)

    day = start
    _patch_today(day)
    while len(lessons) < max_lessons:
        if lessons and len(lessons) % per_day == 0:
            day += timedelta(days=1)
            _patch_today(day)
        with get_db() as conn:
            path = learning_path_service.get_learning_path(conn)
            module_id = path["recommended_module_id"]
            module = next((m for m in path["modules"] if m["id"] == module_id), None)
            if module is None or module["hsk_level"] != 1:
                break
            plan = lesson_service.start_lesson(conn, module_id)
            lesson = plan.get("lesson") or {}
            record = {"n": len(lessons) + 1, "day": (day - start).days, "module": module["title"],
                      "key": lesson.get("key"), "mode": lesson.get("mode"), "new": len(plan["new_words"]),
                      "review": len(plan["review_words"]) + len(plan.get("practice_words") or []),
                      "due": plan["mix"]["due_total"], "steps": 0, "retries": 0, "types": Counter()}
            summary = run_session(conn, plan, record)
            lessons.append(record)
            if follow_review and (summary.get("next") or {}).get("kind") == "review":
                review_plan = lesson_service.start_review(conn)
                rec = {"n": record["n"], "key": "review", "steps": 0, "retries": 0, "types": Counter(),
                       "review": len(review_plan["review_words"])}
                if review_plan["steps"]:
                    run_session(conn, review_plan, rec)
                    reviews.append(rec)

    with get_db() as conn:
        hsk1 = {r[0]: r[1] for r in conn.execute(
            "SELECT w.id, w.hanzi FROM words w JOIN modules m ON m.id = w.module_id WHERE m.hsk_level = 1")}
        unseen = sorted(h for wid, h in hsk1.items() if wid not in _known_ids(conn))

    expected = expected_script_keys(1)
    # урок сценария может идти в два захода (при долге повторений часть новых слов — в
    # следующий урок): порядок сценариев — по первому появлению
    scripted_new = list(dict.fromkeys(r["key"] for r in lessons if r["key"] and r["mode"] == "new"))
    problems = []
    if violations:
        problems.append(f"неизвестные слова в упражнениях: {len(violations)}")
    if scripted_new != expected:
        problems.append("сценарии пройдены не по порядку маршрута или не все")
    too_many = [r["n"] for r in lessons if r["new"] > MAX_NEW_PER_LESSON]
    if too_many:
        problems.append(f"больше {MAX_NEW_PER_LESSON} новых слов в уроках {too_many}")
    if unseen:
        problems.append(f"не пройдены слова HSK 1: {unseen}")
    no_script_steps = [r["n"] for r in lessons if r["key"] and not SCRIPT_TYPES & set(r["types"])]
    if no_script_steps:
        problems.append(f"урок по сценарию без фраз/диалога/перевода: {no_script_steps}")
    if mismatches:
        problems.append(f"верный ответ не принят: {mismatches[:3]}")
    generic = [r["n"] for r in lessons if not r["key"]]
    if generic:   # все слова HSK 1 входят в сценарии — урок без сценария значит, что слово выпало из них
        problems.append(f"уроки HSK 1 без сценария: {generic}")
    no_review = [r["n"] for r in lessons[1:] if r["review"] == 0]
    if no_review:
        problems.append(f"уроки без повторения: {no_review}")
    return {
        "ok": not problems,
        "problems": problems,
        "lessons": len(lessons),
        "days": (day - start).days + 1,
        "last_day": day.isoformat(),
        "scripted_lessons": len(scripted_new),          # разных сценариев, пройденных как «новые»
        "scripted_lesson_sessions": sum(1 for r in lessons if r["key"]),
        "expected_scripted": len(expected),
        "generic_lessons": sum(1 for r in lessons if not r["key"]),
        "practice_lessons": sum(1 for r in lessons if r["key"] and r["mode"] != "new"),
        "hsk1_words": len(hsk1),
        "unseen_hsk1_words": unseen,
        "violations": violations[:20],
        "violation_count": len(violations),
        "answer_mismatches": len(mismatches),
        "step_types": dict(types.most_common()),
        "max_new_per_lesson": max((r["new"] for r in lessons), default=0),
        "avg_steps": round(sum(r["steps"] for r in lessons) / max(1, len(lessons)), 1),
        "review_sessions": len(reviews),
        "avg_review_session_steps": round(sum(r["steps"] for r in reviews) / max(1, len(reviews)), 1),
        "steps_range": _quartiles([r["steps"] for r in lessons]),
        "lesson_log": [{k: r[k] for k in ("n", "day", "module", "key", "mode", "new", "review", "due", "steps",
                                          "retries")} for r in lessons],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", type=Path, default=Path(__file__).resolve().parent.parent / "app.db")
    parser.add_argument("--accuracy", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--log", action="store_true", help="печатать журнал уроков")
    args = parser.parse_args()
    report = validate(args.db, args.accuracy, args.seed)
    if not args.log:
        report.pop("lesson_log")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(0 if report["ok"] else 1)


if __name__ == "__main__":
    main()
