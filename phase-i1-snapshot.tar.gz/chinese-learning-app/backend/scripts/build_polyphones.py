"""
Строит engine/polyphones.py — другие чтения иероглифов (многочтения) для
упражнения pinyin_error: «ошибочный» вариант не должен совпасть с настоящим
чтением того же иероглифа в другом слове (好 hǎo / hào).

Источник — датасет drkameleon/complete-hsk-vocabulary (MIT), тот же, что у
import_hsk_vocabulary.py: для каждого иероглифа из слов HSK 2.0 уровней 1–4
берутся все чтения его одиночной записи (все forms). Ничего не придумывается.

    python3 scripts/build_polyphones.py <путь>/complete.json > engine/polyphones.py
"""
import json
import sys
import unicodedata

LEVELS = {"old-1", "old-2", "old-3", "old-4"}


def main(path: str) -> None:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    chars = {c for w in data if LEVELS & set(w.get("level", [])) for c in w["simplified"]}
    readings: dict[str, set[str]] = {}
    for w in data:
        s = w["simplified"]
        if len(s) == 1 and s in chars:
            for f in w.get("forms") or []:
                p = unicodedata.normalize("NFC", (f.get("transcriptions") or {}).get("pinyin", "")).lower().strip()
                if p and " " not in p:
                    readings.setdefault(s, set()).add(p)
    multi = {c: sorted(r) for c, r in readings.items() if len(r) > 1}
    print('"""')
    print("Чтения многочтений (сгенерировано scripts/build_polyphones.py — не править вручную).")
    print("Источник: drkameleon/complete-hsk-vocabulary (MIT), коммит 7ac65bf; иероглифы слов HSK 2.0 уровней 1–4.")
    print('"""')
    print()
    print("READINGS: dict[str, tuple[str, ...]] = {")
    for c in sorted(multi, key=lambda ch: ch.encode("utf-8")):
        print(f'    "{c}": ({", ".join(chr(34) + r + chr(34) for r in multi[c])}),')
    print("}")


if __name__ == "__main__":
    main(sys.argv[1])
