"""
Поведенческие проверки интерфейса в браузере (инструмент разработчика; нужен
Playwright + Chromium). Запускает сервер на копии текущей app.db и печатает
PASS/FAIL по каждому пункту.

    python3 scripts/ui_checks.py
"""

import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

BACKEND = Path(__file__).resolve().parent.parent
PORT = "8790"
BASE = f"http://127.0.0.1:{PORT}"
results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))


def main() -> int:
    tmpdir = Path(tempfile.mkdtemp())
    shutil.copytree(BACKEND, tmpdir / "backend", ignore=shutil.ignore_patterns("tests", "__pycache__", ".*"))
    shutil.copytree(BACKEND.parent / "frontend", tmpdir / "frontend")
    db = tmpdir / "backend" / "app.db"
    srv = subprocess.Popen([sys.executable, "-m", "uvicorn", "main:app", "--port", PORT], cwd=tmpdir / "backend",
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(BASE + "/api/me")
                break
            except OSError:
                time.sleep(0.3)
        urllib.request.urlopen(urllib.request.Request(BASE + "/api/me/onboarding/complete", method="POST"))
        with sync_playwright() as p:
            browser = p.chromium.launch()
            ctx = browser.new_context(viewport={"width": 390, "height": 844}, reduced_motion="reduce")
            page = ctx.new_page()
            page.goto(BASE + "/")
            page.wait_for_timeout(1000)
            page.click(".tab[data-view=dict]")
            page.wait_for_timeout(600)
            page.locator(".chip[data-filter=all]").click()
            page.wait_for_timeout(600)
            page.locator(".dict-item").first.click()
            page.wait_for_timeout(500)
            tr = page.evaluate("getComputedStyle(document.getElementById('word-sheet')).transform")
            check("[reduced-motion] лист без сдвига", tr in ("none", "matrix(1, 0, 0, 1, 0, 0)"), tr)
            ctx.close()
            for theme in ("light", "dark"):
                ctx = browser.new_context(viewport={"width": 390, "height": 844}, has_touch=True)
                ctx.add_init_script(f"try{{localStorage.setItem('theme','{theme}')}}catch(e){{}}")
                page = ctx.new_page()
                errors: list[str] = []
                page.on("pageerror", lambda e, errors=errors: errors.append(str(e)))
                page.goto(BASE + "/")
                page.wait_for_timeout(1200)
                run_checks(page, theme, db)
                check(f"[{theme}] нет ошибок JS", not errors, "; ".join(errors[:3]))
                ctx.close()
            browser.close()
    finally:
        srv.terminate()
    width = max(len(n) for n, _, _ in results)
    for name, ok, detail in results:
        print(f"{'PASS' if ok else 'FAIL'}  {name.ljust(width)}  {detail}")
    return 0 if all(ok for _, ok, _ in results) else 1


def sessions(db: Path) -> int:
    with sqlite3.connect(db) as conn:
        return conn.execute("SELECT COUNT(*) FROM lesson_sessions").fetchone()[0]


def run_checks(page, theme: str, db: Path) -> None:
    t = f"[{theme}] "
    # поля ввода не меньше 16px — иначе iOS приближает страницу
    sizes = page.evaluate("""[...document.querySelectorAll('input')].map(i => parseFloat(getComputedStyle(i).fontSize))""")
    check(t + "поля ввода ≥ 16px", all(s >= 16 for s in sizes), str(sizes))
    # цвет строки состояния совпадает с фоном темы
    meta = page.evaluate("document.querySelector('meta[name=theme-color]').content")
    paper = page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--paper').trim()")
    check(t + "theme-color = фон темы", meta.lower() == paper.lower(), f"{meta} / {paper}")
    tap = page.evaluate("getComputedStyle(document.documentElement).webkitTapHighlightColor")
    check(t + "нет серой вспышки при касании", tap in ("rgba(0, 0, 0, 0)", "transparent"), tap)
    # зоны нажатия ≥ 44px у главных элементов (видимые размеры, без ::after)
    small = page.evaluate("""[...document.querySelectorAll('.tab, #home-start-btn, .node, .review-link:not(.hidden)')]
        .filter(e => e.offsetParent).map(e => [e.className, Math.round(e.getBoundingClientRect().height)])
        .filter(([, h]) => h < 44)""")
    check(t + "зоны нажатия ≥ 44px (главная)", not small, str(small[:4]))
    # кольцо фокуса с клавиатуры видно
    page.keyboard.press("Tab")
    ring = page.evaluate("(() => { const e = document.activeElement; const cs = getComputedStyle(e); return [e.tagName, cs.outlineStyle, cs.outlineWidth]; })()")
    check(t + "фокус с клавиатуры виден", ring[1] != "none" and ring[2] != "0px", str(ring))
    # двойное нажатие на карточку урока создаёт одну сессию
    before = sessions(db)
    page.locator("#home-start-btn").dblclick()
    page.wait_for_timeout(1500)
    check(t + "двойной запуск урока → 1 сессия", sessions(db) - before == 1, f"+{sessions(db) - before}")
    hscroll = page.evaluate("document.documentElement.scrollWidth > innerWidth")
    check(t + "урок без горизонтальной прокрутки", not hscroll)
    # зоны нажатия в уроке
    small = page.evaluate("""[...document.querySelectorAll('#lesson-back, .option-btn, .rate-btn, #lesson-action:not(.invisible)')]
        .filter(e => e.offsetParent).map(e => [e.id || e.className, Math.round(e.getBoundingClientRect().height)])
        .filter(([, h]) => h < 44)""")
    check(t + "зоны нажатия ≥ 44px (урок)", not small, str(small[:4]))
    page.locator(".option-btn, #lesson-action:not(.invisible)").first.click()
    page.wait_for_timeout(500)
    if page.locator("#lesson-action:not(.invisible)").count() and page.text_content("#lesson-action") == "Дальше":
        page.click("#lesson-action")
        page.wait_for_timeout(400)
    left_at = page.evaluate("lessonRun.index")
    # доступность шага: фокус на новом шаге, прогресс читается, ответ объявляется
    a11y = page.evaluate("""(() => {
        const bar = document.getElementById('lesson-progress');
        const fb = document.querySelector('.lesson-feedback');
        return [document.activeElement && document.activeElement.parentElement && document.activeElement.parentElement.id,
                bar.getAttribute('role'), bar.getAttribute('aria-valuenow') === String(lessonRun.index),
                fb.getAttribute('aria-live')];
    })()""")
    check(t + "фокус на шаге после «Дальше»", a11y[0] == "lesson-step", str(a11y[0]))
    check(t + "progressbar с текущим шагом", a11y[1] == "progressbar" and a11y[2], str(a11y[1:3]))
    check(t + "обратная связь в aria-live", a11y[3] == "polite", str(a11y[3]))
    emoji = page.evaluate("/[\\u{1F300}-\\u{1FAFF}]/u.test(document.body.innerText)")
    check(t + "нет эмодзи в уроке", not emoji)
    page.locator("#lesson-back").click()
    page.wait_for_timeout(600)
    # вышли из урока — на Главной «Незаконченный урок», продолжение с того же шага
    label = page.text_content("#continue-section-label")
    check(t + "после ✕ — карточка «Незаконченный урок»", "Незаконченный" in (label or ""), label or "")
    page.click("#home-start-btn")
    page.wait_for_timeout(500)
    resumed = page.evaluate("document.getElementById('view-lesson').classList.contains('active') && lessonRun.index === " + str(left_at) + " && lessonRun.index > 0")
    check(t + "продолжение урока с того же шага", resumed)
    page.locator("#lesson-back").click()
    page.wait_for_timeout(600)
    # прокрутка запоминается по вкладкам; повторное нажатие вкладки — наверх
    page.evaluate("window.scrollTo(0, 400)")
    page.wait_for_timeout(100)
    page.click(".tab[data-view=dict]")
    page.wait_for_timeout(500)
    dict_y = page.evaluate("window.scrollY")
    page.click(".tab[data-view=home]")
    page.wait_for_timeout(700)
    home_y = page.evaluate("window.scrollY")
    check(t + "вкладки помнят прокрутку", dict_y == 0 and abs(home_y - 400) < 5, f"dict={dict_y}, home={home_y}")
    page.click(".tab[data-view=home]")
    page.wait_for_timeout(900)
    check(t + "повторное нажатие вкладки — наверх", page.evaluate("window.scrollY") == 0)
    # ошибка загрузки профиля — сообщение с повтором, а не пустой экран
    page.route("**/api/statistics*", lambda route: route.abort())
    page.click(".tab[data-view=profile]")
    page.wait_for_timeout(700)
    err = page.evaluate("!document.getElementById('profile-error').classList.contains('hidden')")
    check(t + "ошибка профиля показывается", err)
    page.unroute("**/api/statistics*")
    page.click("#profile-error button")
    page.wait_for_timeout(700)
    check(t + "повтор после ошибки профиля", page.evaluate("document.getElementById('profile-error').classList.contains('hidden')"))
    page.click(".tab[data-view=home]")
    page.wait_for_timeout(700)
    # повторный заход на Главную — без анимации появления
    anims = page.evaluate("document.getAnimations().filter(a => a.animationName === 'home-rise').length")
    check(t + "повторный показ Главной без анимации", anims == 0, f"анимаций: {anims}")
    # нижний лист: открыть, закрыть Escape с возвратом фокуса, смахнуть вниз
    page.click(".tab[data-view=dict]")
    page.wait_for_timeout(700)
    page.locator(".chip[data-filter=all]").click()
    page.wait_for_timeout(700)
    item = page.locator(".dict-item").first
    item.focus()
    page.keyboard.press("Enter")
    page.wait_for_timeout(600)
    opened = page.evaluate("document.getElementById('word-sheet').classList.contains('is-open') && document.body.classList.contains('sheet-open')")
    check(t + "лист открывается, страница под ним заблокирована", opened)
    page.keyboard.press("Escape")
    page.wait_for_timeout(400)
    back = page.evaluate("document.activeElement.classList.contains('dict-item')")
    closed = page.evaluate("!document.getElementById('word-sheet').classList.contains('is-open')")
    check(t + "Escape закрывает лист и возвращает фокус", back and closed)
    item.click()
    page.wait_for_timeout(600)
    box = page.locator("#word-sheet-handle").bounding_box()
    x, y = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
    page.mouse.move(x, y)
    page.mouse.down()
    for i in range(1, 7):
        page.mouse.move(x, y + i * 40)
        page.wait_for_timeout(8)
    page.mouse.up()
    page.wait_for_timeout(500)
    closed = page.evaluate("!document.getElementById('word-sheet').classList.contains('is-open')")
    check(t + "смахивание вниз закрывает лист", closed)
    page.click(".tab[data-view=home]")
    page.wait_for_timeout(600)


if __name__ == "__main__":
    sys.exit(main())
