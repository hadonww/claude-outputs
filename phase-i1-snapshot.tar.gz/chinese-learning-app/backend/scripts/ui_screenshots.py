"""
Скриншоты основных экранов и прохождение урока в браузере (инструмент
разработчика; нужен Playwright + Chromium, в requirements не входит).

    python3 scripts/ui_screenshots.py . /tmp/shots
    env: WIDTHS=320,390,430,1280  THEMES=light,dark  VIEWS=home,lesson,dict,profile
         LESSON_STEPS=6  FINISH=1 (пройти урок до итога)  FULL=1 (во всю высоту)  PORT=8766

Сервер запускается на текущей backend/app.db. Для каждой ширины и темы печатает
ошибки JS и есть ли горизонтальная прокрутка (должно быть False).
"""
import os
import subprocess
import sys
import time
import urllib.request

from playwright.sync_api import sync_playwright

backend, out = sys.argv[1], sys.argv[2]
port = os.environ.get("PORT", "8766")
os.makedirs(out, exist_ok=True)
srv = subprocess.Popen(["python3", "-m", "uvicorn", "main:app", "--port", port], cwd=backend,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
base = f"http://127.0.0.1:{port}"
for _ in range(60):
    try: urllib.request.urlopen(base + "/api/me"); break
    except OSError: time.sleep(0.3)
urllib.request.urlopen(urllib.request.Request(base + "/api/me/onboarding/complete", method="POST"))
widths = [int(w) for w in os.environ.get("WIDTHS", "390").split(",")]
themes = os.environ.get("THEMES", "light,dark").split(",")
views = os.environ.get("VIEWS", "home,lesson,dict,profile").split(",")
steps_n = int(os.environ.get("LESSON_STEPS", "6"))
full = os.environ.get("FULL", "1") == "1"

def answer(pg):
    """Ответить на текущий шаг (иногда неверно) и вернуть тип."""
    if pg.locator(".rating-row").count() and pg.locator(".card-face").count():
        pg.locator(".card-face").click(); pg.wait_for_timeout(150)
        pg.locator(".rate-btn").nth(2).click(); return "recall"
    if pg.locator(".option-btn").count():
        pg.locator(".option-btn").nth(1).click(); pg.wait_for_timeout(350); return "choice"
    if pg.locator(".token-bank .token").count():
        while pg.locator(".token-bank .token").count():
            pg.locator(".token-bank .token").first.click()
        pg.locator("#lesson-action").click(); pg.wait_for_timeout(350); return "order"
    if pg.locator(".pinyin-input").count():
        pg.fill(".pinyin-input", "ni3"); pg.locator("#lesson-action").click(); pg.wait_for_timeout(350); return "pinyin"
    if pg.locator(".stroke-box").count():
        pg.locator("#lesson-action").click(); pg.wait_for_timeout(350); return "hand"
    return "intro"

try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        for w in widths:
            for th in themes:
                ctx = b.new_context(viewport={"width": w, "height": 844 if w < 700 else 900}, device_scale_factor=1)
                ctx.add_init_script(f"try{{localStorage.setItem('theme','{th}')}}catch(e){{}}")
                pg = ctx.new_page()
                errs = []
                pg.on("pageerror", lambda e, errs=errs: errs.append(str(e)))
                pg.on("console", lambda m, errs=errs: errs.append(m.text) if m.type == "error" else None)
                pg.goto(base + "/"); pg.wait_for_timeout(1200)
                hs = {}
                if "home" in views:
                    pg.screenshot(path=f"{out}/home_{w}_{th}.png", full_page=full)
                    hs["home"] = pg.evaluate("document.documentElement.scrollWidth > innerWidth")
                if "dict" in views:
                    pg.click(".tab[data-view=dict]"); pg.wait_for_timeout(800)
                    pg.screenshot(path=f"{out}/dict_{w}_{th}.png")
                    hs["dict"] = pg.evaluate("document.documentElement.scrollWidth > innerWidth")
                    if pg.locator(".dict-item").count():
                        pg.locator(".dict-item").first.click(); pg.wait_for_timeout(500)
                        pg.screenshot(path=f"{out}/sheet_{w}_{th}.png")
                        pg.locator("#word-sheet-close").click()
                    pg.fill("#dict-search", "xuexi"); pg.wait_for_timeout(600)
                    pg.screenshot(path=f"{out}/dictsearch_{w}_{th}.png")
                    pg.fill("#dict-search", "")
                if "profile" in views:
                    pg.click(".tab[data-view=profile]"); pg.wait_for_timeout(900)
                    pg.screenshot(path=f"{out}/profile_{w}_{th}.png", full_page=full)
                    hs["profile"] = pg.evaluate("document.documentElement.scrollWidth > innerWidth")
                if "lesson" in views:
                    pg.click(".tab[data-view=home]"); pg.wait_for_timeout(900)
                    pg.click("#home-start-btn"); pg.wait_for_timeout(1000)
                    seen = {}
                    for i in range(steps_n):
                        kind = pg.evaluate("lessonRun && lessonRun.steps[lessonRun.index].type")
                        if not kind: break
                        tag = f"{i:02d}_{kind}"
                        pg.screenshot(path=f"{out}/lesson{tag}_{w}_{th}.png")
                        answer(pg)
                        pg.wait_for_timeout(300)
                        pg.screenshot(path=f"{out}/lesson{tag}b_{w}_{th}.png")
                        hs.setdefault("lesson", False)
                        hs["lesson"] |= pg.evaluate("document.documentElement.scrollWidth > innerWidth")
                        btn = pg.locator("#lesson-action:not(.invisible)")
                        if btn.count() and btn.is_enabled() and pg.evaluate("document.getElementById('lesson-action').textContent") == "Дальше":
                            btn.click()
                        pg.wait_for_timeout(400)
                        if pg.locator("#lesson-summary:not(.hidden)").count():
                            break
                    if os.environ.get("FINISH") == "1":
                        typeseen = set()
                        for _ in range(80):
                            if pg.locator("#lesson-summary:not(.hidden)").count(): break
                            kind = pg.evaluate("lessonRun && lessonRun.steps[lessonRun.index] && lessonRun.steps[lessonRun.index].type")
                            first = kind not in typeseen
                            if first:
                                typeseen.add(kind); pg.screenshot(path=f"{out}/type_{kind}_{w}_{th}.png")
                            answer(pg); pg.wait_for_timeout(250)
                            if first:
                                pg.screenshot(path=f"{out}/type_{kind}b_{w}_{th}.png")
                            btn = pg.locator("#lesson-action:not(.invisible)")
                            if btn.count() and pg.evaluate("document.getElementById('lesson-action').textContent") == "Дальше":
                                btn.click()
                            pg.wait_for_timeout(250)
                        pg.wait_for_timeout(800)
                        pg.screenshot(path=f"{out}/summary_{w}_{th}.png", full_page=True)
                print(w, th, "errors:", errs[:5], "hscroll:", hs)
                ctx.close()
        b.close()
finally:
    srv.terminate()
