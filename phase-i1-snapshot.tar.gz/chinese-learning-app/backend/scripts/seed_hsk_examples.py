"""
Phase C: небольшой рукописный (не сгенерированный массово) набор примеров для
самых частотных слов из HSK-импорта (Phase B) — чтобы после Phase C уже можно
было реально проверить fill_blank/sentence_order на новой лексике.

Каждое предложение написано вручную, используя ТОЛЬКО целевое слово + слова,
которые уже есть в базе (в основном рукописные 177 + несколько корректно
разобранных импортированных) — специально избегаю слов, у которых Phase B
audit нашёл неверную омографическую форму (没/吗/了 и т.п., см. отчёт).

Перед вставкой каждое предложение проходит реальную проверку (не считается
валидным просто потому, что я так сказал):
  - все иероглифы предложения резолвятся в существующие word_id;
  - целевое слово реально входит в used_word_ids;
  - 3..9 слов (разумная длина для sentence_order);
  - без дублей (тот же target + тот же sentence_cn уже есть в БД).
Что не проходит эту проверку — печатается и НЕ вставляется, а не тихо
пропускается.

Партия 2 (HSK1_SENTENCES, 2026-10-04): примеры для HSK1-слов, у которых не было
пригодного примера. Дополнительные правила для неё (и для всех будущих партий):
  - у примера есть pinyin (по словарным тонам слов, без тон-сандхи — так же,
    как пиньинь на карточках); он сверяется с пиньинем слов из used_word_ids;
  - все слова предложения не выше HSK-уровня целевого слова;
  - целевое слово встречается в предложении один раз (иначе fill_blank
    оставит подсказку во втором вхождении).

Запуск: python3 scripts/seed_hsk_examples.py [--dry-run]
"""

import argparse
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# (target_hanzi, sentence_cn, sentence_ru)
SEED_SENTENCES = [
    ("的", "这是我的书。", "Это моя книга."),
    ("个", "我有一个朋友。", "У меня есть один друг."),
    ("和", "我和你是朋友。", "Мы с тобой друзья."),
    ("也", "我也喜欢中国。", "Мне тоже нравится Китай."),
    ("都", "我们都是学生。", "Мы все студенты."),
    ("很", "老师很好。", "Учитель очень хороший."),
    ("大", "这个学校很大。", "Эта школа очень большая."),
    ("小", "他的书很小。", "Его книга маленькая."),
    ("多", "他有很多书。", "У него много книг."),
    ("太", "水太多了。", "Воды слишком много."),
    ("最", "他最喜欢看书。", "Он больше всего любит читать."),
    ("只", "我只有一本书。", "У меня только одна книга."),
    ("因为", "因为我喜欢你。", "Потому что ты мне нравишься."),
    ("如果", "如果你去，我也去。", "Если ты пойдёшь, я тоже пойду."),
    ("但是", "我喜欢你，但是他不喜欢你。", "Ты мне нравишься, но ты не нравишься ему."),
    ("已经", "他已经是老师了。", "Он уже учитель."),
    ("可以", "你可以看我的书。", "Ты можешь посмотреть мою книгу."),
    ("可能", "他可能是老师。", "Он, возможно, учитель."),
    ("知道", "我知道你喜欢她。", "Я знаю, что она тебе нравится."),
    ("时候", "我去学校的时候看见他。", "Когда я шёл в школу, я увидел его."),
    ("时间", "我没有时间。", "У меня нет времени."),
    ("需要", "我需要你的书。", "Мне нужна твоя книга."),
    ("开始", "我们开始工作。", "Мы начинаем работать."),
    ("用", "老师用中文说。", "Учитель говорит на китайском."),
    ("给", "我给你一本书。", "Я дам тебе книгу."),
    ("自己", "他自己去学校。", "Он сам идёт в школу."),
    ("怎么", "你怎么知道？", "Откуда ты знаешь?"),
    ("爱", "我爱我的家。", "Я люблю свою семью."),
]


# Партия 2: HSK1-слова без пригодного примера.
# (target_hanzi, sentence_cn, sentence_ru, pinyin)
HSK1_SENTENCES = [
    ("叫", "你叫什么名字？", "Как тебя зовут?", "Nǐ jiào shénme míngzi?"),
    ("漂亮", "她很漂亮。", "Она очень красивая.", "Tā hěn piàoliang."),
    ("认识", "我认识他。", "Я его знаю.", "Wǒ rènshi tā."),
    ("二", "他二十岁。", "Ему двадцать лет.", "Tā èr shí suì."),
    ("五", "我有五个朋友。", "У меня пять друзей.", "Wǒ yǒu wǔ gè péngyou."),
    ("七", "现在七点。", "Сейчас семь часов.", "Xiànzài qī diǎn."),
    ("本", "我有三本书。", "У меня три книги.", "Wǒ yǒu sān běn shū."),
    ("多少", "你们有多少人？", "Сколько вас человек?", "Nǐmen yǒu duōshǎo rén?"),
    ("几", "你几岁？", "Сколько тебе лет?", "Nǐ jǐ suì?"),
    ("少", "他的朋友很少。", "У него мало друзей.", "Tā de péngyou hěn shǎo."),
    ("岁", "我的朋友十八岁。", "Моему другу восемнадцать лет.", "Wǒ de péngyou shí bā suì."),
    ("些", "这些人是我的朋友。", "Эти люди — мои друзья.", "Zhè xiē rén shì wǒ de péngyou."),
    ("明天", "明天你来吗？", "Ты завтра придёшь?", "Míngtiān nǐ lái ma?"),
    ("年", "一年有十二个月。", "В году двенадцать месяцев.", "Yī nián yǒu shí èr gè yuè."),
    ("星期", "这个星期我很忙。", "На этой неделе я очень занят.", "Zhè gè xīngqī wǒ hěn máng."),
    ("点", "现在几点？", "Который час?", "Xiànzài jǐ diǎn?"),
    ("日", "今天是几月几日？", "Какое сегодня число?", "Jīntiān shì jǐ yuè jǐ rì?"),
    ("中午", "我们中午吃米饭。", "В обед мы едим рис.", "Wǒmen zhōngwǔ chī mǐfàn."),
    ("能", "你能来吗？", "Ты сможешь прийти?", "Nǐ néng lái ma?"),
    ("回", "他明天回家。", "Он завтра вернётся домой.", "Tā míngtiān huí jiā."),
    ("开", "请开门。", "Откройте дверь, пожалуйста.", "Qǐng kāi mén."),
    ("看见", "我看见他了。", "Я его увидел.", "Wǒ kànjiàn tā le."),
    ("说话", "他不说话。", "Он молчит.", "Tā bù shuōhuà."),
    ("做", "你在做什么？", "Что ты делаешь?", "Nǐ zài zuò shénme?"),
    ("了", "他来了。", "Он пришёл.", "Tā lái le."),
    ("吗", "你认识他吗？", "Ты его знаешь?", "Nǐ rènshi tā ma?"),
    ("没", "他今天没来。", "Он сегодня не пришёл.", "Tā jīntiān méi lái."),
    ("哪", "你喜欢哪个？", "Какой тебе нравится?", "Nǐ xǐhuan nǎ gè?"),
    ("呢", "我很好，你呢？", "У меня всё хорошо, а у тебя?", "Wǒ hěn hǎo, nǐ ne?"),
    ("怎么样", "你的朋友怎么样？", "Как поживает твой друг?", "Nǐ de péngyou zěnmeyàng?"),
    ("杯子", "桌子上有一个杯子。", "На столе стоит чашка.", "Zhuōzi shàng yǒu yī gè bēizi."),
    ("后面", "他在我后面。", "Он позади меня.", "Tā zài wǒ hòumian."),
    ("里", "他在家里。", "Он дома.", "Tā zài jiā lǐ."),
    ("前面", "他在我前面。", "Он впереди меня.", "Tā zài wǒ qiánmiàn."),
    ("上", "杯子在桌子上。", "Чашка на столе.", "Bēizi zài zhuōzi shàng."),
    ("下", "下个星期他来。", "На следующей неделе он приедет.", "Xià gè xīngqī tā lái."),
    ("住", "我住在北京。", "Я живу в Пекине.", "Wǒ zhù zài Běijīng."),
    ("高兴", "认识你很高兴。", "Рад с тобой познакомиться.", "Rènshi nǐ hěn gāoxìng."),
    ("再见", "爸爸，妈妈，再见！", "Папа, мама, до свидания!", "Bàba, māma, zàijiàn!"),
    ("不客气", "谢谢你！不客气。", "— Спасибо! — Не за что.", "Xièxie nǐ! Bùkèqi."),
    ("电影", "我想看电影。", "Я хочу посмотреть фильм.", "Wǒ xiǎng kàn diànyǐng."),
    ("东西", "我去商店买东西。", "Я иду в магазин за покупками.", "Wǒ qù shāngdiàn mǎi dōngxi."),
    ("喂", "喂，你是谁？", "Алло, кто это?", "Wèi, nǐ shì shéi?"),
    ("医院", "妈妈在医院。", "Мама в больнице.", "Māma zài yīyuàn."),
    ("菜", "我喜欢吃这个菜。", "Мне нравится это блюдо.", "Wǒ xǐhuan chī zhè gè cài."),
    ("饭馆", "这个饭馆很大。", "Этот ресторан большой.", "Zhè gè fànguǎn hěn dà."),
    ("块", "苹果五块钱。", "Яблоки стоят пять юаней.", "Píngguǒ wǔ kuài qián."),
    ("商店", "我在商店买衣服。", "Я покупаю одежду в магазине.", "Wǒ zài shāngdiàn mǎi yīfu."),
    ("学习", "我们在学校学习。", "Мы учимся в школе.", "Wǒmen zài xuéxiào xuéxí."),
    ("写", "我会写这个字。", "Я умею писать этот иероглиф.", "Wǒ huì xiě zhè gè zì."),
    ("汉语", "我会说汉语。", "Я говорю по-китайски.", "Wǒ huì shuō hànyǔ."),
    ("同学", "他是我的同学。", "Он мой одноклассник.", "Tā shì wǒ de tóngxué."),
    ("字", "这个字怎么读？", "Как читается этот иероглиф?", "Zhè gè zì zěnme dú?"),
    ("医生", "我爸爸是医生。", "Мой папа врач.", "Wǒ bàba shì yīshēng."),
    ("电话", "电话在桌子上。", "Телефон на столе.", "Diànhuà zài zhuōzi shàng."),
    ("电视", "我不喜欢看电视。", "Я не люблю смотреть телевизор.", "Wǒ bù xǐhuan kàn diànshì."),
    ("北京", "我想去北京。", "Я хочу поехать в Пекин.", "Wǒ xiǎng qù Běijīng."),
    ("雨", "雨很大。", "Идёт сильный дождь.", "Yǔ hěn dà."),
    ("山", "山上很冷。", "В горах холодно.", "Shān shàng hěn lěng."),
    ("冷", "今天很冷。", "Сегодня холодно.", "Jīntiān hěn lěng."),
    ("热", "今天太热了。", "Сегодня слишком жарко.", "Jīntiān tài rè le."),
    ("下雨", "明天会下雨吗？", "Завтра будет дождь?", "Míngtiān huì xiàyǔ ma?"),
    ("火车站", "我去火车站。", "Я еду на вокзал.", "Wǒ qù huǒchēzhàn."),
]


# Замена двух неестественных примеров партии 1 (тот же формат и проверки, что у партии 2).
REPLACEMENT_SENTENCES = [
    ("就", "我就来。", "Я сейчас приду.", "Wǒ jiù lái."),
    ("它", "这是我的狗，它很小。", "Это моя собака, она маленькая.", "Zhè shì wǒ de gǒu, tā hěn xiǎo."),
]

# Снятые примеры (target_hanzi, sentence_cn): неестественные формулировки. В уже
# заполненной БД они не удаляются, а получают needs_review=1 — движок их не
# использует, данные не теряются; в новые БД они больше не попадают.
RETIRED_SENTENCES = [
    ("就", "我们去学校，就去。"),
    ("它", "这本书，它很好。"),
    ("电话", "你的电话是多少？"),
    ("不客气", "不客气，我们是朋友。"),
    ("再见", "我们明天再见！"),
    ("山", "我们明天去山上。"),
]


def retire_examples(conn) -> int:
    retired = 0
    for target_hanzi, sentence_cn in RETIRED_SENTENCES:
        cur = conn.execute(
            """UPDATE examples SET needs_review = 1
               WHERE sentence_cn = ? AND needs_review = 0
                 AND target_word_id IN (SELECT id FROM words WHERE hanzi = ?)""",
            (sentence_cn, target_hanzi),
        )
        retired += cur.rowcount
    return retired


def _plain(pinyin: str) -> str:
    """Сравнимая форма пиньиня: без регистра, пробелов, апострофов и знаков."""
    return "".join(ch for ch in pinyin.lower() if ch.isalpha())


def check_pinyin(conn, used_ids: list[int], pinyin: str) -> bool:
    """
    Пиньинь предложения = пиньиням слов used_word_ids по порядку (словарные
    тоны). Для HSK-слов берётся пиньинь из карты курса (исправленные чтения
    了 le, 吗 ma, 没 méi), а не сырой из датасета: скрипт запускается до
    connect_hsk_course.py, и проверка не должна зависеть от порядка запуска.
    """
    from scripts.connect_hsk_course import load_full_course_map

    overrides = {h: e["pinyin"] for h, e in load_full_course_map().items() if e["pinyin"]}
    placeholders = ",".join("?" for _ in used_ids)
    by_id = {r[0]: overrides.get(r[1], r[2]) for r in conn.execute(
        f"SELECT id, hanzi, pinyin FROM words WHERE id IN ({placeholders})", used_ids)}
    return _plain(pinyin) == _plain("".join(by_id[i] for i in used_ids))


def resolve(conn, hanzi: str) -> int | None:
    row = conn.execute("SELECT id FROM words WHERE hanzi = ?", (hanzi,)).fetchone()
    return row[0] if row else None


def build_used_word_ids(conn, sentence_cn: str) -> list[int] | None:
    """Реальный состав по факту базы: жадно ищем самое длинное совпадение
    слова из БД в каждой позиции (та же идея, что и в engine.tokenize, но
    напрямую по словам с id, без промежуточного набора строк)."""
    from engine.exercise_types import SENTENCE_PUNCT

    text = "".join(c for c in sentence_cn if c not in SENTENCE_PUNCT)
    ids: list[int] = []
    i = 0
    while i < len(text):
        matched = False
        for n in (4, 3, 2, 1):
            if i + n > len(text):
                continue
            word_id = resolve(conn, text[i:i + n])
            if word_id is not None:
                ids.append(word_id)
                i += n
                matched = True
                break
        if not matched:
            return None  # символ не резолвится ни в одно слово базы
    return ids


def seed_examples(conn, dry_run: bool = False) -> tuple[int, int, int, list]:
    """Снимает неестественные примеры и вставляет рукописные (без commit): (снято, принято, всего, отклонено)."""
    inserted, rejected = 0, []
    retired = retire_examples(conn)
    batch = ([(t, cn, ru, None) for t, cn, ru in SEED_SENTENCES]
             + list(HSK1_SENTENCES) + list(REPLACEMENT_SENTENCES))
    for target_hanzi, sentence_cn, sentence_ru, pinyin in batch:
        target_id = resolve(conn, target_hanzi)
        if target_id is None:
            rejected.append((target_hanzi, sentence_cn, "целевое слово не найдено в БД"))
            continue

        used_ids = build_used_word_ids(conn, sentence_cn)
        if used_ids is None:
            rejected.append((target_hanzi, sentence_cn, "не все иероглифы резолвятся в слова БД"))
            continue
        if target_id not in used_ids:
            rejected.append((target_hanzi, sentence_cn, "целевое слово не найдено в разборе предложения"))
            continue
        if not (3 <= len(used_ids) <= 9):
            rejected.append((target_hanzi, sentence_cn, f"длина {len(used_ids)} вне диапазона 3..9"))
            continue
        dup = conn.execute(
            "SELECT 1 FROM examples WHERE target_word_id = ? AND sentence_cn = ?",
            (target_id, sentence_cn),
        ).fetchone()
        if dup:
            rejected.append((target_hanzi, sentence_cn, "уже есть в БД (дубль)"))
            continue
        if pinyin is not None:  # правила партии 2 (см. docstring)
            if used_ids.count(target_id) != 1:
                rejected.append((target_hanzi, sentence_cn, "целевое слово встречается не один раз"))
                continue
            levels = {r[0]: r[1] for r in conn.execute(
                f"SELECT id, hsk FROM words WHERE id IN ({','.join('?' for _ in used_ids)})", used_ids)}
            above = [wid for wid in used_ids if levels[wid] > levels[target_id]]
            if above:
                rejected.append((target_hanzi, sentence_cn, f"слова выше уровня цели: {above}"))
                continue
            if not check_pinyin(conn, used_ids, pinyin):
                rejected.append((target_hanzi, sentence_cn, f"pinyin не совпадает с пиньинем слов: {pinyin}"))
                continue

        if not dry_run:
            conn.execute(
                """INSERT INTO examples (target_word_id, sentence_cn, sentence_ru, pinyin, used_word_ids,
                   source, needs_review) VALUES (?, ?, ?, ?, ?, 'seed_handwritten', 0)""",
                (target_id, sentence_cn, sentence_ru, pinyin, __import__("json").dumps(used_ids)),
            )
        inserted += 1
    return retired, inserted, len(batch), rejected


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from app.config import DB_PATH
    from app.db import init_db

    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    retired, inserted, total, rejected = seed_examples(conn, args.dry_run)

    if not args.dry_run:
        conn.commit()
    else:
        conn.rollback()
    print(f"Снято (needs_review=1) неестественных примеров: {retired}")

    print(f"Принято{' (dry-run, не записано)' if args.dry_run else ''}: {inserted} из {total}")
    print(f"Отклонено: {len(rejected)}")
    for hanzi, sent, reason in rejected:
        print(f"  {hanzi} | {sent} -> {reason}")
    conn.close()


if __name__ == "__main__":
    main()
