"""
Автоматические проверки качества примеров предложений (чистые функции, без БД).

Пример задаётся пословной разметкой: слова через пробел, знаки препинания —
отдельными токенами («我 每天 都 锻炼 身体 。»). Разметку пишет человек (или
Claude) — это и есть явный состав предложения (used_word_ids), а не догадка
жадной токенизации. Проверки ниже ловят механические ошибки; естественность
фразы и точность перевода машина не проверяет — для этого список ручной проверки
(scripts/reports/examples_review_list.tsv).

Жёсткие проверки (пример отклоняется):
  * каждый токен — слово базы или знак препинания;
  * целевое слово встречается ровно один раз (иначе fill_blank оставит подсказку),
    кроме парных конструкций REPEATABLE_TARGETS (一边…一边, 越…越);
  * 3..12 слов; в конце — знак конца предложения;
  * все слова не выше HSK-уровня целевого слова;
  * в китайской части нет латиницы/кириллицы, в русской — нет иероглифов, есть кириллица;
  * пиньинь собирается из пиньиня слов (словарные тоны, без тон-сандхи — как на карточках).
Мягкие (пример принимается, но попадает в список ручной проверки):
  * слова того же уровня, что и цель (пример станет доступен только после их изучения);
  * у цели спорный перевод (doubt) — значение в примере нужно сверить;
  * соседние токены вместе образуют слово базы («没 关系» при слове 没关系 — ошибка,
    «三 点 十 分» при слове 十分 — нет).
"""

from dataclasses import dataclass, field

PUNCT_TOKENS = {"。", "，", "？", "！", "、", "：", "；", "“", "”", "…", "—"}
END_PUNCT = {"。", "？", "！", "…"}
PINYIN_PUNCT = {"。": ".", "，": ",", "？": "?", "！": "!", "、": ",", "：": ":", "；": ";",
                "“": "“", "”": "”", "…": "…", "—": "—"}
MIN_WORDS, MAX_WORDS = 3, 12
# Парные конструкции, где целевое слово по определению стоит дважды (一边…一边,
# 越…越, 又…又). В fill_blank пропуск ставится на первое вхождение, второе остаётся
# подсказкой — для таких слов это и есть учебная цель (узнать конструкцию).
REPEATABLE_TARGETS = {"一边", "越", "又"}


@dataclass
class CheckedExample:
    target: str
    tokens: list[str]
    sentence_ru: str
    sentence_cn: str = ""
    used_word_ids: list[int] = field(default_factory=list)
    pinyin: str = ""
    difficulty: int | None = None
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


def parse_line(line: str) -> tuple[str, list[str], str] | None:
    """'target<TAB>сегментированное предложение<TAB>перевод' -> части; комментарии и пустые — None."""
    if not line.strip() or line.lstrip().startswith("#"):
        return None
    parts = line.rstrip("\n").split("\t")
    if len(parts) != 3:
        raise ValueError(f"ожидалось 3 колонки через TAB: {line!r}")
    target, segmented, ru = (p.strip() for p in parts)
    return target, segmented.split(), ru


def _is_cjk(ch: str) -> bool:
    return "一" <= ch <= "鿿"


def split_words(words: list[str], vocab: dict[str, dict]) -> list[str]:
    """Соседние токены, которые вместе образуют слово базы («没 关系» при слове 没关系):
    такая разметка привязывает к предложению не те слова (关系 «отношения»)."""
    found = []
    for i in range(len(words)):
        for n in (2, 3, 4):
            chunk = words[i:i + n]
            if len(chunk) == n and "".join(chunk) in vocab:
                found.append("".join(chunk))
    return found


def join_pinyin(parts: list[str]) -> str:
    """Пиньинь предложения: слова через пробел, знаки препинания прилеплены, первая буква заглавная."""
    out = ""
    for p in parts:
        if p in PINYIN_PUNCT.values():
            out += p
        else:
            out += (" " if out else "") + p
    return out[:1].upper() + out[1:]


def check_example(target: str, tokens: list[str], sentence_ru: str, vocab: dict[str, dict],
                  doubt_words: set[str] = frozenset()) -> CheckedExample:
    """
    vocab: hanzi -> {"id", "hsk", "pinyin"} (пиньинь — уже исправленный, как на карточке).
    """
    ex = CheckedExample(target, tokens, sentence_ru, sentence_cn="".join(tokens))
    words = [t for t in tokens if t not in PUNCT_TOKENS]
    unknown = [t for t in words if t not in vocab]
    if unknown:
        ex.errors.append(f"нет в базе: {' '.join(unknown)}")
    if target not in vocab:
        ex.errors.append("целевого слова нет в базе")
    if words.count(target) != 1 and not (target in REPEATABLE_TARGETS and words.count(target) == 2):
        ex.errors.append(f"целевое слово встречается {words.count(target)} раз(а)")
    if not (MIN_WORDS <= len(words) <= MAX_WORDS):
        ex.errors.append(f"длина {len(words)} слов вне {MIN_WORDS}..{MAX_WORDS}")
    if not tokens or tokens[-1] not in END_PUNCT:
        ex.errors.append("нет знака конца предложения")
    if any(ch.isascii() and ch.isalpha() or "Ѐ" <= ch <= "ӿ" for ch in ex.sentence_cn):
        ex.errors.append("латиница/кириллица в китайском предложении")
    if not sentence_ru or any(_is_cjk(ch) for ch in sentence_ru) \
            or not any("Ѐ" <= ch <= "ӿ" for ch in sentence_ru):
        ex.errors.append("русский перевод пуст, без кириллицы или с иероглифами")
    if ex.errors:
        return ex

    level = vocab[target]["hsk"]
    above = [t for t in words if vocab[t]["hsk"] > level]
    if above:
        ex.errors.append(f"слова выше уровня цели (HSK {level}): {' '.join(above)}")
        return ex
    same = sorted({t for t in words if t != target and vocab[t]["hsk"] == level and level > 1})
    if same:
        ex.warnings.append(f"слова того же уровня: {' '.join(same)}")
    split = split_words(words, vocab)
    if split:  # «十 分» (10 минут) рядом со словом 十分 «очень» — бывает верно, решает человек
        ex.warnings.append(f"соседние токены образуют слово базы: {' '.join(split)}")
    if target in doubt_words:
        ex.warnings.append("у целевого слова спорный перевод — сверить значение в примере")

    ex.used_word_ids = [vocab[t]["id"] for t in words]
    ex.pinyin = join_pinyin([PINYIN_PUNCT[t] if t in PUNCT_TOKENS else vocab[t]["pinyin"] for t in tokens])
    ex.difficulty = max(vocab[t]["hsk"] for t in words)
    return ex


@dataclass
class CheckedDialogue:
    target: str
    a: CheckedExample
    b: CheckedExample
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


def _check_line(tokens: list[str], ru: str, vocab: dict[str, dict]) -> CheckedExample:
    """Одна реплика диалога: слова есть в базе, знак конца, русский перевод; длина 1..12."""
    ex = CheckedExample("", tokens, ru, sentence_cn="".join(tokens))
    words = [t for t in tokens if t not in PUNCT_TOKENS]
    unknown = [t for t in words if t not in vocab]
    if unknown:
        ex.errors.append(f"нет в базе: {' '.join(unknown)}")
    if not (1 <= len(words) <= MAX_WORDS):
        ex.errors.append(f"длина {len(words)} слов")
    if not tokens or tokens[-1] not in END_PUNCT:
        ex.errors.append("нет знака конца предложения")
    if not ru or any(_is_cjk(ch) for ch in ru) or not any("\u0400" <= ch <= "\u04ff" for ch in ru):
        ex.errors.append("русский перевод пуст, без кириллицы или с иероглифами")
    if not ex.errors:
        ex.used_word_ids = [vocab[t]["id"] for t in words]
        ex.pinyin = join_pinyin([PINYIN_PUNCT[t] if t in PUNCT_TOKENS else vocab[t]["pinyin"] for t in tokens])
        ex.difficulty = max(vocab[t]["hsk"] for t in words)
    return ex


def check_dialogue(target: str, a_tokens: list[str], a_ru: str, b_tokens: list[str], b_ru: str,
                   vocab: dict[str, dict]) -> CheckedDialogue:
    """Диалог из двух реплик: обе реплики проходят _check_line, целевое слово есть
    в диалоге, и ни одно слово не выше уровня цели (цель — самое «позднее» слово)."""
    a, b = _check_line(a_tokens, a_ru, vocab), _check_line(b_tokens, b_ru, vocab)
    dlg = CheckedDialogue(target, a, b, errors=[f"A: {e}" for e in a.errors] + [f"B: {e}" for e in b.errors])
    if dlg.errors:
        return dlg
    words = [t for t in a_tokens + b_tokens if t not in PUNCT_TOKENS]
    if target not in vocab or target not in words:
        dlg.errors.append("целевого слова нет в диалоге или в базе")
        return dlg
    level = vocab[target]["hsk"]
    above = [t for t in words if vocab[t]["hsk"] > level]
    if above:
        dlg.errors.append(f"слова выше уровня цели (HSK {level}): {' '.join(above)}")
    split = split_words(words, vocab)
    if split:
        dlg.warnings.append(f"соседние токены образуют слово базы: {' '.join(split)}")
    return dlg
