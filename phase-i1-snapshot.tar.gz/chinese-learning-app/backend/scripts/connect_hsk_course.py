"""
Подключение импортированных HSK 2.0 слов (уровни 1-4) к курсу.

Запуск (из backend/), после import_hsk_vocabulary.py и seed_hsk_examples.py:
    python3 scripts/connect_hsk_course.py [--dry-run]

Что делает (идемпотентно, повторный запуск ничего не портит):
  * по data/hsk_course_map.tsv (уровни 1-3) и data/hsk4_course_map.tsv
    (уровень 4) ставит слову категорию (тему курса), русский
    перевод (translation_source='reviewed_ru' для status=reviewed, иначе
    'draft_ru'; английский исходник сохраняется в translation_en и не
    перезаписывается) и, если задано, исправленный пиньинь
    многочтения (了 le, 没 méi, 吗 ma, ...; pinyin_numeric тогда обнуляется —
    он относился к неверному чтению);
  * нормализует пиньинь импортированных слов к формату рукописных
    («shí hou» -> «shíhou», «Běi jīng» -> «běijīng», «kě ài» -> «kě'ài»):
    иначе в pinyin_choice верный вариант узнаётся по формату записи;
  * создаёт строки progress (слово становится видимым для курса);
  * пересчитывает раскладку всех слов курса по модулям тема × уровень
    (modules_repo.sync_course_modules(reassign=True)).
Слово из базы, которого нет в карте, не трогается и остаётся «спящим».
"""

import argparse
import sqlite3
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
MAP_PATH = DATA_DIR / "hsk_course_map.tsv"            # HSK 2.0, уровни 1-3
HSK4_MAP_PATH = DATA_DIR / "hsk4_course_map.tsv"      # HSK 2.0, уровень 4
MAP_PATHS = (MAP_PATH, HSK4_MAP_PATH)
VOWEL_START = set("aoeāáǎàōóǒòēéěè")
# translation_source подключённых слов: reviewed_ru — перевод прошёл повторную
# проверку (status=reviewed в карте); draft_ru — черновик или спорный (doubt: …).
REVIEWED_SOURCE = "reviewed_ru"
DRAFT_SOURCE = "draft_ru"


def load_course_map(path: Path = MAP_PATH) -> dict[str, dict]:
    result = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        hanzi, category, ru, override, status = (line.split("\t") + [""] * 5)[:5]
        status = status.strip()
        result[hanzi] = {"category": category.strip(), "translation": ru.strip(),
                         "pinyin": override.strip() or None,
                         "source": REVIEWED_SOURCE if status == "reviewed" else DRAFT_SOURCE,
                         "doubt": status[len("doubt:"):].strip() if status.startswith("doubt:") else None}
    return result


def load_full_course_map(paths: tuple[Path, ...] = MAP_PATHS) -> dict[str, dict]:
    """Все карты курса; один hanzi в двух картах — ошибка данных (не молча перезаписываем)."""
    result: dict[str, dict] = {}
    for path in paths:
        part = load_course_map(path)
        clash = set(part) & set(result)
        if clash:
            raise ValueError(f"{path.name}: слова уже есть в другой карте: {sorted(clash)[:10]}")
        result.update(part)
    return result


def normalize_pinyin(pinyin: str) -> str:
    """Слоги слитно, нижний регистр, апостроф перед слогом на a/o/e (kě'ài)."""
    syllables = [s for s in pinyin.lower().split() if s]
    out = ""
    for s in syllables:
        if out and s[0] in VOWEL_START:
            out += "'"
        out += s
    return out


def connect(conn, course_map: dict[str, dict], today_iso: str, user_id: int) -> dict:
    from app.repositories.modules_repo import sync_course_modules

    rows = conn.execute(
        """SELECT w.id, w.hanzi, w.pinyin, w.translation, w.translation_en, w.translation_source,
                  p.word_id AS has_progress
           FROM words w LEFT JOIN progress p ON p.word_id = w.id
           WHERE w.hsk_version = '2.0'"""
    ).fetchall()
    updated, progress_added, unmapped = 0, 0, []
    for r in rows:
        entry = course_map.get(r["hanzi"])
        if entry is None:
            unmapped.append(r["hanzi"])
            continue
        # английский берётся из translation только при первом подключении
        # (translation_source ещё NULL), дальше translation_en не трогается
        english = r["translation_en"] or (r["translation"] if r["translation_source"] is None else None)
        pinyin = entry["pinyin"] or normalize_pinyin(r["pinyin"])
        conn.execute(
            """UPDATE words SET category = ?, translation = ?, translation_en = ?,
               translation_source = ?, pinyin = ?,
               pinyin_numeric = CASE WHEN ? THEN NULL ELSE pinyin_numeric END
               WHERE id = ?""",
            (entry["category"], entry["translation"], english, entry.get("source", DRAFT_SOURCE),
             pinyin, int(bool(entry["pinyin"])), r["id"]),
        )
        updated += 1
        if r["has_progress"] is None:
            conn.execute(
                """INSERT INTO progress (word_id, user_id, repetitions, ease_factor, interval_days, due_date)
                   VALUES (?, ?, 0, 2.5, 0, ?)""",
                (r["id"], user_id, today_iso),
            )
            progress_added += 1
    modules = sync_course_modules(conn, reassign=True)
    return {"updated": updated, "progress_added": progress_added, "unmapped": unmapped, "modules": modules}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from app.config import DB_PATH
    from app.db import init_db
    from app.utils import today_date

    init_db()
    course_map = load_full_course_map()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    user_id = conn.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()[0]
    result = connect(conn, course_map, today_date().isoformat(), user_id)

    per_level = Counter()
    for (category, level), module_id in result["modules"].items():
        n = conn.execute("SELECT COUNT(*) FROM words WHERE module_id = ?", (module_id,)).fetchone()[0]
        per_level[level] += n
    in_course = conn.execute("SELECT COUNT(*) FROM words WHERE module_id IS NOT NULL").fetchone()[0]
    total = conn.execute("SELECT COUNT(*) FROM words").fetchone()[0]
    print(f"Обновлено HSK-слов: {result['updated']}, новых строк progress: {result['progress_added']}")
    sources = dict(conn.execute(
        "SELECT translation_source, COUNT(*) FROM words WHERE hsk_version = '2.0' GROUP BY 1").fetchall())
    doubts = [h for h, e in course_map.items() if e["doubt"]]
    print(f"Переводы: {sources}; спорных (doubt): {len(doubts)} {doubts}")
    print(f"Без записи в карте (остались вне курса): {len(result['unmapped'])} {result['unmapped'][:20]}")
    print(f"Слов в курсе: {in_course} из {total}; модулей: {len(result['modules'])}; по уровням: {dict(sorted(per_level.items()))}")

    if args.dry_run:
        conn.rollback()
        print("--dry-run: изменения откатены.")
    else:
        conn.commit()
    conn.close()


if __name__ == "__main__":
    main()
