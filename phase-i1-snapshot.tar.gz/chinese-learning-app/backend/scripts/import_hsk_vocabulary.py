"""
Импорт HSK vocabulary из drkameleon/complete-hsk-vocabulary (MIT) — старый
стандарт (HSK 2.0, теги old-N). Phase B импортировала уровни 1-3; с 2026-10-04
по умолчанию импортируются уровни 1-4 (--levels).

Запуск (из backend/):
    python3 scripts/import_hsk_vocabulary.py /path/to/complete.json [--levels 1-4] [--dry-run]

Идемпотентность: слово, чей hanzi уже есть в базе, пропускается (не
перезаписывается и не дублируется), поэтому повторный запуск, а также запуск
с --levels 1-4 поверх уже импортированных 1-3, добавляет только недостающие
слова. Существующие id, переводы и прогресс не меняются. Отчёт (без списка
вставляемых слов) пишется рядом с датасетом и, с --report, по указанному пути.

Правила (см. отчёт Phase B в разговоре — все решения объяснены там же):
  * category НЕ придумывается — импортированные слова получают NULL;
  * hsk_version='2.0' для этой партии — колонка допускает и другие значения
    в будущем (HSK 3.0 и т.д.), это не единственный поддерживаемый стандарт;
  * example_cn/example_ru НЕ заполняются — в датасете нет примеров, выдумывать
    их здесь нельзя (Phase C — отдельная инфраструктура примеров);
  * слово, чей hanzi уже есть в базе, пропускается — рукописная версия
    (с примером/категорией/компонентами) остаётся авторитетной;
  * progress-строка НЕ создаётся — слово невидимо для planner и профильной
    статистики (словарь видит сразу), пока scripts/connect_hsk_course.py не
    подключит его к курсу (тема, RU-перевод, progress, модуль).
"""

import argparse
import json
import sqlite3
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

HSK_VERSION = "2.0"
DEFAULT_LEVELS = (1, 2, 3, 4)
TARGET_TAGS = {f"old-{n}": n for n in DEFAULT_LEVELS}


# Исправления уровня, где датасет доказуемо ошибается. У этих слов в HSK 2.0 две
# записи списка — уровень 2 (等 «ждать», 对 «правильный», 过 частица опыта guo) и
# уровень 4 (等 «и т. д.», 对 «к, по отношению к», 过 «проходить»); датасет склеил их
# в одну запись с тегом old-4, повторённым дважды (['old-4', 'old-4']), и потерял
# old-2. Сверено со списком HSK 2 AllSet Learning (resources.allsetlearning.com/
# chinese/vocabulary/HSK_2_Vocabulary). Другие слова с повторённым тегом (得, 还, 长,
# 只) уже стоят на своём раннем уровне — их не трогаем.
LEVEL_CORRECTIONS: dict[str, int] = {"等": 2, "对": 2, "过": 2}


def parse_levels(spec: str) -> tuple[int, ...]:
    """'1-4' -> (1, 2, 3, 4); '4' -> (4,); '1,2' -> (1, 2). Только 1..6 (HSK 2.0)."""
    levels: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            lo, hi = (int(x) for x in part.split("-", 1))
            levels |= set(range(lo, hi + 1))
        elif part:
            levels.add(int(part))
    if not levels or not all(1 <= n <= 6 for n in levels):
        raise ValueError(f"Уровни HSK 2.0 — 1..6, получено: {spec!r}")
    return tuple(sorted(levels))


def pick_hsk_level(levels: list[str], targets: dict[str, int] | None = None) -> int | None:
    """Самый ранний уровень old-N слова (консервативнее). Уровень считается по ВСЕМ
    тегам old-*, а не только по целевым: слово old-2 + old-4 — это слово HSK2, и
    импорт «только уровня 4» не должен вставить его как HSK4."""
    targets = TARGET_TAGS if targets is None else targets
    all_old = [int(tag[4:]) for tag in levels if tag.startswith("old-") and tag[4:].isdigit()]
    if not all_old:
        return None
    level = min(all_old)
    return level if f"old-{level}" in targets else None


def _pick_primary_form(forms: list[dict]) -> dict:
    """
    forms[0] не всегда основной смысл: у части слов первая форма — редкое
    прочтение (фамилия, архаичный вариант, справочная ссылка "used in ..."),
    а бытовое значение стоит дальше. Проверено на реальных данных (см. отчёт
    Phase B): форма с БОЛЬШИМ числом meanings почти всегда и есть основная
    (春: 1/1/7 знач. -> форма с 7 действительно "spring"; 东,也,从,关 — то же
    самое). Сначала откидываем формы-однозначно-фамилии/варианты, затем среди
    оставшихся берём самую "богатую" по числу значений.
    Остаётся нерешаемый случай без сигнала в датасете: 告诉 — форма 0 "press
    charges" и форма 1 "to tell" обе содержат ровно 1 meanings-элемент, не
    различить программно. Такие слова просто ПОПАДАЮТ в
    ambiguous_needs_manual_review, а не молча считаются корректными.
    """
    def is_reference_only(f):
        meanings = f.get("meanings") or []
        return len(meanings) == 1 and (
            meanings[0].lower().startswith("surname ") or "variant of" in meanings[0].lower()
            or meanings[0].lower().startswith("used in ")
            or meanings[0].lower().startswith(("(classical)", "(archaic)"))
        )

    candidates = [f for f in forms if f.get("meanings") and not is_reference_only(f)] or forms
    # Имя собственное (пиньинь с заглавной: 夏 Xià «династия Ся», 西 Xī «Запад, Испания»)
    # не основное значение, если у слова есть нарицательная форма (xià «лето», xī «запад»).
    common = [f for f in candidates if not _form_pinyin(f)[:1].isupper()]
    return max(common or candidates, key=lambda f: len(f.get("meanings") or []))


def _form_pinyin(form: dict) -> str:
    return ((form.get("transcriptions") or {}).get("pinyin") or "").strip()


def entry_levels(entry: dict) -> list[str]:
    """Теги уровня с учётом LEVEL_CORRECTIONS (исправленный уровень добавляется к тегам)."""
    tags = list(entry.get("level", []))
    fix = LEVEL_CORRECTIONS.get(entry.get("simplified", ""))
    if fix is not None:
        tags.append(f"old-{fix}")
    return tags


def normalize_entry(entry: dict, targets: dict[str, int] | None = None) -> dict | None:
    level = pick_hsk_level(entry_levels(entry), targets)
    if level is None:
        return None
    forms = entry.get("forms") or []
    if not forms:
        return None
    first = _pick_primary_form(forms)
    meanings = first.get("meanings") or []
    pinyin = (first.get("transcriptions") or {}).get("pinyin")
    if not entry.get("simplified") or not pinyin or not meanings:
        return None
    return {
        "hanzi": entry["simplified"],
        "pinyin": pinyin,
        "pinyin_numeric": (first.get("transcriptions") or {}).get("numeric"),
        "translation": "; ".join(meanings),
        "traditional": first.get("traditional"),
        "part_of_speech": "/".join(entry.get("pos") or []) or None,
        "hsk": level,
        "frequency": entry.get("frequency"),
        "forms_count": len(forms),
    }


def build_report(entries: list[dict], existing_hanzi: set[str], levels: tuple[int, ...] = DEFAULT_LEVELS) -> dict:
    targets = {f"old-{n}": n for n in levels}
    normalized = [normalize_entry(e, targets) for e in entries]
    candidates = [n for n in normalized if n is not None]
    skipped_no_old_tag = sum(1 for e in entries if pick_hsk_level(entry_levels(e), targets) is None)
    skipped_bad_fields = sum(
        1 for e in entries
        if pick_hsk_level(entry_levels(e), targets) is not None and normalize_entry(e, targets) is None
    )

    by_hanzi: dict[str, list[dict]] = {}
    for c in candidates:
        by_hanzi.setdefault(c["hanzi"], []).append(c)
    dup_within_dataset = {h: v for h, v in by_hanzi.items() if len(v) > 1}
    multi_form = sum(1 for c in candidates if c["forms_count"] > 1)

    already_in_db = [c for c in candidates if c["hanzi"] in existing_hanzi]
    to_insert = {}  # hanzi -> запись; при дублях внутри датасета берём самый низкий уровень
    for c in candidates:
        if c["hanzi"] in existing_hanzi:
            continue
        cur = to_insert.get(c["hanzi"])
        if cur is None or c["hsk"] < cur["hsk"]:
            to_insert[c["hanzi"]] = c

    ambiguous = sorted((c["hanzi"], c["translation"]) for c in to_insert.values() if c["forms_count"] > 1)

    return {
        "hsk_version": HSK_VERSION,
        "level_corrections": LEVEL_CORRECTIONS,
        "levels": list(levels),
        "total_dataset_entries": len(entries),
        "skipped_not_target_levels": skipped_no_old_tag,
        "skipped_missing_required_fields": skipped_bad_fields,
        "candidates_target_levels": len(candidates),
        "candidates_by_level": dict(sorted(Counter(c["hsk"] for c in candidates).items())),
        "duplicates_within_dataset": len(dup_within_dataset),
        "duplicate_examples": list(dup_within_dataset.items())[:10],
        "entries_with_multiple_forms": multi_form,
        "ambiguous_needs_manual_review": ambiguous,
        "already_in_our_db_kept_handwritten": len(already_in_db),
        "already_in_our_db_examples": sorted(c["hanzi"] for c in already_in_db)[:20],
        "to_insert": list(to_insert.values()),
        "by_level": dict(sorted(Counter(c["hsk"] for c in to_insert.values()).items())),
    }


def insert_words(db_path: Path, to_insert: list[dict]) -> tuple[int, int, int]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executemany(
        """INSERT INTO words (hanzi, pinyin, pinyin_numeric, translation, traditional,
           part_of_speech, hsk, hsk_version, frequency, category)
           SELECT :hanzi, :pinyin, :pinyin_numeric, :translation, :traditional,
                  :part_of_speech, :hsk, '2.0', :frequency, NULL
           WHERE NOT EXISTS (SELECT 1 FROM words WHERE hanzi = :hanzi)""",
        to_insert,
    )
    n = conn.execute("SELECT COUNT(*) FROM words").fetchone()[0]

    # Новый словарь мог закрыть то, чего не хватало старым примерам при
    # первой миграции (Phase C) — пробуем разобрать needs_review ещё раз.
    from app.db import reparse_examples_needing_review
    resolved, still_pending = reparse_examples_needing_review(conn)

    conn.commit()
    conn.close()
    return n, resolved, still_pending


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=Path)
    parser.add_argument("--levels", default="1-4", help="уровни HSK 2.0, например 1-4 или 4")
    parser.add_argument("--report", type=Path, help="дополнительно сохранить отчёт по этому пути")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    levels = parse_levels(args.levels)

    from app.config import DB_PATH
    from app.db import init_db

    init_db()  # гарантируем, что схема Phase B уже применена

    entries = json.loads(args.dataset.read_text(encoding="utf-8"))
    conn = sqlite3.connect(DB_PATH)
    existing_hanzi = {r[0] for r in conn.execute("SELECT hanzi FROM words")}
    conn.close()

    report = build_report(entries, existing_hanzi, levels)

    print(f"Стандарт: HSK {HSK_VERSION}, уровни {list(levels)}")
    print(f"Всего записей в датасете: {report['total_dataset_entries']}")
    print(f"Вне выбранных уровней (пропущены): {report['skipped_not_target_levels']}")
    print(f"В выбранных уровнях, но без pinyin/meanings/simplified (пропущены): {report['skipped_missing_required_fields']}")
    print(f"Кандидатов: {report['candidates_target_levels']} {report['candidates_by_level']}")
    print(f"  из них с >1 формой (омографы, взята первая): {report['entries_with_multiple_forms']}")
    print(f"  дублей simplified внутри датасета: {report['duplicates_within_dataset']}")
    print(f"Уже есть в нашей базе (оставлена рукописная версия, не тронуты): {report['already_in_our_db_kept_handwritten']}")
    print(f"Будет вставлено новых слов: {len(report['to_insert'])}")
    print(f"  по уровням: {report['by_level']}")
    print(f"  многоформенных слов, требующих ручной проверки значения: {len(report['ambiguous_needs_manual_review'])}")
    for hanzi, translation in report["ambiguous_needs_manual_review"][:15]:
        print(f"    {hanzi}: {translation}")

    report_path = args.dataset.parent / "hsk_import_report.json"
    with_out_words = {k: v for k, v in report.items() if k != "to_insert"}
    report_json = json.dumps(with_out_words, ensure_ascii=False, indent=2)
    report_path.write_text(report_json, encoding="utf-8")
    print(f"\nПолный отчёт сохранён: {report_path}")
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(report_json, encoding="utf-8")
        print(f"Копия отчёта: {args.report}")

    if args.dry_run:
        print("\n--dry-run: запись в БД не производилась.")
        return report

    total = insert_words(DB_PATH, report["to_insert"])
    n_words, resolved, still_pending = total
    print(f"\nВставлено. Итого слов в базе: {n_words}")
    print(f"Повторный разбор examples.needs_review новым словарём: разобрано {resolved}, всё ещё не разобрано {still_pending}")
    return report


if __name__ == "__main__":
    main()
