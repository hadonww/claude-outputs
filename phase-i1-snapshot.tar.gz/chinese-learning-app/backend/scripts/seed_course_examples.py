"""
Примеры предложений курса из размеченных файлов data/examples/hsk*.tsv.

Запуск (из backend/), ПОСЛЕ import_hsk_vocabulary.py и connect_hsk_course.py:
    python3 scripts/seed_course_examples.py [--dry-run]

Формат строки файла: target<TAB>пословная разметка<TAB>русский перевод, например
    锻炼	我 每天 早上 锻炼 身体 。	Я каждое утро делаю зарядку.

Каждый пример проходит scripts/example_checks.check_example (все слова есть в базе,
цель ровно один раз, уровень слов не выше уровня цели, длина, пунктуация, русский
перевод). Не прошедшие — печатаются и НЕ вставляются. Пиньинь собирается из
пиньиня слов (словарные тоны, без тон-сандхи — как на карточках), used_word_ids —
из разметки, difficulty — максимальный HSK-уровень слов примера.

Идемпотентно: пример с тем же target и тем же предложением не вставляется второй
раз; существующие примеры не меняются и не удаляются. Примеры написаны Claude и
носителем не проверены: source = 'course_handwritten', а список для ручной
проверки — scripts/reports/examples_review_list.tsv.
"""

import argparse
import json
import sqlite3
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

EXAMPLES_DIR = Path(__file__).resolve().parent.parent / "data" / "examples"
REPORTS_DIR = Path(__file__).resolve().parent / "reports"
SOURCE = "course_handwritten"


def load_vocab(conn) -> dict[str, dict]:
    from scripts.connect_hsk_course import load_full_course_map, normalize_pinyin

    overrides = {h: e["pinyin"] for h, e in load_full_course_map().items() if e["pinyin"]}
    vocab = {}
    for wid, hanzi, pinyin, hsk, version in conn.execute(
            "SELECT id, hanzi, pinyin, hsk, hsk_version FROM words"):
        effective = overrides.get(hanzi) or (normalize_pinyin(pinyin) if version == "2.0" else pinyin)
        vocab[hanzi] = {"id": wid, "hsk": hsk, "pinyin": effective}
    return vocab


def load_examples(directory: Path = EXAMPLES_DIR) -> list[tuple[str, list[str], str, str]]:
    from scripts.example_checks import parse_line

    rows = []
    for path in sorted(directory.glob("hsk*.tsv")):
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            parsed = parse_line(line)
            if parsed:
                rows.append((*parsed, f"{path.name}:{n}"))
    return rows


def doubt_words() -> set[str]:
    from scripts.connect_hsk_course import load_full_course_map

    return {h for h, e in load_full_course_map().items() if e["doubt"]}


def check_all(conn) -> list:
    from scripts.example_checks import check_example

    vocab, doubts = load_vocab(conn), doubt_words()
    checked = []
    for target, tokens, ru, where in load_examples():
        ex = check_example(target, tokens, ru, vocab, doubts)
        ex.where = where
        checked.append(ex)
    return checked


def seed(conn, checked) -> dict:
    inserted = duplicates = 0
    for ex in checked:
        if not ex.ok:
            continue
        target_id = conn.execute("SELECT id FROM words WHERE hanzi = ?", (ex.target,)).fetchone()[0]
        if conn.execute("SELECT 1 FROM examples WHERE target_word_id = ? AND sentence_cn = ?",
                        (target_id, ex.sentence_cn)).fetchone():
            duplicates += 1
            continue
        conn.execute(
            """INSERT INTO examples (target_word_id, sentence_cn, sentence_ru, pinyin, used_word_ids,
               difficulty, source, needs_review) VALUES (?, ?, ?, ?, ?, ?, ?, 0)""",
            (target_id, ex.sentence_cn, ex.sentence_ru, ex.pinyin, json.dumps(ex.used_word_ids),
             ex.difficulty, SOURCE))
        inserted += 1
    return {"inserted": inserted, "duplicates": duplicates}


def coverage(conn) -> dict:
    """Сколько слов курса по уровням имеют хотя бы один пригодный пример (needs_review = 0)."""
    rows = conn.execute(
        """SELECT w.hsk, COUNT(*) AS total,
                  SUM(EXISTS(SELECT 1 FROM examples e WHERE e.target_word_id = w.id AND e.needs_review = 0))
           FROM words w WHERE w.module_id IS NOT NULL GROUP BY w.hsk ORDER BY w.hsk""").fetchall()
    return {f"hsk{lvl}": {"words": total, "with_example": int(n or 0)} for lvl, total, n in rows}


def write_review_list(conn, checked, path: Path) -> int:
    """Список ручной проверки: примеры с предупреждениями + старые needs_review."""
    lines = ["# where\ttarget\tsentence_cn\tsentence_ru\treason"]
    for ex in checked:
        if ex.ok and ex.warnings:
            lines.append("\t".join([ex.where, ex.target, ex.sentence_cn, ex.sentence_ru, "; ".join(ex.warnings)]))
    for hanzi, cn, ru in conn.execute(
            """SELECT w.hanzi, e.sentence_cn, e.sentence_ru FROM examples e JOIN words w ON w.id = e.target_word_id
               WHERE e.needs_review = 1 ORDER BY e.id"""):
        lines.append(f"db:needs_review\t{hanzi}\t{cn}\t{ru}\tстарый пример, снят с использования движком")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(lines) - 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from app.config import DB_PATH
    from app.db import init_db

    init_db()
    conn = sqlite3.connect(DB_PATH)
    checked = check_all(conn)
    rejected = [ex for ex in checked if not ex.ok]
    result = seed(conn, checked)
    cov = coverage(conn)
    review_n = write_review_list(conn, checked, REPORTS_DIR / "examples_review_list.tsv")
    by_level = Counter(ex.difficulty for ex in checked if ex.ok)

    print(f"Примеров в файлах: {len(checked)}; принято проверками: {len(checked) - len(rejected)}; "
          f"вставлено: {result['inserted']}; уже были: {result['duplicates']}")
    print(f"Сложность (макс. уровень слов): {dict(sorted(by_level.items()))}")
    print(f"Покрытие слов курса примерами: {cov}")
    print(f"Список ручной проверки: {review_n} строк -> scripts/reports/examples_review_list.tsv")
    print(f"Отклонено: {len(rejected)}")
    for ex in rejected:
        print(f"  {ex.where} {ex.target} | {' '.join(ex.tokens)} -> {'; '.join(ex.errors)}")

    if args.dry_run:
        conn.rollback()
        print("--dry-run: изменения откатены.")
    else:
        conn.commit()
    conn.close()
    return rejected


if __name__ == "__main__":
    main()
