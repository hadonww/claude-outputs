"""
Полная база курса с нуля — та же последовательность, что в CLAUDE.md, одной функцией
(для проверок курса, симуляций и тестов; рабочую app.db не трогает):

    init_db → импорт HSK 2.0 из датасета → рукописные примеры → подключение к курсу
    → примеры data/examples → мини-диалоги data/dialogues.tsv → init_db (исправления контента)

    python3 scripts/build_course_db.py <путь>/complete.json /tmp/course.db [--levels 1-4]

Датасет — drkameleon/complete-hsk-vocabulary (MIT), коммит 7ac65bf. Для тестов есть его
выборка уровня 1: tests/fixtures/hsk12_dataset.json (уровни 1–2).
"""

import argparse
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def build(db_path: Path, dataset: Path, levels: str = "1-4") -> Path:
    import app.config as cfg
    import app.db as dbm
    from app.utils import today_date
    from scripts import seed_course_examples, seed_dialogues, seed_hsk_examples
    from scripts.connect_hsk_course import connect, load_full_course_map
    from scripts.import_hsk_vocabulary import build_report, insert_words, parse_levels

    db_path = Path(db_path)
    db_path.unlink(missing_ok=True)
    cfg.DB_PATH = db_path
    dbm.DB_PATH = db_path
    dbm.init_db()

    entries = json.loads(Path(dataset).read_text(encoding="utf-8"))
    conn = sqlite3.connect(db_path)
    existing = {r[0] for r in conn.execute("SELECT hanzi FROM words")}
    conn.close()
    insert_words(db_path, build_report(entries, existing, parse_levels(levels))["to_insert"])

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    seed_hsk_examples.seed_examples(conn)
    user_id = conn.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()[0]
    connect(conn, load_full_course_map(), today_date().isoformat(), user_id)
    seed_course_examples.seed(conn, seed_course_examples.check_all(conn))
    seed_dialogues.seed(conn, seed_dialogues.check_all(conn))
    conn.commit()
    conn.close()
    dbm.init_db()   # исправления контента и пересборка пиньиня примеров по итоговым словам
    return db_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=Path)
    parser.add_argument("db", type=Path)
    parser.add_argument("--levels", default="1-4")
    args = parser.parse_args()
    path = build(args.db, args.dataset, args.levels)
    conn = sqlite3.connect(path)
    print(f"{path}: слов {conn.execute('SELECT COUNT(*) FROM words').fetchone()[0]}, "
          f"примеров {conn.execute('SELECT COUNT(*) FROM examples WHERE needs_review = 0').fetchone()[0]}, "
          f"диалогов {conn.execute('SELECT COUNT(*) FROM dialogues').fetchone()[0]}")


if __name__ == "__main__":
    main()
