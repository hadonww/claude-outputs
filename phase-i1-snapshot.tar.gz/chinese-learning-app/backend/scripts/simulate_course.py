"""
Симуляция прохождения курса (инструмент разработчика, БД не трогает).

Копирует app.db во временный файл и проходит курс через настоящие сервисы
(lesson_service) так же, как это делает фронтенд: план урока → ответы на шаги →
завершение. Ученик детерминированный: отвечает верно с вероятностью --accuracy
(Random(seed)). Дата подменяется, чтобы SRS-повторы реально наступали.

Запуск (из backend/, на полной БД):
    python3 scripts/simulate_course.py --days 30 --lessons-per-day 2 [--accuracy 0.85]

Отчёт: какие модули/уровни пройдены, распределение типов упражнений, сколько
новых/повторений в уроке, и нарушения known-vocabulary guard (шаг с предложением,
где есть слово, не известное ученику к этому моменту) — их должно быть 0.
"""

import argparse
import json
import shutil
import sqlite3
import sys
import tempfile
from collections import Counter
from datetime import date, timedelta
from pathlib import Path
from random import Random

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))



def _patch_today(day: date):
    import app.services.learning_service as ls
    import app.services.lesson_service as les
    import app.services.profile_service as ps
    import app.services.statistics_service as ss
    from app import utils

    for mod in (utils, ls, les, ps, ss):
        mod.today_date = lambda d=day: d


def _answer(step: dict, correct: bool):
    """Ответ симулированного ученика: верный или заведомо неверный."""
    p = step.get("payload") or {}
    t = step["type"]
    if t == "introduction":
        return None
    if t == "matching":
        pairs = list(p["answers"])
        return {"pairs": pairs if correct else [pairs[1], pairs[0], *pairs[2:]]}
    if t == "tone_choice" and "syllables" in p:
        tones = [p["answers"][i] for i, s in enumerate(p["syllables"]) if s["tested"]]
        return {"tones": tones if correct else [tones[0] % 4 + 1, *tones[1:]]}
    if "answer_index" in p:
        n = len(p["options"])
        return p["answer_index"] if correct else (p["answer_index"] + 1) % n
    if t == "sentence_order":
        return p["answer_tokens"] if correct else list(reversed(p["answer_tokens"]))
    if t == "pinyin_input":
        return p["answer"] if correct else "xx"
    if t == "translation_build":
        return p["answers"][0] if correct else list(reversed(p["answers"][0]))
    if t == "speaking":
        return {"skipped": True}  # без провайдера распознавания речь не оценивается
    if t == "recall":
        return 2 if correct else 0
    if t == "handwriting":
        return {"mistakes": 0 if correct else 4}
    return None


def _known_ids(conn) -> set[int]:
    return {r[0] for r in conn.execute(
        "SELECT word_id FROM progress WHERE repetitions > 0 OR total_attempts > 0")}


def run(db_src: Path, days: int, per_day: int, accuracy: float, seed: int, start: date,
        keep: Path | None = None) -> dict:
    tmp = keep or Path(tempfile.mkdtemp()) / "sim.db"
    shutil.copy(db_src, tmp)
    import app.config as cfg
    import app.db as dbm

    cfg.DB_PATH = tmp
    dbm.DB_PATH = tmp
    dbm.init_db()  # миграции (например, таблица lesson_sessions) на копии
    from app.db import get_db
    from app.repositories import lesson_sessions_repo
    from app.services import learning_path_service, lesson_service

    rng = Random(seed)
    types, violations, lessons, accuracies = Counter(), [], [], []
    retries = 0
    for d in range(days):
        day = start + timedelta(days=d)
        _patch_today(day)
        for _ in range(per_day):
            with get_db() as conn:
                path = learning_path_service.get_learning_path(conn)
                module_id = path["recommended_module_id"]
                if module_id is None:
                    break
                plan = lesson_service.start_lesson(conn, module_id)
                sid = plan["session_id"]
                known = _known_ids(conn) | {w["id"] for w in plan["review_words"]}
                introduced: set[int] = set()
                i = 0
                while True:
                    steps = lesson_sessions_repo.get(conn, sid)["steps"]
                    if i >= len(steps):
                        break
                    step = steps[i]
                    types[step["type"]] += 1
                    used = (step.get("payload") or {}).get("used_word_ids") or []
                    bad = [w for w in used if w != step["word_id"] and w not in known and w not in introduced]
                    if bad:
                        violations.append({"day": d, "module": module_id, "type": step["type"],
                                           "word": step["word_id"], "unknown": bad})
                    if step["type"] == "introduction":
                        introduced.add(step["word_id"])
                    res = lesson_service.record_session_attempt(
                        conn, sid, i, _answer(step, rng.random() < accuracy))
                    retries += bool(res.get("appended_step"))
                    i += 1
                summary = lesson_service.complete_session(conn, sid)
                accuracies.append(summary["accuracy"]["percent"])
                lessons.append({"day": d, "module": module_id, "level": plan["module"]["hsk_level"],
                                "steps": len(plan["steps"]), "new": len(plan["new_words"]),
                                "review": len(plan["review_words"])})
    with get_db() as conn:
        path = learning_path_service.get_learning_path(conn)
        done = Counter(m["hsk_level"] for m in path["modules"] if m["status"] == "completed")
        states = conn.execute(
            """SELECT SUM(repetitions = 0 AND total_attempts = 0), SUM(repetitions BETWEEN 1 AND 2),
                      SUM(repetitions > 2 AND interval_days < 21), SUM(repetitions > 2 AND interval_days >= 21)
               FROM progress""").fetchone()
    return {
        "lessons": len(lessons),
        "levels_reached": dict(Counter(lesson["level"] for lesson in lessons)),
        "completed_modules_by_level": dict(sorted(done.items())),
        "avg_steps": round(sum(lesson["steps"] for lesson in lessons) / max(1, len(lessons)), 1),
        "avg_new": round(sum(lesson["new"] for lesson in lessons) / max(1, len(lessons)), 2),
        "avg_review": round(sum(lesson["review"] for lesson in lessons) / max(1, len(lessons)), 2),
        "step_types": dict(types.most_common()),
        "retry_steps": retries,
        "avg_lesson_accuracy": round(sum(a for a in accuracies if a is not None)
                                     / max(1, sum(1 for a in accuracies if a is not None)), 1),
        "guard_violations": len(violations),
        "violation_examples": violations[:5],
        "word_states": dict(zip(("new", "learning", "review", "mastered"), states, strict=True)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=30)
    parser.add_argument("--lessons-per-day", type=int, default=2)
    parser.add_argument("--accuracy", type=float, default=0.85)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--start", default="2026-01-05")
    parser.add_argument("--db", type=Path, default=None)
    parser.add_argument("--keep", type=Path, default=None, help="сохранить итоговую БД по этому пути (для скриншотов)")
    parser.add_argument("--skip-to-level", type=int, default=None,
                        help="считать все слова уровней ниже этого уже изученными (проверка HSK 3/4)")
    args = parser.parse_args()

    from app.config import DB_PATH

    src = args.db or DB_PATH
    if args.skip_to_level:
        tmp = Path(tempfile.mkdtemp()) / "skip.db"
        shutil.copy(src, tmp)
        conn = sqlite3.connect(tmp)
        conn.execute(
            """UPDATE progress SET repetitions = 3, interval_days = 30, total_attempts = 3, total_correct = 3,
               due_date = '2099-01-01', last_reviewed = ? WHERE word_id IN
               (SELECT w.id FROM words w JOIN modules m ON m.id = w.module_id WHERE m.hsk_level < ?)""",
            (args.start, args.skip_to_level))
        conn.commit()
        conn.close()
        src = tmp
    report = run(Path(src), args.days, args.lessons_per_day, args.accuracy, args.seed,
                 date.fromisoformat(args.start), args.keep)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
