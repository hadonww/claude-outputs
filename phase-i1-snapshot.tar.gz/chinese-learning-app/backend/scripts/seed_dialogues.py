"""
Мини-диалоги из data/dialogues.tsv (запуск из backend/, после connect_hsk_course.py):
    python3 scripts/seed_dialogues.py [--dry-run]

Формат строки: target<TAB>A пословно<TAB>перевод A<TAB>B пословно<TAB>перевод B.
Проверки — scripts/example_checks.check_dialogue; не прошедшие печатаются и не
вставляются. Идемпотентно: диалог с тем же target и репликами не дублируется.
Написаны Claude, носителем не проверены (source = 'course_handwritten').
"""

import argparse
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

DIALOGUES_PATH = Path(__file__).resolve().parent.parent / "data" / "dialogues.tsv"


def load_dialogues(path: Path = DIALOGUES_PATH) -> list[tuple]:
    rows = []
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip() or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) != 5:
            raise ValueError(f"{path.name}:{n}: ожидалось 5 колонок")
        target, a, a_ru, b, b_ru = (p.strip() for p in parts)
        rows.append((target, a.split(), a_ru, b.split(), b_ru, f"{path.name}:{n}"))
    return rows


def check_all(conn) -> list:
    from scripts.example_checks import check_dialogue
    from scripts.seed_course_examples import load_vocab

    vocab = load_vocab(conn)
    checked = []
    for target, a, a_ru, b, b_ru, where in load_dialogues():
        dlg = check_dialogue(target, a, a_ru, b, b_ru, vocab)
        dlg.where = where
        dlg.target_id = vocab.get(target, {}).get("id")
        checked.append(dlg)
    return checked


def seed(conn, checked) -> int:
    inserted = 0
    for d in checked:
        if not d.ok:
            continue
        if conn.execute("SELECT 1 FROM dialogues WHERE target_word_id = ? AND line_a_cn = ? AND line_b_cn = ?",
                        (d.target_id, d.a.sentence_cn, d.b.sentence_cn)).fetchone():
            continue
        conn.execute(
            """INSERT INTO dialogues (target_word_id, line_a_cn, line_a_ru, line_a_pinyin, line_b_cn, line_b_ru,
               line_b_pinyin, used_word_ids, difficulty, source)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'course_handwritten')""",
            (d.target_id, d.a.sentence_cn, d.a.sentence_ru, d.a.pinyin, d.b.sentence_cn, d.b.sentence_ru,
             d.b.pinyin, json.dumps(d.a.used_word_ids + d.b.used_word_ids), max(d.a.difficulty, d.b.difficulty)))
        inserted += 1
    return inserted


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from app.config import DB_PATH
    from app.db import init_db

    init_db()
    conn = sqlite3.connect(DB_PATH)
    checked = check_all(conn)
    rejected = [d for d in checked if not d.ok]
    inserted = seed(conn, checked)
    print(f"Диалогов в файле: {len(checked)}; вставлено: {inserted}; отклонено: {len(rejected)}")
    for d in rejected:
        print(f"  {d.where} {d.target}: {'; '.join(d.errors)}")
    for d in checked:
        if d.ok and d.warnings:
            print(f"  (проверить) {d.where} {d.target}: {'; '.join(d.warnings)}")
    if args.dry_run:
        conn.rollback()
        print("--dry-run: изменения откатены.")
    else:
        conn.commit()
    conn.close()


if __name__ == "__main__":
    main()
