"""
Модуль интервальных повторений (Spaced Repetition).

Реализует алгоритм SM-2 (SuperMemo 2) — тот же принцип, что лежит в основе
Anki. Вынесен в отдельный модуль специально, чтобы позже его можно было
заменить на более продвинутый алгоритм (например FSRS) без изменения
остального кода: единственная точка входа — функция review().

Оценка пользователя (quality) приходит с фронтенда как одна из 4 кнопок:
    0 — "Не знаю"   (полный провал, слово начинается заново)
    1 — "Сложно"    (вспомнил с трудом)
    2 — "Хорошо"    (вспомнил уверенно)
    3 — "Легко"     (вспомнил мгновенно)

Внутри они мапятся на классическую 0-5 шкалу SM-2.
"""

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

QUALITY_MAP = {0: 0, 1: 3, 2: 4, 3: 5}

MIN_EASE_FACTOR = 1.3
DEFAULT_EASE_FACTOR = 2.5


@dataclass
class ReviewState:
    repetitions: int
    ease_factor: float
    interval_days: int


def review(state: ReviewState, quality_button: int, today: date | None = None) -> tuple[ReviewState, date]:
    """
    Принимает текущее состояние карточки и оценку пользователя (0-3),
    возвращает новое состояние + дату следующего повторения.
    """
    today = today or datetime.now(timezone.utc).date()
    q = QUALITY_MAP.get(quality_button, 3)

    if q < 3:
        # Забыл — сбрасываем прогресс по слову, возвращаем его "завтра"
        repetitions = 0
        interval = 1
    else:
        if state.repetitions == 0:
            interval = 1
        elif state.repetitions == 1:
            interval = 6
        else:
            interval = round(state.interval_days * state.ease_factor)
        repetitions = state.repetitions + 1

    ease_factor = state.ease_factor + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
    ease_factor = max(MIN_EASE_FACTOR, ease_factor)

    new_state = ReviewState(
        repetitions=repetitions,
        ease_factor=round(ease_factor, 3),
        interval_days=interval,
    )
    due_date = today + timedelta(days=interval)
    return new_state, due_date


def word_state(repetitions: int, interval_days: int) -> str:
    """
    Классифицирует слово в одну из 4 стадий изучения — используется для
    прогресса в профиле и для более осознанного подбора слов в сессию.
    """
    if repetitions == 0:
        return "new"
    if repetitions <= 2:
        return "learning"
    if interval_days >= 21:
        return "mastered"
    return "review"
