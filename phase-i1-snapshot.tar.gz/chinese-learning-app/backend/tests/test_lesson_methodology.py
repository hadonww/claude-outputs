"""
Методика урока (2026-10): новые типы упражнений, фазы урока, повтор ошибки,
адаптивная норма новых слов, серверная проверка ответов. Только чистый engine.
"""

import sys
from pathlib import Path
from random import Random

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine import exercise_types as ex
from engine.answer_check import AnswerError, check_answer, pinyin_key
from engine.lesson_planner import (
    REVIEW_CAP,
    adaptive_daily_new,
    plan_lesson,
    retry_step,
)
from engine.scoring import derive_srs_quality

ZERO = {s: 0.0 for s in ["vocabulary", "characters", "pinyin", "tones", "listening", "grammar", "writing", "speaking"]}


def w(i, hanzi, pinyin, tr, cat="люди", examples=None, state="new"):
    return {"id": i, "hanzi": hanzi, "pinyin": pinyin, "translation": tr, "category": cat,
            "state": state, "examples": examples or []}


POOL = [
    w(1, "我", "wǒ", "я"), w(2, "你", "nǐ", "ты"), w(3, "是", "shì", "быть"),
    w(4, "学生", "xuésheng", "студент"), w(5, "老师", "lǎoshī", "учитель"),
    w(6, "好", "hǎo", "хороший"), w(7, "家", "jiā", "дом, семья", "дом"),
    w(8, "房子", "fángzi", "дом (здание)", "дом"), w(9, "书", "shū", "книга", "школа"),
]
for item in POOL:
    item["state"] = "review"

EX = {
    4: [{"sentence_cn": "我是学生。", "sentence_ru": "Я студент.", "used_word_ids": [1, 3, 4], "pinyin": "Wǒ shì xuésheng."}],
    5: [{"sentence_cn": "你是老师。", "sentence_ru": "Ты учитель.", "used_word_ids": [2, 3, 5], "pinyin": "Nǐ shì lǎoshī."}],
    9: [{"sentence_cn": "我是书。", "sentence_ru": "Я книга.", "used_word_ids": [1, 3, 9], "pinyin": "Wǒ shì shū."}],
}


def new_word(i):
    base = next(p for p in POOL if p["id"] == i)
    return {**base, "state": "new", "examples": EX.get(i, [])}


# ---------- новые типы упражнений ----------

def test_word_choice_is_meaning_to_hanzi_without_synonyms():
    item = POOL[6]  # 家 «дом, семья» — 房子 «дом (здание)» тоже «дом»
    for seed in range(20):
        p = ex.get("word_choice").build(item, POOL, Random(seed))
        assert p["prompt"] == "дом, семья" and p["options"][p["answer_index"]] == "家"
        assert "房子" not in p["options"]
        assert p["option_translation"][p["answer_index"]] == "дом, семья"
        assert len(set(p["options"])) == 4


def test_sentence_meaning_needs_known_words_and_a_bank_of_other_sentences():
    item = new_word(4)
    st = ex.get("sentence_meaning")
    assert not st.requires(item, POOL, {"known_word_ids": {1, 3}, "sentence_bank": []})
    ctx = {"known_word_ids": {1, 3}, "sentence_bank": ["Ты учитель.", "Я книга.", "Я студент."]}
    assert st.requires(item, POOL, ctx)
    p = st.build(item, POOL, Random(1), ctx)
    assert p["options"][p["answer_index"]] == "Я студент." and len(p["options"]) == 3
    assert p["options"].count("Я студент.") == 1            # своя фраза не попадает в дистракторы
    assert not st.requires(item, POOL, {"known_word_ids": {1}, "sentence_bank": ctx["sentence_bank"]})
    listening = ex.get("sentence_listening").build(item, POOL, Random(1), ctx)
    assert listening["prompt_audio"] == "我是学生。" and "prompt" not in listening


def test_pinyin_input_payload():
    p = ex.get("pinyin_input").build(POOL[1], POOL, Random(0))
    assert p["prompt"] == "你" and p["answer"] == "nǐ"


# ---------- серверная проверка ответа ----------

def test_choice_check_and_explanations():
    p = ex.get("recognition").build(POOL[0], POOL, Random(3))
    right = p["answer_index"]
    assert check_answer("recognition", p, right)["correct"]
    wrong = (right + 1) % 4
    res = check_answer("recognition", p, wrong)
    assert not res["correct"] and res["expected"] == "я"
    assert p["option_hanzi"][wrong] in res["explanation"]
    with pytest.raises(AnswerError):
        check_answer("recognition", p, 9)
    with pytest.raises(AnswerError):
        check_answer("recognition", p, "1")


def test_tone_check_explains_the_tone():
    p = ex.get("tone_choice").build(POOL[1], POOL, Random(0))
    res = check_answer("tone_choice", p, {"tones": [4]})
    assert not res["correct"] and "3-й" in res["explanation"]


@pytest.mark.parametrize("typed", ["nǐ", "ni3", "NI3", " ni 3 "])
def test_pinyin_input_accepts_marks_or_numbers(typed):
    assert check_answer("pinyin_input", {"answer": "nǐ"}, typed)["correct"]


def test_pinyin_input_neutral_tone_umlaut_and_feedback():
    assert pinyin_key("péngyou") == pinyin_key("peng2you5") == pinyin_key("peng2you")
    assert check_answer("pinyin_input", {"answer": "lǜ"}, "lv4")["correct"]
    tone = check_answer("pinyin_input", {"answer": "nǐ"}, "ni2")
    assert not tone["correct"] and "тон" in tone["explanation"]
    umlaut = check_answer("pinyin_input", {"answer": "lǜ"}, "lu4")
    assert not umlaut["correct"] and "ü" in umlaut["explanation"]
    assert not check_answer("pinyin_input", {"answer": "nǐ"}, "wo3")["correct"]


def test_order_recall_handwriting_checks():
    p = {"tokens": ["是", "我", "学生"], "answer_tokens": ["我", "是", "学生"]}
    assert check_answer("sentence_order", p, ["我", "是", "学生"])["correct"]
    assert not check_answer("sentence_order", p, ["是", "我", "学生"])["correct"]
    with pytest.raises(AnswerError):
        check_answer("sentence_order", p, ["我", "是", "书"])      # чужие плитки
    assert check_answer("recall", {}, 2)["correct"] and check_answer("recall", {}, 2)["self_assessed"]
    assert not check_answer("recall", {}, 0)["correct"]
    assert check_answer("handwriting", {}, {"mistakes": 1})["correct"]
    assert not check_answer("handwriting", {}, {"mistakes": 5})["correct"]
    assert not check_answer("handwriting", {}, {"skipped": True})["correct"]


# ---------- фазы урока ----------

def test_lesson_phases_context_and_production_after_all_introductions():
    news = [new_word(4), new_word(5), new_word(9)]
    reviews = [POOL[5]]
    steps = plan_lesson(news, reviews, ZERO, POOL, rng=Random(1), budget=40)
    last_intro = max(i for i, s in enumerate(steps) if s.type == "introduction")
    late = [i for i, s in enumerate(steps) if s.word_id in {4, 5, 9} and s.phase >= 3]
    assert late and min(late) > last_intro
    for wid in (4, 5, 9):
        own = [s for s in steps if s.word_id == wid]
        assert own[0].type == "introduction"
        assert own[-1].final and own[-1].type == "word_choice"   # финальный шаг — воспроизведение
    phases = [s.phase for s in steps if s.word_id in {4, 5, 9} and s.phase >= 3]
    assert phases == sorted(phases)


def test_writing_focus_is_capped_per_lesson():
    many = [{**p, "state": "new"} for p in POOL]
    mastery = {**ZERO, "characters": 90, "listening": 90, "pinyin": 90, "tones": 90, "grammar": 90, "writing": 0}
    steps = plan_lesson(many, [], mastery, POOL, rng=Random(1), budget=60)
    assert sum(s.type == "handwriting" for s in steps) <= 3


def test_retry_step_is_a_different_non_final_exercise():
    step = retry_step(POOL[0], "recognition", POOL, Random(0), {"known_word_ids": {1}})
    assert step is not None and step.type != "recognition"
    assert step.retry and not step.final and step.graded


# ---------- адаптивность и SRS-оценка ----------

def test_adaptive_daily_new_words():
    assert adaptive_daily_new(5, None, 0) == (5, "norm")
    assert adaptive_daily_new(5, 0.5, 0) == (3, "low_accuracy")
    assert adaptive_daily_new(5, 0.7, 0) == (4, "low_accuracy")
    assert adaptive_daily_new(5, 0.95, 0) == (6, "high_accuracy")
    assert adaptive_daily_new(5, 0.95, REVIEW_CAP + 5) == (5, "norm")   # при долге повторений не ускоряемся
    assert adaptive_daily_new(1, 0.3, 0) == (1, "low_accuracy")


def test_srs_quality_one_mistake_of_two_is_hard_not_forgotten():
    assert derive_srs_quality(1, 2) == 1
    assert derive_srs_quality(2, 4) == 1
    assert derive_srs_quality(3, 4) == 0
    assert derive_srs_quality(0, 3, recall_quality=0) == 0     # «Не знаю» — честно 0


# ---------- мини-диалоги ----------

DLG = [
    {"id": 1, "target_word_id": 4, "a_cn": "你是学生吗？", "a_ru": "Ты студент?", "a_pinyin": "Nǐ shì xuésheng ma?",
     "b_cn": "我是学生。", "b_ru": "Я студент.", "b_pinyin": "Wǒ shì xuésheng.", "used_word_ids": [2, 3, 4, 1, 3, 4]},
    {"id": 2, "target_word_id": 5, "a_cn": "你是老师吗？", "a_ru": "Вы учитель?", "a_pinyin": None,
     "b_cn": "我是老师。", "b_ru": "Я учитель.", "b_pinyin": None, "used_word_ids": [2, 3, 5, 1, 3, 5]},
    {"id": 3, "target_word_id": 6, "a_cn": "你好！", "a_ru": "Привет!", "a_pinyin": None,
     "b_cn": "你好！", "b_ru": "Привет!", "b_pinyin": None, "used_word_ids": [2, 6, 2, 6]},
    {"id": 4, "target_word_id": 9, "a_cn": "这是书吗？", "a_ru": "Это книга?", "a_pinyin": None,
     "b_cn": "是书。", "b_ru": "Да, книга.", "b_pinyin": None, "used_word_ids": [3, 9, 3, 9]},
]


def test_dialogue_reply_uses_only_known_dialogues_and_known_distractors():
    item = {**new_word(4), "dialogues": [DLG[0]]}
    st = ex.get("dialogue_reply")
    ctx = {"known_word_ids": {1, 2, 3, 5, 6}, "dialogue_bank": DLG}
    assert st.requires(item, POOL, ctx)
    p = st.build(item, POOL, Random(0), ctx)
    assert p["prompt"] == "你是学生吗？" and p["options"][p["answer_index"]] == "我是学生。"
    assert "这是书吗？" not in p["options"] and "是书。" not in p["options"]   # 书 незнакомо — не дистрактор
    assert len(p["options"]) == 3
    # реплика с незнакомым словом (学生 знаком, но 你 — нет) делает диалог недоступным
    assert not st.requires(item, POOL, {"known_word_ids": {1, 3, 5, 6}, "dialogue_bank": DLG})
    wrong = (p["answer_index"] + 1) % 3
    res = check_answer("dialogue_reply", p, wrong)
    assert not res["correct"] and "Я студент." in res["explanation"]
