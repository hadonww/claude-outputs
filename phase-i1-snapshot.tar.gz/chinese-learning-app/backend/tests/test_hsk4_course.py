"""
HSK 4 (HSK 2.0, тег old-4): импорт идемпотентен, не трогает существующие слова и
прогресс, карта курса уровня 4 согласована с маршрутом, слова попадают в модули
своего уровня. Чистая логика — на синтетических записях датасета; БД — во
временном файле (как в остальных тестах).
"""

import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import curriculum as cur
from scripts.import_hsk_vocabulary import (
    LEVEL_CORRECTIONS,
    build_report,
    insert_words,
    parse_levels,
    pick_hsk_level,
)


def form(meanings, pinyin="x", traditional=None):
    return {"traditional": traditional, "transcriptions": {"pinyin": pinyin, "numeric": None},
            "meanings": meanings, "classifiers": []}


def entry(simplified, levels, meanings=("m",), pinyin="x"):
    return {"simplified": simplified, "level": levels, "forms": [form(list(meanings), pinyin)],
            "pos": ["n"], "frequency": 1}


# ---------- уровни ----------

def test_parse_levels():
    assert parse_levels("1-4") == (1, 2, 3, 4)
    assert parse_levels("4") == (4,)
    assert parse_levels("1,3") == (1, 3)
    with pytest.raises(ValueError):
        parse_levels("0-9")


def test_level_is_earliest_old_tag_even_if_not_imported():
    only4 = {"old-4": 4}
    assert pick_hsk_level(["old-4"], only4) == 4
    # слово HSK2, у которого есть и тег old-4, не должно стать словом HSK4
    assert pick_hsk_level(["old-2", "old-4"], only4) is None
    assert pick_hsk_level(["new-4"], only4) is None


def test_level_corrections_move_merged_entries_to_level_2():
    assert LEVEL_CORRECTIONS == {"等": 2, "对": 2, "过": 2}
    report = build_report([entry("等", ["old-4", "old-4"]), entry("故意", ["old-4"])], set(), (1, 2, 3, 4))
    levels = {w["hanzi"]: w["hsk"] for w in report["to_insert"]}
    assert levels == {"等": 2, "故意": 4}
    assert report["level_corrections"] == LEVEL_CORRECTIONS


def test_report_only_inserts_missing_words():
    entries = [entry("你", ["old-1"]), entry("故意", ["old-4"]), entry("偶尔", ["old-4"]),
               entry("太阳", ["old-3"]), entry("云", ["old-5"])]
    report = build_report(entries, {"你", "偶尔"}, (1, 2, 3, 4))
    assert sorted(w["hanzi"] for w in report["to_insert"]) == ["太阳", "故意"]
    assert report["by_level"] == {3: 1, 4: 1}
    assert report["already_in_our_db_kept_handwritten"] == 2
    assert report["skipped_not_target_levels"] == 1          # old-5 — вне выбранных уровней
    again = build_report(entries, {"你", "偶尔", "太阳", "故意"}, (1, 2, 3, 4))
    assert again["to_insert"] == []                           # повторный запуск — ничего нового


# ---------- БД: идемпотентная вставка и сохранность прогресса ----------

@pytest.fixture()
def db_path():
    from app import db as db_module

    path = Path(tempfile.mkdtemp()) / "test_hsk4.db"
    db_module.DB_PATH = path
    db_module.init_db()
    return path


def _row(word):
    return {"pinyin_numeric": None, "traditional": None, "part_of_speech": "d", "frequency": 1, **word}


def test_insert_is_idempotent_and_keeps_existing_words_and_progress(db_path):
    conn = sqlite3.connect(db_path)
    first = conn.execute("SELECT id, hanzi, translation FROM words ORDER BY id LIMIT 1").fetchone()
    conn.execute("UPDATE progress SET repetitions = 3, interval_days = 10, total_attempts = 4 WHERE word_id = ?",
                 (first[0],))
    before = conn.execute("SELECT * FROM progress ORDER BY word_id").fetchall()
    words_before = conn.execute("SELECT * FROM words ORDER BY id").fetchall()
    conn.commit()
    conn.close()

    batch = [_row({"hanzi": "故意", "pinyin": "gù yì", "translation": "deliberately", "hsk": 4}),
             _row({"hanzi": first[1], "pinyin": "zzz", "translation": "OVERWRITE?", "hsk": 4})]
    insert_words(db_path, batch)
    insert_words(db_path, batch)                              # второй прогон

    conn = sqlite3.connect(db_path)
    assert conn.execute("SELECT COUNT(*) FROM words WHERE hanzi = '故意'").fetchone()[0] == 1
    assert conn.execute("SELECT COUNT(*) FROM words WHERE hanzi = ?", (first[1],)).fetchone()[0] == 1
    assert conn.execute("SELECT * FROM words WHERE id <= ? ORDER BY id", (words_before[-1][0],)).fetchall() \
        == words_before                                       # старые слова (id, перевод, всё) не тронуты
    assert conn.execute("SELECT * FROM progress ORDER BY word_id").fetchall() == before
    new = conn.execute("SELECT hsk, hsk_version, category, module_id FROM words WHERE hanzi = '故意'").fetchone()
    assert new == (4, "2.0", None, None)                      # «спит» до connect_hsk_course
    conn.close()


def test_connect_puts_level4_words_into_level4_modules_without_moving_old_words(db_path):
    from app.db import get_db
    from scripts.connect_hsk_course import connect

    with get_db() as conn:
        old_modules = dict(conn.execute("SELECT id, module_id FROM words WHERE module_id IS NOT NULL").fetchall())
        old_progress = conn.execute("SELECT * FROM progress ORDER BY word_id").fetchall()
        for hanzi, cat in (("故意", "оценка и модальность"), ("偶尔", "наречия времени"),
                           ("忽然", "наречия времени"), ("其次", "союзы и связки"), ("否则", "союзы и связки"),
                           ("亿", "числа"), ("倍", "числа")):
            conn.execute("INSERT INTO words (hanzi, pinyin, translation, hsk, hsk_version) VALUES (?, 'x', 'en', 4, '2.0')",
                         (hanzi,))
        course_map = {
            "故意": {"category": "оценка и модальность", "translation": "нарочно", "pinyin": None},
            "偶尔": {"category": "наречия времени", "translation": "изредка", "pinyin": None},
            "忽然": {"category": "наречия времени", "translation": "вдруг", "pinyin": None},
            "其次": {"category": "союзы и связки", "translation": "во-вторых", "pinyin": None},
            "否则": {"category": "союзы и связки", "translation": "иначе", "pinyin": None},
            "亿": {"category": "числа", "translation": "сто миллионов", "pinyin": None},
            "倍": {"category": "числа", "translation": "раз (вдвое)", "pinyin": None},
        }
        connect(conn, course_map, "2026-10-04", 1)
        connect(conn, course_map, "2026-10-04", 1)            # идемпотентно
        moved = {wid: mid for wid, mid in conn.execute("SELECT id, module_id FROM words") if wid in old_modules
                 and old_modules[wid] != mid}
        assert moved == {}                                    # старые слова остались в своих модулях
        old_ids = ",".join(str(r[0]) for r in old_progress)
        assert conn.execute(f"SELECT * FROM progress WHERE word_id IN ({old_ids}) ORDER BY word_id").fetchall() \
            == old_progress
        levels = dict(conn.execute(
            "SELECT w.hanzi, m.hsk_level FROM words w JOIN modules m ON m.id = w.module_id WHERE w.hsk = 4"))
    assert set(levels.values()) == {4} and len(levels) == 7


def test_level4_modules_follow_level3_in_route():
    modules = [{"id": 1, "category": "люди", "order_index": 1, "hsk_level": 4},
               {"id": 2, "category": "союзы и связки", "order_index": 2, "hsk_level": 4},
               {"id": 3, "category": "грамматика", "order_index": 3, "hsk_level": 3},
               {"id": 4, "category": "характер", "order_index": 4, "hsk_level": 4}]
    ordered = cur.route_order(modules)
    assert [m["id"] for m in ordered] == [3, 1, 4, 2]          # HSK3 → HSK4: основы → общество → связки
    assert ordered[-1]["section_title"] == "Мысли и связная речь · HSK 4"


# ---------- карта курса HSK 4 ----------

def test_hsk4_course_map_is_consistent():
    from scripts.connect_hsk_course import (
        HSK4_MAP_PATH,
        load_course_map,
        load_full_course_map,
    )

    hsk4 = load_course_map(HSK4_MAP_PATH)
    full = load_full_course_map()                            # бросает исключение при пересечении карт
    assert len(hsk4) == 593 and len(full) == 446 + 593
    route_categories = {c for s in cur.ROUTE_SECTIONS for c in s.categories}
    assert {e["category"] for e in hsk4.values()} <= route_categories
    for hanzi, e in hsk4.items():
        assert e["translation"], hanzi
        assert not any("a" <= ch.lower() <= "z" for ch in e["translation"]), hanzi   # перевод русский
        assert not any("一" <= ch <= "鿿" for ch in e["translation"]), hanzi  # не выдаёт ответ
        assert e["source"] == "draft_ru", hanzi             # непроверенный перевод не выдаётся за проверенный
    doubts = {h: e["doubt"] for h, e in hsk4.items() if e["doubt"]}
    assert doubts and all(doubts.values())
    assert {"咸", "困", "以"} <= set(doubts)
    assert hsk4["趟"]["pinyin"] == "tàng" and hsk4["狮子"]["pinyin"] == "shīzi"
    # модули HSK 4 не раздуты: ни одна тема уровня 4 не больше 40 слов
    sizes: dict[str, int] = {}
    for hanzi, e in hsk4.items():
        if hanzi not in LEVEL_CORRECTIONS:
            sizes[e["category"]] = sizes.get(e["category"], 0) + 1
    assert max(sizes.values()) <= 40, sizes
