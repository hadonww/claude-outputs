"""
Phase E: тесты backend-слоя статистики. Основной принцип — ничего не
выдумывается: если данных недостаточно, поле честно None/no_data, а не
правдоподобный ноль.
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_phase_e.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def _module(client, category):
    return next(m for m in client.get("/api/learning-path").json()["modules"] if m["category"] == category)


# ---------- word_state_counts: категории не пересекаются ----------

def test_word_states_do_not_overlap_and_sum_to_total(client):
    from app.db import get_db
    from app.repositories import progress_repo

    with get_db() as conn:
        counts = progress_repo.word_state_counts(conn)
    assert counts["new"] + counts["learning"] + counts["review"] + counts["mastered"] == counts["total_encountered"]
    # на свежей БД все 177 рукописных слов имеют progress-строку = "new"
    assert counts["new"] == 177 and counts["due_now"] == 0


def test_due_now_only_counts_words_with_real_repetitions(client):
    """due — временной флаг, не состояние; у repetitions=0 (new) его быть не может."""
    from app.db import get_db
    from app.repositories import progress_repo

    mid = _module(client, "люди")["id"]
    word = client.get(f"/api/lessons/{mid}/plan").json()["new_words"][0]
    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": word["id"], "exercise_type": "recall", "correct": True, "final": True, "recall_quality": 2})

    with get_db() as conn:
        conn.execute("UPDATE progress SET due_date='2000-01-01' WHERE word_id != ?", (word["id"],))
        counts = progress_repo.word_state_counts(conn)
    # все ОСТАЛЬНЫЕ слова всё ещё repetitions=0 (new) -> due_now не растёт от них
    assert counts["due_now"] == 0
    assert counts["new"] == 176


def test_learning_and_review_and_mastered_classify_correctly(client):
    from app.db import get_db
    from app.repositories import progress_repo

    with get_db() as conn:
        rows = conn.execute("SELECT word_id FROM progress LIMIT 3").fetchall()
        conn.execute("UPDATE progress SET repetitions=1, interval_days=1 WHERE word_id=?", (rows[0]["word_id"],))
        conn.execute("UPDATE progress SET repetitions=5, interval_days=5 WHERE word_id=?", (rows[1]["word_id"],))
        conn.execute("UPDATE progress SET repetitions=5, interval_days=30 WHERE word_id=?", (rows[2]["word_id"],))
        counts = progress_repo.word_state_counts(conn)
    assert counts["learning"] >= 1 and counts["review"] >= 1 and counts["mastered"] >= 1


# ---------- longest streak ----------

def test_longest_streak_from_activity_history(client):
    from app.db import get_db
    from app.repositories import stats_repo

    with get_db() as conn:
        for day in ("2026-01-01", "2026-01-02", "2026-01-03",  # 3 подряд
                     "2026-01-05",                              # пропуск -> разрыв
                     "2026-01-10", "2026-01-11"):                # ещё 2 подряд
            conn.execute("INSERT INTO activity_log (day, reviews_count) VALUES (?, 1)", (day,))
        assert stats_repo.longest_streak(conn) == 3


def test_longest_streak_zero_with_no_activity(client):
    from app.db import get_db
    from app.repositories import stats_repo

    with get_db() as conn:
        assert stats_repo.longest_streak(conn) == 0


def test_multiple_activities_same_day_count_as_one_day(client):
    from app.db import get_db
    from app.repositories import stats_repo

    with get_db() as conn:
        conn.execute("INSERT INTO activity_log (day, reviews_count) VALUES ('2026-02-01', 5)")
        conn.execute("INSERT INTO activity_log (day, reviews_count) VALUES ('2026-02-02', 1)")
        assert stats_repo.longest_streak(conn) == 2


# ---------- lesson completion ----------

def test_lesson_completion_counts_real_attempts_not_client_claims(client):
    mid = _module(client, "люди")["id"]
    plan = client.get(f"/api/lessons/{mid}/plan").json()
    word_ids = list({s["word_id"] for s in plan["steps"]})
    for wid in word_ids[:2]:
        client.post(f"/api/lessons/{mid}/attempts", json={
            "word_id": wid, "exercise_type": "recognition", "correct": True})

    # клиент завышает список — сервер должен принять только реально отвеченные
    res = client.post(f"/api/lessons/{mid}/complete", json={
        "new_word_ids": word_ids, "review_word_ids": []}).json()
    assert res["exercises_count"] == 2
    assert res["new_words_count"] == 2  # только 2 реально отвечены, не весь список


def test_lesson_completion_is_a_delta_not_cumulative_across_calls(client):
    mid = _module(client, "люди")["id"]
    plan = client.get(f"/api/lessons/{mid}/plan").json()
    word_ids = list({s["word_id"] for s in plan["steps"]})
    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": word_ids[0], "exercise_type": "recognition", "correct": True})
    first = client.post(f"/api/lessons/{mid}/complete", json={"new_word_ids": word_ids, "review_word_ids": []}).json()
    assert first["exercises_count"] == 1

    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": word_ids[1], "exercise_type": "recognition", "correct": True})
    second = client.post(f"/api/lessons/{mid}/complete", json={"new_word_ids": word_ids, "review_word_ids": []}).json()
    assert second["exercises_count"] == 1  # только НОВАЯ попытка, не 1+1=2 задвоенных


def test_lesson_completion_appears_in_statistics(client):
    mid = _module(client, "люди")["id"]
    plan = client.get(f"/api/lessons/{mid}/plan").json()
    wid = plan["steps"][0]["word_id"]
    client.post(f"/api/lessons/{mid}/attempts", json={"word_id": wid, "exercise_type": "recognition", "correct": True})
    client.post(f"/api/lessons/{mid}/complete", json={"new_word_ids": [wid], "review_word_ids": []})

    stats = client.get("/api/statistics").json()
    assert stats["lessons"]["completed_count"] == 1
    assert stats["lessons"]["recent"][0]["module_title"] == "Люди"


def test_complete_unknown_module_404(client):
    assert client.post("/api/lessons/999999/complete", json={}).status_code == 404


# ---------- study time ----------

def test_study_time_only_counts_measured_attempts(client):
    mid = _module(client, "люди")["id"]
    plan = client.get(f"/api/lessons/{mid}/plan").json()
    words = list({s["word_id"] for s in plan["steps"]})
    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": words[0], "exercise_type": "recognition", "correct": True, "response_ms": 2500})
    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": words[1], "exercise_type": "recognition", "correct": True})  # без response_ms

    stats = client.get("/api/statistics").json()
    st = stats["study_time"]
    assert st["total_attempts"] == 2 and st["measured_attempts"] == 1
    assert st["total_answer_time_ms"] == 2500
    assert st["average_answer_time_ms"] == 2500


def test_study_time_is_none_when_nothing_measured(client):
    stats = client.get("/api/statistics").json()
    st = stats["study_time"]
    assert st["measured_attempts"] == 0
    assert st["average_answer_time_ms"] is None


# ---------- review consistency (planned -> completed) ----------

def test_review_schedule_created_on_submit_review(client):
    mid = _module(client, "люди")["id"]
    wid = client.get(f"/api/lessons/{mid}/plan").json()["new_words"][0]["id"]
    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": wid, "exercise_type": "recall", "correct": True, "final": True, "recall_quality": 2})

    from app.db import get_db
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM review_schedule WHERE word_id=?", (wid,)).fetchall()
    assert len(rows) == 1 and rows[0]["completed_at"] is None  # следующая запланирована, ещё не наступила


def test_review_consistency_planned_vs_completed(client):
    from app.db import get_db
    from app.repositories import review_schedule_repo

    mid = _module(client, "люди")["id"]
    wid = client.get(f"/api/lessons/{mid}/plan").json()["new_words"][0]["id"]
    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": wid, "exercise_type": "recall", "correct": True, "final": True, "recall_quality": 2})

    with get_db() as conn:
        conn.execute("UPDATE review_schedule SET scheduled_for='2000-01-01' WHERE word_id=?", (wid,))

    # до повторного ответа: planned=1, completed=0
    stats = client.get("/api/statistics").json()
    assert stats["review_consistency"]["planned"] == 1
    assert stats["review_consistency"]["completed"] == 0

    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": wid, "exercise_type": "recall", "correct": True, "final": True, "recall_quality": 2})
    with get_db() as conn:
        from app.utils import today_date
        c = review_schedule_repo.consistency(conn, 1, today_date().isoformat())
    assert c["completed"] == 1 and c["completion_rate"] == 100.0


# ---------- mastery snapshots ----------

def test_mastery_snapshot_created_on_review(client):
    mid = _module(client, "люди")["id"]
    wid = client.get(f"/api/lessons/{mid}/plan").json()["new_words"][0]["id"]
    client.post(f"/api/lessons/{mid}/attempts", json={
        "word_id": wid, "exercise_type": "recognition", "correct": True, "final": True, "recall_quality": 2})

    from app.db import get_db
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM mastery_history").fetchall()
    assert len(rows) == 8  # снимок всех 8 навыков сразу


def test_repeated_snapshot_same_day_does_not_duplicate(client):
    mid = _module(client, "люди")["id"]
    words = client.get(f"/api/lessons/{mid}/plan").json()["new_words"]
    for w in words[:2]:
        client.post(f"/api/lessons/{mid}/attempts", json={
            "word_id": w["id"], "exercise_type": "recognition", "correct": True,
            "final": True, "recall_quality": 2})

    from app.db import get_db
    with get_db() as conn:
        count = conn.execute("SELECT COUNT(*) FROM mastery_history").fetchone()[0]
    assert count == 8  # второй визит в тот же день обновил, не задвоил


# ---------- per-skill mastery: no_data honest ----------

def test_skill_with_no_attempts_is_no_data_not_fake_zero(client):
    stats = client.get("/api/statistics").json()
    for skill in stats["skills"]:
        assert skill["no_data"] is True
        assert skill["score"] is None  # не выдуманный 0%


def test_skill_with_attempts_gets_real_score(client):
    mid = _module(client, "люди")["id"]
    wid = client.get(f"/api/lessons/{mid}/plan").json()["new_words"][0]["id"]
    client.post(f"/api/lessons/{mid}/attempts", json={"word_id": wid, "exercise_type": "recognition", "correct": True})

    stats = client.get("/api/statistics").json()
    characters = next(s for s in stats["skills"] if s["skill"] == "characters")
    assert characters["no_data"] is False
    assert characters["score"] is not None
    assert characters["attempts"] == 1 and characters["accuracy"] == 100.0


# ---------- exercise statistics ----------

def test_exercise_stats_by_type_and_skill(client):
    mid = _module(client, "люди")["id"]
    wid = client.get(f"/api/lessons/{mid}/plan").json()["new_words"][0]["id"]
    client.post(f"/api/lessons/{mid}/attempts", json={"word_id": wid, "exercise_type": "recognition", "correct": True})
    client.post(f"/api/lessons/{mid}/attempts", json={"word_id": wid, "exercise_type": "recognition", "correct": False})

    stats = client.get("/api/statistics").json()
    rec = next(r for r in stats["exercise_stats"]["by_type"] if r["exercise_type"] == "recognition")
    assert rec["attempts"] == 2 and rec["accuracy"] == 50.0


# ---------- profile API: backward compatibility + new fields ----------

def test_profile_keeps_existing_fields_and_adds_longest_streak(client):
    body = client.get("/api/profile").json()
    for field in ("streak", "total_reviews", "total_words", "learned_count",
                  "mastered_count", "accuracy", "by_level", "weak_words", "week_activity"):
        assert field in body  # обратная совместимость — ничего не сломано
    assert "longest_streak" in body


# ---------- regression ----------

def test_statistics_endpoint_does_not_crash_on_totally_fresh_db(client):
    res = client.get("/api/statistics")
    assert res.status_code == 200
    body = res.json()
    assert body["word_states"]["total_encountered"] == 177
    assert body["lessons"]["completed_count"] == 0
    assert body["review_consistency"]["planned"] == 0
    assert body["review_consistency"]["completion_rate"] is None  # не 0%, честный None


# ---------- Phase F prep: гибкий период активности ----------

def test_statistics_activity_days_default_and_param(client):
    default = client.get("/api/statistics").json()
    assert len(default["activity"]) == 30

    week = client.get("/api/statistics?activity_days=7").json()
    assert len(week["activity"]) == 7
    # последние 7 дней 30-дневного периода должны совпасть с week-периодом
    assert [d["day"] for d in week["activity"]] == [d["day"] for d in default["activity"][-7:]]
