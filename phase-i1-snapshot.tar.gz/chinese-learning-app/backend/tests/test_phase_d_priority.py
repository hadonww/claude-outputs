"""
Phase D, п.2: просроченное СЛАБОЕ слово должно иметь приоритет выше, чем
просто просроченное сильное слово — не только ORDER BY due_date.
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_weak_priority.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def _two_words_of_one_module(client):
    words = client.get("/api/words", params={"category": "люди"}).json()
    module_id = words[0]["module_id"]
    same = [w for w in words if w["module_id"] == module_id]
    return same[0]["id"], same[1]["id"], module_id


def _set_progress(conn, word_id, *, repetitions, total_attempts, total_correct, due_date):
    conn.execute(
        """UPDATE progress SET repetitions=?, total_attempts=?, total_correct=?, due_date=?
           WHERE word_id=?""",
        (repetitions, total_attempts, total_correct, due_date, word_id),
    )


def test_weak_overdue_word_ranks_before_strong_overdue_word(client):
    from app.db import get_db
    from app.repositories import progress_repo

    strong_word, weak_word, module_id = _two_words_of_one_module(client)

    with get_db() as conn:
        _set_progress(conn, strong_word, repetitions=3, total_attempts=5, total_correct=5, due_date="2000-01-01")
        _set_progress(conn, weak_word, repetitions=3, total_attempts=5, total_correct=1, due_date="2000-01-01")
        ordered = [r["id"] for r in progress_repo.due_review_words_for_module(conn, module_id, "2100-01-01")]

    assert weak_word in ordered and strong_word in ordered
    assert ordered.index(weak_word) < ordered.index(strong_word)


def test_weak_priority_applies_to_cross_module_review_too(client):
    from app.db import get_db
    from app.repositories import progress_repo

    words = client.get("/api/words", params={"category": "люди"}).json()
    strong_word, weak_word = words[0]["id"], words[1]["id"]

    with get_db() as conn:
        _set_progress(conn, strong_word, repetitions=3, total_attempts=5, total_correct=5, due_date="2000-01-01")
        _set_progress(conn, weak_word, repetitions=3, total_attempts=5, total_correct=1, due_date="2000-01-01")
        other_module = conn.execute(
            "SELECT id FROM modules WHERE category = 'числа' ORDER BY id LIMIT 1").fetchone()["id"]
        ordered = [r["id"] for r in
                   progress_repo.due_review_words_excluding_module(conn, other_module, "2100-01-01", 10)]

    assert ordered.index(weak_word) < ordered.index(strong_word)


def test_weak_priority_in_global_review_plan_too(client):
    from app.db import get_db
    from app.repositories import progress_repo

    words = client.get("/api/words", params={"category": "люди"}).json()
    strong_word, weak_word = words[0]["id"], words[1]["id"]

    with get_db() as conn:
        _set_progress(conn, strong_word, repetitions=3, total_attempts=5, total_correct=5, due_date="2000-01-01")
        _set_progress(conn, weak_word, repetitions=3, total_attempts=5, total_correct=1, due_date="2000-01-01")
        ordered = [r["id"] for r in progress_repo.due_review_words(conn, "2100-01-01")]

    assert ordered.index(weak_word) < ordered.index(strong_word)


def test_words_with_too_few_attempts_are_not_treated_as_weak(client):
    """1 попытка недостаточно, чтобы судить о слабости (WEAK_MIN_ATTEMPTS=2) —
    иначе одна случайная ошибка навсегда прыгала бы в приоритет."""
    from app.db import get_db
    from app.repositories import progress_repo

    one_wrong, one_right, module_id = _two_words_of_one_module(client)

    with get_db() as conn:
        _set_progress(conn, one_wrong, repetitions=1, total_attempts=1, total_correct=0, due_date="2000-01-01")
        _set_progress(conn, one_right, repetitions=1, total_attempts=1, total_correct=1, due_date="2000-01-01")
        rows = {r["id"]: dict(r) for r in progress_repo.due_review_words_for_module(conn, module_id, "2100-01-01")}
    # оба входят; при total_attempts=1 ни один не считается "weak" — проверяем, что не падает
    assert one_wrong in rows and one_right in rows
