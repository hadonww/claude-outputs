"""Phase I — исправления контента HSK 1–4 (аудит): данные, миграция старых баз, импорт."""

import json
import sqlite3
import sys
import tempfile
from pathlib import Path
from random import Random

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

BACKEND = Path(__file__).resolve().parent.parent


@pytest.fixture()
def fresh_db():
    import app.config as cfg
    from app import db as db_module

    saved = cfg.DB_PATH, db_module.DB_PATH
    path = Path(tempfile.mkdtemp()) / "fixes.db"
    cfg.DB_PATH = db_module.DB_PATH = path
    db_module.init_db()
    yield path
    cfg.DB_PATH, db_module.DB_PATH = saved


def _word(path, hanzi):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    row = conn.execute(
        "SELECT w.*, m.hsk_level ml FROM words w LEFT JOIN modules m ON m.id = w.module_id WHERE hanzi = ?",
        (hanzi,)).fetchone()
    return dict(row) if row else None


def test_fresh_database_has_corrected_seed_words(fresh_db):
    assert _word(fresh_db, "中国")["pinyin"] == "Zhōngguó"     # имя собственное — с заглавной
    assert _word(fresh_db, "中文")["pinyin"] == "Zhōngwén"
    assert _word(fresh_db, "学生")["pinyin"] == "xuésheng"      # второй слог лёгкий (как в HSK)
    assert _word(fresh_db, "小姐")["pinyin"] == "xiǎojie"
    for hanzi in ("儿子", "女儿", "猫", "狗", "飞机", "先生", "零", "分钟", "上午", "没关系"):
        w = _word(fresh_db, hanzi)
        assert w["hsk"] == 1 and w["ml"] == 1, hanzi           # HSK 2.0 уровень 1 — в модулях HSK 1
    # 出租车 — тоже уровень 1; модуль «Транспорт» HSK 1 появляется вместе с 火车站 после импорта HSK
    assert _word(fresh_db, "出租车")["hsk"] == 1


def test_old_database_is_migrated_on_start(fresh_db):
    """База, созданная до аудита: неверные уровень, пиньинь, пример и пиньинь примеров —
    init_db исправляет их и пересчитывает модули, прогресс слова не теряется."""
    from app import db as db_module

    conn = sqlite3.connect(fresh_db)
    son = _word(fresh_db, "儿子")["id"]
    zero = _word(fresh_db, "零")["id"]
    conn.execute("UPDATE progress SET repetitions = 3, interval_days = 10 WHERE word_id = ?", (son,))
    conn.execute("UPDATE words SET hsk = 2 WHERE id = ?", (son,))
    conn.execute("UPDATE words SET pinyin = 'zhōngguó' WHERE hanzi = '中国'")
    conn.execute("UPDATE examples SET sentence_cn = '我的电话号码有一个零。', sentence_ru = 'x', pinyin = NULL "
                 "WHERE target_word_id = ?", (zero,))
    conn.execute("UPDATE examples SET pinyin = 'Tā lái liǎo.' WHERE sentence_cn = '他来了。'")
    conn.commit()
    conn.close()
    db_module.init_db()

    assert _word(fresh_db, "中国")["pinyin"] == "Zhōngguó"
    son_row = _word(fresh_db, "儿子")
    assert son_row["hsk"] == 1 and son_row["ml"] == 1
    conn = sqlite3.connect(fresh_db)
    assert conn.execute("SELECT repetitions, interval_days FROM progress WHERE word_id = ?", (son,)).fetchone() == (3, 10)
    sentences = [r[0] for r in conn.execute("SELECT sentence_cn FROM examples WHERE target_word_id = ?", (zero,))]
    assert "我的电话号码有一个零。" not in sentences and "现在是二零二六年。" in sentences
    # 了 (le) появляется в базе только после импорта HSK: тогда пример разобран и его пиньинь
    # пересобран; в чистой seed-базе пример ещё не разобран (needs_review) и не используется
    le = conn.execute("SELECT pinyin FROM examples WHERE sentence_cn = '他来了。' AND needs_review = 0").fetchone()
    if le:
        assert "liǎo" not in le[0]


def test_example_pinyin_is_rebuilt_from_current_words():
    from app.content_fixes import _sentence_pinyin

    words = [{"hanzi": "谢谢", "pinyin": "xièxie"}, {"hanzi": "你", "pinyin": "nǐ"}, {"hanzi": "不客气", "pinyin": "bùkèqi"}]
    assert _sentence_pinyin("谢谢你！不客气。", words) == "Xièxie nǐ! Bùkèqi."
    assert _sentence_pinyin("谢谢他！", words[:2]) is None          # слова не складываются в фразу


def test_course_maps_have_fixed_translations_and_proper_nouns():
    from scripts.connect_hsk_course import load_full_course_map

    m = load_full_course_map()
    assert m["以为"]["translation"].startswith("думать")             # не «ошибочно полагать»
    assert m["跑步"]["translation"].startswith("бегать")             # глагол, не только «бег»
    assert m["发烧"]["translation"].startswith("температурить")
    assert m["感冒"]["translation"].startswith("простудиться")
    assert "сейчас" in m["呢"]["translation"]                        # 在…呢 тоже значение HSK 1
    for hanzi, pinyin in [("北京", "Běijīng"), ("汉语", "Hànyǔ"), ("长城", "Chángchéng"), ("亚洲", "Yàzhōu")]:
        assert m[hanzi]["pinyin"] == pinyin
    doubts = {h for h, e in m.items() if e["doubt"]}
    assert not {"了", "呢"} & doubts                                   # решены: перевод передаёт обе функции
    assert {"把", "干", "咸", "困", "以"} <= doubts                    # многозначность — решает человек


def test_examples_fixed_where_chinese_was_ambiguous_or_unnatural():
    from scripts.seed_course_examples import load_examples

    rows = {(t, "".join(tokens)): ru for t, tokens, ru, _ in load_examples()}
    assert not any(t == "倍" and "大两倍" in cn for t, cn in rows)     # «大两倍» — двусмысленно (втрое?)
    assert ("倍", "这个房子是那个的两倍大。") in rows
    assert ("出租车", "我们坐出租车去火车站。") in rows                 # пример уровня 1 для слова HSK 1


def test_import_prefers_common_form_over_proper_noun():
    from scripts.import_hsk_vocabulary import _pick_primary_form

    xia = [{"transcriptions": {"pinyin": "Xià"}, "meanings": ["the Xia dynasty", "Xia kingdom", "surname Xia"]},
           {"transcriptions": {"pinyin": "xià"}, "meanings": ["summer"]}]
    assert _pick_primary_form(xia)["meanings"] == ["summer"]
    yun = [{"transcriptions": {"pinyin": "yún"}, "meanings": ["(classical) to say"]},
           {"transcriptions": {"pinyin": "Yún"}, "meanings": ["surname Yun", "abbr. for Yunnan"]},
           {"transcriptions": {"pinyin": "yún"}, "meanings": ["cloud"]}]
    assert _pick_primary_form(yun)["meanings"] == ["cloud"]
    beijing = [{"transcriptions": {"pinyin": "Běi jīng"}, "meanings": ["Beijing"]}]
    assert _pick_primary_form(beijing)["meanings"] == ["Beijing"]   # нарицательной формы нет — имя остаётся


def test_pinyin_choice_options_do_not_leak_answer_by_capital_letter():
    """Регрессия (Phase I): с пиньинем Běijīng верный вариант узнавался по заглавной букве."""
    from engine import exercise_types as ex

    pool = [{"id": i, "hanzi": h, "pinyin": p, "translation": t, "category": "c"} for i, (h, p, t) in enumerate(
        [("北京", "Běijīng", "Пекин"), ("中国", "Zhōngguó", "Китай"), ("老师", "lǎoshī", "учитель"),
         ("朋友", "péngyou", "друг"), ("名字", "míngzi", "имя")], start=1)]
    for seed in range(5):
        p = ex.get("pinyin_choice").build(pool[0], pool, Random(seed))
        assert all(o == o.lower() for o in p["options"])
        assert p["options"][p["answer_index"]] == "běijīng"


def test_lesson_data_files_are_valid_json():
    for path in (BACKEND / "data" / "lessons").glob("*.json"):
        json.loads(path.read_text(encoding="utf-8"))
