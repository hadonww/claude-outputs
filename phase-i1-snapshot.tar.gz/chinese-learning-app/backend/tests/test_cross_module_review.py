"""
Аудит, пункт 2: "если слово появилось в Lesson 10, оно не должно исчезнуть
после Lesson 10" — должно возвращаться и в уроках ДРУГИХ модулей, не только
через отдельный /api/review.
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_cross_module.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def modules(client):
    return sorted(client.get("/api/learning-path").json()["modules"], key=lambda m: m["route_index"])


def learn_word(client, module_id, word_id):
    client.post(f"/api/lessons/{module_id}/attempts", json={
        "word_id": word_id, "exercise_type": "recognition", "correct": True, "final": True})


def make_due(client):
    """Тот же приём, что и в test_review_mode.py: имитируем прошествие времени."""
    from app.db import get_db

    with get_db() as conn:
        conn.execute("UPDATE progress SET due_date = '2000-01-01' WHERE repetitions > 0")


def test_word_from_module_a_appears_in_module_b_review(client):
    a, b = modules(client)[:2]
    word_a = client.get(f"/api/lessons/{a['id']}/plan").json()["new_words"][0]
    learn_word(client, a["id"], word_a["id"])
    make_due(client)

    plan_b = client.get(f"/api/lessons/{b['id']}/plan").json()
    review_ids = {w["id"] for w in plan_b["review_words"]}
    assert word_a["id"] in review_ids, "слово модуля A не вернулось в уроке модуля B"
    step_ids = {s["word_id"] for s in plan_b["steps"]}
    assert word_a["id"] in step_ids, "слово A есть в review_words, но не попало в шаги урока B"


def test_own_category_review_takes_priority_over_foreign(client):
    a, b = modules(client)[:2]
    word_a = client.get(f"/api/lessons/{a['id']}/plan").json()["new_words"][0]
    learn_word(client, a["id"], word_a["id"])
    # несколько слов B тоже становятся "due" — свои должны идти первыми
    words_b = client.get(f"/api/lessons/{b['id']}/plan").json()["new_words"][:3]
    for w in words_b:
        learn_word(client, b["id"], w["id"])
    make_due(client)

    plan_b = client.get(f"/api/lessons/{b['id']}/plan").json()
    own_ids = {w["id"] for w in words_b}
    foreign_ids = {word_a["id"]}
    review_order = [w["id"] for w in plan_b["review_words"]]
    # свои слова B должны присутствовать все; чужое (A) — тоже, но не вытесняет свои
    assert own_ids <= set(review_order)
    assert foreign_ids <= set(review_order)


def test_attempt_on_foreign_review_word_is_accepted(client):
    a, b = modules(client)[:2]
    word_a = client.get(f"/api/lessons/{a['id']}/plan").json()["new_words"][0]
    learn_word(client, a["id"], word_a["id"])
    make_due(client)

    res = client.post(f"/api/lessons/{b['id']}/attempts", json={
        "word_id": word_a["id"], "exercise_type": "recall", "correct": True,
        "final": True, "recall_quality": 2})
    assert res.status_code == 200
    assert res.json()["srs"] is not None


def test_untouched_word_from_another_module_is_still_rejected(client):
    """Cross-module разрешён только для слов, которые SRS реально отслеживает
    (repetitions > 0) — произвольную подмену чужого нетронутого слова
    по-прежнему нельзя протащить через attempts другого модуля."""
    a, b = modules(client)[:2]
    untouched = client.get(f"/api/lessons/{a['id']}/plan").json()["new_words"][0]
    res = client.post(f"/api/lessons/{b['id']}/attempts", json={
        "word_id": untouched["id"], "exercise_type": "recognition", "correct": True})
    assert res.status_code == 400


def test_review_cap_is_shared_between_own_and_foreign(client):
    """own + foreign вместе не должны превышать REVIEW_CAP — иначе повторение
    вытеснило бы всё остальное содержимое урока."""
    from engine.lesson_planner import REVIEW_CAP

    mods = modules(client)
    a = mods[0]
    # учим много слов в остальных модулях, чтобы "чужих" due было с запасом
    for m in mods[1:5]:
        w = client.get(f"/api/lessons/{m['id']}/plan").json()["new_words"][0]
        learn_word(client, m["id"], w["id"])
    make_due(client)

    plan_a = client.get(f"/api/lessons/{a['id']}/plan").json()
    assert len(plan_a["review_words"]) <= REVIEW_CAP
