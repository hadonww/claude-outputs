"""
Качество примеров предложений: чистые проверки scripts/example_checks.py и
согласованность файлов data/examples/*.tsv. Полная проверка по настоящей базе
(все слова есть, уровни не выше цели, покрытие) — тест в конце; он строит полную
БД из датасета и запускается, только если задана переменная HSK_DATASET
(путь к complete.json), иначе пропускается.
"""

import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.example_checks import check_example, join_pinyin, parse_line

VOCAB = {
    "我": {"id": 1, "hsk": 1, "pinyin": "wǒ"},
    "很": {"id": 2, "hsk": 1, "pinyin": "hěn"},
    "忙": {"id": 3, "hsk": 1, "pinyin": "máng"},
    "最近": {"id": 4, "hsk": 3, "pinyin": "zuìjìn"},
    "其实": {"id": 5, "hsk": 3, "pinyin": "qíshí"},
    "偶尔": {"id": 6, "hsk": 4, "pinyin": "ǒu'ěr"},
    "喝": {"id": 7, "hsk": 1, "pinyin": "hē"},
    "咖啡": {"id": 8, "hsk": 2, "pinyin": "kāfēi"},
    "一边": {"id": 9, "hsk": 3, "pinyin": "yībiān"},
    "吃": {"id": 10, "hsk": 1, "pinyin": "chī"},
    "看": {"id": 11, "hsk": 1, "pinyin": "kàn"},
    "没": {"id": 12, "hsk": 1, "pinyin": "méi"},
    "关系": {"id": 13, "hsk": 3, "pinyin": "guānxi"},
    "没关系": {"id": 14, "hsk": 1, "pinyin": "méiguānxi"},
}


def test_valid_example_gets_ids_pinyin_and_difficulty():
    ex = check_example("偶尔", ["我", "偶尔", "喝", "咖啡", "。"], "Иногда я пью кофе.", VOCAB)
    assert ex.ok and not ex.warnings
    assert ex.sentence_cn == "我偶尔喝咖啡。"
    assert ex.used_word_ids == [1, 6, 7, 8]
    assert ex.pinyin == "Wǒ ǒu'ěr hē kāfēi."
    assert ex.difficulty == 4


def test_unknown_word_and_missing_target_are_rejected():
    ex = check_example("偶尔", ["我", "偶尔", "喝", "茶", "。"], "Иногда я пью чай.", VOCAB)
    assert not ex.ok and "нет в базе: 茶" in ex.errors[0]


def test_word_above_target_level_is_rejected():
    ex = check_example("忙", ["我", "最近", "很", "忙", "。"], "Я в последнее время занят.", VOCAB)
    assert not ex.ok and "выше уровня" in ex.errors[0]


def test_same_level_words_only_warn():
    ex = check_example("其实", ["其实", "我", "最近", "很", "忙", "。"], "На самом деле я сейчас занят.", VOCAB)
    assert ex.ok and any("того же уровня: 最近" in w for w in ex.warnings)


def test_target_twice_rejected_except_paired_constructions():
    twice = check_example("忙", ["我", "忙", "很", "忙", "。"], "Я занят.", VOCAB)
    assert not twice.ok
    paired = check_example("一边", ["我", "一边", "吃", "一边", "看", "。"], "Я ем и смотрю.", VOCAB)
    assert paired.ok


def test_length_punctuation_and_scripts():
    assert not check_example("忙", ["我", "忙", "。"], "Я занят.", VOCAB).ok              # 2 слова
    assert not check_example("忙", ["我", "很", "忙"], "Я занят.", VOCAB).ok              # без точки
    assert not check_example("忙", ["我", "很", "忙", "。"], "I am busy.", VOCAB).ok          # перевод не русский
    assert not check_example("忙", ["我", "很", "忙", "。"], "Я 忙.", VOCAB).ok               # иероглиф в переводе


def test_split_word_is_flagged_for_review():
    ex = check_example("关系", ["我", "和", "他", "没", "关系", "。"], "У меня с ним нет отношений.",
                       {**VOCAB, "和": {"id": 15, "hsk": 1, "pinyin": "hé"}, "他": {"id": 16, "hsk": 1, "pinyin": "tā"}})
    assert ex.ok and any("没关系" in w for w in ex.warnings)


def test_join_pinyin_and_parse_line():
    assert join_pinyin(["nǐ", "hǎo", "!"]) == "Nǐ hǎo!"
    assert parse_line("# комментарий") is None
    assert parse_line("忙\t我 很 忙 。\tЯ занят.") == ("忙", ["我", "很", "忙", "。"], "Я занят.")
    with pytest.raises(ValueError):
        parse_line("忙 我很忙")


# ---------- файлы примеров ----------

def _rows():
    from scripts.seed_course_examples import load_examples

    return load_examples()


def test_example_files_are_consistent():
    from scripts.connect_hsk_course import HSK4_MAP_PATH, load_course_map
    from scripts.import_hsk_vocabulary import LEVEL_CORRECTIONS

    rows = _rows()
    assert len(rows) >= 900
    seen = set()
    hsk4 = set(load_course_map(HSK4_MAP_PATH)) - set(LEVEL_CORRECTIONS)
    for target, tokens, ru, where in rows:
        key = (target, "".join(tokens))
        assert key not in seen, where
        seen.add(key)
        assert target in tokens, where
        assert any("Ѐ" <= ch <= "ӿ" for ch in ru), where
        if where.startswith("hsk4"):
            assert target in hsk4, where                     # файл уровня 4 — только слова уровня 4
        else:
            assert target not in hsk4, where
    covered4 = {t for t, *_, w in rows if w.startswith("hsk4")}
    assert hsk4 - covered4 == {"无"}                         # 无 — книжное, пример осознанно не дан


@pytest.mark.skipif(not os.environ.get("HSK_DATASET"), reason="нужен HSK_DATASET=путь к complete.json")
def test_all_examples_pass_checks_on_full_database():
    import json
    import sqlite3

    from app import db as db_module
    from scripts.connect_hsk_course import connect, load_full_course_map
    from scripts.import_hsk_vocabulary import build_report, insert_words
    from scripts.seed_course_examples import check_all, coverage, seed

    path = Path(tempfile.mkdtemp()) / "full.db"
    db_module.DB_PATH = path
    db_module.init_db()
    entries = json.loads(Path(os.environ["HSK_DATASET"]).read_text(encoding="utf-8"))
    conn = sqlite3.connect(path)
    existing = {r[0] for r in conn.execute("SELECT hanzi FROM words")}
    conn.close()
    insert_words(path, build_report(entries, existing)["to_insert"])
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    connect(conn, load_full_course_map(), "2026-10-04", 1)
    checked = check_all(conn)
    assert [ex.where for ex in checked if not ex.ok] == []
    result = seed(conn, checked)
    assert result["inserted"] == len(checked)
    assert seed(conn, checked)["inserted"] == 0                # идемпотентно
    cov = coverage(conn)
    assert cov["hsk4"]["with_example"] == cov["hsk4"]["words"] - 1   # все, кроме 无

    from scripts.seed_dialogues import check_all as check_dialogues

    assert [d.where for d in check_dialogues(conn) if not d.ok] == []
    conn.close()


# ---------- мини-диалоги ----------

def test_check_dialogue():
    from scripts.example_checks import check_dialogue

    ok = check_dialogue("偶尔", ["你", "喝", "咖啡", "吗", "？"], "Ты пьёшь кофе?", ["偶尔", "喝", "。"], "Иногда.",
                        {**VOCAB, "你": {"id": 20, "hsk": 1, "pinyin": "nǐ"}, "吗": {"id": 21, "hsk": 1, "pinyin": "ma"}})
    assert ok.ok and ok.b.pinyin == "Ǒu'ěr hē." and ok.a.used_word_ids == [20, 7, 8, 21]
    above = check_dialogue("忙", ["我", "很", "忙", "。"], "Я занят.", ["其实", "我", "很", "忙", "。"], "На самом деле занят.", VOCAB)
    assert not above.ok and "выше уровня" in above.errors[0]
    missing = check_dialogue("忙", ["我", "很", "好", "。"], "Мне хорошо.", ["我", "很", "好", "。"], "Мне хорошо.",
                             {**VOCAB, "好": {"id": 22, "hsk": 1, "pinyin": "hǎo"}})
    assert not missing.ok


def test_dialogue_file_is_well_formed():
    from scripts.seed_dialogues import load_dialogues

    rows = load_dialogues()
    assert len(rows) >= 50
    assert len({(r[0], "".join(r[1]), "".join(r[3])) for r in rows}) == len(rows)
    assert len({"".join(r[3]) for r in rows}) >= len(rows) - 3      # ответы разные — есть из чего брать дистракторы
