"""
API, которыми пользуется обновлённый интерфейс: поиск словаря по пиньиню без
тонов, слабые слова, карточка слова, пояснения на пути обучения, дистракторы
в пределах уровня; и статическая проверка фронтенда (у каждого типа упражнения
из реестра есть рендерер).
"""

import re
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

FRONTEND = Path(__file__).resolve().parent.parent.parent / "frontend"


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_ui.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def test_dictionary_search_by_pinyin_without_tones(client):
    hanzi = lambda q: {w["hanzi"] for w in client.get("/api/words", params={"q": q}).json()}
    assert "学习" in hanzi("xuexi")
    assert "学习" in hanzi("xue xi")
    assert "你" in hanzi("ni3")
    assert "你" in hanzi("你")
    assert "学习" in hanzi("учиться") or "学习" in hanzi("учить")


def test_weak_filter_and_word_detail(client):
    from app.db import get_db

    words = client.get("/api/words").json()
    weak_id, ok_id = words[0]["id"], words[1]["id"]
    with get_db() as conn:
        conn.execute("UPDATE progress SET total_attempts = 4, total_correct = 1, repetitions = 1 WHERE word_id = ?",
                     (weak_id,))
        conn.execute("UPDATE progress SET total_attempts = 4, total_correct = 4, repetitions = 2 WHERE word_id = ?",
                     (ok_id,))
    weak = {w["id"] for w in client.get("/api/words", params={"weak": "true"}).json()}
    assert weak == {weak_id}
    detail = client.get(f"/api/words/{weak_id}").json()
    assert detail["module"]["id"] and detail["progress"]["attempts"] == 4
    assert detail["progress"]["next_review"]
    assert isinstance(detail["examples"], list)
    fresh = client.get(f"/api/words/{words[5]['id']}").json()
    assert fresh["progress"]["next_review"] is None            # не изучалось — нет даты повторения


def test_learning_path_explains_recommendation_and_locks(client):
    body = client.get("/api/learning-path").json()
    assert set(body) == {"modules", "recommended_module_id"}  # контракт верхнего уровня не изменился
    current = [m for m in body["modules"] if m["recommendation_reason"]]
    assert len(current) == 1 and current[0]["id"] == body["recommended_module_id"]
    assert "HSK 1" in current[0]["recommendation_reason"]
    locked = [m for m in body["modules"] if m["status"] == "locked"]
    assert locked and all(m["locked_reason"] for m in locked)
    assert all(m["description"] for m in body["modules"])


def test_lesson_distractors_stay_within_lesson_level(client):
    from app.db import get_db

    with get_db() as conn:  # слово уровня 4 в базе — не должно стать вариантом ответа в HSK 1
        conn.execute("INSERT INTO words (hanzi, pinyin, translation, hsk, category) VALUES ('故意', 'gùyì', 'нарочно', 4, 'люди')")
        wid = conn.execute("SELECT id FROM words WHERE hanzi = '故意'").fetchone()[0]
        conn.execute("INSERT INTO progress (word_id, user_id, due_date) VALUES (?, 1, '2026-01-01')", (wid,))
        levels = dict(conn.execute("SELECT hanzi, hsk FROM words").fetchall())
    module_id = client.get("/api/learning-path").json()["recommended_module_id"]
    plan = client.get(f"/api/lessons/{module_id}/plan").json()
    options = {h for s in plan["steps"] for h in (s["payload"].get("option_hanzi") or []) if h}
    assert options and "故意" not in options
    assert all(levels[h] <= 1 for h in options)


def test_frontend_has_renderer_for_every_exercise_type():
    from engine.exercise_types import REGISTRY

    js = (FRONTEND / "app.js").read_text(encoding="utf-8")
    for name in REGISTRY:
        assert re.search(rf'(\b{name}\b\s*\(|"{name}"|STEP_RENDERERS\.{name}\b)', js), f"нет рендерера для {name}"


def test_frontend_static_structure():
    html = (FRONTEND / "index.html").read_text(encoding="utf-8")
    assert 'id="theme-toggle"' not in html                     # плавающая кнопка темы убрана (перекрывала поиск)
    assert 'data-theme-choice="system"' in html
    assert 'id="lesson-footer"' in html and 'id="word-sheet"' in html
    assert "HSK 4–6 — скоро" not in html
