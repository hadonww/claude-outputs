"""
Шаг 1 плана "Lesson-first": Module -> Lesson фильтрует контент по модулю.
Раньше /api/session отдавал глобальный список независимо от выбранного
модуля — эти тесты фиксируют, что для /api/lessons/{module_id}/plan это
больше не так.
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture(scope="module")
def client():
    from app import db as db_module

    tmp_dir = tempfile.mkdtemp()
    db_module.DB_PATH = Path(tmp_dir) / "test_lessons.db"
    # main мог быть импортирован ранее другим тестовым модулем (init_db уже
    # отработал на чужой БД) — инициализируем свою явно.
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app as fastapi_app

    return TestClient(fastapi_app)


def _modules(client):
    return sorted(client.get("/api/learning-path").json()["modules"], key=lambda m: m["order_index"])


def test_lesson_plan_only_contains_words_of_its_module(client):
    for module in _modules(client)[:4]:
        plan = client.get(f"/api/lessons/{module['id']}/plan").json()
        assert plan["module"]["id"] == module["id"]
        words = plan["new_words"] + plan["review_words"]
        assert words, f"у модуля {module['title']} нет контента"
        assert all(w["category"] == module["category"] for w in words)


def test_two_modules_get_different_content(client):
    a, b = _modules(client)[:2]
    ids_a = {w["id"] for w in client.get(f"/api/lessons/{a['id']}/plan").json()["new_words"]}
    ids_b = {w["id"] for w in client.get(f"/api/lessons/{b['id']}/plan").json()["new_words"]}
    assert ids_a and ids_b
    assert ids_a.isdisjoint(ids_b)


def test_lesson_plan_respects_daily_limit(client):
    client.post("/api/settings", json={"daily_new_words": 3})
    module = _modules(client)[0]
    plan = client.get(f"/api/lessons/{module['id']}/plan").json()
    assert len(plan["new_words"]) == 3


def test_review_words_are_also_scoped_to_module(client):
    a, b = _modules(client)[:2]
    word_b = client.get(f"/api/lessons/{b['id']}/plan").json()["new_words"][0]
    client.post("/api/review", json={"word_id": word_b["id"], "quality": 2})

    plan_a = client.get(f"/api/lessons/{a['id']}/plan").json()
    assert word_b["id"] not in {w["id"] for w in plan_a["review_words"]}


def test_unknown_module_returns_404(client):
    assert client.get("/api/lessons/999999/plan").status_code == 404


def test_learning_path_contract_unchanged(client):
    body = client.get("/api/learning-path").json()
    assert set(body.keys()) == {"modules", "recommended_module_id"}
