"""
Тесты дизайн-системы (Phase 3, PLAN_WB_v1.md).

Не трогают backend/app — читают frontend/design-tokens.json и
frontend/style.css как текст. Превращают "ручной чек-лист" из плана в
автоматическую проверку:
  1. design-tokens.json — у light и dark одинаковый набор каналов
     (ничего не "забыто" для тёмной темы).
  2. style.css — каждый использованный var(--x) где-то определён
     (защита от опечаток/битых ссылок).
  3. Каждый цветовой токен, объявленный в базовом :root, переопределён
     в обоих тёмных блоках — то есть тема реально "полноценная", а не
     инверсия (прямое требование ARCHITECTURE_WB_v1.md, раздел 11).
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

FRONTEND_DIR = Path(__file__).resolve().parent.parent.parent / "frontend"
TOKENS_PATH = FRONTEND_DIR / "design-tokens.json"
CSS_PATH = FRONTEND_DIR / "style.css"

# Соответствие "семантическое имя в design-tokens.json" -> "имя CSS-переменной
# в style.css". Имена не совпадают дословно (--seal вместо --accent и т.п.) —
# исторически сложившиеся короткие имена сохранены ради совместимости со
# всеми уже написанными компонентами (см. комментарий в начале :root
# в style.css). Список должен обновляться при добавлении новых цветовых
# токенов — если тест падает на "новый токен без маппинга", это осознанный
# сигнал, а не случайность.
COLOR_TOKEN_TO_CSS_VAR = {
    "bg": "--paper",
    "bgElevated": "--paper-raised",
    "bgSubtle": "--paper-subtle",
    "textPrimary": "--ink",
    "textSecondary": "--ink-soft",
    "textTertiary": "--ink-faint",
    "textOnAccent": "--on-accent",
    "accent": "--seal",
    "accentHover": "--seal-strong",
    "accentSubtle": "--seal-soft",
    "accentFill": "--seal-fill",
    "ctaAlt": "--cta-alt",
    "emphasis": "--emphasis",
    "success": "--jade",
    "successSubtle": "--jade-soft",
    "warning": "--gold",
    "warningSubtle": "--gold-soft",
    "danger": "--danger",
    "dangerSubtle": "--danger-soft",
    "info": "--info",
    "infoSubtle": "--info-soft",
    "border": "--line",
    "borderStrong": "--line-strong",
    "progressTrack": "--progress-track",
    "progressFill": "--progress-fill",
    "artWashSat": "--art-wash-sat",
    "artWashL1": "--art-wash-l1",
    "artWashL2": "--art-wash-l2",
    "artFg": "--art-fg",
    "artSun": "--art-sun",
    "sectionHueDefault": "--section-hue",
    "nodeSheen": "--node-sheen",
    "nodeDepth": "--node-depth",
}

# Токены, для которых одинаковое значение в light/dark — осознанное решение,
# не забытая перекраска (например белый текст поверх акцентной кнопки
# остаётся белым независимо от темы, потому что сам акцентный цвет уже
# меняется между темами).
INTENTIONALLY_SAME_IN_BOTH_THEMES = {"--on-accent", "--section-hue"}


def load_tokens():
    return json.loads(TOKENS_PATH.read_text(encoding="utf-8"))


def load_css():
    return CSS_PATH.read_text(encoding="utf-8")


def extract_root_block(css: str, selector_start: str) -> str:
    """Грубый, но достаточный парсер: находит `selector { ... }` (без
    вложенных фигурных скобок внутри — их в этих блоках не бывает)."""
    idx = css.index(selector_start)
    open_brace = css.index("{", idx)
    close_brace = css.index("}", open_brace)
    return css[open_brace + 1: close_brace]


def defined_vars(block: str) -> set[str]:
    return set(re.findall(r"(--[a-zA-Z0-9-]+)\s*:", block))


# ---------------------------------------------------------------------------
# 1. design-tokens.json — паритет каналов между темами
# ---------------------------------------------------------------------------

def test_light_and_dark_have_identical_color_channels():
    tokens = load_tokens()
    assert set(tokens["light"]["color"].keys()) == set(tokens["dark"]["color"].keys())


def test_light_and_dark_have_identical_shadow_channels():
    tokens = load_tokens()
    assert set(tokens["light"]["shadow"].keys()) == set(tokens["dark"]["shadow"].keys())


def test_every_color_token_has_a_css_var_mapping():
    """Если добавили новый канал в JSON, но забыли завести CSS-переменную —
    тест укажет на это явно, а не тихо потеряется."""
    tokens = load_tokens()
    json_keys = set(tokens["light"]["color"].keys())
    mapped_keys = set(COLOR_TOKEN_TO_CSS_VAR.keys())
    assert json_keys == mapped_keys, (
        f"Расхождение между design-tokens.json и маппингом теста: "
        f"только в JSON: {json_keys - mapped_keys}, только в маппинге: {mapped_keys - json_keys}"
    )


# ---------------------------------------------------------------------------
# 2. style.css — нет ссылок на неопределённые переменные
# ---------------------------------------------------------------------------

def test_no_dangling_css_var_references():
    css = load_css()
    used = set(re.findall(r"var\((--[a-zA-Z0-9-]+)", css))
    defined = set(re.findall(r"(--[a-zA-Z0-9-]+)\s*:", css))
    dangling = used - defined
    assert not dangling, f"var() ссылается на неопределённые токены: {dangling}"


# ---------------------------------------------------------------------------
# 3. Light/Dark — полноценные темы, не инверсия
# ---------------------------------------------------------------------------

def test_every_color_css_var_overridden_in_both_dark_blocks():
    css = load_css()
    root_block = extract_root_block(css, ":root {")
    media_dark_block = extract_root_block(css, ':root:not([data-theme="light"]) {')
    attr_dark_block = extract_root_block(css, ':root[data-theme="dark"] {')

    root_vars = defined_vars(root_block)
    expected_color_vars = set(COLOR_TOKEN_TO_CSS_VAR.values())
    missing_from_root = expected_color_vars - root_vars
    assert not missing_from_root, f"Токены из маппинга отсутствуют в базовом :root: {missing_from_root}"

    media_vars = defined_vars(media_dark_block)
    attr_vars = defined_vars(attr_dark_block)

    missing_in_media = expected_color_vars - media_vars
    missing_in_attr = expected_color_vars - attr_vars
    assert not missing_in_media, f"Не переопределены в @media(dark): {missing_in_media}"
    assert not missing_in_attr, f"Не переопределены в [data-theme=dark]: {missing_in_attr}"


def test_dark_block_values_actually_differ_from_light():
    """Проверка от копипаста: тёмная тема должна реально иметь другие
    значения, а не совпадать с light (что было бы инверсией только по
    названию, не по факту)."""
    css = load_css()
    root_block = extract_root_block(css, ":root {")
    attr_dark_block = extract_root_block(css, ':root[data-theme="dark"] {')

    def values(block):
        return dict(re.findall(r"(--[a-zA-Z0-9-]+)\s*:\s*([^;]+);", block))

    light_values = values(root_block)
    dark_values = values(attr_dark_block)

    for var in COLOR_TOKEN_TO_CSS_VAR.values():
        if var in INTENTIONALLY_SAME_IN_BOTH_THEMES:
            continue
        if var in light_values and var in dark_values:
            assert light_values[var].strip() != dark_values[var].strip(), (
                f"{var} имеет одинаковое значение в light и dark — это инверсия, не отдельная тема"
            )


# ---------------------------------------------------------------------------
# 4. Контраст текста (WCAG): вторичный текст, статусы и мелкий акцентный текст
#    читаются на всех фонах обеих тем (UX-аудит 2026-10, п.3)
# ---------------------------------------------------------------------------

def _luminance(hex_color: str) -> float:
    h = hex_color.lstrip("#")
    channels = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    lin = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in channels]
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]


def _contrast(a: str, b: str) -> float:
    la, lb = sorted([_luminance(a), _luminance(b)], reverse=True)
    return (la + 0.05) / (lb + 0.05)


def test_text_tokens_meet_contrast_on_their_surfaces():
    tokens = load_tokens()
    checks = [  # (текст, фон, минимум)
        ("textPrimary", "bg", 7.0), ("textSecondary", "bg", 4.5), ("textSecondary", "bgElevated", 4.5),
        ("textTertiary", "bg", 4.0), ("textTertiary", "bgElevated", 4.0),
        ("success", "successSubtle", 4.5), ("warning", "warningSubtle", 4.5),
        ("accentHover", "accentSubtle", 4.5), ("accentHover", "bg", 4.5), ("info", "infoSubtle", 4.5),
        ("textOnAccent", "accentFill", 4.5), ("textOnAccent", "ctaAlt", 4.5), ("emphasis", "bgElevated", 4.5), ("danger", "bg", 4.5), ("danger", "dangerSubtle", 4.5),
    ]
    failures = []
    for theme in ("light", "dark"):
        c = tokens[theme]["color"]
        for text, surface, minimum in checks:
            ratio = _contrast(c[text], c[surface])
            if ratio < minimum:
                failures.append(f"{theme}: {text} на {surface} = {ratio:.2f} < {minimum}")
    assert not failures, failures


def test_no_hardcoded_accent_rgba_outside_tokens():
    """Тень/свечение акцента — через color-mix(var(--seal)), а не зашитым rgba
    старого красного (в тёмной теме акцент другой)."""
    assert "rgba(225, 54, 43" not in load_css()


def test_font_sizes_follow_scale():
    """Размеры шрифта — только ступени шкалы из design-tokens.json (раньше их было 29)."""
    sizes = load_tokens()["typography"]["allowedSizes"]
    allowed = {float(v) for v in sizes["text"] + sizes["hanzi"]}
    used = {float(v) for v in re.findall(r"font-size:\s*([0-9.]+)px", load_css())}
    assert used <= allowed, sorted(used - allowed)


def test_frontend_uses_svg_icons_not_emoji():
    """Эмодзи-иконки рисуются по-разному на платформах и не красятся токенами."""
    frontend = Path(__file__).resolve().parent.parent.parent / "frontend"
    for name in ("app.js", "index.html"):
        text = (frontend / name).read_text(encoding="utf-8")
        found = [ch for ch in ("🔊", "🔥", "🔒", "⌂", "✕") if ch in text]
        assert not found, (name, found)
