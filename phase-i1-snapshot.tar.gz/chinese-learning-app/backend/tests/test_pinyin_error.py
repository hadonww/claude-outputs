"""pinyin_error: поиск записи пиньиня с ошибкой (engine, без БД)."""

import json
import sys
from pathlib import Path
from random import Random

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services.lesson_service import ANSWER_FIELDS
from engine import exercise_types as ex
from engine import pinyin_errors as pe
from engine.answer_check import AnswerError, check_answer, pinyin_key
from engine.syllables import SYLLABLES, split_syllables

SEED = Path(__file__).resolve().parent.parent / "seed_data.json"


def w(wid, hanzi, pinyin, translation="-", category="c"):
    return {"id": wid, "hanzi": hanzi, "pinyin": pinyin, "translation": translation, "category": category}


POOL = [
    w(1, "你", "nǐ", "ты"), w(2, "好", "hǎo", "хороший"), w(3, "他", "tā", "он"),
    w(4, "电子邮件", "diàn zǐ yóu jiàn", "электронная почта"), w(5, "谢谢", "xièxie", "спасибо"),
    w(6, "中国", "Zhōngguó", "Китай"), w(7, "银行", "yínháng", "банк"), w(8, "常常", "chángcháng", "часто"),
    w(9, "吗", "ma", "вопрос"), w(10, "老师", "lǎoshī", "учитель"), w(11, "绿", "lǜ", "зелёный"),
]
T = ex.get("pinyin_error")


def by_hanzi(h):
    return next(x for x in POOL if x["hanzi"] == h)


def build(h, seed=0, pool=POOL, ctx=None):
    return T.build(by_hanzi(h), pool, Random(seed), ctx)


def wrong_options(payload, pool):
    """Независимо от answer_index: какие варианты расходятся с настоящим пиньинем."""
    words = {x["hanzi"]: x for x in pool}
    bad = []
    if payload["prompt"]:      # слово из нескольких слогов: вариант = иероглиф + его слог
        syllables = split_syllables(words[payload["prompt"]]["pinyin"], payload["prompt"])
        for i, (opt, s) in enumerate(zip(payload["options"], syllables)):
            if opt != f"{s.hanzi} {s.text}":
                bad.append(i)
    else:                      # слово из одного слога: варианты = слово + пиньинь
        for i, opt in enumerate(payload["options"]):
            hanzi, pinyin = opt.split(" ", 1)
            if pinyin_key(pinyin) != pinyin_key(words[hanzi]["pinyin"]):
                bad.append(i)
    return bad


# ---------- правила пиньиня ----------

@pytest.mark.parametrize("base, tone, expected", [
    ("hao", 3, "hǎo"), ("xie", 4, "xiè"), ("gou", 3, "gǒu"), ("liu", 2, "liú"), ("gui", 4, "guì"),
    ("lü", 4, "lǜ"), ("zhuang", 1, "zhuāng"), ("men", None, "men"),
])
def test_place_tone(base, tone, expected):
    assert pe.place_tone(base, tone) == expected


def test_mistakes_are_real_syllables_and_change_something():
    for item in POOL:
        syllables = pe.word_syllables(item)
        for _, m in pe.mistakes(list(syllables or [])):
            assert m.base in SYLLABLES
            assert m.text != syllables[m.index].text


def test_tone_confusions_prefer_common_pairs():
    found = pe.mistakes(list(pe.word_syllables(by_hanzi("你"))))   # nǐ, 3-й тон
    tones = {m.tone: weight for weight, m in found if m.kind == "tone"}
    assert tones[2] > tones[4] and 3 not in tones


def test_other_reading_of_same_character_is_never_a_mistake():
    """好 hào — настоящее чтение (好奇), его нельзя выдать за ошибку."""
    texts = {m.text for _, m in pe.mistakes(list(pe.word_syllables(by_hanzi("好"))))}
    assert "hào" not in texts and "háo" in texts


def test_yi_and_bu_tones_are_not_mutated():
    syllables = pe.word_syllables(w(0, "一定", "yídìng"))
    assert all(m.index == 1 for _, m in pe.mistakes(list(syllables)) if m.kind == "tone")


def test_letter_mistakes():
    kinds = {(m.kind, m.text) for _, m in pe.mistakes(list(pe.word_syllables(by_hanzi("中国"))))}
    assert {("initial", "zōng"), ("initial", "kuó")} <= kinds
    assert ("tone", "zhòng") not in kinds                   # 中 zhòng — настоящее чтение
    assert ("final", "zhōn") not in kinds                   # zhon — не слог путунхуа
    kinds = {(m.kind, m.text) for _, m in pe.mistakes(list(pe.word_syllables(by_hanzi("银行"))))}
    assert {("final", "yíng"), ("final", "hán")} <= kinds
    assert ("umlaut", "lù") in {(m.kind, m.text) for _, m in pe.mistakes(list(pe.word_syllables(by_hanzi("绿"))))}


def test_neutral_syllable_can_get_a_wrong_tone():
    found = pe.mistakes(list(pe.word_syllables(by_hanzi("谢谢"))))
    assert any(m.kind == "neutral" and m.index == 1 and m.text == "xiè" for _, m in found)


# ---------- слово из нескольких слогов ----------

def test_two_syllable_word_one_option_per_character():
    p = build("中国")
    assert p["prompt"] == "中国" and p["hint"] == "Китай"
    assert [o.split(" ")[0] for o in p["options"]] == ["中", "国"]
    assert wrong_options(p, POOL) == [p["answer_index"]]


@pytest.mark.parametrize("seed", range(8))
def test_four_syllable_word_exactly_one_wrong(seed):
    p = build("电子邮件", seed)
    assert len(p["options"]) == 4 and len(set(p["options"])) == 4
    assert wrong_options(p, POOL) == [p["answer_index"]]
    m = p["answer"]
    assert p["options"][p["answer_index"]] == f"{m['hanzi']} {m['wrong']}"


def test_neutral_word_mutation_never_duplicates_an_option():
    for seed in range(20):
        p = build("谢谢", seed)
        assert len(set(p["options"])) == 2 and wrong_options(p, POOL) == [p["answer_index"]]


def test_repeated_character_word_is_excluded():
    assert not T.requires(by_hanzi("常常"), POOL)


# ---------- слово из одного слога ----------

@pytest.mark.parametrize("seed", range(8))
def test_single_syllable_word_with_other_words(seed):
    p = build("你", seed)
    assert p["prompt"] is None and p["hint"] is None
    assert len(p["options"]) == 3 and len(set(p["options"])) == 3
    assert any(o.startswith("你 ") for o in p["options"])
    assert wrong_options(p, POOL) == [p["answer_index"]]


def test_single_syllable_prefers_known_words():
    p = build("你", 0, ctx={"known_word_ids": {3, 10}})
    assert {o.split(" ")[0] for o in p["options"]} == {"你", "他", "老师"}


def test_single_syllable_uses_only_known_words_in_a_lesson():
    """Регрессия (Phase I): ошибка может быть в любом слове группы, поэтому в уроке
    группа — только из знакомых слов; раньше незнакомые подставлялись, если знакомых мало."""
    for s in range(10):
        p = build("你", s, ctx={"known_word_ids": {2, 3, 10}})
        assert {o.split(" ")[0] for o in p["options"]} <= {"你", "好", "他", "老师"}
        assert set(p["used_word_ids"]) <= {1, 2, 3, 10}
    assert not T.requires(by_hanzi("你"), POOL, {"known_word_ids": {3}})     # знакомых меньше двух
    assert T.requires(by_hanzi("电子邮件"), POOL, {"known_word_ids": set()})  # многосложному другие не нужны


def test_single_syllable_needs_two_other_words():
    assert not T.requires(by_hanzi("你"), [by_hanzi("你"), by_hanzi("好")])
    assert T.requires(by_hanzi("你"), POOL)


def test_neutral_only_word_not_applicable():
    assert not T.requires(by_hanzi("吗"), POOL)


# ---------- payload и проверка ----------

def test_answer_is_hidden_from_client():
    for h in ("你", "电子邮件"):
        p = build(h)
        visible = {k for k in p if k not in ANSWER_FIELDS}
        assert visible == {"prompt", "hint", "question", "options", "used_word_ids"}


def test_build_is_deterministic():
    assert build("电子邮件", 5) == build("电子邮件", 5)


def test_check_correct_choice():
    p = build("电子邮件", 1)
    res = check_answer("pinyin_error", p, p["answer_index"])
    assert res["correct"] and res["expected"] == p["options"][p["answer_index"]] and res["explanation"] is None


def test_check_wrong_choice_explains_the_mistake():
    p = build("电子邮件", 1)
    m, k = p["answer"], p["answer_index"]
    chosen = (k + 1) % 4
    res = check_answer("pinyin_error", p, chosen)
    assert not res["correct"] and res["expected"] == p["options"][k]
    assert m["hanzi"] in res["explanation"] and m["right"] in res["explanation"] and m["wrong"] in res["explanation"]
    assert f"«{p['options'][chosen]}» записано верно" in res["explanation"]


def test_tone_explanation_names_the_tone():
    p = {"options": ["你 nǐ", "他 tǎ", "好 hǎo"], "answer_index": 1,
         "answer": {"kind": "tone", "hanzi": "他", "right": "tā", "wrong": "tǎ", "right_tone": 1, "wrong_tone": 3}}
    res = check_answer("pinyin_error", p, 0)
    assert res["explanation"] == "Ошибка — в «他 tǎ»: 他 — tā, 1-й (ровный) тон, а не tǎ. «你 nǐ» записано верно."


@pytest.mark.parametrize("bad", [None, "1", -1, 3, True, [0], {"tones": [1]}])
def test_malformed_answer_rejected(bad):
    with pytest.raises(AnswerError):
        check_answer("pinyin_error", build("你"), bad)


def test_every_seed_word_has_exactly_one_wrong_option():
    """На всех 177 рукописных словах: ровно одна запись расходится с настоящим пиньинем."""
    seed = json.loads(SEED.read_text(encoding="utf-8"))
    pool = [{**x, "id": i} for i, x in enumerate(seed)]
    built = 0
    for item in pool:
        if not T.requires(item, pool):
            continue
        for s in range(3):
            p = T.build(item, pool, Random(s))
            assert len(set(p["options"])) == len(p["options"])
            assert wrong_options(p, pool) == [p["answer_index"]], (item["hanzi"], p["options"])
            built += 1
    assert built > 170 * 3 - 10


def test_registered_as_pinyin_practice():
    t = ex.get("pinyin_error")
    assert t.skill == "pinyin" and ex.phase("pinyin_error") == 2 and ex.stage("pinyin_error") == "practice"
