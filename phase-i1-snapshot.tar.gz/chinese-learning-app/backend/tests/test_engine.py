"""Тесты чистого Learning Engine: mastery, реестр упражнений, планировщик."""

import ast
import sys
from pathlib import Path
from random import Random

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine import exercise_types as ex
from engine.lesson_planner import plan_lesson
from engine.mastery import update_mastery

ENGINE_DIR = Path(__file__).resolve().parent.parent / "engine"

WORDS = [
    {"id": 1, "hanzi": "你", "pinyin": "nǐ", "translation": "ты", "state": "new"},
    {"id": 2, "hanzi": "我", "pinyin": "wǒ", "translation": "я", "state": "new"},
    {"id": 3, "hanzi": "他", "pinyin": "tā", "translation": "он", "state": "new"},
    {"id": 4, "hanzi": "她", "pinyin": "tā", "translation": "она", "state": "new"},
    {"id": 5, "hanzi": "好", "pinyin": "hǎo", "translation": "хороший", "state": "new"},
    {"id": 6, "hanzi": "们", "pinyin": "men", "translation": "мн. число", "state": "new"},
]
ZERO = {s: 0.0 for s in ["vocabulary", "characters", "pinyin", "tones", "listening", "grammar", "writing", "speaking"]}


def plan(new, review=(), mastery=None, **kw):
    return plan_lesson(list(new), list(review), mastery or ZERO, WORDS, rng=Random(1), **kw)


# ---- mastery ----
def test_mastery_moves_toward_target_and_clamps():
    assert update_mastery(0, True) == 20
    assert update_mastery(50, False) == 40
    assert update_mastery(100, True) == 100
    assert update_mastery(0, False) == 0
    assert 0 <= update_mastery(99.9, True, k=5) <= 100


# ---- registry ----
def test_registry_has_required_types():
    assert {"introduction", "recognition", "listening", "recall", "handwriting",
            "pinyin_choice", "tone_choice"} <= set(ex.REGISTRY)


def test_every_choice_payload_has_valid_answer_index():
    item = WORDS[0]
    for name in ("recognition", "listening", "pinyin_choice"):
        payload = ex.get(name).build(item, WORDS, Random(3))
        assert 0 <= payload["answer_index"] < len(payload["options"])
        assert len(set(payload["options"])) == len(payload["options"])


def test_tone_choice_options_are_four_tones_of_same_syllable():
    payload = ex.get("tone_choice").build(WORDS[0], WORDS, Random(3))
    [syllable] = payload["syllables"]
    assert syllable["options"] == ex.tone_variants("nǐ") and syllable["tested"]
    assert payload["answers"] == [3]


def test_neutral_tone_word_excludes_tone_choice():
    assert not ex.get("tone_choice").requires(WORDS[5], WORDS)  # "men" без диакритики


def test_new_exercise_type_needs_no_planner_change():
    ex.REGISTRY["dummy"] = ex.ExerciseType("dummy", "grammar", lambda i, p, c=None: True, lambda i, p, r: {})
    try:
        assert plan(WORDS[:2])  # планировщик по-прежнему работает
    finally:
        del ex.REGISTRY["dummy"]


# ---- planner ----
def test_new_word_starts_with_introduction_then_recognition():
    steps = plan(WORDS[:1])
    assert [s.type for s in steps[:2]] == ["introduction", "recognition"]


def test_review_word_uses_recall_not_introduction():
    review = [{**WORDS[0], "state": "review"}]
    types = [s.type for s in plan([], review)]
    assert types[0] == "recall" and "introduction" not in types


def test_mastered_word_is_only_one_recall_step():
    steps = plan([], [{**WORDS[0], "state": "mastered"}])
    assert [s.type for s in steps] == ["recall"]


def test_each_word_has_exactly_one_final_step_and_it_is_its_last():
    steps = plan(WORDS[:4])
    for wid in {s.word_id for s in steps}:
        own = [s for s in steps if s.word_id == wid]
        assert [s.final for s in own].count(True) == 1 and own[-1].final


def test_weak_skill_gets_matching_exercise():
    mastery = {**ZERO, "characters": 90, "listening": 90, "pinyin": 90, "tones": 5, "writing": 90}
    types = [s.type for s in plan(WORDS[:1], mastery=mastery)]
    assert "tone_choice" in types


def test_weak_writing_adds_handwriting():
    mastery = {**ZERO, "characters": 90, "listening": 90, "pinyin": 90, "tones": 90, "writing": 5}
    assert "handwriting" in [s.type for s in plan(WORDS[:1], mastery=mastery)]


def test_strong_characters_skips_recognition():
    mastery = {**ZERO, "characters": 95}
    assert "recognition" not in [s.type for s in plan(WORDS[:2], mastery=mastery)]


def test_lessons_are_not_all_the_same_template():
    steps = plan(WORDS[:5])
    focus_types = {s.type for s in steps if s.type not in ("introduction", "recognition")}
    assert len(focus_types) >= 2  # ничья mastery разрешается ротацией по слову


def test_plan_is_deterministic():
    a = [s.to_dict() for s in plan(WORDS[:4])]
    b = [s.to_dict() for s in plan(WORDS[:4])]
    assert a == b


def test_different_mastery_gives_different_plan():
    weak_tones = {**ZERO, "characters": 90, "listening": 90, "pinyin": 90, "writing": 90, "tones": 0}
    weak_listen = {**ZERO, "characters": 90, "tones": 90, "pinyin": 90, "writing": 90, "listening": 0}
    a = [s.type for s in plan(WORDS[:2], mastery=weak_tones)]
    b = [s.type for s in plan(WORDS[:2], mastery=weak_listen)]
    assert a != b


def test_budget_is_respected_and_every_kept_word_is_complete():
    steps = plan(WORDS[:5], budget=8)
    assert len(steps) <= 8
    assert all(any(s.final for s in steps if s.word_id == w) for w in {s.word_id for s in steps})


def test_lesson_shape_interleaves_new_and_review_not_one_block_then_another():
    """Phase D, п.3: 'новое -> закрепление -> старое -> новое -> ...', а не
    'сначала весь review, потом всё новое' (было так до Phase D)."""
    review = [{**WORDS[4], "state": "review"}]
    steps = plan(WORDS[:4], review)
    # первый шаг — новое слово (NEW_CHUNK идёт первым блоком)
    assert steps[0].type == "introduction"
    # но review не задвинут в самый конец — он должен появиться среди первой половины шагов
    review_positions = [i for i, s in enumerate(steps) if s.word_id == 5]
    assert review_positions and review_positions[0] < len(steps) - 2


def test_engine_is_pure_no_web_or_db_imports():
    banned = {"fastapi", "sqlite3", "starlette", "pydantic", "requests", "httpx"}
    for path in ENGINE_DIR.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.Import):
                names = [a.name.split(".")[0] for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module.split(".")[0]]
            assert not (set(names) & banned), f"{path.name} импортирует {names}"


def test_one_weak_skill_does_not_make_every_word_identical():
    mastery = {**ZERO, "characters": 90, "listening": 90, "pinyin": 90, "tones": 90, "writing": 0}
    steps = plan(WORDS[:5], mastery=mastery)
    handwriting = [s for s in steps if s.type == "handwriting"]
    assert 2 <= len(handwriting) <= 3                                  # приоритет есть, но с потолком
    assert len({s.word_id for s in steps if s.type != "introduction"} - {s.word_id for s in handwriting}) >= 2


# ---- sentence_order / fill_blank (Phase C: used_word_ids, не токенизация) ----
def ex_item(word_id, hanzi, pinyin, translation, examples=None):
    return {"id": word_id, "hanzi": hanzi, "pinyin": pinyin, "translation": translation,
            "state": "new", "examples": examples or []}


EX_WORDS = [
    ex_item(1, "我", "wǒ", "я", [
        {"sentence_cn": "我是学生。", "sentence_ru": "Я студент.", "used_word_ids": [1, 2, 3]}]),
    ex_item(2, "是", "shì", "быть", [
        {"sentence_cn": "我是书。", "sentence_ru": "Я книга.", "used_word_ids": [1, 2, 4]}]),
    ex_item(3, "学生", "xuéshēng", "студент", [
        {"sentence_cn": "我是学生。", "sentence_ru": "Я студент.", "used_word_ids": [1, 2, 3]}]),
    ex_item(4, "书", "shū", "книга", [
        {"sentence_cn": "我是书。", "sentence_ru": "Я книга.", "used_word_ids": [1, 2, 4]}]),
    ex_item(5, "好", "hǎo", "хороший"),
]


def test_tokenize_prefers_longest_known_word_and_drops_punctuation():
    # tokenize() больше не используется движком для выбора упражнений (Phase C:
    # used_word_ids — источник истины), но остаётся утилитой для миграции
    # старых свободнотекстовых примеров (db.py) — проверяем её саму по себе.
    vocab = {"我", "是", "学生", "你", "好"}
    assert ex.tokenize("我是学生。", vocab) == ["我", "是", "学生"]
    assert ex.tokenize("你好吗？", vocab) == ["你", "好", "吗"]


def test_sentence_order_payload_is_a_real_shuffle_of_the_answer():
    item = EX_WORDS[0]
    payload = ex.get("sentence_order").build(item, EX_WORDS, Random(5))
    assert sorted(payload["tokens"]) == sorted(payload["answer_tokens"])
    assert payload["tokens"] != payload["answer_tokens"]
    assert "".join(payload["answer_tokens"]) == "我是学生"


def test_fill_blank_blanks_the_target_word_and_has_valid_answer():
    payload = ex.get("fill_blank").build(EX_WORDS[2], EX_WORDS, Random(5))
    assert "＿＿" in payload["prompt"] and "学生" not in payload["prompt"]
    assert payload["options"][payload["answer_index"]] == "学生"


def test_new_types_require_at_least_one_example():
    no_example = ex_item(9, "无", "wú", "нет примеров")  # examples=[]
    assert not ex.get("fill_blank").requires(no_example, EX_WORDS)
    assert not ex.get("sentence_order").requires(no_example, EX_WORDS)


def test_sentence_exercises_reject_sentences_with_unknown_words():
    """Аудит: подтверждённый на живых данных баг — новое слово "我们" давало
    предложение "我们是朋友", где "是"/"朋友" пользователь никогда не видел.
    known_word_ids должен блокировать fill_blank/sentence_order в этом случае
    и разрешать их, когда остальные слова предложения помечены как known."""
    target = ex_item(4, "书", "shū", "книга", [
        {"sentence_cn": "我是书。", "sentence_ru": "Я книга.", "used_word_ids": [1, 2, 4]}])
    ctx_empty = {"known_word_ids": set()}
    assert not ex.get("fill_blank").requires(target, EX_WORDS, ctx_empty)
    assert not ex.get("sentence_order").requires(target, EX_WORDS, ctx_empty)

    ctx_known = {"known_word_ids": {1, 2}}  # "我"(1) и "是"(2) известны, "书"(4) — сама цель
    assert ex.get("fill_blank").requires(target, EX_WORDS, ctx_known)
    assert ex.get("sentence_order").requires(target, EX_WORDS, ctx_known)


def test_known_vocabulary_includes_lesson_words_and_previously_learned_words():
    from engine.lesson_planner import known_vocabulary

    new_items = [{"id": 4, "hanzi": "书"}]
    review_items = [{"id": 1, "hanzi": "我"}]
    pool = [{"id": 2, "hanzi": "是", "state": "review"}, {"id": 5, "hanzi": "水", "state": "new"},
            {"id": 6, "hanzi": "喝", "state": None}]
    known = known_vocabulary(new_items, review_items, pool)
    assert known == {4, 1, 2}  # новые+review слова урока (id 4,1), плюс уже изученное "是" (id 2); 5/6 — нет


def test_planner_never_places_unknown_words_in_a_fresh_lesson():
    """Сквозная проверка на реальном сценарии из аудита: у совершенно нового
    пользователя (все слова new) fill_blank/sentence_order никогда не берут
    слово, чьё предложение ссылается на слова вне этого же урока."""
    mastery = {**ZERO, "grammar": 0}
    words = [
        ex_item(1, "我们", "wǒmen", "мы", [
            {"sentence_cn": "我们是朋友。", "sentence_ru": "Мы друзья.", "used_word_ids": [1, 99, 98]}]),
        ex_item(2, "你", "nǐ", "ты", [
            {"sentence_cn": "你好。", "sentence_ru": "Привет.", "used_word_ids": [2, 97]}]),
    ]
    steps = plan_lesson(words, [], mastery, words, rng=Random(2))
    sentence_steps = [s for s in steps if s.type in ("fill_blank", "sentence_order")]
    assert not sentence_steps  # id 99/98/97 (是/朋友/好) не входят в этот мини-урок


def test_planner_can_use_grammar_types_and_skips_them_without_examples():
    mastery = {**ZERO, "characters": 90, "listening": 90, "pinyin": 90, "tones": 90, "writing": 90, "grammar": 0}
    with_ex = plan_lesson(EX_WORDS[:4], [], mastery, EX_WORDS, rng=Random(1))
    assert {s.type for s in with_ex} & {"fill_blank", "sentence_order"}
    assert len({s.type for s in with_ex if s.skill == "grammar"}) == 2   # оба типа — по ротации
    bare = [{**w, "examples": []} for w in EX_WORDS[:4]]
    no_ex = plan_lesson(bare, [], mastery, bare, rng=Random(1))
    assert not ({s.type for s in no_ex} & {"fill_blank", "sentence_order"})


def test_distractors_prefer_same_category():
    item = {"id": 1, "hanzi": "吃", "translation": "есть", "category": "еда"}
    pool = [item] + [{"id": i, "hanzi": f"食{i}", "translation": f"еда{i}", "category": "еда"} for i in range(2, 6)] + \
           [{"id": i, "hanzi": f"山{i}", "translation": f"гора{i}", "category": "природа"} for i in range(6, 12)]
    for seed in range(5):
        options = ex._distractors(item, pool, "translation", Random(seed))
        assert len(options) == 3 and all(o.startswith("еда") for o in options)


# ---- Phase D: бюджет, форма урока, анти-повтор ----

def test_compute_budget_scales_with_new_and_review():
    from engine.lesson_planner import REVIEW_CAP, compute_budget
    assert compute_budget(0) == 24  # DEFAULT_BUDGET, если daily_new_words не задан
    assert compute_budget(5) == 5 * 4 + REVIEW_CAP * 2
    assert compute_budget(3) < compute_budget(10)  # монотонность


def test_new_words_are_not_crowded_out_when_review_is_large():
    """Phase D, п.4: review не должен блокировать новое. С REVIEW_CAP=8
    просроченных слов и маленьким бюджетом новое всё равно должно попасть."""
    from engine.lesson_planner import REVIEW_CAP

    review = [{**WORDS[0], "id": 100 + i, "hanzi": f"复{i}", "state": "review"} for i in range(REVIEW_CAP)]
    steps = plan_lesson(WORDS[:2], review, ZERO, WORDS + review, budget=16, rng=Random(1))
    new_word_ids = {1, 2}
    assert any(s.word_id in new_word_ids and s.type == "introduction" for s in steps)


def test_review_does_not_disappear_when_new_words_present():
    """Обратная гарантия: обилие нового не должно вытеснять review целиком."""
    many_new = [{**WORDS[0], "id": 200 + i, "hanzi": f"新{i}", "state": "new"} for i in range(10)]
    review = [{**WORDS[4], "state": "review"}]
    steps = plan_lesson(many_new, review, ZERO, WORDS + many_new, rng=Random(1))
    assert any(s.word_id == 5 for s in steps)


def test_diversify_breaks_up_three_consecutive_same_type():
    from engine.lesson_planner import Step, _diversify_consecutive_types

    steps = [
        Step("recognition", "characters", 1, True, True),
        Step("recognition", "characters", 2, True, True),
        Step("recognition", "characters", 3, True, True),
        Step("listening", "listening", 4, True, True),
    ]
    fixed = _diversify_consecutive_types(steps)
    assert not any(fixed[i].type == fixed[i - 1].type == fixed[i - 2].type for i in range(2, len(fixed)))
    assert {s.word_id for s in fixed} == {1, 2, 3, 4}  # ничего не потеряно, только переставлено


def test_diversify_is_noop_when_already_fine():
    from engine.lesson_planner import Step, _diversify_consecutive_types

    steps = [Step("recognition", "characters", 1, True, True),
             Step("listening", "listening", 2, True, True),
             Step("recognition", "characters", 3, True, True)]
    assert [s.type for s in _diversify_consecutive_types(steps)] == ["recognition", "listening", "recognition"]
