"""
Phase B: тесты чистой логики scripts/import_hsk_vocabulary.py — на синтетических
данных, без сети и без реального датасета (тот проверяется вручную, см. отчёт).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.import_hsk_vocabulary import build_report, normalize_entry, pick_hsk_level


def entry(simplified, level, forms, pos=None, frequency=None):
    return {"simplified": simplified, "level": level, "forms": forms, "pos": pos, "frequency": frequency}


def form(meanings, pinyin="nǐ", numeric="ni3", traditional=None):
    return {"meanings": meanings, "transcriptions": {"pinyin": pinyin, "numeric": numeric},
            "traditional": traditional}


# ---------- pick_hsk_level ----------

def test_picks_earliest_old_level_present():
    assert pick_hsk_level(["old-3"]) == 3
    assert pick_hsk_level(["new-7", "old-2"]) == 2  # игнорирует new-*, берёт old-*
    assert pick_hsk_level(["old-1", "old-3"]) == 1  # самый ранний из нескольких


def test_no_old_tag_means_not_a_candidate():
    assert pick_hsk_level(["new-4", "newest-5"]) is None
    assert pick_hsk_level([]) is None


# ---------- normalize_entry: базовые поля ----------

def test_normalize_maps_dataset_fields():
    e = entry("你", ["old-1"], [form(["you"], pinyin="nǐ", numeric="ni3", traditional="你")], pos=["r"], frequency=100)
    n = normalize_entry(e)
    assert n["hanzi"] == "你" and n["pinyin"] == "nǐ" and n["pinyin_numeric"] == "ni3"
    assert n["translation"] == "you" and n["hsk"] == 1 and n["part_of_speech"] == "r" and n["frequency"] == 100


def test_multiple_meanings_joined_with_semicolon():
    e = entry("吃", ["old-1"], [form(["to eat", "to consume"])])
    assert normalize_entry(e)["translation"] == "to eat; to consume"


def test_missing_required_field_is_rejected():
    assert normalize_entry(entry("", ["old-1"], [form(["x"])])) is None  # нет simplified
    assert normalize_entry(entry("你", ["old-1"], [form([], pinyin="nǐ")])) is None  # нет meanings
    assert normalize_entry(entry("你", ["old-1"], [{"meanings": ["x"], "transcriptions": {}}])) is None  # нет pinyin
    assert normalize_entry(entry("你", [], [form(["x"])])) is None  # нет old-тега


# ---------- эвристика выбора основной формы (аудит Phase B) ----------

def test_prefers_form_with_most_meanings_over_surname_or_variant():
    # реальный кейс из датасета: 春 — "old variant of 春" / "surname Chun" / 7 значений
    e = entry("春", ["old-3"], [
        form(["old variant of 春"]),
        form(["surname Chun"]),
        form(["spring (season)", "gay", "joyful", "youthful", "love", "lust", "life"]),
    ])
    assert normalize_entry(e)["translation"].startswith("spring (season)")


def test_falls_back_to_first_form_when_all_are_reference_only():
    e = entry("云", ["old-2"], [form(["surname Yun; abbr. for Yunnan Province 云南省"])])
    n = normalize_entry(e)
    assert n is not None and "surname" in n["translation"]  # честно, не выдумываем лучший вариант


def test_tie_on_meaning_count_keeps_first_form_and_is_a_known_limitation():
    # реальный кейс: 告诉 — "press charges" vs "to tell", оба по 1 значению,
    # алгоритм не может это различить (нет сигнала в датасете) — фиксируем
    # текущее поведение явно, а не оставляем как случайность.
    e = entry("告诉", ["old-2"], [
        form(["to press charges; to file a complaint"]),
        form(["to tell; to inform; to let know"]),
    ])
    assert normalize_entry(e)["translation"] == "to press charges; to file a complaint"


# ---------- build_report: dedup / skip-existing / агрегаты ----------

def test_existing_hanzi_are_skipped_not_overwritten():
    entries = [entry("你", ["old-1"], [form(["you"])])]
    report = build_report(entries, existing_hanzi={"你"})
    assert report["to_insert"] == []
    assert report["already_in_our_db_kept_handwritten"] == 1


def test_duplicate_simplified_within_dataset_keeps_lowest_level():
    entries = [
        entry("的", ["old-3"], [form(["possessive particle"])]),
        entry("的", ["old-1"], [form(["possessive particle"])]),
    ]
    report = build_report(entries, existing_hanzi=set())
    assert len(report["to_insert"]) == 1
    assert report["to_insert"][0]["hsk"] == 1
    assert report["duplicates_within_dataset"] == 1


def test_multi_form_words_are_flagged_for_manual_review():
    entries = [entry("春", ["old-3"], [form(["a"]), form(["b", "c"])])]
    report = build_report(entries, existing_hanzi=set())
    assert report["entries_with_multiple_forms"] == 1
    assert any(h == "春" for h, _ in report["ambiguous_needs_manual_review"])


def test_report_by_level_counts_match_to_insert():
    entries = [
        entry("一", ["old-1"], [form(["one"])]),
        entry("二", ["old-1"], [form(["two"])]),
        entry("三", ["old-3"], [form(["three"])]),
    ]
    report = build_report(entries, existing_hanzi=set())
    assert report["by_level"] == {1: 2, 3: 1}
