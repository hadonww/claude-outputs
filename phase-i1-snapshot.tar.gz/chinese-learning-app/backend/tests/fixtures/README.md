# Тестовые данные

`hsk12_dataset.json` — выборка датасета [drkameleon/complete-hsk-vocabulary](https://github.com/drkameleon/complete-hsk-vocabulary)
(лицензия MIT, коммит `7ac65bf`): все записи с тегом `old-1` или `old-2` (HSK 2.0, уровни 1–2), без изменений.
Нужна, чтобы тесты строили настоящую базу курса HSK 1 (`scripts/build_course_db.py`) без полного
датасета (9,7 МБ) и проверяли весь маршрут HSK 1 последовательно (`scripts/validate_hsk1_course.py`).

Пересобрать: взять из полного `complete.json` записи, у которых в `level` есть `old-1` или `old-2`. Уровень 2 нужен, чтобы раскладка слов по модулям HSK 1 совпадала с полной базой (крошечные группы уровня 2 иначе сливаются с уровнем 1).
