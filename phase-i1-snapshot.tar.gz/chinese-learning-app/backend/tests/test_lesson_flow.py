"""Module -> Lesson -> Exercise -> Attempt -> Mastery/SRS -> прогресс пути (через API)."""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from engine.scoring import derive_srs_quality


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_flow.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def first_module(client):
    return min(client.get("/api/learning-path").json()["modules"], key=lambda m: m["order_index"])


def mastery(client):
    from app.db import get_db
    from app.repositories import mastery_repo

    with get_db() as conn:
        return mastery_repo.get_all_mastery(conn, 1)


def test_plan_has_steps_from_planner_only_of_this_module(client):
    m = first_module(client)
    plan = client.get(f"/api/lessons/{m['id']}/plan").json()
    assert plan["steps"]
    assert plan["steps"][0]["type"] == "introduction"
    assert {s["type"] for s in plan["steps"]} >= {"introduction", "recognition"}
    module_word_ids = {w["id"] for w in plan["new_words"]}
    assert {s["word_id"] for s in plan["steps"]} <= module_word_ids


def test_graded_attempt_is_saved_and_updates_mastery(client):
    m = first_module(client)
    plan = client.get(f"/api/lessons/{m['id']}/plan").json()
    step = next(s for s in plan["steps"] if s["type"] == "recognition")
    assert mastery(client)["characters"] == 0

    res = client.post(f"/api/lessons/{m['id']}/attempts", json={
        "word_id": step["word_id"], "exercise_type": "recognition", "correct": True}).json()
    assert res["skill"] == "characters" and res["mastery"] == 20
    assert mastery(client)["characters"] == 20

    from app.db import get_db
    from app.repositories import attempts_repo
    with get_db() as conn:
        assert attempts_repo.count_attempts(conn, 1) == 1


def test_wrong_answer_lowers_mastery(client):
    m = first_module(client)
    wid = client.get(f"/api/lessons/{m['id']}/plan").json()["steps"][0]["word_id"]
    for _ in range(2):
        client.post(f"/api/lessons/{m['id']}/attempts",
                    json={"word_id": wid, "exercise_type": "listening", "correct": True})
    client.post(f"/api/lessons/{m['id']}/attempts",
                json={"word_id": wid, "exercise_type": "listening", "correct": False})
    assert mastery(client)["listening"] < 36  # 20 -> 36 -> ниже после ошибки


def test_srs_updates_only_on_final_step(client):
    m = first_module(client)
    wid = client.get(f"/api/lessons/{m['id']}/plan").json()["steps"][0]["word_id"]
    before = client.get("/api/home").json()["learned_count"]
    client.post(f"/api/lessons/{m['id']}/attempts",
                json={"word_id": wid, "exercise_type": "recognition", "correct": True})
    assert client.get("/api/home").json()["learned_count"] == before  # не финальный

    res = client.post(f"/api/lessons/{m['id']}/attempts", json={
        "word_id": wid, "exercise_type": "pinyin_choice", "correct": True, "final": True}).json()
    assert res["srs"]["state"] == "learning"
    assert client.get("/api/home").json()["learned_count"] == before + 1


def test_introduction_is_not_graded(client):
    m = first_module(client)
    wid = client.get(f"/api/lessons/{m['id']}/plan").json()["steps"][0]["word_id"]
    res = client.post(f"/api/lessons/{m['id']}/attempts",
                      json={"word_id": wid, "exercise_type": "introduction", "correct": True}).json()
    assert res["skill"] is None and res["mastery"] is None


def test_completing_words_moves_learning_path_progress(client):
    m = first_module(client)
    plan = client.get(f"/api/lessons/{m['id']}/plan").json()
    for wid in {s["word_id"] for s in plan["steps"]}:
        client.post(f"/api/lessons/{m['id']}/attempts", json={
            "word_id": wid, "exercise_type": "recognition", "correct": True, "final": True})
    after = next(x for x in client.get("/api/learning-path").json()["modules"] if x["id"] == m["id"])
    assert after["learned_words"] == len({s["word_id"] for s in plan["steps"]})
    assert after["state"] == "in_progress"


def test_planner_adapts_after_attempts(client):
    m = first_module(client)
    a = [s["type"] for s in client.get(f"/api/lessons/{m['id']}/plan").json()["steps"]]
    wid = client.get(f"/api/lessons/{m['id']}/plan").json()["steps"][0]["word_id"]
    for _ in range(12):  # высокий characters/listening/pinyin/writing, слабые tones
        for t in ("recognition", "listening", "pinyin_choice", "handwriting"):
            client.post(f"/api/lessons/{m['id']}/attempts",
                        json={"word_id": wid, "exercise_type": t, "correct": True})
    b = [s["type"] for s in client.get(f"/api/lessons/{m['id']}/plan").json()["steps"]]
    assert a != b
    assert b.count("tone_choice") > a.count("tone_choice")   # слабые tones получили больше упражнений
    assert b.count("recognition") < a.count("recognition")   # сильные characters — меньше


def test_word_from_another_module_is_rejected(client):
    a, b = sorted(client.get("/api/learning-path").json()["modules"], key=lambda m: m["order_index"])[:2]
    other = client.get(f"/api/lessons/{b['id']}/plan").json()["new_words"][0]["id"]
    res = client.post(f"/api/lessons/{a['id']}/attempts",
                      json={"word_id": other, "exercise_type": "recognition", "correct": True})
    assert res.status_code == 400


def test_unknown_type_and_module(client):
    m = first_module(client)
    wid = client.get(f"/api/lessons/{m['id']}/plan").json()["steps"][0]["word_id"]
    assert client.post(f"/api/lessons/{m['id']}/attempts",
                       json={"word_id": wid, "exercise_type": "nope", "correct": True}).status_code == 400
    assert client.post("/api/lessons/999999/attempts",
                       json={"word_id": wid, "exercise_type": "recall", "correct": True}).status_code == 404


def test_derive_srs_quality_rules():
    assert derive_srs_quality(0, 0) == 2                      # только показали
    assert derive_srs_quality(0, 3) == 2                      # без ошибок
    assert derive_srs_quality(1, 3) == 1                      # ошибка в трети -> "сложно"
    assert derive_srs_quality(2, 3) == 0                      # больше трети -> не выучено
    assert derive_srs_quality(0, 3, recall_quality=3) == 3    # самооценка "легко"
    assert derive_srs_quality(1, 3, recall_quality=3) == 1    # ошибки ограничивают оценку


def test_one_skipped_step_does_not_erase_correct_answers(client):
    m = first_module(client)
    wid = client.get(f"/api/lessons/{m['id']}/plan").json()["steps"][0]["word_id"]
    res = client.post(f"/api/lessons/{m['id']}/attempts", json={
        "word_id": wid, "exercise_type": "handwriting", "correct": False,
        "final": True, "mistakes": 1, "attempts_total": 4}).json()
    assert res["srs"]["state"] == "learning"  # 1 ошибка из 4 -> слово засчитано
