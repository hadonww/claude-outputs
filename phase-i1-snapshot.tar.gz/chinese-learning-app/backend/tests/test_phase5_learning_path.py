"""
Тесты Phase 5: правило "первый не completed модуль по маршруту курса"
проверяется fixture-сценариями на реальной схеме (через test-БД, как в
test_phase2_domain_model.py), не моками.
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture(scope="module")
def conn():
    from app import db as db_module

    tmp_dir = tempfile.mkdtemp()
    db_module.DB_PATH = Path(tmp_dir) / "test_phase5.db"
    db_module.init_db()

    with db_module.get_db() as c:
        yield c


def test_module_state_helper():
    from app.services.learning_path_service import _module_state

    assert _module_state(total_words=0, learned_words=0) == "not_started"
    assert _module_state(total_words=10, learned_words=0) == "not_started"
    assert _module_state(total_words=10, learned_words=5) == "in_progress"
    assert _module_state(total_words=10, learned_words=10) == "completed"
    assert _module_state(total_words=10, learned_words=12) == "completed"  # не падает на edge case


def test_learning_path_shape_and_module_count(conn):
    from app.services import learning_path_service

    path = learning_path_service.get_learning_path(conn)
    assert "modules" in path and "recommended_module_id" in path
    assert len({m["category"] for m in path["modules"]}) == 16  # 16 категорий из seed_data.json (Phase 2)
    assert len(path["modules"]) > 16                               # тема × уровень HSK
    for m in path["modules"]:
        for key in ("id", "order_index", "title", "total_words", "learned_words",
                    "progress_percent", "state"):
            assert key in m


def test_fresh_db_recommends_first_module_in_order(conn):
    from app.services import learning_path_service

    path = learning_path_service.get_learning_path(conn)
    first_on_route = path["modules"][0]  # порядок ответа = порядок маршрута (app/curriculum.py)
    assert path["recommended_module_id"] == first_on_route["id"]
    assert first_on_route["state"] == "not_started"


def test_recommendation_advances_once_first_module_is_touched(conn):
    from app.repositories import progress_repo
    from app.services import learning_path_service

    path_before = learning_path_service.get_learning_path(conn)
    first_module = path_before["modules"][0]  # первый по маршруту

    # находим одно слово из категории первого модуля и "изучаем" его
    word = conn.execute(
        "SELECT id FROM words WHERE category = ? LIMIT 1", (first_module["category"],)
    ).fetchone()
    row = progress_repo.get_progress_row(conn, word["id"])
    from srs import ReviewState
    from srs import review as srs_review

    state = ReviewState(row["repetitions"], row["ease_factor"], row["interval_days"])
    new_state, due = srs_review(state, quality_button=2, today=None)
    progress_repo.update_progress_after_review(
        conn, word["id"], new_state, due.isoformat(), "2026-01-15", is_correct=1
    )

    path_after = learning_path_service.get_learning_path(conn)
    updated_first = next(m for m in path_after["modules"] if m["id"] == first_module["id"])
    assert updated_first["state"] == "in_progress"
    assert updated_first["learned_words"] == 1
    # рекомендация остаётся тем же модулем, пока он не completed (только in_progress)
    assert path_after["recommended_module_id"] == first_module["id"]
