"""Маршрут курса: разделы, порядок отдельно от order_index, статусы Completed/Current/Locked."""

import ast
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from app import curriculum as cur

ALL_CATEGORIES = {
    "люди", "числа", "время", "действия", "семья", "дом", "эмоции", "повседневная жизнь",
    "еда", "покупки", "школа", "работа", "технологии", "транспорт", "путешествия", "природа",
    "грамматика",  # служебные слова HSK (частицы, союзы, вопросительные) — подключены вместе с HSK1-3
}
# темы, появляющиеся только с HSK 4 (data/hsk4_course_map.tsv)
HSK4_CATEGORIES = {
    "изменения и процессы", "характер", "здоровье и спорт", "культура и досуг", "общество",
    "мнения и рассуждения", "абстрактные понятия", "качества и свойства", "оценка и модальность",
    "наречия времени", "союзы и связки",
}


# ---------- чистая логика маршрута ----------

def fake(i, category, state="not_started", order_index=None):
    return {"id": i, "category": category, "order_index": order_index or i, "state": state}


def test_route_covers_every_seeded_category_exactly_once():
    listed = [c for s in cur.ROUTE_SECTIONS for c in s.categories]
    assert len(listed) == len(set(listed)) == len(ALL_CATEGORIES | HSK4_CATEGORIES) == 28
    assert set(listed) == ALL_CATEGORIES | HSK4_CATEGORIES
    assert all(cur.module_description(c) for c in listed)  # у каждой темы есть описание
    assert listed[:4] == ["люди", "числа", "время", "действия"]  # требование владельца к порядку


def test_route_order_ignores_order_index_and_adds_section_fields():
    modules = [fake(1, "еда", order_index=1), fake(2, "люди", order_index=2), fake(3, "числа", order_index=3)]
    ordered = cur.route_order(modules)
    assert [m["category"] for m in ordered] == ["люди", "числа", "еда"]
    assert [m["route_index"] for m in ordered] == [0, 1, 2]
    assert ordered[0]["section_id"] == "basics" and ordered[0]["section_title_zh"] == "基础"
    assert [m["position_in_section"] for m in ordered] == [0, 1, 0]
    assert modules[0]["order_index"] == 1 and "route_index" not in modules[0]  # вход не мутируется


def test_unknown_category_goes_to_extra_section_at_the_end():
    ordered = cur.route_order([fake(1, "новая", order_index=1), fake(2, "люди", order_index=2)])
    assert [m["category"] for m in ordered] == ["люди", "новая"]
    assert ordered[1]["section_id"] == "extra"


def test_statuses_completed_current_locked():
    mods = cur.route_order([fake(1, "люди", "completed"), fake(2, "числа"), fake(3, "время")])
    statuses, current = cur.compute_statuses(mods)
    assert current == 2
    assert statuses == {1: "completed", 2: "current", 3: "locked"}


def test_all_completed_means_no_current():
    mods = cur.route_order([fake(1, "люди", "completed"), fake(2, "числа", "completed")])
    statuses, current = cur.compute_statuses(mods)
    assert current is None and set(statuses.values()) == {"completed"}


def test_linearity_is_policy_not_structure_unlock_opens_a_locked_module():
    mods = cur.route_order([fake(1, "люди"), fake(2, "числа"), fake(3, "время")])
    statuses, current = cur.compute_statuses(mods, unlocked_ids={3})
    assert current == 1                              # рекомендация не меняется
    assert statuses == {1: "current", 2: "locked", 3: "available"}


def test_started_work_is_never_locked():
    mods = cur.route_order([fake(1, "люди"), fake(2, "числа", "in_progress")])
    assert cur.compute_statuses(mods)[0][2] == "available"


def test_curriculum_module_is_pure():
    tree = ast.parse(Path(cur.__file__).read_text(encoding="utf-8"))
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported |= {a.name.split(".")[0] for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module.split(".")[0])
    assert not imported & {"fastapi", "sqlite3", "starlette", "pydantic"}


# ---------- через API и БД ----------

@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_route.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def path(client):
    return client.get("/api/learning-path").json()


def test_module_order_index_in_db_is_untouched(client):
    from app.db import get_db

    with get_db() as conn:
        rows = conn.execute("SELECT category FROM modules ORDER BY order_index").fetchall()
    assert rows[0]["category"] == "действия"          # как при сидировании: по числу слов
    assert [r["category"] for r in rows][:3] == ["действия", "школа", "еда"]


def test_api_returns_modules_in_route_order_with_contiguous_sections(client):
    body = path(client)
    mods = body["modules"]
    assert [m["category"] for m in mods[:4]] == ["люди", "числа", "время", "действия"]
    assert [m["route_index"] for m in mods] == list(range(len(mods)))
    levels = [m["hsk_level"] for m in mods]
    assert levels == sorted(levels)                    # HSK1 целиком раньше HSK2, HSK2 раньше HSK3
    keys = [m["section_key"] for m in mods]
    assert all(keys.index(k) + keys.count(k) - 1 == max(i for i, x in enumerate(keys) if x == k)
               for k in set(keys))                     # каждая глава (раздел × уровень) — сплошной блок
    first_level = [m["section_id"] for m in mods if m["hsk_level"] == 1]
    assert list(dict.fromkeys(first_level)) == ["basics", "everyday", "food", "study_work", "world"]
    assert "extra" not in {m["section_id"] for m in mods}
    assert all(m["section_title"].endswith(f"HSK {m['hsk_level']}") for m in mods)
    assert all(m["total_words"] > 0 for m in mods)      # пустые модули не попадают в путь


def test_fresh_path_has_one_current_and_rest_locked(client):
    body = path(client)
    statuses = [m["status"] for m in body["modules"]]
    assert statuses[0] == "current" and set(statuses[1:]) == {"locked"}
    assert body["recommended_module_id"] == body["modules"][0]["id"]


def test_top_level_contract_and_state_field_unchanged(client):
    body = path(client)
    assert set(body) == {"modules", "recommended_module_id"}
    assert {m["state"] for m in body["modules"]} == {"not_started"}


def test_finishing_a_module_moves_current_to_next_on_the_route(client):
    first = path(client)["modules"][0]
    words = [w for w in client.get("/api/words", params={"category": first["category"]}).json()
             if w["module_id"] == first["id"]]
    for w in words:
        client.post(f"/api/lessons/{first['id']}/attempts", json={
            "word_id": w["id"], "exercise_type": "recognition", "correct": True, "final": True})
    body = path(client)
    assert [m["status"] for m in body["modules"][:3]] == ["completed", "current", "locked"]
    assert body["modules"][1]["category"] == "числа"
    assert body["recommended_module_id"] == body["modules"][1]["id"]


def test_service_accepts_unlock_override_without_changing_route_or_data(client):
    from app.db import get_db
    from app.services import learning_path_service

    target = next(m for m in path(client)["modules"] if m["category"] == "еда")
    with get_db() as conn:
        result = learning_path_service.get_learning_path(conn, unlocked_ids={target["id"]})
    by_id = {m["id"]: m for m in result["modules"]}
    first_of = {}
    for m in result["modules"]:
        first_of.setdefault(m["category"], m)
    assert by_id[target["id"]]["status"] == "available"
    assert first_of["люди"]["status"] == "current" and first_of["школа"]["status"] == "locked"
    assert result["modules"][0]["category"] == "люди"


def test_touching_a_later_module_does_not_lock_it_again(client):
    food = next(m for m in path(client)["modules"] if m["category"] == "еда")
    word = next(w for w in client.get("/api/words", params={"category": "еда"}).json()
                if w["module_id"] == food["id"])
    client.post(f"/api/lessons/{food['id']}/attempts", json={
        "word_id": word["id"], "exercise_type": "recognition", "correct": True, "final": True})
    mods = path(client)["modules"]
    by_id = {m["id"]: m for m in mods}
    assert by_id[food["id"]]["status"] == "available" and mods[0]["category"] == "люди"
    assert mods[0]["status"] == "current"
