"""Словарь: фильтр "встречались" — только слова, по которым уже были ответы."""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_dict.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def test_seen_is_empty_for_new_user_and_grows_after_lesson(client):
    assert client.get("/api/words", params={"seen": True}).json() == []
    m = min(client.get("/api/learning-path").json()["modules"], key=lambda m: m["order_index"])
    word = client.get(f"/api/lessons/{m['id']}/plan").json()["new_words"][0]
    client.post(f"/api/lessons/{m['id']}/attempts", json={
        "word_id": word["id"], "exercise_type": "recognition", "correct": True, "final": True})
    seen = client.get("/api/words", params={"seen": True}).json()
    assert [w["id"] for w in seen] == [word["id"]]
    assert len(client.get("/api/words").json()) > 1  # обычный поиск по-прежнему по всей базе
