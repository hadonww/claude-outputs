"""
Smoke/contract-тесты поверх FastAPI TestClient (Phase 1, PLAN_WB_v1.md).

Проверяют, что API отвечает так же, как до разбивки main.py на слои —
это не повторное тестирование бизнес-логики (для неё — engine-тесты в
будущих фазах), а гарантия, что рефакторинг не сломал контракт, которым
пользуется существующий web-фронтенд.

Используют отдельную временную SQLite-базу (не трогают backend/app.db).
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture(scope="module")
def client():
    from app import db as db_module

    tmp_dir = tempfile.mkdtemp()
    # Патчим атрибут уже импортированного модуля напрямую (а не app.config) —
    # надёжно работает независимо от порядка запуска тестовых файлов.
    db_module.DB_PATH = Path(tmp_dir) / "test_api_smoke.db"
    # явно, а не через импорт main: main мог быть уже импортирован другим тестовым файлом
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app as fastapi_app

    return TestClient(fastapi_app)


# ---------------------------------------------------------------------------
# /api/home, /api/session
# ---------------------------------------------------------------------------

def test_home_returns_expected_shape(client):
    res = client.get("/api/home")
    assert res.status_code == 200
    body = res.json()
    for key in ("due_review_count", "new_words_available", "learned_count",
                "total_words", "progress_percent", "streak"):
        assert key in body
    assert body["total_words"] > 0  # seed_data.json засеян


def test_session_returns_new_words_on_fresh_db(client):
    res = client.get("/api/session")
    assert res.status_code == 200
    body = res.json()
    assert "review_words" in body and "new_words" in body
    assert len(body["new_words"]) > 0
    assert body["review_words"] == []  # ничего ещё не изучалось


def test_session_respects_explicit_limit(client):
    res = client.get("/api/session?limit=3")
    assert len(res.json()["new_words"]) == 3


# ---------------------------------------------------------------------------
# /api/review — полный цикл SM-2 через API
# ---------------------------------------------------------------------------

def test_review_updates_progress_and_returns_next_due_date(client):
    word_id = client.get("/api/session?limit=1").json()["new_words"][0]["id"]

    res = client.post("/api/review", json={"word_id": word_id, "quality": 2})
    assert res.status_code == 200
    body = res.json()
    assert body["state"] == "learning"
    assert body["interval_days"] == 1

    # то же слово больше не должно быть в new_words
    new_ids = [w["id"] for w in client.get("/api/session").json()["new_words"]]
    assert word_id not in new_ids


def test_review_rejects_invalid_quality(client):
    res = client.post("/api/review", json={"word_id": 1, "quality": 9})
    assert res.status_code == 400


def test_review_404_for_unknown_word(client):
    res = client.post("/api/review", json={"word_id": 999999, "quality": 2})
    assert res.status_code == 404


# ---------------------------------------------------------------------------
# /api/words, /api/categories
# ---------------------------------------------------------------------------

def test_get_word_by_id(client):
    res = client.get("/api/words/1")
    assert res.status_code == 200
    body = res.json()
    assert body["id"] == 1
    assert "hanzi" in body and "pinyin" in body


def test_get_word_404(client):
    assert client.get("/api/words/999999").status_code == 404


def test_search_words_by_translation(client):
    res = client.get("/api/words", params={"q": "я"})
    assert res.status_code == 200
    assert len(res.json()) > 0


def test_categories_nonempty(client):
    res = client.get("/api/categories")
    assert res.status_code == 200
    cats = res.json()
    assert len(cats) > 0
    assert all("name" in c and "count" in c for c in cats)


# ---------------------------------------------------------------------------
# /api/profile
# ---------------------------------------------------------------------------

def test_profile_shape(client):
    res = client.get("/api/profile")
    assert res.status_code == 200
    body = res.json()
    for key in ("streak", "total_words", "learned_count", "mastered_count",
                "accuracy", "by_level", "weak_words", "week_activity"):
        assert key in body
    assert len(body["week_activity"]) == 7


# ---------------------------------------------------------------------------
# /api/settings
# ---------------------------------------------------------------------------

def test_settings_get_defaults(client):
    res = client.get("/api/settings")
    assert res.status_code == 200
    body = res.json()
    assert body["daily_new_words"] == 5  # снижено с 8: меньше нового, больше закрепления (аудит, п.1)
    assert body["preferred_hsk"] == 1
    assert body["onboarded"] is False


def test_settings_update_roundtrip(client):
    res = client.post("/api/settings", json={"daily_new_words": 12, "onboarded": True})
    assert res.status_code == 200
    body = res.json()
    assert body["daily_new_words"] == 12
    assert body["onboarded"] is True

    # эффект виден в /api/session (см. build_session: effective_limit из stats)
    session = client.get("/api/session").json()
    assert len(session["new_words"]) <= 12


def test_settings_update_empty_payload_rejected(client):
    assert client.post("/api/settings", json={}).status_code == 400


# ---------------------------------------------------------------------------
# /api/import-csv
# ---------------------------------------------------------------------------

def test_import_csv_adds_new_word(client):
    csv_text = "hanzi,pinyin,translation,hsk,category\n测试,cèshì,тест,3,технологии\n"
    res = client.post("/api/import-csv", json={"csv": csv_text})
    assert res.status_code == 200
    body = res.json()
    assert body["added"] == 1

    found = client.get("/api/words", params={"q": "测试"}).json()
    assert any(w["hanzi"] == "测试" for w in found)


def test_import_csv_skips_duplicates(client):
    csv_text = "hanzi,pinyin,translation,hsk\n测试,cèshì,тест,3\n"
    res = client.post("/api/import-csv", json={"csv": csv_text})
    assert res.json() == {"added": 0, "skipped": 1}


def test_import_csv_rejects_empty(client):
    assert client.post("/api/import-csv", json={"csv": ""}).status_code == 400
