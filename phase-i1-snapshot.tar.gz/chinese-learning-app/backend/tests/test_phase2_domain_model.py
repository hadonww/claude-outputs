"""
Repository-тесты Phase 2 (PLAN_WB_v1.md): создание mastery-записи,
инкрементальное обновление, выборка модулей/уроков, запись attempt.

Использует отдельную временную БД (та же схема через app.db.init_db()),
не трогает backend/app.db.
"""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture(scope="module")
def conn():
    from app import db as db_module

    tmp_dir = tempfile.mkdtemp()
    # Патчим атрибут уже импортированного модуля напрямую (а не app.config),
    # чтобы это работало независимо от того, что было импортировано раньше
    # в этом же pytest-процессе другими тестовыми файлами.
    db_module.DB_PATH = Path(tmp_dir) / "test_phase2.db"
    db_module.init_db()

    with db_module.get_db() as c:
        yield c


# ---------------------------------------------------------------------------
# skills / mastery
# ---------------------------------------------------------------------------

def test_all_eight_skills_seeded(conn):
    from app.config import SKILLS

    names = {r["name"] for r in conn.execute("SELECT name FROM skills")}
    assert names == set(SKILLS)


def test_mastery_seeded_zero_for_every_skill(conn):
    from app.repositories import mastery_repo

    mastery = mastery_repo.get_all_mastery(conn, user_id=1)
    assert len(mastery) == 8
    assert all(score == 0 for score in mastery.values())


def test_mastery_incremental_update(conn):
    from app.repositories import mastery_repo

    mastery_repo.set_mastery_score(conn, user_id=1, skill="tones", score=42.5, updated_at_iso="2026-01-15")
    assert mastery_repo.get_mastery_score(conn, user_id=1, skill="tones") == 42.5

    # обновление существующей записи (upsert), а не дубликат
    mastery_repo.set_mastery_score(conn, user_id=1, skill="tones", score=55.0, updated_at_iso="2026-01-16")
    assert mastery_repo.get_mastery_score(conn, user_id=1, skill="tones") == 55.0
    rows = conn.execute(
        "SELECT COUNT(*) c FROM mastery WHERE user_id = 1 AND skill = 'tones'"
    ).fetchone()
    assert rows["c"] == 1


def test_mastery_rejects_unknown_skill(conn):
    from app.repositories import mastery_repo

    with pytest.raises(ValueError):
        mastery_repo.set_mastery_score(conn, user_id=1, skill="telepathy", score=10, updated_at_iso="2026-01-15")


# ---------------------------------------------------------------------------
# modules / lessons
# ---------------------------------------------------------------------------

def test_modules_populated_from_categories(conn):
    from app.curriculum import plan_course_modules
    from app.repositories import modules_repo

    modules = modules_repo.list_modules(conn)
    words = [dict(r) for r in conn.execute("SELECT id, category, hsk FROM words")]
    plan = plan_course_modules(words)
    # модуль = тема × уровень HSK (16 тем seed_data.json, мелкие группы слиты с соседним уровнем)
    assert {(m["category"], m["hsk_level"]) for m in modules} == set(plan)
    assert len({m["category"] for m in modules}) == 16
    # отсортированы по order_index (по убыванию количества слов на момент сидирования)
    assert [m["order_index"] for m in modules] == sorted(m["order_index"] for m in modules)


def test_each_module_has_at_least_one_lesson(conn):
    from app.repositories import modules_repo

    modules = modules_repo.list_modules(conn)
    for m in modules:
        lessons = modules_repo.list_lessons_for_module(conn, m["id"])
        assert len(lessons) >= 1


def test_get_module_and_lesson_by_id(conn):
    from app.repositories import modules_repo

    module = modules_repo.get_module(conn, 1)
    assert module is not None
    lesson = modules_repo.get_lesson(conn, 1)
    assert lesson is not None
    assert lesson["module_id"] == module["id"]


# ---------------------------------------------------------------------------
# attempts
# ---------------------------------------------------------------------------

def test_insert_and_list_attempt(conn):
    from app.repositories import attempts_repo

    attempts_repo.insert_attempt(
        conn, user_id=1, exercise_type="vocab_cn_ru", skill="vocabulary",
        content_item_id=1, correct=True, created_at_iso="2026-01-15T10:00:00",
    )
    rows = attempts_repo.list_attempts_for_skill(conn, user_id=1, skill="vocabulary")
    assert len(rows) == 1
    assert rows[0]["correct"] == 1
    assert attempts_repo.count_attempts(conn, user_id=1) == 1


def test_insert_attempt_rejects_unknown_skill(conn):
    from app.repositories import attempts_repo

    with pytest.raises(ValueError):
        attempts_repo.insert_attempt(
            conn, user_id=1, exercise_type="x", skill="telepathy",
            content_item_id=1, correct=True, created_at_iso="2026-01-15T10:00:00",
        )
