"""tone_choice по слогам: разбор пиньиня, payload, проверка ответа (engine, без БД)."""

import sys
from pathlib import Path
from random import Random

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine import exercise_types as ex
from engine.answer_check import AnswerError, check_answer
from engine.syllables import split_syllables


def word(hanzi, pinyin, wid=1):
    return {"id": wid, "hanzi": hanzi, "pinyin": pinyin, "translation": "-"}


def build(hanzi, pinyin):
    return ex.get("tone_choice").build(word(hanzi, pinyin), [], Random(0))


def tones_of(p):
    return [t for t, s in zip(p["answers"], p["syllables"]) if s["tested"]]


# ---------- разбор на слоги ----------

@pytest.mark.parametrize("pinyin, hanzi, expected", [
    ("nǐ", "你", [("nǐ", 3, "你")]),
    ("Zhōngguó", "中国", [("zhōng", 1, "中"), ("guó", 2, "国")]),
    ("kěnéng", "可能", [("kě", 3, "可"), ("néng", 2, "能")]),            # не kěn|éng
    ("gōnggòng qìchē", "公共汽车", [("gōng", 1, "公"), ("gòng", 4, "共"), ("qì", 4, "汽"), ("chē", 1, "车")]),
    ("diàn zǐ yóu jiàn", "电子邮件", [("diàn", 4, "电"), ("zǐ", 3, "子"), ("yóu", 2, "邮"), ("jiàn", 4, "件")]),
    ("nǚ'ér", "女儿", [("nǚ", 3, "女"), ("ér", 2, "儿")]),
    ("xièxie", "谢谢", [("xiè", 4, "谢"), ("xie", None, "谢")]),
    ("yìdiǎnr", "一点儿", [("yì", 4, "一"), ("diǎnr", 3, "点儿")]),
    ("yī huì r", "一会儿", [("yī", 1, "一"), ("huìr", 4, "会儿")]),
])
def test_split_syllables(pinyin, hanzi, expected):
    assert [(s.text, s.tone, s.hanzi) for s in split_syllables(pinyin, hanzi)] == expected


def test_split_rejects_non_pinyin():
    assert split_syllables("abc123", "?") is None
    assert split_syllables("", "?") is None


def test_with_tone_keeps_mark_position():
    s = split_syllables("guó", "国")[0]
    assert [s.with_tone(t) for t in (1, 2, 3, 4)] == ["guō", "guó", "guǒ", "guò"]


# ---------- payload ----------

def test_single_syllable_payload():
    p = build("你", "nǐ")
    assert p["question"] == "Послушайте: какой тон?" and p["audio"] == "你"
    assert p["syllables"] == [{"hanzi": "你", "base": "ni", "tested": True, "options": ["nī", "ní", "nǐ", "nì"]}]
    assert p["answers"] == [3]


def test_two_syllable_payload_tests_both_syllables():
    p = build("电子", "diànzǐ")
    assert [s["base"] for s in p["syllables"]] == ["dian", "zi"]
    assert all(s["tested"] for s in p["syllables"])
    assert p["syllables"][1]["options"] == ["zī", "zí", "zǐ", "zì"]
    assert p["answers"] == [4, 3]
    assert p["question"] == "Послушайте: какие тоны?"


def test_client_fields_do_not_depend_on_the_answer():
    """Всё, кроме answers (его клиент не получает), одинаково для слов, различающихся только тоном."""
    a, b = build("买", "mǎi"), build("卖", "mài")
    assert set(a) == {"prompt", "audio", "question", "syllables", "answers"}
    assert a["syllables"][0]["options"] == b["syllables"][0]["options"] == ["māi", "mái", "mǎi", "mài"]
    assert (a["answers"], b["answers"]) == ([3], [4])


def test_neutral_syllable_shown_but_not_tested():
    p = build("谢谢", "xièxie")
    assert [s["tested"] for s in p["syllables"]] == [True, False]
    assert p["syllables"][1] == {"hanzi": "谢", "base": "xie", "tested": False, "options": None}
    assert p["answers"] == [4, None]
    assert p["question"] == "Послушайте: какой тон?"   # проверяется один слог


def test_requires_at_least_one_toned_syllable():
    req = ex.get("tone_choice").requires
    assert req(word("电子", "diànzǐ"), [])
    assert req(word("谢谢", "xièxie"), [])
    assert not req(word("们", "men"), [])
    assert not req(word("?", "abc123"), [])


# ---------- проверка ответа ----------

def test_single_syllable_correct_and_wrong():
    p = build("你", "nǐ")
    assert check_answer("tone_choice", p, {"tones": [3]})["correct"]
    assert check_answer("tone_choice", p, 3)["correct"]           # одно число для одного слога
    res = check_answer("tone_choice", p, {"tones": [2]})
    assert not res["correct"] and res["expected"] == "nǐ"
    assert res["explanation"] == "Правильно: nǐ — 3-й (нисходяще-восходящий) тон."


def test_multi_syllable_fully_correct():
    p = build("公共汽车", "gōnggòng qìchē")
    res = check_answer("tone_choice", p, {"tones": [1, 4, 4, 1]})
    assert res["correct"] and res["explanation"] is None
    assert res["expected"] == "gōng gòng qì chē"
    assert all(d["correct"] for d in res["syllables"])


def test_multi_syllable_partially_correct_names_wrong_syllables():
    p = build("公共汽车", "gōnggòng qìchē")
    res = check_answer("tone_choice", p, {"tones": [1, 2, 4, 3]})
    assert not res["correct"]
    assert [d["correct"] for d in res["syllables"]] == [True, False, True, False]
    assert "共 gòng — 4-й (нисходящий), а не 2-й" in res["explanation"]
    assert "车 chē — 1-й (ровный), а не 3-й" in res["explanation"]
    assert "公" not in res["explanation"] and "汽" not in res["explanation"]
    assert res["explanation"].startswith("Неверные тоны в слогах:")
    assert res["explanation"].endswith("Остальные слоги — верно.")


def test_only_first_syllable_right_is_not_enough():
    """Раньше проверялся только первый слог; теперь ошибка во втором — ошибка."""
    p = build("电子", "diànzǐ")
    res = check_answer("tone_choice", p, {"tones": [4, 1]})
    assert not res["correct"]
    assert res["explanation"] == "Неверный тон в слоге: 子 zǐ — 3-й (нисходяще-восходящий), а не 1-й. Остальные слоги — верно."


def test_all_syllables_wrong():
    p = build("电子", "diànzǐ")
    res = check_answer("tone_choice", p, {"tones": [1, 1]})
    assert not res["correct"] and "Остальные" not in res["explanation"]
    assert "电 diàn" in res["explanation"] and "子 zǐ" in res["explanation"]


def test_neutral_syllable_is_not_answered():
    p = build("朋友", "péngyou")
    assert tones_of(p) == [2]
    assert check_answer("tone_choice", p, {"tones": [2]})["correct"]
    res = check_answer("tone_choice", p, {"tones": [3]})
    assert not res["correct"] and res["expected"] == "péng you"
    with pytest.raises(AnswerError):
        check_answer("tone_choice", p, {"tones": [2, 1]})     # тон лёгкого слога не принимается


def test_third_tone_sandhi_hint():
    p = build("你好", "nǐhǎo")
    res = check_answer("tone_choice", p, {"tones": [2, 3]})
    assert not res["correct"] and "Перед другим 3-м тоном" in res["explanation"]
    assert "Перед другим" not in check_answer("tone_choice", p, {"tones": [1, 3]})["explanation"]


@pytest.mark.parametrize("bad", [None, "3", [3], {"tones": [3]}, {"tones": [3, 5]}, {"tones": [0, 3]},
                                 {"tones": [True, 3]}, {"tones": [3, 3, 3]}, 3])
def test_malformed_answers_rejected(bad):
    with pytest.raises(AnswerError):
        check_answer("tone_choice", build("你好", "nǐhǎo"), bad)


def test_old_step_format_still_checked_as_choice():
    """Сессии, начатые до перехода на слоги, хранят старый шаг: варианты целого слова."""
    old = {"prompt": "你", "options": ["nì", "nǐ", "nī", "ní"], "answer_index": 1, "option_tone": [4, 3, 1, 2]}
    assert check_answer("tone_choice", old, 1)["correct"]
    res = check_answer("tone_choice", old, 0)
    assert not res["correct"] and "3-й" in res["explanation"]
