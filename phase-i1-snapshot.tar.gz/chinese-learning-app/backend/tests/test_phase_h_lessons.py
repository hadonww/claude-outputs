"""
Phase H — урок как цельное занятие: сценарий темы, учебная последовательность,
перевод, диалог, произношение, «я это уже знаю», weak → due → recent → mastered
и итог урока по реальным данным.
"""

import json
import sqlite3
import sys
import tempfile
from pathlib import Path
from random import Random

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine import exercise_types as ex
from engine import lesson_script
from engine.answer_check import AnswerError, check_answer
from engine.pronunciation import score_utterance

BACKEND = Path(__file__).resolve().parent.parent
LESSONS = BACKEND / "data" / "lessons"
STAGE_RANK = {"new": 0, "practice": 1, "context": 2, "recall": 3, "production": 4, "speaking": 5}

# слова сценария «Люди», которых нет в свежей (seed) базе — в полной базе они есть
EXTRA_WORDS = [("叫", "jiào", "звать, называться", "люди"), ("呢", "ne", "частица «а …?»", "грамматика")]


def blueprint_files():
    return [json.loads(p.read_text(encoding="utf-8")) for p in sorted(LESSONS.glob("*.json"))]


# ---------------------------------------------------------------------------
# Контент: сценарии корректны и не используют неизученных слов
# ---------------------------------------------------------------------------

def test_blueprints_are_small_and_never_use_unlearned_words():
    # Phase I: уроки HSK 1 — один курс; слова, выученные в темах раньше по маршруту
    # (Люди → Числа → Время → …), знакомы и в следующих темах. Поэтому «выученное»
    # накапливается по порядку маршрута, а не заново в каждом файле.
    from app.curriculum import ROUTE_SECTIONS

    order = [c for s in ROUTE_SECTIONS for c in s.categories]
    files = sorted(blueprint_files(), key=lambda f: (f["module"]["hsk_level"], order.index(f["module"]["category"])))
    learned: set[str] = set()
    for f in files:
        for b in f["lessons"]:
            assert 2 <= len(b["new_words"]) <= 5, (b["key"], "новых слов должно быть мало")
            assert b["goal"] and b["can_do"] and b["intro"]
            learned |= set(b["new_words"])
            used = lesson_script.blueprint_hanzi(b)
            # всё, что встречается в фразах, диалоге, переводе и речи, — слова этого
            # или предыдущих уроков темы (никаких «будущих» слов)
            assert used <= learned, (b["key"], used - learned)
            names = set(b.get("names") or {})
            texts = [p["cn"] for p in b["phrases"]] + [sp["cn"] for sp in b["speaking"]]
            texts += [a for t in b["translations"] for a in t["answers"]]
            for line in b["dialogue"]["lines"]:
                texts += [line["cn"], *(d["cn"] for d in line.get("distractors") or [])]
            for text in texts:
                for tok in text.split():
                    if tok.startswith("@"):
                        assert tok[1:] in names, (b["key"], tok)
            for p in b["phrases"]:
                assert len(p["ru_distractors"]) >= 2 and p["ru"] not in p["ru_distractors"]
            for line in b["dialogue"]["lines"]:
                if line.get("user"):
                    assert len(line["distractors"]) >= 2


def test_blueprints_resolve_against_full_database():
    db = BACKEND / "app.db"
    if not db.exists():
        pytest.skip("нет полной базы app.db")
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    words = {r["hanzi"]: dict(r) for r in conn.execute("SELECT id, hanzi, pinyin, translation FROM words")}
    for f in blueprint_files():
        for b in f["lessons"]:
            script = lesson_script.resolve(b, words)
            assert script["phrases"] and script["translations"] and script["dialogue"] and script["speaking"]
            # пиньинь фраз собран из базы, имена — из объявления
            assert all(p["pinyin"] for p in script["phrases"])


def test_choose_script_goes_in_order_and_stops_on_missing_content():
    a, b, c = {"key": "a"}, {"key": "b"}, {"key": "c"}
    assert lesson_script.choose_script([a, b, c], set())["key"] == "a"
    assert lesson_script.choose_script([a, b, c], {"a"})["key"] == "b"
    assert lesson_script.choose_script([a, None, c], {"a"}) is None   # урок с «дырой» не перескакиваем
    assert lesson_script.choose_script([a, b], {"a", "b"}) is None


def _toy_script():
    words = {h: {"id": i, "hanzi": h, "pinyin": py} for i, (h, py) in
             enumerate([("你", "nǐ"), ("好", "hǎo"), ("我", "wǒ"), ("叫", "jiào"), ("他", "tā")], start=1)}
    bp = {"key": "t", "title": "T", "goal": "G", "new_words": ["你", "好"],
          "names": {"安娜": {"pinyin": "Ānnà", "ru": "Анна"}},
          "phrases": [{"cn": "你 好 ！", "ru": "Привет!", "ru_distractors": ["Пока!", "Спасибо!"], "target": "好"},
                      {"cn": "他 好 。", "ru": "Он хороший.", "ru_distractors": ["a", "b"], "target": "他"}],
          "translations": [{"ru": "Меня зовут Анна", "answers": ["我 叫 @安娜"], "extra": ["你"], "target": "叫"}],
          "dialogue": {"lines": [{"who": "A", "cn": "你 好 ！", "ru": "Привет!"},
                                 {"who": "B", "user": True, "cn": "你 好 ！", "ru": "Привет!",
                                  "distractors": [{"cn": "我 好 。", "ru": "x"}, {"cn": "他 好 。", "ru": "y"}]}]},
          "speaking": [{"cn": "你 好 ！", "ru": "Привет!"}]}
    return lesson_script.resolve(bp, words), words


def test_script_steps_skip_anything_with_an_unknown_word():
    script, w = _toy_script()
    known = {w["你"]["id"], w["好"]["id"], w["我"]["id"], w["叫"]["id"]}   # 他 не знаком
    steps = lesson_script.build_steps(script, known, known, Random(1))
    assert steps, "знакомые фразы должны остаться"
    for s in steps:
        assert set(s["payload"]["used_word_ids"]) <= known, s["type"]
    types = [s["type"] for s in steps]
    # фраза с 他 и диалог с вариантом-ответом «他好» — пропущены, а не показаны с незнакомым словом
    assert "dialogue_scene" not in types and types.count("translate_cn_ru") == 1
    assert {"translation_build", "speaking"} <= set(types)
    # пиньинь имени и знаки препинания
    assert script["translations"][0]["pinyin"] == "Wǒ jiào Ānnà"
    assert script["phrases"][0]["pinyin"] == "Nǐ hǎo!"


# ---------------------------------------------------------------------------
# Перевод и упражнения
# ---------------------------------------------------------------------------

def test_translation_build_accepts_any_allowed_answer_and_ignores_extra_tile():
    p = {"tokens": ["叫", "安娜", "你", "我"], "answers": [["我", "叫", "安娜"], ["安娜", "我", "叫"]]}
    assert check_answer("translation_build", p, ["我", "叫", "安娜"])["correct"]
    assert check_answer("translation_build", p, ["安娜", "我", "叫"])["correct"]
    wrong = check_answer("translation_build", p, ["你", "叫", "安娜"])
    assert not wrong["correct"] and "не хватает" in wrong["explanation"] and wrong["expected"] == "我叫安娜"
    order = check_answer("translation_build", p, ["叫", "我", "安娜"])
    assert "порядок" in order["explanation"]
    with pytest.raises(AnswerError):
        check_answer("translation_build", p, ["我", "叫", "他"])        # такой плитки не было


def test_listening_prefers_similar_sounding_distractors():
    item = {"id": 1, "hanzi": "买", "pinyin": "mǎi", "translation": "покупать", "category": "a"}
    pool = [item,
            {"id": 2, "hanzi": "卖", "pinyin": "mài", "translation": "продавать", "category": "z"},
            {"id": 3, "hanzi": "没", "pinyin": "méi", "translation": "нет", "category": "z"},
            {"id": 4, "hanzi": "书", "pinyin": "shū", "translation": "книга", "category": "a"},
            {"id": 5, "hanzi": "水", "pinyin": "shuǐ", "translation": "вода", "category": "z"},
            {"id": 6, "hanzi": "猫", "pinyin": "māo", "translation": "кошка", "category": "z"}]
    payload = ex.get("listening").build(item, pool, Random(3), None)
    assert "卖" in payload["options"]       # тот же слог, другой тон — главный кандидат
    assert {"没", "猫"} & set(payload["options"])  # та же начальная согласная


def test_pinyin_choice_contains_same_syllable_with_wrong_tone():
    item = {"id": 1, "hanzi": "叫", "pinyin": "jiào", "translation": "звать", "category": "a"}
    pool = [item] + [{"id": i, "hanzi": h, "pinyin": py, "translation": t, "category": "a"} for i, (h, py, t) in
                     enumerate([("你", "nǐ", "ты"), ("好", "hǎo", "хороший"), ("我", "wǒ", "я"), ("他", "tā", "он")], 2)]
    p = ex.get("pinyin_choice").build(item, pool, Random(1), None)
    variants = {"jiāo", "jiáo", "jiǎo"}
    assert len(p["options"]) == 4 and variants & set(p["options"])
    wrong = p["options"].index(next(iter(variants & set(p["options"]))))
    res = check_answer("pinyin_choice", p, wrong)
    assert not res["correct"] and "тон" in res["explanation"]


def test_recall_hints_fade_as_word_matures():
    item = {"id": 1, "hanzi": "叫", "pinyin": "jiào", "translation": "звать"}
    assert ex.get("recall").build({**item, "state": "learning"}, [], Random(0), None)["hint_pinyin"] == "jiào"
    assert ex.get("recall").build({**item, "state": "review"}, [], Random(0), None)["hint_pinyin"] is None


# ---------------------------------------------------------------------------
# Произношение
# ---------------------------------------------------------------------------

def test_pronunciation_scoring_is_per_word_and_explains_tones():
    expected = [("我", "wǒ"), ("叫", "jiào"), ("安娜", "Ānnà")]
    perfect = score_utterance(expected, ["wo3", "jiao4", "an1 na4"])
    assert perfect.overall == 100 and perfect.passed
    tone = score_utterance(expected, ["wǒ", "jiāo", "Ānnà"])
    assert [w.score for w in tone.per_word] == [100, 60, 100]
    assert any("叫" in n and "4-й" in n for n in tone.notes)
    missing = score_utterance(expected, ["wǒ", None, None])
    assert missing.overall < 50 and not missing.passed
    assert any("не прозвучало" in n for n in missing.notes)


# ---------------------------------------------------------------------------
# Урок по сценарию через API
# ---------------------------------------------------------------------------

@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_phase_h.db"
    db_module.init_db()
    from app.db import get_db
    from app.repositories import progress_repo, words_repo

    with get_db() as conn:
        people = conn.execute("SELECT id FROM modules WHERE category = 'люди' AND hsk_level = 1").fetchone()[0]
        for hanzi, py, tr, cat in EXTRA_WORDS:
            if conn.execute("SELECT 1 FROM words WHERE hanzi = ?", (hanzi,)).fetchone():
                continue
            wid = words_repo.insert_word(conn, hanzi, py, tr, 1, cat, None, None, None, None)
            conn.execute("UPDATE words SET module_id = ? WHERE id = ?", (people if cat == "люди" else None, wid))
            progress_repo.insert_progress_row(conn, wid, 1, "2000-01-01")

    from fastapi.testclient import TestClient

    from main import app

    c = TestClient(app)
    c.people_module = people
    return c


def server_session(sid):
    from app.db import get_db
    from app.repositories import lesson_sessions_repo

    with get_db() as conn:
        return lesson_sessions_repo.get(conn, sid)


def answer_for(step, correct=True):
    p = step["payload"]
    t = step["type"]
    if t == "introduction":
        return None
    if t == "matching":
        pairs = list(p["answers"])
        return {"pairs": pairs if correct else [pairs[1], pairs[0], *pairs[2:]]}
    if t == "tone_choice" and "syllables" in p:
        tones = [p["answers"][i] for i, s in enumerate(p["syllables"]) if s["tested"]]
        return {"tones": tones if correct else [tones[0] % 4 + 1, *tones[1:]]}
    if "answer_index" in p:
        return p["answer_index"] if correct else (p["answer_index"] + 1) % len(p["options"])
    if t == "sentence_order":
        return p["answer_tokens"] if correct else list(reversed(p["answer_tokens"]))
    if t == "translation_build":
        return p["answers"][0] if correct else list(reversed(p["answers"][0]))
    if t == "pinyin_input":
        return p["answer"] if correct else "zzz"
    if t == "recall":
        return 2 if correct else 0
    if t == "handwriting":
        return {"mistakes": 0 if correct else 5}
    if t == "speaking":
        return {"skipped": True}
    raise AssertionError(t)


def run_all(client, sid, wrong_at: set[int] = frozenset()):
    i = 0
    while i < len(server_session(sid)["steps"]):
        step = server_session(sid)["steps"][i]
        r = client.post(f"/api/sessions/{sid}/attempts",
                        json={"step_index": i, "answer": answer_for(step, i not in wrong_at)})
        assert r.status_code == 200, (step["type"], r.text)
        i += 1
    return client.post(f"/api/sessions/{sid}/complete").json()


def words_by_id(ids):
    from app.db import get_db

    with get_db() as conn:
        return {r["id"]: r["hanzi"] for r in conn.execute(
            f"SELECT id, hanzi FROM words WHERE id IN ({','.join('?' * len(ids))})", list(ids))}


def test_script_lesson_follows_pedagogical_sequence(client):
    plan = client.post(f"/api/lessons/{client.people_module}/start").json()
    assert plan["lesson"]["title"] == "Привет! Меня зовут…" and plan["lesson"]["mode"] == "new"
    assert plan["lesson"]["can_do"] and plan["lesson"]["goal"]
    new_ids = [w["id"] for w in plan["new_words"]]
    assert set(words_by_id(new_ids).values()) == {"你", "好", "我", "叫"}
    # ответы не уходят клиенту
    for step in plan["steps"]:
        assert "answers" not in step["payload"] and "answer_index" not in step["payload"]

    steps = server_session(plan["session_id"])["steps"]
    types = [s["type"] for s in steps]
    assert {"translate_cn_ru", "sentence_listening", "dialogue_scene", "translation_build", "speaking"} <= set(types)
    introduced: set[int] = set()
    seen_before = set()  # свежая база: до урока знакомых слов нет
    last_rank = {}
    first_script = next(i for i, s in enumerate(steps) if s["role"] == "script")
    assert all(s["type"] != "introduction" for s in steps[first_script:]), "сценарий — после знакомства со всеми словами"
    for s in steps:
        used = set((s["payload"] or {}).get("used_word_ids") or [])
        # ни одно упражнение не требует слова, с которым ещё не знакомили
        assert used <= introduced | seen_before | {s["word_id"]}, (s["type"], used - introduced)
        if s["type"] == "introduction":
            introduced.add(s["word_id"])
        else:
            assert s["word_id"] in introduced
        if s["role"] == "new":
            # путь слова: увидел → понял → услышал → вспомнил (этапы не идут назад)
            assert STAGE_RANK[s["stage"]] >= last_rank.get(s["word_id"], 0), (s["type"], s["stage"])
            last_rank[s["word_id"]] = STAGE_RANK[s["stage"]]
    # SRS — один раз на слово и не на шаге речи (её могут пропустить)
    finals = [s["word_id"] for s in steps if s["final"]]
    assert sorted(finals) == sorted(new_ids)
    assert not any(s["final"] for s in steps if s["type"] == "speaking")


def test_full_script_lesson_result_and_next_lesson(client):
    plan = client.post(f"/api/lessons/{client.people_module}/start").json()
    summary = run_all(client, plan["session_id"])
    assert summary["can_do"] == plan["lesson"]["can_do"]
    assert summary["accuracy"]["percent"] == 100 and summary["needs_practice"] == []
    assert {w["hanzi"] for w in summary["strong"]} == {"你", "好", "我", "叫"}
    assert all("без ошибок" in w["why"] for w in summary["strong"])
    assert any("Как тебя зовут?" in m for m in summary["next_message"])
    assert summary["pronunciation"] is None   # речь пропущена — оценки нет, а не «100»
    assert summary["title"] == "Привет! Меня зовут…"
    assert summary["next"]["title"] == "Как тебя зовут?" and summary["next"]["module_id"] == client.people_module

    # второй урок темы: новые только 什么 名字 呢, повторно не учим 你 好 我 叫
    plan2 = client.post(f"/api/lessons/{client.people_module}/start").json()
    assert plan2["lesson"]["key"] == "hsk1-people-2"
    assert set(words_by_id([w["id"] for w in plan2["new_words"]]).values()) <= {"什么", "名字", "呢"}
    steps2 = server_session(plan2["session_id"])["steps"]
    intro_words = {s["word_id"] for s in steps2 if s["type"] == "introduction"}
    assert not intro_words & {w["id"] for w in plan["new_words"]}


def test_mistakes_become_needs_practice_with_next_review(client):
    plan = client.post(f"/api/lessons/{client.people_module}/start").json()
    steps = server_session(plan["session_id"])["steps"]
    wrong = next(i for i, s in enumerate(steps) if s["type"] == "recognition")
    summary = run_all(client, plan["session_id"], {wrong})
    wid = steps[wrong]["word_id"]
    weak = [w for w in summary["needs_practice"] if w["id"] == wid]
    assert weak and weak[0]["mistakes"] >= 1 and weak[0]["note"] and weak[0]["next_review"]
    assert wid not in {w["id"] for w in summary["strong"]}
    assert any(weak[0]["hanzi"] in m and "проверим" in m for m in summary["next_message"])


def test_lesson_becomes_practical_when_words_are_already_known(client):
    from app.db import get_db

    with get_db() as conn:
        conn.execute("""UPDATE progress SET repetitions = 1, interval_days = 1, total_attempts = 2, total_correct = 2,
                        due_date = '2999-01-01', last_reviewed = '2026-01-01'
                        WHERE word_id IN (SELECT id FROM words WHERE hanzi IN ('你','好','我','叫'))""")
    plan = client.post(f"/api/lessons/{client.people_module}/start").json()
    assert plan["lesson"]["mode"] == "practice" and plan["new_words"] == []
    steps = server_session(plan["session_id"])["steps"]
    assert not [s for s in steps if s["type"] == "introduction"]
    assert {"translate_cn_ru", "dialogue_scene", "translation_build"} <= {s["type"] for s in steps}
    # знакомые слова не получают SRS-обновление от фраз (их повтор — по расписанию)
    assert not [s for s in steps if s["final"]]


def test_i_already_know_replaces_practice_with_one_check(client):
    from app.db import get_db

    plan = client.post(f"/api/lessons/{client.people_module}/start").json()
    sid = plan["session_id"]
    steps = server_session(sid)["steps"]
    i = next(k for k, s in enumerate(steps) if s["type"] == "introduction")
    wid = steps[i]["word_id"]
    before = len([s for s in steps if s["word_id"] == wid and s["role"] != "script"])
    r = client.post(f"/api/sessions/{sid}/known", json={"step_index": i}).json()
    assert r["next_index"] == i + 1
    steps = server_session(sid)["steps"]
    verify = steps[i + 1]
    assert verify["word_id"] == wid and verify["role"] == "verify" and not verify["final"]
    own = [s for s in steps if s["word_id"] == wid and s["role"] != "script"]
    assert len(own) == 2 < before                        # знакомство + одна проверка
    assert not any(s["final"] for s in steps if s["word_id"] == wid)
    # повторное заявление и заявление не на карточке слова — отклоняются
    assert client.post(f"/api/sessions/{sid}/known", json={"step_index": i}).status_code == 400
    assert client.post(f"/api/sessions/{sid}/known", json={"step_index": i + 1}).status_code == 400

    summary = run_all(client, sid)
    with get_db() as conn:
        row = conn.execute("SELECT repetitions, interval_days FROM progress WHERE word_id = ?", (wid,)).fetchone()
    assert (row[0], row[1]) == (2, 6)                    # подтвердил — как после двух повторений, не «освоено»
    assert any(w["id"] == wid and "проверка подтвердила" in w["why"] for w in summary["strong"])


def test_i_already_know_refuted_by_check(client):
    from app.db import get_db

    plan = client.post(f"/api/lessons/{client.people_module}/start").json()
    sid = plan["session_id"]
    steps = server_session(sid)["steps"]
    i = next(k for k, s in enumerate(steps) if s["type"] == "introduction")
    wid = steps[i]["word_id"]
    client.post(f"/api/sessions/{sid}/known", json={"step_index": i})
    summary = run_all(client, sid, wrong_at={i + 1})
    with get_db() as conn:
        row = conn.execute("SELECT repetitions, total_attempts FROM progress WHERE word_id = ?", (wid,)).fetchone()
    assert row[0] == 0 and row[1] >= 1                   # не подтвердилось — изучаем как новое
    weak = [w for w in summary["needs_practice"] if w["id"] == wid]
    assert weak and weak[0]["why"] == "проверка «знаю» не подтвердилась"
    # после ошибки слово ещё раз встретилось в уроке
    assert any(s.get("retry") and s["word_id"] == wid for s in server_session(sid)["steps"])


def test_speaking_is_honest_without_provider_and_scored_with_one(client):
    from app.services import pronunciation_service

    plan = client.post(f"/api/lessons/{client.people_module}/start").json()
    sid = plan["session_id"]
    steps = server_session(sid)["steps"]
    k = next(i for i, s in enumerate(steps) if s["type"] == "speaking")
    r = client.post(f"/api/sessions/{sid}/steps/{k}/speech", content=b"fake-audio").json()
    assert r["available"] is False and "не подключена" in r["message"]
    assert str(k) not in server_session(sid)["state"]["answered"]

    class Echo:
        name = "test-echo"

        def recognize(self, audio, expected):
            return [py for _, py in expected[:-1]] + ["zzz"]   # последнее слово сказано неверно

    pronunciation_service.set_provider(Echo())
    try:
        r = client.post(f"/api/sessions/{sid}/steps/{k}/speech", content=b"fake-audio").json()
    finally:
        pronunciation_service.set_provider(None)
    assert r["available"] and 0 < r["pronunciation"]["overall"] < 100
    assert r["pronunciation"]["per_word"][-1]["score"] < 50 and r["pronunciation"]["notes"]
    state = server_session(sid)["state"]
    assert state["speech"][str(k)] == r["pronunciation"]["overall"]
    from app.db import get_db

    with get_db() as conn:
        n = conn.execute("SELECT COUNT(*) FROM attempts WHERE skill = 'speaking'").fetchone()[0]
    assert n == 1


# ---------------------------------------------------------------------------
# Повторение: weak → due → recent → mastered
# ---------------------------------------------------------------------------

def test_review_priorities_and_reasons(client):
    from app.db import get_db

    with get_db() as conn:
        mod = conn.execute("SELECT id FROM modules WHERE category = 'числа' AND hsk_level = 1").fetchone()[0]
        ids = [r[0] for r in conn.execute("SELECT id FROM words WHERE module_id != ? ORDER BY id LIMIT 6", (mod,))]
        weak_due, due, weak_later, today_word, mastered = ids[:5]
        upd = ("UPDATE progress SET repetitions = ?, interval_days = ?, total_attempts = ?, total_correct = ?, "
               "due_date = ?, last_reviewed = ? WHERE word_id = ?")
        conn.execute(upd, (1, 1, 5, 1, "2000-01-01", "1999-12-31", weak_due))
        conn.execute(upd, (2, 6, 4, 4, "2000-01-01", "1999-12-25", due))
        conn.execute(upd, (1, 1, 4, 1, "2999-01-01", "2000-01-01", weak_later))
        conn.execute(upd, (1, 1, 1, 1, "2999-01-01", __import__("app.utils", fromlist=["x"]).today_date().isoformat(),
                           today_word))
        conn.execute(upd, (5, 40, 6, 6, "2999-01-01", "2000-01-01", mastered))
    plan = client.post(f"/api/lessons/{mod}/start").json()
    assert [w["id"] for w in plan["review_words"]][:2] == [weak_due, due]   # слабое — раньше
    steps = server_session(plan["session_id"])["steps"]
    by_word = {}
    for s in steps:
        by_word.setdefault(s["word_id"], []).append(s)
    assert all(s["stage"] == "review" for s in by_word[weak_due])
    assert "Слабое слово" in by_word[weak_due][0]["reason"]
    assert by_word[due][0]["reason"] == "Пора повторить по расписанию"
    assert by_word[weak_later][0]["role"] == "weak" and not any(s["final"] for s in by_word[weak_later])
    assert by_word[today_word][0]["role"] == "recent"
    retention = by_word[mastered]
    assert len(retention) == 1 and retention[0]["role"] == "retention" and not retention[0]["final"]


def test_failed_retention_check_returns_word_to_review(client):
    from app.db import get_db

    with get_db() as conn:
        mod = conn.execute("SELECT id FROM modules WHERE category = 'числа' AND hsk_level = 1").fetchone()[0]
        wid = conn.execute("SELECT id FROM words WHERE module_id != ? ORDER BY id LIMIT 1", (mod,)).fetchone()[0]
        conn.execute("UPDATE progress SET repetitions = 5, interval_days = 40, total_attempts = 6, total_correct = 6, "
                     "due_date = '2999-01-01', last_reviewed = '2000-01-01' WHERE word_id = ?", (wid,))
    plan = client.post(f"/api/lessons/{mod}/start").json()
    sid = plan["session_id"]
    steps = server_session(sid)["steps"]
    k = next(i for i, s in enumerate(steps) if s["role"] == "retention")
    client.post(f"/api/sessions/{sid}/attempts", json={"step_index": k, "answer": answer_for(steps[k], False)})
    with get_db() as conn:
        reps = conn.execute("SELECT repetitions FROM progress WHERE word_id = ?", (wid,)).fetchone()[0]
    assert reps == 0
