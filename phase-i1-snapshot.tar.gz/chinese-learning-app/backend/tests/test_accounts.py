"""
Аккаунт: identity (public_id), username, онбординг, Premium early-100, а также
актуальность серии (streak) при чтении. Всё — на реальной схеме (temp-БД).
"""

import re
import sqlite3
import sys
import tempfile
import threading
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from app import streak as streak_logic

PUBLIC_ID_RE = re.compile(r"^CN-[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{5}$")


@pytest.fixture()
def db_path():
    from app import db as db_module

    path = Path(tempfile.mkdtemp()) / "test_accounts.db"
    db_module.DB_PATH = path
    db_module.init_db()
    return path


@pytest.fixture()
def client(db_path):
    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def _conn():
    from app import db as db_module

    return db_module.get_db()


def _create_users(n):
    from app.services import account_service

    with _conn() as conn:
        return [account_service.create_user(conn) for _ in range(n)]


# ---------------------------------------------------------------- identity / public_id

def test_fresh_db_owner_account_has_public_id_and_no_onboarding(client):
    me = client.get("/api/me").json()
    assert PUBLIC_ID_RE.match(me["public_id"])
    assert me["username"] is None and me["created_at"]
    assert me["onboarding"] == {"completed": False, "completed_at": None}
    assert "id" not in me                                      # внутренний id наружу не уходит


def test_public_ids_are_unique_random_and_not_the_db_id(db_path):
    ids = _create_users(60)
    with _conn() as conn:
        rows = conn.execute("SELECT id, public_id FROM users ORDER BY id").fetchall()
    public = [r["public_id"] for r in rows]
    assert len(rows) == 61 and len(set(public)) == 61
    assert all(PUBLIC_ID_RE.match(p) for p in public)
    assert all(r["public_id"] not in (str(r["id"]), f"CN-{r['id']:05d}") for r in rows)
    assert sorted(public) != public                            # не последовательные
    assert ids == sorted(ids)


def test_public_id_is_unique_at_db_level(db_path):
    with _conn() as conn:
        pid = conn.execute("SELECT public_id FROM users").fetchone()[0]
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("INSERT INTO users (created_at, public_id) VALUES ('2026-10-04', ?)", (pid,))


def test_repeated_reads_are_stable_and_create_nothing(client):
    def counts():
        with _conn() as conn:
            return (conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
                    conn.execute("SELECT COUNT(*) FROM entitlements").fetchone()[0])

    before = counts()
    first = client.get("/api/me").json()
    for _ in range(3):
        assert client.get("/api/me").json() == first
        assert client.get("/api/profile").json()["account"] == first
    assert counts() == before


# ---------------------------------------------------------------- username

@pytest.mark.parametrize("raw, expected", [
    ("ahha", "ahha"), ("@Ahha", "ahha"), ("  li_wei99 ", "li_wei99"), ("abc", "abc"), ("a" * 20, "a" * 20),
])
def test_username_normalization(raw, expected):
    from app.services.account_service import normalize_username

    assert normalize_username(raw) == expected


@pytest.mark.parametrize("raw", [
    "", "ab", "a" * 21, "1abc", "_abc", "ab cd", "ab-cd", "иван", "ab.cd", "admin", "@", "a<b>",
])
def test_username_validation_rejects(raw):
    from app.services.account_service import UsernameError, normalize_username

    with pytest.raises(UsernameError):
        normalize_username(raw)


def test_username_set_change_and_uniqueness(client):
    res = client.put("/api/me/username", json={"username": "@Ahha"})
    assert res.status_code == 200 and res.json()["username"] == "ahha"
    assert client.put("/api/me/username", json={"username": "ahha"}).status_code == 200   # то же имя — ок
    assert client.put("/api/me/username", json={"username": "x"}).status_code == 400
    res = client.put("/api/me/username", json={"username": "li_wei"})                       # смена позже
    assert res.status_code == 200 and res.json()["username"] == "li_wei"

    from app.services import account_service

    other = _create_users(1)[0]
    with _conn() as conn:
        with pytest.raises(account_service.UsernameTaken):
            account_service.change_username(conn, other, "LI_WEI")                          # без учёта регистра
        account_service.change_username(conn, other, "ahha")                                # освободилось после смены
    assert client.put("/api/me/username", json={"username": "ahha"}).status_code == 409


def test_username_uniqueness_is_enforced_by_db(db_path):
    a, b = _create_users(2)
    with _conn() as conn:
        conn.execute("UPDATE users SET username = 'same' WHERE id = ?", (a,))
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute("UPDATE users SET username = 'same' WHERE id = ?", (b,))


# ---------------------------------------------------------------- premium early-100

def _premium(conn, user_id):
    from app.services import account_service

    return account_service.premium_status(conn, user_id)


def test_first_100_get_premium_forever_and_101st_does_not(db_path):
    from app.repositories import entitlements_repo
    from app.services import account_service

    ids = [1] + _create_users(100)                             # владелец + 100 → 101 аккаунт
    with _conn() as conn:
        statuses = [_premium(conn, uid) for uid in ids]
        assert all(s["active"] and s["forever"] and s["grant_type"] == "early_100" for s in statuses[:100])
        assert statuses[0]["label"] == "Premium · навсегда"
        assert statuses[100] == {"active": False, "forever": False, "grant_type": None,
                                 "granted_at": None, "label": None}
        assert entitlements_repo.count_grants(conn, "early_100") == 100
        slots = [r[0] for r in conn.execute("SELECT slot FROM entitlements ORDER BY slot")]
        assert slots == list(range(1, 101))
        # повтор не выдаёт второй grant ни получившему, ни 101-му
        assert account_service.grant_early_access(conn, ids[0]) is False
        assert account_service.grant_early_access(conn, ids[100]) is False
        assert entitlements_repo.count_grants(conn, "early_100") == 100
        grant = conn.execute("SELECT * FROM entitlements WHERE user_id = ?", (ids[5],)).fetchone()
        assert grant["granted_at"] and grant["entitlement"] == "premium" and grant["expires_at"] is None


def test_limit_is_enforced_by_schema_not_only_by_code(db_path):
    _create_users(5)
    with _conn() as conn:
        with pytest.raises(sqlite3.IntegrityError):         # 101-е место физически не записать
            conn.execute("""INSERT INTO entitlements (user_id, entitlement, grant_type, granted_at, slot)
                            VALUES (2, 'premium', 'early_100', 'x', 101)""")
        with pytest.raises(sqlite3.IntegrityError):         # то же место дважды
            conn.execute("""INSERT INTO entitlements (user_id, entitlement, grant_type, granted_at, slot)
                            VALUES (3, 'premium', 'early_100', 'x', 1)""")


def test_concurrent_registrations_never_exceed_100(db_path):
    from app.repositories import entitlements_repo
    from app.services import account_service

    _create_users(80)                                          # 81 аккаунт, осталось 19 мест
    barrier = threading.Barrier(40)
    errors = []

    def register():
        try:
            barrier.wait()
            with _conn() as conn:
                account_service.create_user(conn)
        except Exception as exc:  # noqa: BLE001 — собираем любые сбои потоков
            errors.append(exc)

    threads = [threading.Thread(target=register) for _ in range(40)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors
    with _conn() as conn:
        assert conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 121
        assert entitlements_repo.count_grants(conn, "early_100") == 100
        slots = [r[0] for r in conn.execute("SELECT slot FROM entitlements WHERE grant_type = 'early_100'")]
        assert sorted(slots) == list(range(1, 101))


def test_entitlement_survives_restart_and_cannot_be_set_from_client(client, db_path):
    from app import db as db_module

    db_module.init_db()                                        # повторный старт приложения
    assert client.get("/api/me").json()["premium"]["active"] is True
    with _conn() as conn:                                      # обычный пользователь без гранта
        conn.execute("DELETE FROM entitlements")
    assert client.put("/api/me/username", json={"username": "hacker", "premium": True}).status_code == 200
    assert client.post("/api/settings", json={"premium": True, "daily_new_words": 5}).status_code == 200
    assert client.post("/api/me", json={"premium": True}).status_code == 405
    assert client.get("/api/me").json()["premium"]["active"] is False


def test_constant_matches_schema_limit():
    from app.services import account_service

    assert account_service.EARLY_ACCESS_LIMIT == 100


# ---------------------------------------------------------------- onboarding

def test_onboarding_shown_once_and_completion_is_idempotent(client):
    assert client.get("/api/me").json()["onboarding"]["completed"] is False
    assert client.get("/api/settings").json()["onboarded"] is False
    first = client.post("/api/me/onboarding/complete").json()["onboarding"]
    assert first["completed"] is True and first["completed_at"]
    again = client.post("/api/me/onboarding/complete").json()["onboarding"]
    assert again == first                                       # дата первого завершения не меняется
    assert client.get("/api/settings").json()["onboarded"] is True
    client.post("/api/settings", json={"onboarded": False})    # «распройти» нельзя
    assert client.get("/api/me").json()["onboarding"]["completed"] is True


def test_legacy_settings_flag_completes_onboarding(client):
    client.post("/api/settings", json={"daily_new_words": 8, "onboarded": True})
    assert client.get("/api/me").json()["onboarding"]["completed"] is True


def test_existing_users_get_identity_and_no_repeated_onboarding_after_migration():
    from app import db as db_module

    path = Path(tempfile.mkdtemp()) / "legacy_accounts.db"
    conn = sqlite3.connect(path)
    conn.executescript("""
        CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL);
        INSERT INTO users (id, created_at) VALUES (1, '2026-01-01');
    """)
    conn.commit()
    conn.close()
    db_module.DB_PATH = path
    db_module.init_db()
    db_module.init_db()                                         # идемпотентно
    with db_module.get_db() as c:
        user = c.execute("SELECT * FROM users WHERE id = 1").fetchone()
        assert PUBLIC_ID_RE.match(user["public_id"])
        assert user["onboarding_completed_at"] == "2026-01-01"   # уже пользовался — не показываем
        assert c.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 1
        assert c.execute("SELECT COUNT(*) FROM entitlements WHERE user_id = 1").fetchone()[0] == 1


# ---------------------------------------------------------------- streak: чистая логика

D = date(2026, 10, 4)


def days(*offsets):
    return [D - timedelta(days=o) for o in offsets]


def test_streak_today_yesterday_gap_and_consecutive():
    assert streak_logic.current_streak(days(0), D) == 1                 # today
    assert streak_logic.current_streak(days(1), D) == 1                 # вчера, сегодня ещё не занимался
    assert streak_logic.current_streak(days(2, 3, 4), D) == 0           # пропущен день → сброс
    assert streak_logic.current_streak(days(0, 1, 2, 3), D) == 4        # несколько дней подряд
    assert streak_logic.current_streak(days(1, 2, 3), D) == 3
    assert streak_logic.current_streak(days(0, 1, 3, 4, 5), D) == 2     # разрыв внутри
    assert streak_logic.current_streak([], D) == 0


def test_longest_streak_never_below_current_and_counts_day_once():
    history = days(0, 0, 1, 5, 6, 7, 8)
    assert streak_logic.longest_streak(history) == 4
    assert streak_logic.current_streak(history, D) == 2
    assert streak_logic.longest_streak(days(3, 3, 3)) == 1


# ---------------------------------------------------------------- streak: API

def _log(*offsets):
    from app.utils import today_date

    today = today_date()
    with _conn() as conn:
        for o in offsets:
            conn.execute("INSERT INTO activity_log (day, reviews_count) VALUES (?, 1)",
                         ((today - timedelta(days=o)).isoformat(),))


def _snapshot():
    with _conn() as conn:
        return (conn.execute("SELECT day, reviews_count FROM activity_log ORDER BY day").fetchall(),
                tuple(conn.execute("SELECT * FROM stats").fetchone()))


def test_home_shows_reset_streak_after_gap_without_new_answer(client):
    _log(5, 4, 3, 2)                                           # 4 дня подряд, вчера пропущен
    from app.utils import today_date

    with _conn() as conn:                                      # устаревший кэш, как было в баге
        conn.execute("UPDATE stats SET streak = 4, last_active_date = ?",
                     ((today_date() - timedelta(days=2)).isoformat(),))
    assert client.get("/api/home").json()["streak"] == 0
    profile = client.get("/api/profile").json()
    assert profile["streak"] == 0 and profile["longest_streak"] == 4
    assert client.get("/api/statistics").json()["streak"] == {"current": 0, "longest": 4}


def test_home_streak_yesterday_and_today(client):
    _log(2, 1)
    assert client.get("/api/home").json()["streak"] == 2       # вчера был, сегодня ещё нет
    _log(0)
    assert client.get("/api/home").json()["streak"] == 3


def test_repeated_reads_do_not_mutate_activity(client):
    _log(3, 1)
    before = _snapshot()
    for _ in range(3):
        client.get("/api/home")
        client.get("/api/profile")
        client.get("/api/statistics")
    assert _snapshot() == before


def test_new_answer_after_gap_starts_new_streak_and_keeps_record(client):
    _log(6, 5, 4)
    module = client.get("/api/learning-path").json()["modules"][0]
    words = [w for w in client.get("/api/words", params={"category": module["category"]}).json()
             if w["module_id"] == module["id"]]
    for w in words[:2]:                                         # два ответа в один день — один день серии
        client.post(f"/api/lessons/{module['id']}/attempts", json={
            "word_id": w["id"], "exercise_type": "recognition", "correct": True, "final": True})
    assert client.get("/api/home").json()["streak"] == 1
    profile = client.get("/api/profile").json()
    assert profile["longest_streak"] == 3 and profile["learned_count"] == 2   # прогресс записан
    with _conn() as conn:
        assert conn.execute("SELECT streak FROM stats").fetchone()[0] == 1   # кэш согласован


# ---------------------------------------------------------------- profile

def test_profile_contains_account_progress_and_premium(client):
    client.put("/api/me/username", json={"username": "ahha"})
    p = client.get("/api/profile").json()
    acc = p["account"]
    assert acc["username"] == "ahha" and PUBLIC_ID_RE.match(acc["public_id"])
    assert acc["premium"]["label"] == "Premium · навсегда" and acc["created_at"]
    for key in ("streak", "longest_streak", "learned_count", "total_words", "by_level"):
        assert key in p
