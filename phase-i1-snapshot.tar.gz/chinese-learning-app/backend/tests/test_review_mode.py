"""Review = Lesson Runner + другой план (просроченные слова всех модулей)."""

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_review.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def learn_words(client, n_modules=2, per_module=3):
    """Выучить по несколько слов в первых модулях и сделать их просроченными."""
    from app.db import get_db

    modules = sorted(client.get("/api/learning-path").json()["modules"], key=lambda m: m["order_index"])[:n_modules]
    ids = []
    for m in modules:
        for w in client.get(f"/api/lessons/{m['id']}/plan").json()["new_words"][:per_module]:
            client.post(f"/api/lessons/{m['id']}/attempts", json={
                "word_id": w["id"], "exercise_type": "recognition", "correct": True, "final": True})
            ids.append(w["id"])
    with get_db() as conn:
        conn.execute("UPDATE progress SET due_date = '2000-01-01' WHERE repetitions > 0")
    return ids


def test_review_plan_empty_when_nothing_is_due(client):
    plan = client.get("/api/review/plan").json()
    assert plan["steps"] == [] and plan["module"]["title"] == "Повторение"


def test_review_plan_contains_due_words_from_several_modules_and_no_intro(client):
    ids = learn_words(client)
    plan = client.get("/api/review/plan").json()
    step_words = {s["word_id"] for s in plan["steps"]}
    assert step_words and step_words <= set(ids)
    assert len({w["category"] for w in plan["review_words"]}) == 2
    assert "introduction" not in {s["type"] for s in plan["steps"]}
    assert plan["steps"][0]["type"] == "recall"


def test_review_attempts_update_mastery_and_reschedule_srs(client):
    learn_words(client, n_modules=1, per_module=2)
    plan = client.get("/api/review/plan").json()
    due_before = client.get("/api/home").json()["due_review_count"]
    assert due_before > 0
    for wid in {s["word_id"] for s in plan["steps"]}:
        res = client.post("/api/review/attempts", json={
            "word_id": wid, "exercise_type": "recall", "correct": True, "final": True, "recall_quality": 2}).json()
        assert res["srs"]["interval_days"] >= 1
    assert client.get("/api/home").json()["due_review_count"] < due_before


def test_review_attempt_rejects_unknown_type(client):
    res = client.post("/api/review/attempts", json={"word_id": 1, "exercise_type": "x", "correct": True})
    assert res.status_code == 400
