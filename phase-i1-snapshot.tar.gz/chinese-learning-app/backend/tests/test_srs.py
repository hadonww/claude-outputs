"""
Тесты для srs.py — первый тест в проекте (Phase 0 из PLAN_WB_v1.md).

Модуль уже был чистым и детерминированным до этих тестов — здесь только
фиксируется его поведение таблицей примеров, без изменения самого модуля.
"""

import sys
from datetime import date, datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from srs import DEFAULT_EASE_FACTOR, MIN_EASE_FACTOR, ReviewState, review, word_state

TODAY = date(2026, 1, 15)


def fresh_state():
    return ReviewState(repetitions=0, ease_factor=DEFAULT_EASE_FACTOR, interval_days=0)


# ---------------------------------------------------------------------------
# review()
# ---------------------------------------------------------------------------

def test_quality_0_resets_progress_and_returns_tomorrow():
    state = ReviewState(repetitions=5, ease_factor=2.8, interval_days=30)
    new_state, due = review(state, quality_button=0, today=TODAY)
    assert new_state.repetitions == 0
    assert new_state.interval_days == 1
    assert due == date(2026, 1, 16)


def test_first_successful_review_interval_is_1_day():
    new_state, due = review(fresh_state(), quality_button=2, today=TODAY)
    assert new_state.repetitions == 1
    assert new_state.interval_days == 1
    assert due == date(2026, 1, 16)


def test_second_successful_review_interval_is_6_days():
    state = ReviewState(repetitions=1, ease_factor=DEFAULT_EASE_FACTOR, interval_days=1)
    new_state, due = review(state, quality_button=2, today=TODAY)
    assert new_state.repetitions == 2
    assert new_state.interval_days == 6
    assert due == date(2026, 1, 21)


def test_third_plus_review_interval_scales_by_ease_factor():
    state = ReviewState(repetitions=2, ease_factor=2.5, interval_days=6)
    new_state, due = review(state, quality_button=2, today=TODAY)
    # interval = round(6 * 2.5) = 15
    assert new_state.repetitions == 3
    assert new_state.interval_days == 15
    assert due == date(2026, 1, 30)


def test_easy_answer_increases_ease_factor_more_than_good():
    state_good = ReviewState(repetitions=2, ease_factor=2.5, interval_days=6)
    state_easy = ReviewState(repetitions=2, ease_factor=2.5, interval_days=6)
    good, _ = review(state_good, quality_button=2, today=TODAY)   # "Хорошо"
    easy, _ = review(state_easy, quality_button=3, today=TODAY)   # "Легко"
    assert easy.ease_factor > good.ease_factor
    assert easy.interval_days >= good.interval_days


def test_hard_answer_is_still_a_success_but_grows_ease_factor_least():
    state = ReviewState(repetitions=2, ease_factor=2.5, interval_days=6)
    new_state, _ = review(state, quality_button=1, today=TODAY)  # "Сложно"
    assert new_state.repetitions == 3  # прогресс не сбрасывается
    assert new_state.ease_factor <= DEFAULT_EASE_FACTOR + 0.1  # растёт слабо


def test_ease_factor_never_drops_below_minimum():
    state = ReviewState(repetitions=10, ease_factor=MIN_EASE_FACTOR, interval_days=100)
    new_state, _ = review(state, quality_button=0, today=TODAY)
    assert new_state.ease_factor >= MIN_EASE_FACTOR


def test_review_defaults_to_real_today_when_not_provided():
    # today=None не должен падать — используется datetime.now(timezone.utc).date()
    _, due = review(fresh_state(), quality_button=2, today=None)
    assert isinstance(due, date)
    assert due >= datetime.now(timezone.utc).date()


# ---------------------------------------------------------------------------
# word_state()
# ---------------------------------------------------------------------------

def test_word_state_new():
    assert word_state(repetitions=0, interval_days=0) == "new"


def test_word_state_learning():
    assert word_state(repetitions=1, interval_days=1) == "learning"
    assert word_state(repetitions=2, interval_days=6) == "learning"


def test_word_state_review():
    assert word_state(repetitions=3, interval_days=15) == "review"


def test_word_state_mastered():
    assert word_state(repetitions=5, interval_days=21) == "mastered"
    assert word_state(repetitions=5, interval_days=60) == "mastered"
