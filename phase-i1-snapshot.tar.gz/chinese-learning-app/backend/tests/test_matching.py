"""matching: сопоставить иероглифы с переводами (engine, без БД)."""

import sys
from itertools import permutations
from pathlib import Path
from random import Random

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services.lesson_service import ANSWER_FIELDS, client_step
from engine import exercise_types as ex
from engine.answer_check import AnswerError, check_answer


def w(wid, hanzi, translation, category="люди"):
    return {"id": wid, "hanzi": hanzi, "pinyin": "x", "translation": translation, "category": category}


POOL = [
    w(1, "你", "ты"), w(2, "我", "я"), w(3, "他", "он"), w(4, "她", "она"), w(5, "老师", "учитель"),
    w(6, "家", "дом, семья", "дом"), w(7, "房子", "дом (здание)", "дом"), w(8, "书", "книга", "школа"),
    w(9, "好", "хороший", "качества"), w(10, "学生", "студент"),
]
ALL = {x["id"] for x in POOL}
T = ex.get("matching")


def build(target_id=1, seed=0, known=ALL):
    item = next(x for x in POOL if x["id"] == target_id)
    return T.build(item, POOL, Random(seed), {"known_word_ids": set(known)})


def translation_of(hanzi):
    return next(x["translation"] for x in POOL if x["hanzi"] == hanzi)


# ---------- генерация ----------

@pytest.mark.parametrize("seed", range(10))
def test_several_pairs_each_with_one_translation(seed):
    p = build(seed=seed)
    n = len(p["left"])
    assert n == 4 and len(p["right"]) == 4
    assert len(set(p["left"])) == n and len(set(p["right"])) == n
    assert "你" in p["left"]
    # answers — верный перевод каждого иероглифа, по настоящим данным словаря
    assert [p["right"][j] for j in p["answers"]] == [translation_of(h) for h in p["left"]]
    assert sorted(p["answers"]) == list(range(n))


@pytest.mark.parametrize("seed", range(20))
def test_no_translation_stands_opposite_its_word(seed):
    p = build(seed=seed)
    assert all(j != i for i, j in enumerate(p["answers"]))


def test_order_varies_between_builds():
    assert len({tuple(build(seed=s)["left"]) for s in range(10)}) > 1
    assert len({tuple(build(seed=s)["right"]) for s in range(10)}) > 1


def test_build_is_deterministic():
    assert build(seed=4) == build(seed=4)


def test_only_known_words_besides_target():
    known = {2, 3, 9}
    for s in range(10):
        p = build(seed=s, known=known)
        assert set(p["used_word_ids"]) <= known | {1}
        assert set(p["left"]) == {"你", "我", "他", "好"}


def test_overlapping_meanings_never_together():
    """家 «дом, семья» и 房子 «дом (здание)» — у 家 было бы два верных перевода."""
    for s in range(30):
        left = build(target_id=6, seed=s)["left"]
        assert "房子" not in left
    for s in range(30):
        assert not {"家", "房子"} <= set(build(target_id=1, seed=s)["left"])


def test_same_topic_words_come_first():
    p = build(target_id=1, seed=0, known=ALL)
    others = [h for h in p["left"] if h != "你"]
    assert all(next(x for x in POOL if x["hanzi"] == h)["category"] == "люди" for h in others)


def test_fewer_known_words_gives_fewer_pairs():
    p = build(seed=0, known={2, 3})
    assert len(p["left"]) == 3


def test_requires_known_words():
    item = POOL[0]
    assert T.requires(item, POOL, {"known_word_ids": ALL})
    assert not T.requires(item, POOL, {"known_word_ids": {2}})        # одна пара в дополнение — мало
    assert not T.requires(item, POOL, {"known_word_ids": set()})
    assert not T.requires(item, POOL, None)                           # без known_word_ids — не строим


def test_answer_key_is_hidden_from_client():
    step = {"type": "matching", "payload": build(), "word_id": 1}
    visible = client_step(step, 0)["payload"]
    assert "answers" in ANSWER_FIELDS and "answers" not in visible
    assert set(visible) == {"question", "left", "right", "used_word_ids"}
    assert visible["used_word_ids"] == sorted(visible["used_word_ids"])   # не в порядке иероглифов


def test_registered_as_characters_practice():
    t = ex.get("matching")
    assert t.skill == "characters" and ex.phase("matching") == 1 and ex.stage("matching") == "practice"


# ---------- проверка ----------

def test_all_pairs_correct():
    p = build(seed=2)
    res = check_answer("matching", p, {"pairs": p["answers"]})
    assert res["correct"] and res["explanation"] is None
    assert all(d["correct"] for d in res["pairs"])
    assert res["expected"].split("\n") == [f"{h} — {translation_of(h)}" for h in p["left"]]


def test_bare_list_is_accepted():
    p = build(seed=2)
    assert check_answer("matching", p, list(p["answers"]))["correct"]


def test_partially_correct_names_each_wrong_pair():
    p = build(seed=2)
    pairs = list(p["answers"])
    pairs[0], pairs[1] = pairs[1], pairs[0]
    res = check_answer("matching", p, {"pairs": pairs})
    assert not res["correct"]
    assert [d["correct"] for d in res["pairs"]] == [False, False, True, True]
    h0, h1 = p["left"][0], p["left"][1]
    assert res["explanation"].startswith("Неверные пары (2 из 4):")
    assert f"{h0} — «{translation_of(h0)}», а не «{translation_of(h1)}»" in res["explanation"]
    assert p["left"][2] not in res["explanation"]


def test_only_the_key_permutation_is_correct():
    p = build(seed=3)
    correct = [perm for perm in permutations(range(4)) if check_answer("matching", p, list(perm))["correct"]]
    assert correct == [tuple(p["answers"])]


@pytest.mark.parametrize("bad", [
    None, 0, "0", {"pairs": [0, 1, 2]}, {"pairs": [0, 0, 1, 2]}, {"pairs": [0, 1, 2, 9]},
    {"pairs": [0, 1, 2, True]}, {"pairs": ["0", 1, 2, 3]}, {"tones": [0, 1, 2, 3]},
])
def test_malformed_answers_rejected(bad):
    with pytest.raises(AnswerError):
        check_answer("matching", build(seed=1), bad)
