"""
Phase B, миграция схемы: category стал nullable (вместо NOT NULL DEFAULT),
добавлены hsk_version/traditional/part_of_speech/pinyin_numeric. Проверяем,
что существующие слова и progress не теряются, и что миграция идемпотентна.
"""

import sqlite3
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest


@pytest.fixture()
def fresh_db_path():
    return Path(tempfile.mkdtemp()) / "test_schema.db"


def test_fresh_db_has_nullable_category_and_new_columns(fresh_db_path):
    from app import db as db_module

    db_module.DB_PATH = fresh_db_path
    db_module.init_db()

    with db_module.get_db() as conn:
        cols = {r["name"]: dict(r) for r in conn.execute("PRAGMA table_info(words)").fetchall()}
        assert cols["category"]["notnull"] == 0
        for new_col in ("hsk_version", "traditional", "part_of_speech", "pinyin_numeric"):
            assert new_col in cols, f"{new_col} отсутствует в свежей схеме"


def test_word_with_null_category_can_be_inserted_and_read_back(fresh_db_path):
    from app import db as db_module

    db_module.DB_PATH = fresh_db_path
    db_module.init_db()

    with db_module.get_db() as conn:
        conn.execute(
            "INSERT INTO words (hanzi, pinyin, translation, hsk, category, hsk_version) "
            "VALUES ('测', 'cè', 'тест', 4, NULL, '2.0')"
        )
    with db_module.get_db() as conn:
        row = conn.execute("SELECT * FROM words WHERE hanzi = '测'").fetchone()
        assert row["category"] is None
        assert row["hsk_version"] == "2.0"


def _make_legacy_db(path: Path):
    """Схема ДО Phase B: category NOT NULL DEFAULT, нет новых полей."""
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(
        """
        CREATE TABLE words (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hanzi TEXT NOT NULL, pinyin TEXT NOT NULL, translation TEXT NOT NULL,
            hsk INTEGER NOT NULL, category TEXT NOT NULL DEFAULT 'повседневная жизнь',
            example_cn TEXT, example_ru TEXT, components TEXT, strokes INTEGER,
            frequency INTEGER, related TEXT
        );
        CREATE TABLE progress (
            word_id INTEGER PRIMARY KEY REFERENCES words(id),
            repetitions INTEGER NOT NULL DEFAULT 0, ease_factor REAL NOT NULL DEFAULT 2.5,
            interval_days INTEGER NOT NULL DEFAULT 0, due_date TEXT NOT NULL,
            last_reviewed TEXT, total_attempts INTEGER NOT NULL DEFAULT 0,
            total_correct INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL);
        INSERT INTO users (id, created_at) VALUES (1, '2026-01-01');
        """
    )
    conn.execute("INSERT INTO words (id, hanzi, pinyin, translation, hsk, category) "
                 "VALUES (1, '你', 'nǐ', 'ты', 1, 'люди')")
    conn.execute("INSERT INTO progress (word_id, repetitions, ease_factor, interval_days, due_date) "
                 "VALUES (1, 3, 2.6, 10, '2026-01-01')")
    conn.commit()
    conn.close()


def test_migration_preserves_existing_words_and_progress(fresh_db_path):
    _make_legacy_db(fresh_db_path)
    from app import db as db_module

    db_module.DB_PATH = fresh_db_path
    db_module.init_db()

    with db_module.get_db() as conn:
        cols = {r["name"]: dict(r) for r in conn.execute("PRAGMA table_info(words)").fetchall()}
        assert cols["category"]["notnull"] == 0

        word = conn.execute("SELECT * FROM words WHERE id = 1").fetchone()
        assert word["hanzi"] == "你" and word["category"] == "люди"  # не потеряно, не затёрто

        progress = conn.execute("SELECT * FROM progress WHERE word_id = 1").fetchone()
        assert progress["repetitions"] == 3 and progress["interval_days"] == 10  # SRS-прогресс цел


def test_migration_is_idempotent(fresh_db_path):
    _make_legacy_db(fresh_db_path)
    from app import db as db_module

    db_module.DB_PATH = fresh_db_path
    db_module.init_db()
    db_module.init_db()  # повторный запуск не должен падать/дублировать

    with db_module.get_db() as conn:
        assert conn.execute("SELECT COUNT(*) FROM words WHERE id = 1").fetchone()[0] == 1


# ---------- Phase C: examples ----------

def test_examples_table_created_and_seeded_from_legacy_words(fresh_db_path):
    from app import db as db_module

    db_module.DB_PATH = fresh_db_path
    db_module.init_db()

    with db_module.get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM examples").fetchone()[0]
        assert total == 177  # у каждого рукописного слова был example_cn (Phase B audit)
        ok = conn.execute("SELECT COUNT(*) FROM examples WHERE needs_review = 0").fetchone()[0]
        assert ok > 0  # хоть что-то разобралось уже на 177-словном словаре


def test_reparse_resolves_more_after_vocabulary_grows(fresh_db_path):
    from app import db as db_module

    db_module.DB_PATH = fresh_db_path
    db_module.init_db()

    with db_module.get_db() as conn:
        before = conn.execute("SELECT COUNT(*) FROM examples WHERE needs_review = 0").fetchone()[0]
        # имитируем рост словаря: добавляем недостающее служебное слово вручную
        pending = conn.execute(
            "SELECT id, target_word_id, sentence_cn FROM examples WHERE needs_review = 1"
        ).fetchall()
        assert pending  # на 177 словах точно есть нерешённые (см. отчёт Phase C)

    with db_module.get_db() as conn:
        conn.execute("INSERT INTO words (hanzi, pinyin, translation, hsk, category) "
                     "VALUES ('很', 'hěn', 'очень', 1, NULL)")
        resolved, _still_pending = db_module.reparse_examples_needing_review(conn)
        assert resolved >= 0  # не падает, возвращает числа

    with db_module.get_db() as conn:
        after = conn.execute("SELECT COUNT(*) FROM examples WHERE needs_review = 0").fetchone()[0]
        assert after >= before  # пополнение словаря никогда не уменьшает число решённых


def test_migration_never_fabricates_used_word_ids_for_unresolved_examples(fresh_db_path):
    from app import db as db_module

    db_module.DB_PATH = fresh_db_path
    db_module.init_db()

    with db_module.get_db() as conn:
        rows = conn.execute("SELECT used_word_ids FROM examples WHERE needs_review = 1").fetchall()
        assert all(r["used_word_ids"] == "[]" for r in rows)  # честный пустой список, не угадывание
