"""
Phase I.1 — длина урока и баланс повторения (движок, без базы).

Проверяются инварианты и диапазоны, а не точные случайные числа: бюджет урока по
сценарию меньше прежнего, просроченное не слабое слово занимает один шаг, а слабое —
два, слабая практика не вытесняется полным уроком, при долге новых слов меньше, но
урок не превращается в чистое повторение, а разделение сценария не теряет фразы.
"""

import sys
from pathlib import Path
from random import Random

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine.lesson_planner import (
    BACKLOG_REVIEW_CAP,
    BACKLOG_THRESHOLD,
    LESSON_REVIEW_CAP,
    MAX_RETRIES_PER_LESSON,
    compute_budget,
    lesson_mix,
    plan_lesson,
)
from engine.lesson_script import lesson_new_ids, split_new_words

ZERO = {s: 0.0 for s in ["vocabulary", "characters", "pinyin", "tones", "listening", "grammar", "writing", "speaking"]}


def _w(i, state="new", role=None):
    w = {"id": i, "hanzi": f"字{i}", "pinyin": f"zì{i}", "translation": f"слово {i}", "state": state}
    if role:
        w["role"] = role
    return w


POOL = [_w(i, "review") for i in range(1, 40)]


# ---------------------------------------------------------------------------
# Бюджет и смесь
# ---------------------------------------------------------------------------

def test_scripted_budget_is_in_normal_lesson_range():
    """Обычный урок по сценарию: 3–5 новых + до LESSON_REVIEW_CAP повторений → 15–25 шагов бюджета."""
    for n in (3, 4, 5):
        assert 15 <= compute_budget(n, LESSON_REVIEW_CAP, scripted=True) <= 25
    # без сценария путь нового слова длиннее (4 шага), бюджет не меньше сценарного
    assert compute_budget(4, LESSON_REVIEW_CAP) >= compute_budget(4, LESSON_REVIEW_CAP, scripted=True)
    assert compute_budget(1, 0, scripted=True) >= 15


def test_normal_review_flow_does_not_cut_new_words():
    for due in range(BACKLOG_THRESHOLD + 1):
        assert lesson_mix(4, due) == (4, LESSON_REVIEW_CAP)


def test_backlog_cuts_new_words_but_never_to_pure_review():
    prev = 5
    for due in (BACKLOG_THRESHOLD + 1, 2 * BACKLOG_THRESHOLD, 2 * BACKLOG_THRESHOLD + 1, 200):
        new, cap = lesson_mix(5, due)
        assert 1 <= new < 5 and new <= prev
        assert cap == BACKLOG_REVIEW_CAP
        prev = new
    # долг ограничен: повторений в уроке не больше BACKLOG_REVIEW_CAP, бюджет остаётся обычным
    assert compute_budget(lesson_mix(5, 200)[0], BACKLOG_REVIEW_CAP, scripted=True) <= 25
    assert 0 < MAX_RETRIES_PER_LESSON <= 4


# ---------------------------------------------------------------------------
# Компактное повторение и приоритет слабых
# ---------------------------------------------------------------------------

def _per_word(steps):
    out = {}
    for s in steps:
        out[s.word_id] = out.get(s.word_id, 0) + 1
    return out


def test_compact_review_gives_one_step_to_due_and_two_to_weak():
    reviews = [_w(1, "learning", "weak"), _w(2, "review", "due"), _w(3, "review", "due"), _w(4, "learning", "due")]
    steps = plan_lesson([], reviews, ZERO, POOL, budget=40, rng=Random(3), review_cap=4, compact_review=True)
    per = _per_word(steps)
    assert per[1] >= 2
    assert per[2] == per[3] == per[4] == 1
    # без compact_review (Phase H по умолчанию) — прежнее повторение: recall + фокус
    full = _per_word(plan_lesson([], reviews, ZERO, POOL, budget=40, rng=Random(3), review_cap=4))
    assert all(full[i] >= 2 for i in (2, 3, 4))


def test_weak_practice_is_kept_even_when_new_words_fill_the_budget():
    new = [_w(i) for i in range(20, 25)]
    weak = [_w(30, "learning", "weak"), _w(31, "learning", "weak")]
    budget = compute_budget(len(new), LESSON_REVIEW_CAP)
    steps = plan_lesson(new, [], ZERO, POOL, budget=budget, rng=Random(1), practice_items=weak, compact_review=True)
    ids = {s.word_id for s in steps}
    assert {30, 31} <= ids
    assert {20, 21, 22, 23, 24} <= ids


def test_backlog_lesson_has_both_new_words_and_capped_review():
    """Урок при долге: все выбранные новые слова введены, повторение — ровно cap слов, не больше."""
    new_n, cap = lesson_mix(5, 3 * BACKLOG_THRESHOLD)
    new = [_w(i) for i in range(20, 20 + new_n)]
    reviews = [_w(i, "review", "due") for i in range(1, 15)]
    budget = compute_budget(new_n, cap)
    steps = plan_lesson(new, reviews, ZERO, POOL, budget=budget, rng=Random(2), review_cap=cap, compact_review=True)
    assert {w["id"] for w in new} <= {s.word_id for s in steps if s.type == "introduction"}
    reviewed = {s.word_id for s in steps if s.word_id in range(1, 15)}
    assert 1 <= len(reviewed) <= cap
    assert len(steps) <= budget


# ---------------------------------------------------------------------------
# Разделение сценария при долге
# ---------------------------------------------------------------------------

SCRIPT = {
    "new_word_ids": [1, 2, 3, 4, 5],
    "phrases": [{"word_ids": [1, 2]}, {"word_ids": [1, 3]}, {"word_ids": [4, 5]}],
    "translations": [{"word_ids": [1, 2, 9]}],
    "speaking": [{"word_ids": [2, 9]}],
    "dialogue": {"lines": [{"user": False, "word_ids": [9]}, {"user": True, "word_ids": [1, 2]}]},
}


def test_split_keeps_most_usable_script_items_in_script_order():
    seen = {9}
    picked = split_new_words(SCRIPT, seen, 2)
    assert picked == [1, 2]                     # фразы, перевод, речь и диалог остаются в уроке
    rest = lesson_new_ids(SCRIPT, seen | set(picked))
    assert rest == [3, 4, 5]
    assert split_new_words(SCRIPT, seen, 5) == [1, 2, 3, 4, 5]
    assert split_new_words(SCRIPT, seen, 0) == []


def test_split_introduces_other_module_words_now():
    """Слово чужой темы нельзя отложить: модуль закроется по своим словам и оно потеряется."""
    picked = split_new_words(SCRIPT, {9}, 2, own_ids={1, 2, 3, 4})
    assert 5 in picked and len(picked) == 2
    # чужие слова вводятся все, даже сверх limit; откладываются только свои
    assert split_new_words(SCRIPT, {9}, 2, own_ids={1}) == [2, 3, 4, 5]
    # своих слов в сценарии нет — откладывать нечего, урок не делится
    assert split_new_words(SCRIPT, {9}, 2, own_ids={7}) == [1, 2, 3, 4, 5]
