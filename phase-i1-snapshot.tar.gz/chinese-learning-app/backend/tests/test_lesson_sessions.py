"""
Сессия урока через API: клиент получает шаги без ответов, присылает действие
пользователя, правильность решает сервер; ошибки возвращаются повтором в конце
урока; итог урока считается по фактам сессии.
"""

import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.services.lesson_service import ANSWER_FIELDS


@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_sessions.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def first_module(client):
    path = client.get("/api/learning-path").json()
    return path["recommended_module_id"]


def server_steps(session_id):
    from app.db import get_db
    from app.repositories import lesson_sessions_repo

    with get_db() as conn:
        return lesson_sessions_repo.get(conn, session_id)["steps"]


def answer_for(step, correct=True):
    p = step["payload"]
    if step["type"] == "introduction":
        return None
    if step["type"] == "matching":
        pairs = list(p["answers"])
        return {"pairs": pairs if correct else [pairs[1], pairs[0], *pairs[2:]]}
    if step["type"] == "tone_choice" and "syllables" in p:
        tones = [p["answers"][i] for i, s in enumerate(p["syllables"]) if s["tested"]]
        return {"tones": tones if correct else [tones[0] % 4 + 1, *tones[1:]]}
    if "answer_index" in p:
        return p["answer_index"] if correct else (p["answer_index"] + 1) % len(p["options"])
    if step["type"] == "sentence_order":
        return p["answer_tokens"] if correct else list(reversed(p["answer_tokens"]))
    if step["type"] == "pinyin_input":
        return p["answer"] if correct else "zzz"
    if step["type"] == "recall":
        return 2 if correct else 0
    if step["type"] == "handwriting":
        return {"mistakes": 0 if correct else 5}
    raise AssertionError(step["type"])


def test_start_hides_answers_and_numbers_steps(client):
    plan = client.post(f"/api/lessons/{first_module(client)}/start").json()
    assert plan["session_id"] and plan["steps"]
    for i, step in enumerate(plan["steps"]):
        assert step["index"] == i
        assert not set(step["payload"]) & set(ANSWER_FIELDS)
    assert "mix" in plan and plan["mix"]["new_limit"] >= 1


def test_server_decides_correctness_and_counts_attempts(client):
    from app.db import get_db

    plan = client.post(f"/api/lessons/{first_module(client)}/start").json()
    sid = plan["session_id"]
    steps = server_steps(sid)
    graded = next(i for i, s in enumerate(steps) if s["graded"] and "answer_index" in s["payload"])
    url = f"/api/sessions/{sid}/attempts"

    wrong = client.post(url, json={"step_index": graded, "answer": answer_for(steps[graded], False)}).json()
    assert wrong["correct"] is False and wrong["expected"] and wrong["explanation"]
    appended = wrong["appended_step"]
    assert appended and appended["retry"] and appended["index"] == len(steps)
    assert not set(appended["payload"]) & set(ANSWER_FIELDS)

    # повтор отправки того же шага не засчитывается второй раз
    again = client.post(url, json={"step_index": graded, "answer": answer_for(steps[graded], True)}).json()
    assert again["repeated"] and again["correct"] is False
    with get_db() as conn:
        n = conn.execute("SELECT COUNT(*) FROM attempts").fetchone()[0]
    assert n == 1

    # повтор ошибки добавляется один раз на слово
    steps = server_steps(sid)
    same_word = [i for i, s in enumerate(steps) if s["word_id"] == steps[graded]["word_id"]
                 and s["graded"] and i != graded and not s.get("retry")]
    if same_word:
        res = client.post(url, json={"step_index": same_word[0], "answer": answer_for(steps[same_word[0]], False)})
        assert res.json()["appended_step"] is None


def test_bad_answers_are_rejected_not_counted(client):
    plan = client.post(f"/api/lessons/{first_module(client)}/start").json()
    sid = plan["session_id"]
    steps = server_steps(sid)
    graded = next(i for i, s in enumerate(steps) if "answer_index" in s["payload"])
    url = f"/api/sessions/{sid}/attempts"
    assert client.post(url, json={"step_index": graded, "answer": 99}).status_code == 400
    assert client.post(url, json={"step_index": 999, "answer": 0}).status_code == 400
    assert client.post("/api/sessions/nope/attempts", json={"step_index": 0, "answer": 0}).status_code == 404


def test_full_lesson_updates_srs_and_returns_honest_summary(client):
    from app.db import get_db

    module_id = first_module(client)
    plan = client.post(f"/api/lessons/{module_id}/start").json()
    sid = plan["session_id"]
    url = f"/api/sessions/{sid}/attempts"
    i, wrong_once = 0, False
    while i < len(server_steps(sid)):
        step = server_steps(sid)[i]
        correct = True
        if step["graded"] and not wrong_once and not step.get("retry"):
            correct, wrong_once = False, True          # одна ошибка за урок
        res = client.post(url, json={"step_index": i, "answer": answer_for(step, correct)})
        assert res.status_code == 200, res.text
        i += 1

    summary = client.post(f"/api/sessions/{sid}/complete").json()
    acc = summary["accuracy"]
    assert acc["graded"] >= 1 and acc["correct"] == acc["graded"] - 1
    assert acc["percent"] == round(100 * acc["correct"] / acc["graded"])
    assert {w["id"] for w in summary["new_words"]} == {w["id"] for w in plan["new_words"]}
    assert all(w["result"] in ("ok", "improved", "hard", "again") for w in summary["new_words"])
    assert len(summary["mistakes"]) == 1 and summary["mistakes"][0]["expected"]
    assert summary["next_review_date"] and summary["next"]
    # слово с ошибкой — в списке «повторить», остальные новые засчитаны
    assert summary["to_repeat"] and summary["to_repeat"][0]["id"] == summary["mistakes"][0]["id"]

    # итог идемпотентен, completion записан один раз
    assert client.post(f"/api/sessions/{sid}/complete").json() == summary
    with get_db() as conn:
        assert conn.execute("SELECT COUNT(*) FROM lesson_completions").fetchone()[0] == 1
        learned = conn.execute("SELECT COUNT(*) FROM progress WHERE repetitions > 0").fetchone()[0]
    assert learned >= len(plan["new_words"]) - 1
    # после завершения ответы не принимаются
    assert client.post(url, json={"step_index": 0, "answer": None}).status_code == 400


def test_review_session(client):
    from app.db import get_db

    with get_db() as conn:
        conn.execute("UPDATE progress SET repetitions = 1, interval_days = 1, total_attempts = 1, "
                     "due_date = '2000-01-01' WHERE word_id IN (SELECT id FROM words ORDER BY id LIMIT 3)")
    plan = client.post("/api/review/start").json()
    assert plan["session_id"] and len(plan["review_words"]) == 3
    sid = plan["session_id"]
    for i, step in enumerate(server_steps(sid)):
        assert client.post(f"/api/sessions/{sid}/attempts",
                           json={"step_index": i, "answer": answer_for(step)}).status_code == 200
    summary = client.post(f"/api/sessions/{sid}/complete").json()
    assert summary["title"] == "Повторение" and len(summary["review_words"]) == 3
    assert summary["accuracy"]["percent"] == 100 and summary["mistakes"] == []


def test_tone_choice_step_per_syllable_via_api(client):
    """tone_choice через API: верные тоны клиенту не отдаются, ответ — тон на каждый слог."""
    modules = [m["id"] for m in client.get("/api/learning-path").json()["modules"]]
    for module_id in modules:
        plan = client.post(f"/api/lessons/{module_id}/start").json()
        found = [s for s in plan["steps"] if s["type"] == "tone_choice"]
        if found:
            break
    else:
        pytest.skip("в уроках нет шага tone_choice")
    step = found[0]
    assert "answers" not in step["payload"] and step["payload"]["syllables"]
    server = server_steps(plan["session_id"])[step["index"]]
    right = [t for t, s in zip(server["payload"]["answers"], server["payload"]["syllables"]) if s["tested"]]
    wrong = [right[0] % 4 + 1, *right[1:]]
    url = f"/api/sessions/{plan['session_id']}/attempts"
    assert client.post(url, json={"step_index": step["index"], "answer": {"tones": [5] * len(right)}}).status_code == 400
    res = client.post(url, json={"step_index": step["index"], "answer": {"tones": wrong}}).json()
    assert res["correct"] is False and "тон" in res["explanation"]
    assert len(res["expected"].split(" ")) == len(step["payload"]["syllables"])


def test_pinyin_error_step_via_api(client):
    """pinyin_error через API: номер ошибочной записи и сама ошибка клиенту не отдаются."""
    from random import Random

    from app.db import get_db
    from app.repositories import words_repo
    from app.services import lesson_service
    from engine import exercise_types as ex
    from engine.lesson_planner import Step

    with get_db() as conn:
        pool = [words_repo.word_row_to_dict(r) for r in conn.execute("SELECT * FROM words")]
        item = next(w for w in pool if len(w["hanzi"]) == 2 and ex.get("pinyin_error").requires(w, pool))
        t = ex.get("pinyin_error")
        step = Step(t.name, t.skill, item["id"], graded=True, mandatory=True,
                    payload=t.build(item, pool, Random(0)), phase=2).to_dict()
        plan = lesson_service._new_session(conn, {"steps": [step], "new_words": [], "review_words": [item]},
                                           None, "review")
    client_payload = plan["steps"][0]["payload"]
    assert set(client_payload) == {"prompt", "hint", "question", "options", "used_word_ids"}
    server = server_steps(plan["session_id"])[0]["payload"]
    url = f"/api/sessions/{plan['session_id']}/attempts"
    wrong = (server["answer_index"] + 1) % len(server["options"])
    res = client.post(url, json={"step_index": 0, "answer": wrong}).json()
    assert res["correct"] is False and res["expected"] == server["options"][server["answer_index"]]
    assert "записано верно" in res["explanation"]


def test_matching_end_to_end_in_lesson_session(client):
    """
    Сопоставление в настоящей сессии урока: первый урок делает слова знакомыми;
    во втором уроке шаг matching либо есть в плане, либо появляется повтором
    после ошибки в recognition (тот же навык). Пары клиенту не отдаются, ответ с
    двумя переставленными парами — неверный с объяснением, итог урока его учитывает.
    """
    def answer(sid, i, correct=True):
        step = server_steps(sid)[i]
        return client.post(f"/api/sessions/{sid}/attempts",
                           json={"step_index": i, "answer": answer_for(step, correct)}).json()

    first = client.post(f"/api/lessons/{first_module(client)}/start").json()
    for i in range(len(first["steps"])):
        answer(first["session_id"], i)
    assert client.post(f"/api/sessions/{first['session_id']}/complete").status_code == 200

    plan = client.post(f"/api/lessons/{first_module(client)}/start").json()
    sid = plan["session_id"]
    at = next(i for i, s in enumerate(server_steps(sid)) if s["type"] in ("matching", "recognition"))
    for i in range(at):
        answer(sid, i)
    visible = next(s for s in plan["steps"] if s["index"] == at)
    if visible["type"] == "recognition":          # ошибка -> повтор того же навыка в конце урока
        visible = answer(sid, at, correct=False)["appended_step"]
        assert visible and visible["type"] == "matching"
        for i in range(at + 1, visible["index"]):
            answer(sid, i)
        at = visible["index"]

    step = server_steps(sid)[at]
    assert step["type"] == "matching" and len(step["payload"]["left"]) >= 3
    assert "answers" not in visible["payload"] and visible["payload"]["left"] == step["payload"]["left"]
    url = f"/api/sessions/{sid}/attempts"
    assert client.post(url, json={"step_index": at, "answer": {"pairs": [0, 0, 1]}}).status_code == 400
    res = answer(sid, at, correct=False)
    assert res["correct"] is False and res["explanation"].startswith("Неверные пары (2 из")
    assert len(res["expected"].split("\n")) == len(step["payload"]["left"])

    i = at + 1
    while i < len(server_steps(sid)):      # остальные шаги (и повторы) — верно
        answer(sid, i)
        i += 1
    summary = client.post(f"/api/sessions/{sid}/complete").json()
    assert any(m["exercise"] == "сопоставление" for m in summary["mistakes"])
