"""
Курс HSK1-3: раскладка слов по модулям тема × уровень, подключение
импортированных HSK-слов, баланс новое/повторение, забытые слова и
known-vocabulary guard по порядку урока.
"""

import sys
import tempfile
from pathlib import Path
from random import Random

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from app import curriculum as cur
from engine import exercise_types as ex
from engine.lesson_planner import (
    BACKLOG_REVIEW_CAP,
    BACKLOG_THRESHOLD,
    LESSON_REVIEW_CAP,
    lesson_mix,
    plan_lesson,
)

ZERO = {s: 0.0 for s in ["vocabulary", "characters", "pinyin", "tones", "listening", "grammar", "writing", "speaking"]}


# ---------- раскладка по модулям (чистая логика) ----------

def w(i, category, hsk):
    return {"id": i, "category": category, "hsk": hsk}


def test_plan_course_modules_splits_by_level():
    plan = cur.plan_course_modules([w(1, "люди", 1), w(2, "люди", 1), w(3, "люди", 2), w(4, "люди", 2)])
    assert plan == {("люди", 1): [1, 2], ("люди", 2): [3, 4]}


def test_tiny_group_folds_into_next_level_not_earlier():
    # одно слово HSK1 не становится модулем: уходит в HSK2 (лёгкое слово чуть позже)
    plan = cur.plan_course_modules([w(1, "транспорт", 1), w(2, "транспорт", 2), w(3, "транспорт", 2)])
    assert plan == {("транспорт", 2): [1, 2, 3]}


def test_tiny_top_level_folds_into_previous_level():
    plan = cur.plan_course_modules([w(1, "работа", 2), w(2, "работа", 2), w(3, "работа", 3)])
    assert plan == {("работа", 2): [1, 2, 3]}


def test_words_without_category_are_not_in_course():
    assert cur.plan_course_modules([w(1, None, 1), w(2, None, 1)]) == {}


def test_route_goes_through_all_topics_level_by_level():
    mods = [{"id": i, "category": c, "hsk_level": lvl, "order_index": i}
            for i, (c, lvl) in enumerate([("еда", 1), ("люди", 2), ("числа", 1), ("люди", 1),
                                          ("действия", 1), ("время", 1)], start=1)]
    ordered = cur.route_order(mods)
    assert [(m["category"], m["hsk_level"]) for m in ordered] == [
        ("люди", 1), ("числа", 1), ("время", 1), ("действия", 1), ("еда", 1), ("люди", 2)]
    assert ordered[0]["section_key"] == "basics-1" and ordered[-1]["section_key"] == "basics-2"
    assert ordered[0]["section_id"] == ordered[-1]["section_id"] == "basics"   # оттенок раздела общий
    assert ordered[-1]["section_title"] == "Основы · HSK 2"
    assert ordered[-1]["position_in_section"] == 0


# ---------- баланс новое / повторение ----------

def test_lesson_mix_cuts_new_words_when_review_backlog_grows():
    """Phase I.1: обычный поток повторений (до BACKLOG_THRESHOLD) не режет новые слова;
    при долге новых меньше, но не ноль, а повторений больше — урок не становится чистым повторением."""
    assert lesson_mix(5, 0) == (5, LESSON_REVIEW_CAP)
    assert lesson_mix(5, BACKLOG_THRESHOLD) == (5, LESSON_REVIEW_CAP)
    new_mid, cap_mid = lesson_mix(5, BACKLOG_THRESHOLD + 1)
    assert 1 <= new_mid < 5 and cap_mid == BACKLOG_REVIEW_CAP > LESSON_REVIEW_CAP
    new_hi, cap_hi = lesson_mix(5, 100)
    assert 1 <= new_hi <= new_mid and cap_hi == cap_mid
    assert lesson_mix(0, 100)[0] == 0


def test_short_module_tail_is_taken_now_not_left_for_a_two_step_lesson():
    assert lesson_mix(5, 0, module_remaining=6)[0] == 6      # иначе следующий урок = 1 слово
    assert lesson_mix(5, 0, module_remaining=7)[0] == 7
    assert lesson_mix(5, 0, module_remaining=8)[0] == 5      # хвост 3 — нормальный урок
    assert lesson_mix(5, 0, module_remaining=3)[0] == 5      # меньше лимита — берётся сколько есть
    assert lesson_mix(0, 0, module_remaining=1)[0] == 0


def test_review_cap_param_limits_reviews():
    pool = [{"id": i, "hanzi": f"字{i}", "pinyin": f"zì{i}", "translation": f"слово {i}", "state": "review"}
            for i in range(1, 30)]
    steps = plan_lesson([], pool[:20], ZERO, pool, budget=100, rng=Random(1), review_cap=12)
    assert len({s.word_id for s in steps}) == 12


def test_lapsed_review_word_is_repeated_not_reintroduced():
    pool = [{"id": i, "hanzi": h, "pinyin": p, "translation": t, "state": "new"}
            for i, (h, p, t) in enumerate([("你", "nǐ", "ты"), ("我", "wǒ", "я"), ("好", "hǎo", "хороший"),
                                           ("人", "rén", "человек")], start=1)]
    steps = plan_lesson([], [pool[0]], ZERO, pool, rng=Random(1))
    assert steps[0].type == "recall" and all(s.type != "introduction" for s in steps)


def test_words_learned_today_get_one_practice_step_without_srs():
    pool = [{"id": i, "hanzi": h, "pinyin": p, "translation": t, "state": "learning"}
            for i, (h, p, t) in enumerate([("你", "nǐ", "ты"), ("我", "wǒ", "я"), ("好", "hǎo", "хороший"),
                                           ("人", "rén", "человек"), ("大", "dà", "большой")], start=1)]
    new = [{**pool[4], "state": "new"}]
    steps = plan_lesson(new, [], ZERO, pool, rng=Random(1), practice_items=pool[:2])
    practice = [s for s in steps if s.word_id in (1, 2)]
    assert len(practice) == 2 and all(not s.final and s.type != "recall" for s in practice)
    assert any(s.final for s in steps if s.word_id == 5)              # новое слово — как обычно
    # при заполненной очереди повторения закрепления нет
    reviews = [{**pool[2], "state": "review"}, {**pool[3], "state": "review"}]
    steps = plan_lesson([], reviews, ZERO, pool, rng=Random(1), review_cap=2, practice_items=pool[:2])
    assert {s.word_id for s in steps} == {3, 4}


# ---------- known-vocabulary guard по порядку урока ----------

POOL = [
    {"id": 1, "hanzi": "我", "pinyin": "wǒ", "translation": "я", "state": "new"},
    {"id": 2, "hanzi": "是", "pinyin": "shì", "translation": "быть", "state": "new"},
    {"id": 3, "hanzi": "学生", "pinyin": "xuésheng", "translation": "студент", "state": "new"},
    {"id": 4, "hanzi": "老师", "pinyin": "lǎoshī", "translation": "учитель", "state": "new"},
    {"id": 5, "hanzi": "好", "pinyin": "hǎo", "translation": "хороший", "state": "new"},
]


def with_example(word, sentence, ids):
    return {**word, "examples": [{"id": 900 + word["id"], "sentence_cn": sentence, "sentence_ru": "—",
                                  "used_word_ids": ids}]}


def test_example_of_first_new_word_may_not_use_a_later_new_word():
    first = with_example(POOL[0], "我是学生。", [1, 2, 3])   # 是 и 学生 вводятся ПОЗЖЕ в этом уроке
    steps = plan_lesson([first, POOL[1], POOL[2]], [], {**ZERO, "grammar": 0}, POOL, rng=Random(3))
    for s in steps:
        if s.word_id == 1:
            assert s.type not in ("fill_blank", "sentence_order")
            if s.type == "introduction":
                assert s.payload["example_cn"] is None


def test_example_may_use_words_introduced_earlier_in_the_lesson():
    last = with_example(POOL[2], "我是学生。", [1, 2, 3])
    steps = plan_lesson([POOL[0], POOL[1], last], [], ZERO, POOL, rng=Random(3))
    intro = next(s for s in steps if s.word_id == 3 and s.type == "introduction")
    assert intro.payload["example_cn"] == "我是学生。"
    first_intro = {s.word_id: i for i, s in reversed(list(enumerate(steps))) if s.type == "introduction"}
    for i, s in enumerate(steps):
        for wid in (s.payload or {}).get("used_word_ids") or []:
            assert wid == s.word_id or first_intro[wid] < i


def test_introduction_hides_legacy_example_with_unknown_words():
    word = {**POOL[2], "example_cn": "我是学生。", "example_ru": "Я студент.",
            "examples": [{"id": 1, "sentence_cn": "我是学生。", "sentence_ru": "Я студент.", "used_word_ids": [1, 2, 3]}]}
    payload = ex.get("introduction").build(word, POOL, Random(0), {"known_word_ids": set()})
    assert payload["example_cn"] is None and payload["example_ru"] is None
    payload = ex.get("introduction").build(word, POOL, Random(0), {"known_word_ids": {1, 2}})
    assert payload["example_cn"] == "我是学生。"


def test_introduction_without_examples_table_shows_no_unchecked_example():
    word = {**POOL[2], "example_cn": "老师好。", "example_ru": "—", "examples": []}
    payload = ex.get("introduction").build(word, POOL, Random(0), {"known_word_ids": {1, 2, 4, 5}})
    assert payload["example_cn"] is None


# ---------- честные варианты ответа ----------

def test_listening_never_offers_a_homophone_as_distractor():
    pool = [{"id": 1, "hanzi": "他", "pinyin": "tā", "translation": "он"},
            {"id": 2, "hanzi": "她", "pinyin": "tā", "translation": "она"},
            {"id": 3, "hanzi": "它", "pinyin": "tā", "translation": "оно"},
            {"id": 4, "hanzi": "我", "pinyin": "wǒ", "translation": "я"},
            {"id": 5, "hanzi": "你", "pinyin": "nǐ", "translation": "ты"},
            {"id": 6, "hanzi": "好", "pinyin": "hǎo", "translation": "хороший"}]
    for seed in range(20):
        payload = ex.get("listening").build(pool[0], pool, Random(seed))
        assert "她" not in payload["options"] and "它" not in payload["options"]


def test_recognition_never_offers_a_synonym_as_distractor():
    pool = [{"id": 1, "hanzi": "家", "pinyin": "jiā", "translation": "дом, семья", "category": "дом"},
            {"id": 2, "hanzi": "房子", "pinyin": "fángzi", "translation": "дом (здание)", "category": "дом"},
            {"id": 3, "hanzi": "门", "pinyin": "mén", "translation": "дверь", "category": "дом"},
            {"id": 4, "hanzi": "床", "pinyin": "chuáng", "translation": "кровать", "category": "дом"},
            {"id": 5, "hanzi": "桌子", "pinyin": "zhuōzi", "translation": "стол", "category": "дом"},
            {"id": 6, "hanzi": "椅子", "pinyin": "yǐzi", "translation": "стул", "category": "дом"}]
    for seed in range(20):
        payload = ex.get("recognition").build(pool[0], pool, Random(seed))
        assert "дом (здание)" not in payload["options"]


def test_pinyin_choice_ignores_spacing_variants():
    pool = [{"id": 1, "hanzi": "时候", "pinyin": "shíhou", "translation": "момент"},
            {"id": 2, "hanzi": "X", "pinyin": "shí hou", "translation": "x"},
            {"id": 3, "hanzi": "我", "pinyin": "wǒ", "translation": "я"},
            {"id": 4, "hanzi": "你", "pinyin": "nǐ", "translation": "ты"},
            {"id": 5, "hanzi": "好", "pinyin": "hǎo", "translation": "хороший"}]
    payload = ex.get("pinyin_choice").build(pool[0], pool, Random(0))
    assert "shí hou" not in payload["options"]


def test_fill_blank_blanks_the_target_position_not_an_earlier_substring():
    pool = [{"id": 1, "hanzi": "中国人", "pinyin": "zhōngguórén", "translation": "китаец"},
            {"id": 2, "hanzi": "是", "pinyin": "shì", "translation": "быть"},
            {"id": 3, "hanzi": "人", "pinyin": "rén", "translation": "человек"},
            {"id": 4, "hanzi": "好", "pinyin": "hǎo", "translation": "хороший"},
            {"id": 5, "hanzi": "我", "pinyin": "wǒ", "translation": "я"}]
    item = {**pool[2], "examples": [{"id": 1, "sentence_cn": "中国人是人。", "sentence_ru": "—",
                                     "used_word_ids": [1, 2, 3]}]}
    payload = ex.get("fill_blank").build(item, pool, Random(0), {"known_word_ids": {1, 2}})
    assert payload["prompt"] == "中国人是＿＿。"


# ---------- БД: подключение HSK-слов, забытые слова ----------

@pytest.fixture()
def client():
    from app import db as db_module

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_hsk_course.db"
    db_module.init_db()

    from fastapi.testclient import TestClient

    from main import app

    return TestClient(app)


def _insert_imported(conn, hanzi, pinyin, translation, hsk):
    conn.execute(
        """INSERT INTO words (hanzi, pinyin, translation, hsk, hsk_version, category)
           VALUES (?, ?, ?, ?, '2.0', NULL)""", (hanzi, pinyin, translation, hsk))


def test_connect_script_puts_imported_words_into_level_modules(client):
    from app.db import get_db
    from scripts.connect_hsk_course import connect, normalize_pinyin

    assert normalize_pinyin("Běi jīng") == "běijīng"
    assert normalize_pinyin("kě ài") == "kě'ài"

    course_map = {
        "爱": {"category": "эмоции", "translation": "любить", "pinyin": None},
        "了": {"category": "грамматика", "translation": "частица завершённости", "pinyin": "le"},
        "吗": {"category": "грамматика", "translation": "вопросительная частица", "pinyin": "ma"},
    }
    with get_db() as conn:
        _insert_imported(conn, "爱", "ài", "to love", 1)
        _insert_imported(conn, "了", "liǎo", "to finish", 1)
        _insert_imported(conn, "吗", "má", "(coll.) what?", 1)
        _insert_imported(conn, "云", "Yún", "surname Yun", 3)   # нет в карте -> остаётся вне курса
        result = connect(conn, course_map, "2026-10-04", 1)
        again = connect(conn, course_map, "2026-10-04", 1)            # идемпотентно
        rows = {r["hanzi"]: dict(r) for r in conn.execute(
            "SELECT w.*, p.word_id AS has_progress FROM words w LEFT JOIN progress p ON p.word_id = w.id "
            "WHERE hsk_version = '2.0'")}
    assert result["updated"] == 3 and result["progress_added"] == 3 and result["unmapped"] == ["云"]
    assert again["progress_added"] == 0
    assert rows["了"]["pinyin"] == "le" and rows["了"]["translation"].startswith("частица")
    assert rows["了"]["translation_en"] == "to finish" and rows["了"]["translation_source"] == "draft_ru"

    # повторный прогон с проверенным переводом: source меняется, английский исходник не теряется
    course_map["爱"] = {**course_map["爱"], "translation": "любить (кого-то)", "source": "reviewed_ru"}
    with get_db() as conn:
        connect(conn, course_map, "2026-10-04", 1)
        love = dict(conn.execute("SELECT * FROM words WHERE hanzi = '爱'").fetchone())
    assert love["translation"] == "любить (кого-то)" and love["translation_source"] == "reviewed_ru"
    assert love["translation_en"] == "to love"
    assert rows["云"]["module_id"] is None and rows["云"]["has_progress"] is None
    assert rows["了"]["module_id"] == rows["吗"]["module_id"] is not None

    path = client.get("/api/learning-path").json()["modules"]
    grammar = next(m for m in path if m["category"] == "грамматика")
    assert grammar["hsk_level"] == 1 and grammar["total_words"] == 2
    assert grammar["section_title"] == "Повседневность · HSK 1"


def test_course_map_file_is_consistent():
    from scripts.connect_hsk_course import load_course_map

    course_map = load_course_map()
    route_categories = {c for s in cur.ROUTE_SECTIONS for c in s.categories}
    assert len(course_map) == 446
    assert {e["category"] for e in course_map.values()} <= route_categories
    assert all(e["translation"] and not any("a" <= ch.lower() <= "z" for ch in e["translation"])
               for e in course_map.values())                      # перевод русский, не английский
    # проверенная часть карты: статус reviewed или doubt с причиной (61 слово HSK1 +
    # отдельно проверенные служебные слова HSK2/3)
    reviewed = {h for h, e in course_map.items() if e["source"] == "reviewed_ru"}
    doubt = {h: e["doubt"] for h, e in course_map.items() if e["doubt"]}
    assert len(reviewed) + len(doubt) >= 61 and not reviewed & set(doubt)
    assert all(reason for reason in doubt.values())
    # Phase I: 了 и 呢 — спорность снята, перевод передаёт обе функции уровня HSK 1
    assert {"了", "呢", "的", "地", "得", "着"} <= reviewed and "把" in doubt
    assert "изменилась" in course_map["了"]["translation"] and "сейчас" in course_map["呢"]["translation"]
    assert all(course_map[h]["source"] == "draft_ru" for h in doubt)
    # иероглиф в переводе выдал бы ответ в recognition («частица (的)» при prompt 的)
    assert not any("\u4e00" <= ch <= "\u9fff" for e in course_map.values() for ch in e["translation"])


def test_forgotten_word_stays_in_review_and_does_not_reopen_its_module(client):
    from app.db import get_db

    first = client.get("/api/learning-path").json()["modules"][0]
    words = [x for x in client.get("/api/words", params={"category": first["category"]}).json()
             if x["module_id"] == first["id"]]
    for x in words:
        client.post(f"/api/lessons/{first['id']}/attempts", json={
            "word_id": x["id"], "exercise_type": "recognition", "correct": True, "final": True})
    forgotten = words[0]["id"]
    # провал на повторении: SM-2 сбрасывает repetitions в 0
    client.post(f"/api/lessons/{first['id']}/attempts", json={
        "word_id": forgotten, "exercise_type": "recognition", "correct": False, "final": True,
        "mistakes": 1, "attempts_total": 1})
    with get_db() as conn:
        row = conn.execute("SELECT repetitions, total_attempts FROM progress WHERE word_id = ?", (forgotten,)).fetchone()
        assert row["repetitions"] == 0 and row["total_attempts"] == 2
        conn.execute("UPDATE progress SET due_date = '2000-01-01' WHERE word_id = ?", (forgotten,))

    path = client.get("/api/learning-path").json()
    by_id = {m["id"]: m for m in path["modules"]}
    assert by_id[first["id"]]["state"] == "completed"           # маршрут не откатывается назад
    assert path["recommended_module_id"] != first["id"]

    nxt = path["recommended_module_id"]
    plan = client.get(f"/api/lessons/{nxt}/plan").json()
    assert forgotten in {x["id"] for x in plan["review_words"]}       # вернулось через review
    assert forgotten not in {x["id"] for x in plan["new_words"]}
    steps = [s for s in plan["steps"] if s["word_id"] == forgotten]
    assert steps and steps[0]["type"] == "recall"
    # ответ по забытому слову из чужого модуля принимается (оно уже в SRS)
    res = client.post(f"/api/lessons/{nxt}/attempts", json={
        "word_id": forgotten, "exercise_type": "recall", "correct": True, "final": True})
    assert res.status_code == 200


def test_sync_reuses_original_modules_and_hides_empty_ones(client):
    from app.db import get_db

    with get_db() as conn:
        mods = conn.execute("SELECT id, category, hsk_level FROM modules ORDER BY id").fetchall()
        # исходные 16 модулей (id 1..16) сохранены, у каждого есть слова
        counts = {r["id"]: r["n"] for r in conn.execute(
            "SELECT m.id, COUNT(w.id) n FROM modules m LEFT JOIN words w ON w.module_id = m.id GROUP BY m.id")}
        conn.execute("INSERT INTO modules (order_index, title, hsk_level, category) VALUES (999, 'Пусто', 1, 'люди')")
    assert all(counts[i] > 0 for i in range(1, 17))
    assert len(mods) == len({(m["category"], m["hsk_level"]) for m in mods})
    path = client.get("/api/learning-path").json()["modules"]
    assert "Пусто" not in {m["title"] for m in path}


def test_every_course_word_belongs_to_exactly_one_module(client):
    from app.db import get_db

    with get_db() as conn:
        orphans = conn.execute(
            """SELECT COUNT(*) FROM words w JOIN progress p ON p.word_id = w.id
               WHERE w.category IS NOT NULL AND w.module_id IS NULL""").fetchone()[0]
        mismatched = conn.execute(
            """SELECT COUNT(*) FROM words w JOIN modules m ON m.id = w.module_id
               WHERE m.category != w.category""").fetchone()[0]
    assert orphans == 0 and mismatched == 0


# ---------- партия примеров HSK1 (scripts/seed_hsk_examples.py) ----------

def test_hsk1_example_batch_is_well_formed():
    from scripts.seed_hsk_examples import (
        HSK1_SENTENCES,
        REPLACEMENT_SENTENCES,
        RETIRED_SENTENCES,
        SEED_SENTENCES,
    )

    targets = [t for t, *_ in HSK1_SENTENCES]
    assert len(targets) == len(set(targets))                          # по одному примеру на слово
    old = {(t, cn) for t, cn, _ in SEED_SENTENCES}
    active = old | {(t, cn) for t, cn, *_ in HSK1_SENTENCES + REPLACEMENT_SENTENCES}
    assert not active & set(RETIRED_SENTENCES)                        # снятые не вставляются заново
    for target, _ in RETIRED_SENTENCES:                                # у каждого снятого есть замена
        assert any(t == target for t, *_ in HSK1_SENTENCES + REPLACEMENT_SENTENCES)
    for target, cn, ru, pinyin in HSK1_SENTENCES + REPLACEMENT_SENTENCES:
        assert (target, cn) not in old
        assert cn.count(target) == 1, cn                               # fill_blank без подсказки
        assert all("一" <= ch <= "鿿" or ch in "。？！，" for ch in cn), cn
        assert ru and not any("a" <= ch.lower() <= "z" for ch in ru)
        assert pinyin and pinyin[-1] in ".?!" and not any("一" <= ch <= "鿿" for ch in pinyin)


def test_example_pinyin_check_uses_corrected_readings():
    """Проверка пиньиня не зависит от порядка скриптов: 了 сверяется с le из карты, а не с liǎo датасета."""
    from app import db as db_module
    from scripts.seed_hsk_examples import build_used_word_ids, check_pinyin

    db_module.DB_PATH = Path(tempfile.mkdtemp()) / "test_seed_pinyin.db"
    db_module.init_db()
    with db_module.get_db() as conn:
        _insert_imported(conn, "了", "liǎo", "to finish", 1)
        ids = build_used_word_ids(conn, "他来了。")
        assert ids is not None and len(ids) == 3
        assert check_pinyin(conn, ids, "Tā lái le.")
        assert not check_pinyin(conn, ids, "Tā lái liǎo.")
