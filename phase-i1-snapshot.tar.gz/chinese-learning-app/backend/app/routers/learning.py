from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..db import get_db
from ..services import learning_service

router = APIRouter(prefix="/api", tags=["learning"])


class ReviewIn(BaseModel):
    word_id: int
    quality: int  # 0=не знаю, 1=сложно, 2=хорошо, 3=легко


@router.get("/home")
def home():
    with get_db() as conn:
        return learning_service.home_stats(conn)


@router.get("/session")
def get_session(limit: int | None = None):
    with get_db() as conn:
        return learning_service.build_session(conn, limit)


@router.post("/review")
def submit_review(payload: ReviewIn):
    if payload.quality not in (0, 1, 2, 3):
        raise HTTPException(400, "quality должен быть 0..3")
    with get_db() as conn:
        result = learning_service.submit_review(conn, payload.word_id, payload.quality)
    if result is None:
        raise HTTPException(404, "Слово не найдено")
    return result
