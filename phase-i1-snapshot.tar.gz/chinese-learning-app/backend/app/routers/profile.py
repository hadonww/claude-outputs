from fastapi import APIRouter

from ..db import get_db
from ..services import profile_service, statistics_service

router = APIRouter(prefix="/api", tags=["profile"])


@router.get("/profile")
def profile():
    with get_db() as conn:
        return profile_service.get_profile(conn)


@router.get("/statistics")
def statistics(activity_days: int = 30):
    with get_db() as conn:
        return statistics_service.get_statistics(conn, activity_days=activity_days)
