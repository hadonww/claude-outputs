from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..db import get_db
from ..services import settings_service

router = APIRouter(prefix="/api", tags=["settings"])


class SettingsIn(BaseModel):
    daily_new_words: int | None = None
    preferred_hsk: int | None = None
    knows_pinyin: bool | None = None
    knows_tones: bool | None = None
    onboarded: bool | None = None


@router.get("/settings")
def get_settings():
    with get_db() as conn:
        return settings_service.get_settings(conn)


@router.post("/settings")
def update_settings(payload: SettingsIn):
    with get_db() as conn:
        result = settings_service.update_settings(conn, payload)
    if result is None:
        raise HTTPException(400, "Нечего обновлять")
    return result
