from fastapi import APIRouter, HTTPException

from ..db import get_db
from ..repositories.users_repo import get_current_user_id
from ..services import content_service

router = APIRouter(prefix="/api", tags=["content"])


@router.get("/words")
def search_words(q: str = "", category: str = "", hsk: int = 0, seen: bool = False, weak: bool = False):
    with get_db() as conn:
        return content_service.search_words(conn, q, category, hsk, seen, weak)


@router.get("/words/{word_id}")
def get_word(word_id: int):
    with get_db() as conn:
        word = content_service.get_word(conn, word_id)
    if word is None:
        raise HTTPException(404, "Слово не найдено")
    return word


@router.get("/categories")
def list_categories():
    with get_db() as conn:
        return content_service.list_categories(conn)


@router.post("/import-csv")
def import_csv(payload: dict):
    csv_text = payload.get("csv", "")
    if not csv_text.strip():
        raise HTTPException(400, "Пустой CSV")
    with get_db() as conn:
        user_id = get_current_user_id(conn)
        return content_service.import_csv(conn, csv_text, user_id)
