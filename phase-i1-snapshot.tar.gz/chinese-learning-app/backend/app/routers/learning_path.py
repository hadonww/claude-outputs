from fastapi import APIRouter

from ..db import get_db
from ..services import learning_path_service

router = APIRouter(prefix="/api", tags=["learning_path"])


@router.get("/learning-path")
def get_learning_path():
    with get_db() as conn:
        return learning_path_service.get_learning_path(conn)
