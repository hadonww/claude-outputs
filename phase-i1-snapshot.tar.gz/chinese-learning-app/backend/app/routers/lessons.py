from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..db import get_db
from ..services import lesson_service

router = APIRouter(prefix="/api", tags=["lessons"])


class AttemptIn(BaseModel):
    word_id: int
    exercise_type: str
    correct: bool
    final: bool = False
    mistakes: int = Field(0, ge=0)
    attempts_total: int = Field(1, ge=0)
    recall_quality: int | None = Field(None, ge=0, le=3)
    response_ms: int | None = Field(None, ge=0)


class SessionAttemptIn(BaseModel):
    step_index: int = Field(..., ge=0)
    # индекс варианта | список плиток | набранный пиньинь | самооценка 0..3 |
    # {"mistakes": n, "skipped": bool} для письма; для знакомства — null
    answer: int | str | list[str] | dict | None = None
    response_ms: int | None = Field(None, ge=0)


class KnownIn(BaseModel):
    step_index: int = Field(..., ge=0)


class CompletionIn(BaseModel):
    new_word_ids: list[int] = Field(default_factory=list)
    review_word_ids: list[int] = Field(default_factory=list)


@router.get("/lessons/{module_id}/plan")
def get_lesson_plan(module_id: int):
    with get_db() as conn:
        plan = lesson_service.get_lesson_plan(conn, module_id)
    if plan is None:
        raise HTTPException(404, "Модуль не найден")
    return plan


@router.post("/lessons/{module_id}/attempts")
def post_attempt(module_id: int, body: AttemptIn):
    with get_db() as conn:
        try:
            return lesson_service.record_attempt(conn, module_id, **body.model_dump())
        except LookupError:
            raise HTTPException(404, "Модуль не найден") from None
        except lesson_service.LessonError as e:
            raise HTTPException(400, str(e)) from None


@router.get("/review/plan")
def get_review_plan():
    with get_db() as conn:
        return lesson_service.get_review_plan(conn)


@router.post("/review/attempts")
def post_review_attempt(body: AttemptIn):
    with get_db() as conn:
        try:
            return lesson_service.record_attempt(conn, None, **body.model_dump())
        except lesson_service.LessonError as e:
            raise HTTPException(400, str(e)) from None


@router.post("/lessons/{module_id}/complete")
def complete_module_lesson(module_id: int, body: CompletionIn):
    with get_db() as conn:
        try:
            return lesson_service.complete_lesson(
                conn, module_id, new_word_ids=body.new_word_ids, review_word_ids=body.review_word_ids)
        except LookupError:
            raise HTTPException(404, "Модуль не найден") from None


@router.post("/review/complete")
def complete_review_session(body: CompletionIn):
    with get_db() as conn:
        return lesson_service.complete_lesson(
            conn, None, new_word_ids=body.new_word_ids, review_word_ids=body.review_word_ids)


# --- Сессии урока: план без ответов, проверка на сервере (2026-10) ---

@router.post("/lessons/{module_id}/start")
def start_lesson(module_id: int):
    with get_db() as conn:
        plan = lesson_service.start_lesson(conn, module_id)
    if plan is None:
        raise HTTPException(404, "Модуль не найден")
    return plan


@router.post("/review/start")
def start_review():
    with get_db() as conn:
        return lesson_service.start_review(conn)


@router.post("/sessions/{session_id}/attempts")
def post_session_attempt(session_id: str, body: SessionAttemptIn):
    with get_db() as conn:
        try:
            return lesson_service.record_session_attempt(
                conn, session_id, body.step_index, body.answer, body.response_ms)
        except LookupError:
            raise HTTPException(404, "Урок не найден") from None
        except lesson_service.LessonError as e:
            raise HTTPException(400, str(e)) from None


@router.post("/sessions/{session_id}/complete")
def complete_session(session_id: str):
    with get_db() as conn:
        try:
            return lesson_service.complete_session(conn, session_id)
        except LookupError:
            raise HTTPException(404, "Урок не найден") from None


# --- Phase H: «я это уже знаю» и оценка произношения ---

@router.post("/sessions/{session_id}/known")
def claim_known(session_id: str, body: KnownIn):
    with get_db() as conn:
        try:
            return lesson_service.claim_known(conn, session_id, body.step_index)
        except LookupError:
            raise HTTPException(404, "Урок не найден") from None
        except lesson_service.LessonError as e:
            raise HTTPException(400, str(e)) from None


@router.post("/sessions/{session_id}/steps/{step_index}/speech")
async def assess_speech(session_id: str, step_index: int, request: Request):
    """Тело запроса — запись голоса (audio/webm, audio/mp4, audio/wav…)."""
    audio = await request.body()
    with get_db() as conn:
        try:
            return lesson_service.assess_speaking(conn, session_id, step_index, audio)
        except LookupError:
            raise HTTPException(404, "Урок не найден") from None
        except lesson_service.LessonError as e:
            raise HTTPException(400, str(e)) from None


@router.get("/pronunciation/status")
def pronunciation_status():
    from ..services import pronunciation_service

    return {"available": pronunciation_service.is_available()}
