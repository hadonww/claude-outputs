from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..db import get_db
from ..repositories import users_repo
from ..services import account_service

router = APIRouter(prefix="/api/me", tags=["account"])


class UsernameIn(BaseModel):
    username: str


@router.get("")
def me():
    with get_db() as conn:
        return account_service.get_account(conn, users_repo.get_current_user_id(conn))


@router.put("/username")
def change_username(payload: UsernameIn):
    with get_db() as conn:
        user_id = users_repo.get_current_user_id(conn)
        try:
            account_service.change_username(conn, user_id, payload.username)
        except account_service.UsernameTaken as exc:
            raise HTTPException(409, str(exc)) from exc
        except account_service.UsernameError as exc:
            raise HTTPException(400, str(exc)) from exc
        return account_service.get_account(conn, user_id)


@router.post("/onboarding/complete")
def complete_onboarding():
    with get_db() as conn:
        user_id = users_repo.get_current_user_id(conn)
        account_service.complete_onboarding(conn, user_id)
        return account_service.get_account(conn, user_id)
