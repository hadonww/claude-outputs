"""
Маршрут курса (Learning Path): порядок модулей и тематические разделы.

Модули в БД (`modules`, их `order_index`) — это лишь набор единиц контента.
Порядок, в котором пользователь их проходит, и группировка в «главы» живут
здесь, отдельно от данных: курс можно перестроить правкой ROUTE_SECTIONS, без
миграции таблицы модулей.

Модуль = тема (категория) × уровень HSK (`modules.hsk_level`). Маршрут проходит
весь список тем на уровне 1, затем на уровне 2 и т.д.: «Люди·1 → Числа·1 →
Время·1 → Действия·1 → … → Люди·2 → …», поэтому слово HSK3 никогда не идёт
раньше слова HSK1 только из-за порядка тем. Раскладку слов по модулям считает
plan_course_modules() (крошечные группы сливаются с соседним уровнем той же
темы), применяет её modules_repo.sync_course_modules().

Линейность — политика, а не структура: доступность модуля вычисляет
compute_statuses(). Сейчас открыт только следующий по маршруту модуль;
`unlocked_ids` — точка расширения, через которую placement-тест или проверка
«Я это уже знаю» смогут открыть модуль, не меняя ни маршрут, ни данные.

Чистый модуль: без FastAPI и SQL, поэтому тестируется на обычных словарях.
"""

from collections.abc import Iterable
from dataclasses import dataclass


@dataclass(frozen=True)
class Section:
    id: str
    title_zh: str
    title_ru: str
    categories: tuple[str, ...]  # категории слов = модули раздела, в порядке прохождения


ROUTE_SECTIONS: tuple[Section, ...] = (
    Section("basics", "基础", "Основы", ("люди", "числа", "время")),
    Section("everyday", "日常生活", "Повседневность",
            ("действия", "изменения и процессы", "грамматика", "семья", "дом", "эмоции",
             "повседневная жизнь")),
    Section("food", "食物", "Еда и покупки", ("еда", "покупки")),
    Section("study_work", "学习工作", "Учёба и работа", ("школа", "работа", "технологии")),
    Section("world", "出行", "Мир вокруг", ("транспорт", "путешествия", "природа")),
    # Темы, которые появляются только с HSK 4 (лексика HSK 4 — на треть абстрактная:
    # характер, общество, рассуждения, связки). Раздел без модулей уровня просто
    # не показывается на этом уровне, поэтому маршрут HSK 1–3 не меняется.
    Section("society", "人与社会", "Люди и общество",
            ("характер", "здоровье и спорт", "культура и досуг", "общество")),
    Section("thinking", "思考表达", "Мысли и связная речь",
            ("мнения и рассуждения", "абстрактные понятия", "качества и свойства",
             "оценка и модальность", "наречия времени", "союзы и связки")),
)

# Короткое описание модуля для пути обучения: что за слова внутри и зачем они.
# Тема одна на все уровни, поэтому описание общее; уровень показывает заголовок главы.
CATEGORY_DESCRIPTIONS: dict[str, str] = {
    "люди": "Местоимения, люди вокруг, внешность и возраст",
    "числа": "Счёт, количество, номера и доли",
    "время": "Часы, дни, сроки и «когда»",
    "действия": "Базовые глаголы: что делаем руками и ногами",
    "изменения и процессы": "Глаголы изменения: увеличить, продолжить, отказаться",
    "грамматика": "Частицы, предлоги, счётные слова и служебные слова",
    "семья": "Родственники и семейные отношения",
    "дом": "Квартира, вещи и домашние дела",
    "эмоции": "Чувства, настроение и реакции",
    "повседневная жизнь": "Бытовые ситуации и распорядок дня",
    "еда": "Блюда, вкусы, кафе и застолье",
    "покупки": "Магазин, цены, деньги и оплата",
    "школа": "Учёба, экзамены и язык",
    "работа": "Профессии, офис и карьера",
    "технологии": "Телефон, компьютер и интернет",
    "транспорт": "Как добраться: транспорт и дорога",
    "путешествия": "Поездки, места и достопримечательности",
    "природа": "Погода, животные, растения и мир вокруг",
    "характер": "Черты характера и поведение людей",
    "здоровье и спорт": "Тело, самочувствие, врач и спорт",
    "культура и досуг": "Книги, театр, кино и мероприятия",
    "общество": "Закон, СМИ, экономика и экология",
    "мнения и рассуждения": "Как высказать мнение, согласиться и возразить",
    "абстрактные понятия": "Причина, результат, условие, особенность",
    "качества и свойства": "Описать предмет: сложный, точный, широкий",
    "оценка и модальность": "Наречия оценки: наверняка, неужели, как раз",
    "наречия времени": "Как развиваются события: вдруг, постепенно, всё ещё",
    "союзы и связки": "Связная речь: хотя, поэтому, не только… но и",
}


def module_description(category: str | None) -> str | None:
    return CATEGORY_DESCRIPTIONS.get(category or "")

# Модули, которых нет в маршруте (например, новая категория из CSV-импорта),
# не теряются: они идут в конце отдельным разделом, в порядке order_index.
EXTRA_SECTION = Section("extra", "更多", "Дополнительно", ())

STATUS_COMPLETED = "completed"
STATUS_CURRENT = "current"
STATUS_AVAILABLE = "available"   # открыт вне очереди (override или работа уже начата)
STATUS_LOCKED = "locked"


# Группа (тема, уровень) меньше этого числа слов не становится отдельным
# модулем — модуль из одного слова бессмыслен как узел пути.
MIN_MODULE_WORDS = 2


def plan_course_modules(words: Iterable[dict], min_words: int = MIN_MODULE_WORDS) -> dict[tuple[str, int], list[int]]:
    """
    Раскладка слов по модулям (тема, уровень). Вход — словари с id/category/hsk
    (слова без категории в курс не попадают). Группа меньше min_words
    сливается с СЛЕДУЮЩИМ уровнем той же темы (лёгкое слово чуть позже — не
    нарушение порядка), а если следующего нет — с предыдущим. Детерминирована:
    внутри группы id по возрастанию.
    """
    by_cat: dict[str, dict[int, list[int]]] = {}
    for w in words:
        if not w.get("category"):
            continue
        by_cat.setdefault(w["category"], {}).setdefault(int(w["hsk"]), []).append(w["id"])

    plan: dict[tuple[str, int], list[int]] = {}
    for category, levels in by_cat.items():
        groups = {lvl: sorted(ids) for lvl, ids in levels.items()}
        changed = True
        while changed and len(groups) > 1:
            changed = False
            for lvl in sorted(groups):
                if len(groups[lvl]) >= min_words:
                    continue
                higher = [x for x in sorted(groups) if x > lvl]
                lower = [x for x in sorted(groups) if x < lvl]
                target = higher[0] if higher else lower[-1]
                groups[target] = sorted(groups[target] + groups.pop(lvl))
                changed = True
                break
        for lvl, ids in groups.items():
            plan[(category, lvl)] = ids
    return plan


def route_order(modules: Iterable[dict], sections: tuple[Section, ...] = ROUTE_SECTIONS) -> list[dict]:
    """
    Модули в порядке маршрута + поля раздела. Исходные словари не меняются.
    Порядок: уровень HSK модуля → раздел → тема внутри раздела → order_index.
    Модуль без уровня (hsk_level = NULL, например из CSV) идёт после всех
    уровней. section_id общий для всех уровней (от него зависит оттенок
    раздела во фронтенде); section_key уникален для пары (раздел, уровень) —
    по нему фронтенд группирует главы.
    """
    slot: dict[str, tuple[int, int]] = {}
    for si, section in enumerate(sections):
        for pi, category in enumerate(section.categories):
            slot.setdefault(category, (si, pi))
    extra_index = len(sections)

    def level(m: dict) -> int:
        lvl = m.get("hsk_level")
        return lvl if lvl is not None else 99

    def key(m: dict) -> tuple[int, int, int, int]:
        si, pi = slot.get(m["category"], (extra_index, 0))
        return level(m), si, pi, m["order_index"]

    all_sections = [*sections, EXTRA_SECTION]
    result, per_section = [], {}
    for route_index, m in enumerate(sorted(modules, key=key)):
        lvl, si = key(m)[0], key(m)[1]
        section = all_sections[si]
        position = per_section.get((lvl, si), 0)
        per_section[(lvl, si)] = position + 1
        has_level = m.get("hsk_level") is not None
        result.append({
            **m,
            "route_index": route_index,
            "section_id": section.id,
            "section_key": f"{section.id}-{lvl}" if has_level else section.id,
            "section_index": si,
            "section_title": f"{section.title_ru} · HSK {lvl}" if has_level else section.title_ru,
            "section_title_zh": section.title_zh,
            "position_in_section": position,
        })
    return result


def compute_statuses(ordered_modules: list[dict], unlocked_ids: Iterable[int] = ()) -> tuple[dict[int, str], int | None]:
    """
    Статус каждого модуля и id текущего.

      completed — все слова модуля пройдены (state, см. learning_path_service);
      current   — первый по маршруту не завершённый;
      available — открыт вне очереди: явно (unlocked_ids) или пользователь уже
                  начал его проходить (запирать начатую работу нельзя);
      locked    — остальные.
    """
    unlocked = set(unlocked_ids)
    current_id = next((m["id"] for m in ordered_modules if m["state"] != "completed"), None)
    statuses: dict[int, str] = {}
    for m in ordered_modules:
        if m["state"] == "completed":
            statuses[m["id"]] = STATUS_COMPLETED
        elif m["id"] == current_id:
            statuses[m["id"]] = STATUS_CURRENT
        elif m["id"] in unlocked or m["state"] == "in_progress":
            statuses[m["id"]] = STATUS_AVAILABLE
        else:
            statuses[m["id"]] = STATUS_LOCKED
    return statuses, current_id
