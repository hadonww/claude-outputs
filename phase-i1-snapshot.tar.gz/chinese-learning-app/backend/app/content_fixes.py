"""
Исправления контента для уже существующих баз (Phase I, аудит HSK 1–4).

Источники истины — seed_data.json, data/*_course_map.tsv и data/examples/*.tsv:
в свежей базе всё уже верно. Здесь те же правки применяются к базам, созданным
раньше: init_db вызывает apply() на каждом старте, правки идемпотентны (второй
запуск ничего не меняет). Прогресс хранится по слову, поэтому смена уровня и
модуля его не теряет.
"""

import json

# Уровень и пиньинь рукописных слов (hanzi -> поля). Уровень: 14 слов HSK 2.0
# уровня 1 стояли на «уровне курса» 2 — тема «Транспорт» HSK 1 из-за этого была
# пустой, а 儿子/女儿/猫/狗/飞机 появлялись только после HSK 1.
WORD_FIXES: dict[str, dict] = {
    **{h: {"hsk": 1} for h in ("儿子", "女儿", "没关系", "猫", "狗", "先生", "水果", "分钟", "上午",
                               "零", "飞机", "出租车", "打电话")},
    "小姐": {"hsk": 1, "pinyin": "xiǎojie"},
    "学生": {"pinyin": "xuésheng"},
    # имена собственные пишутся с заглавной (раньше импорт делал их строчными)
    "中国": {"pinyin": "Zhōngguó"}, "中文": {"pinyin": "Zhōngwén"},
    "北京": {"pinyin": "Běijīng"}, "汉语": {"pinyin": "Hànyǔ"},
    "京剧": {"pinyin": "Jīngjù"}, "亚洲": {"pinyin": "Yàzhōu"},
    "长城": {"pinyin": "Chángchéng"}, "长江": {"pinyin": "Chángjiāng"},
    # импорт взял форму имени собственного (夏 «династия Ся», 西 «Испания»),
    # а не основное значение — английский исходник и числовой пиньинь от неё
    "夏": {"translation_en": "summer", "pinyin_numeric": "xia4"},
    "西": {"translation_en": "west", "pinyin_numeric": "xi1"},
    "云": {"translation_en": "cloud", "pinyin_numeric": "yun2"},
    "狮子": {"translation_en": "lion", "pinyin_numeric": "shi1 zi5"},
    # русские переводы (те же, что в data/hsk_course_map.tsv)
    "以为": {"translation": "думать, считать (обычно ошибочно)"},
    "跑步": {"translation": "бегать (трусцой), пробежка"},
    "发烧": {"translation": "температурить, жар"},
    "感冒": {"translation": "простудиться; простуда"},
    "了": {"translation": "частица: действие завершилось или ситуация изменилась",
           "translation_source": "reviewed_ru"},
    "呢": {"translation": "частица «а …?»; действие идёт сейчас", "translation_source": "reviewed_ru"},
}
# Источник перевода меняется, только если слово уже подключено к курсу (не NULL).
_SOURCE_ONLY_IF_SET = {"translation_source"}

# Примеры: (цель, прежнее предложение) -> (пословная разметка, перевод).
EXAMPLE_FIXES: dict[tuple[str, str], tuple[str, str]] = {
    # «大两倍» по-китайски двусмысленно (строго — «больше на два раза», т. е. втрое)
    ("倍", "这个房子比那个大两倍。"): ("这 个 房子 是 那 个 的 两 倍 大 。", "Этот дом в два раза больше того."),
    # 脚 — ступня: контекст «много прошёл» делает значение однозначным
    ("脚", "我的脚很疼。"): ("我 走 了 很 多 路 ， 脚 很 疼 。", "Я много прошёл, ноги болят."),
    # неестественная фраза («в номере есть ноль») со словом HSK 4 (号码)
    ("零", "我的电话号码有一个零。"): ("现在 是 二 零 二 六 年 。", "Сейчас две тысячи двадцать шестой год."),
}

_PUNCT_PINYIN = {"。": ".", "，": ",", "？": "?", "！": "!", "、": ",", "：": ":", "；": ";",
                 "“": "“", "”": "”", "…": "…", "—": "—", "（": "(", "）": ")"}
_SENTENCE_END = {".", "!", "?"}


def _join_pinyin(parts: list[str]) -> str:
    """Слова через пробел, знаки прилеплены; с заглавной — начало и слово после конца фразы."""
    out, capital = "", True
    for p in parts:
        if p in _PUNCT_PINYIN.values():
            out += p
            capital = capital or p in _SENTENCE_END
        else:
            out += (" " if out else "") + (p[:1].upper() + p[1:] if capital else p)
            capital = False
    return out


def _consume(sentence: str, used: list[dict], k: int) -> tuple[str | None, int]:
    """Разбор предложения словами used, начиная с k-го: (пиньинь или None, следующий k)."""
    parts, i = [], 0
    while i < len(sentence):
        ch = sentence[i]
        if ch in _PUNCT_PINYIN:
            parts.append(_PUNCT_PINYIN[ch])
            i += 1
        elif ch.isspace():
            i += 1
        elif k < len(used) and sentence.startswith(used[k]["hanzi"], i):
            parts.append(used[k]["pinyin"])
            i += len(used[k]["hanzi"])
            k += 1
        else:
            return None, k
    return (_join_pinyin(parts) if parts else None), k


def _sentence_pinyin(sentence: str, used: list[dict]) -> str | None:
    """Пиньинь предложения по его словам (used_word_ids по порядку) и знакам препинания;
    None — если слова не складываются в предложение (тогда ничего не трогаем)."""
    pinyin, k = _consume(sentence, used, 0)
    return pinyin if k == len(used) else None


def _fix_words(conn) -> bool:
    level_changed = False
    cols = {r[1] for r in conn.execute("PRAGMA table_info(words)")}
    for hanzi, fields in WORD_FIXES.items():
        row = conn.execute("SELECT * FROM words WHERE hanzi = ?", (hanzi,)).fetchone()
        if row is None:
            continue
        for col, value in fields.items():
            if col not in cols or row[col] == value:
                continue
            if col in _SOURCE_ONLY_IF_SET and row[col] is None:
                continue
            conn.execute(f"UPDATE words SET {col} = ? WHERE id = ?", (value, row["id"]))
            level_changed |= col == "hsk"
    return level_changed


def _fix_examples(conn) -> None:
    vocab = {r["hanzi"]: dict(r) for r in conn.execute("SELECT id, hanzi, pinyin, hsk FROM words")}
    for (target, old_cn), (segmented, ru) in EXAMPLE_FIXES.items():
        tokens = segmented.split()
        words = [t for t in tokens if t not in _PUNCT_PINYIN]
        if target not in vocab or any(t not in vocab for t in words):
            continue
        conn.execute(
            """UPDATE examples SET sentence_cn = ?, sentence_ru = ?, used_word_ids = ?, pinyin = ?,
               difficulty = ?, needs_review = 0 WHERE target_word_id = ? AND sentence_cn = ?""",
            ("".join(tokens), ru, json.dumps([vocab[t]["id"] for t in words]),
             _join_pinyin([_PUNCT_PINYIN.get(t) or vocab[t]["pinyin"] for t in tokens]),
             max(vocab[t]["hsk"] for t in words), vocab[target]["id"], old_cn),
        )


def _refresh_pinyin(conn) -> None:
    """
    Пиньинь примеров и мини-диалогов собирается из пиньиня слов. Если пиньинь
    слова исправили (了 le, 吗 ma, 北京 Běijīng) после того, как пример был
    записан, пример держал старое чтение («Tā lái liǎo», «Nǐ hǎo má?»): здесь он
    пересобирается по текущим словам. Старые примеры (перенесённые со строки
    слова) так же получают пиньинь и сложность (макс. уровень слов).
    """
    words = {r["id"]: dict(r) for r in conn.execute("SELECT id, hanzi, pinyin, hsk FROM words")}
    for r in conn.execute("SELECT id, sentence_cn, used_word_ids, pinyin, difficulty FROM examples "
                          "WHERE needs_review = 0").fetchall():
        ids = json.loads(r["used_word_ids"] or "[]")
        if not ids or any(i not in words for i in ids):
            continue
        used = [words[i] for i in ids]
        pinyin = _sentence_pinyin(r["sentence_cn"], used) or r["pinyin"]
        difficulty = r["difficulty"] or max(w["hsk"] for w in used)
        if (pinyin, difficulty) != (r["pinyin"], r["difficulty"]):
            conn.execute("UPDATE examples SET pinyin = ?, difficulty = ? WHERE id = ?", (pinyin, difficulty, r["id"]))
    for r in conn.execute("SELECT * FROM dialogues").fetchall():
        ids = json.loads(r["used_word_ids"] or "[]")
        if not ids or any(i not in words for i in ids):
            continue
        used = [words[i] for i in ids]
        a, k = _consume(r["line_a_cn"], used, 0)
        b, k = _consume(r["line_b_cn"], used, k) if a else (None, k)
        if a and b and k == len(used) and (a, b) != (r["line_a_pinyin"], r["line_b_pinyin"]):
            conn.execute("UPDATE dialogues SET line_a_pinyin = ?, line_b_pinyin = ? WHERE id = ?", (a, b, r["id"]))


def apply(conn) -> bool:
    """Применяет все правки; True — менялся уровень слов (нужен пересчёт модулей)."""
    level_changed = _fix_words(conn)
    _fix_examples(conn)
    _refresh_pinyin(conn)
    return level_changed
