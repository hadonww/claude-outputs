"""
Единственное место в проекте с DDL/миграциями/сидированием (Phase 1 из
PLAN_WB_v1.md). Роуты и сервисы сюда не заглядывают напрямую — только
через `get_db()` для получения соединения и через repositories/ для
запросов.

Phase 1 добавляет таблицу `users` (см. ARCHITECTURE_WB_v1.md, раздел 2) —
пока всегда ровно один пользователь, чтобы не ломать поведение текущего
однопользовательского MVP, но уже как настоящая сущность с FK, а не
захардкоженная константа `id=1` в каждом запросе. Благодаря AUTOINCREMENT
первый (и пока единственный) пользователь получает id=1 — это ровно то
значение, которое уже используется в существующих БД для `stats.id`,
поэтому миграция не требует переноса данных.

Phase 2 добавляет domain-модель для Adaptive Learning Engine (ARCHITECTURE
раздел 2): `skills` (справочник фиксированного набора навыков), `mastery`
(per-skill прогресс), `modules`/`lessons` (структура курса — на этом этапе
заполняется автоматически из существующих категорий `words`, без ручного
авторства контента) и `attempts` (атомарные события ответов — пока никем
не пишутся, таблица заводится заранее под Phase 3/6). Ничего из Phase 1
не изменено — только добавление новых таблиц и их сидирование.
"""

import json
import sqlite3
from contextlib import contextmanager

from .config import DB_PATH, SEED_PATH, SKILLS
from .utils import today_date


@contextmanager
def get_db():
    # timeout: одновременные записи (несколько пользователей регистрируются
    # сразу) ждут блокировку SQLite, а не падают с "database is locked"
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _add_column_if_missing(conn, table, column, ddl):
    cols = [r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def _migrate_legacy_examples(conn):
    """
    Phase C: у рукописных 177 слов example_cn/example_ru лежали прямо на
    строке слова, без явного состава предложения. target_word_id для них
    известен однозначно (это и есть то слово, которому принадлежал пример) —
    неоднозначна только реконструкция used_word_ids: она делается жадной
    токенизацией по всему словарю (engine.exercise_types.tokenize), это
    единственный доступный источник для СТАРЫХ свободнотекстовых примеров.
    Если токенизация даёт фрагмент, не совпадающий ни с одним словом базы,
    надёжно разобрать пример нельзя — он помечается needs_review=1 и не
    используется движком (см. examples_repo.get_examples_for_words), а не
    молча считается корректным.

    Важно: эта функция видит только словарь НА МОМЕНТ вызова. При первом
    запуске (init_db, до HSK-импорта) это всего 177 слов — многие needs_review
    объясняются не плохими предложениями, а тем, что базовые служебные слова
    (的/了/很/个 и т.п.) появляются только после HSK-импорта. См.
    reparse_examples_needing_review() — её стоит вызвать повторно после
    любого пополнения словаря, чтобы разобрать то, что не удалось раньше.
    """
    words = conn.execute("SELECT id, hanzi, example_cn, example_ru FROM words").fetchall()
    for w in words:
        if not w["example_cn"] or not w["example_ru"]:
            continue
        conn.execute(
            """INSERT INTO examples (target_word_id, sentence_cn, sentence_ru, used_word_ids,
               source, needs_review) VALUES (?, ?, ?, '[]', 'migrated_legacy', 1)""",
            (w["id"], w["example_cn"], w["example_ru"]),
        )
    reparse_examples_needing_review(conn)


def reparse_examples_needing_review(conn) -> tuple[int, int]:
    """
    Повторная попытка разобрать used_word_ids для примеров с needs_review=1,
    текущим словарём (безопасно вызывать в любой момент — например, сразу
    после HSK-импорта: новые слова могли закрыть то, чего не хватало раньше).
    Возвращает (сколько разобрано сейчас, сколько всё ещё требует проверки).
    """
    from engine.exercise_types import tokenize

    vocab_rows = conn.execute("SELECT id, hanzi FROM words").fetchall()
    vocab = {r["hanzi"] for r in vocab_rows}
    hanzi_to_id = {r["hanzi"]: r["id"] for r in vocab_rows}

    pending = conn.execute(
        "SELECT id, target_word_id, sentence_cn FROM examples WHERE needs_review = 1"
    ).fetchall()
    resolved = 0
    for ex in pending:
        tokens = tokenize(ex["sentence_cn"], vocab)
        ids = [hanzi_to_id[t] for t in tokens if t in hanzi_to_id]
        ok = len(ids) == len(tokens) and ex["target_word_id"] in ids
        if ok:
            conn.execute(
                "UPDATE examples SET used_word_ids = ?, needs_review = 0 WHERE id = ?",
                (json.dumps(ids), ex["id"]),
            )
            resolved += 1
    still_pending = len(pending) - resolved
    return resolved, still_pending


def _migrate_words_category_nullable(conn):
    """
    category был NOT NULL DEFAULT 'повседневная жизнь'. Phase B добавляет
    слова из внешнего датасета, у которого нет надёжного источника категории
    (это не то же самое, что домены существующих 16 модулей курса) — лучше
    честный NULL, чем придуманная категория. SQLite не умеет снять NOT NULL
    через ALTER, поэтому таблица пересобирается; foreign_keys на время
    выключаем, иначе SQLite не даст DROP TABLE words, на которую ссылается
    progress. Идемпотентно: проверяем notnull-флаг перед пересборкой.
    """
    col = next(r for r in conn.execute("PRAGMA table_info(words)").fetchall() if r["name"] == "category")
    if col["notnull"] == 0:
        return  # уже мигрировано

    conn.execute("PRAGMA foreign_keys = OFF")
    conn.executescript(
        """
        CREATE TABLE words_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hanzi TEXT NOT NULL,
            pinyin TEXT NOT NULL,
            translation TEXT NOT NULL,
            hsk INTEGER NOT NULL,
            category TEXT,
            example_cn TEXT,
            example_ru TEXT,
            components TEXT,
            strokes INTEGER,
            frequency INTEGER,
            related TEXT
        );
        INSERT INTO words_new (id, hanzi, pinyin, translation, hsk, category,
            example_cn, example_ru, components, strokes, frequency, related)
        SELECT id, hanzi, pinyin, translation, hsk, category,
            example_cn, example_ru, components, strokes, frequency, related FROM words;
        DROP TABLE words;
        ALTER TABLE words_new RENAME TO words;
        """
    )
    conn.execute("PRAGMA foreign_keys = ON")


def _migrate_accounts(conn):
    """
    Аккаунт: public_id / username / onboarding_completed_at в users и таблица
    entitlements (права вроде Premium, с указанием, кто, когда и почему их
    выдал). Пользователи, существовавшие ДО этой миграции, уже пользуются
    приложением — им онбординг не показывается повторно (completed_at =
    created_at), а early-access выдаётся в порядке регистрации (как и всем
    новым — в момент создания аккаунта, см. account_service.create_user).
    """
    had_column = "onboarding_completed_at" in {
        r["name"] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
    _add_column_if_missing(conn, "users", "public_id", "public_id TEXT")
    _add_column_if_missing(conn, "users", "username", "username TEXT")
    _add_column_if_missing(conn, "users", "onboarding_completed_at", "onboarding_completed_at TEXT")
    if not had_column:
        conn.execute("UPDATE users SET onboarding_completed_at = created_at WHERE onboarding_completed_at IS NULL")
    # уникальность — на уровне БД (username хранится нормализованным, в нижнем регистре)
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_public_id ON users(public_id)")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username)")

    had_entitlements = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'entitlements'").fetchone()
    # Лимит early_100 зашит в CHECK + UNIQUE(grant_type, slot): даже при гонке
    # двух транзакций в БД физически не может оказаться больше 100 таких строк.
    conn.execute(
        """CREATE TABLE IF NOT EXISTS entitlements (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               user_id INTEGER NOT NULL REFERENCES users(id),
               entitlement TEXT NOT NULL,
               grant_type TEXT NOT NULL,
               granted_at TEXT NOT NULL,
               expires_at TEXT,
               slot INTEGER,
               UNIQUE (user_id, grant_type),
               UNIQUE (grant_type, slot),
               CHECK (grant_type != 'early_100'
                      OR (slot BETWEEN 1 AND 100 AND expires_at IS NULL AND entitlement = 'premium'))
           )"""
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_entitlements_user ON entitlements(user_id)")

    from .services import account_service

    for row in conn.execute("SELECT id FROM users ORDER BY id").fetchall():
        account_service.ensure_public_id(conn, row["id"])
        if not had_entitlements:
            account_service.grant_early_access(conn, row["id"])


def init_db():
    with get_db() as conn:
        conn.executescript(
            """
            -- id — внутренний ключ (никогда не показывается наружу); public_id —
            -- публичный короткий идентификатор (CN-XXXXX), username — редактируемое
            -- уникальное имя; onboarding_completed_at NULL = онбординг не пройден.
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                public_id TEXT,
                username TEXT,
                onboarding_completed_at TEXT
            );

            CREATE TABLE IF NOT EXISTS words (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hanzi TEXT NOT NULL,
                pinyin TEXT NOT NULL,
                translation TEXT NOT NULL,
                hsk INTEGER NOT NULL,
                category TEXT,
                example_cn TEXT,
                example_ru TEXT,
                components TEXT,
                strokes INTEGER,
                frequency INTEGER,
                related TEXT
            );

            CREATE TABLE IF NOT EXISTS progress (
                word_id INTEGER PRIMARY KEY REFERENCES words(id),
                repetitions INTEGER NOT NULL DEFAULT 0,
                ease_factor REAL NOT NULL DEFAULT 2.5,
                interval_days INTEGER NOT NULL DEFAULT 0,
                due_date TEXT NOT NULL,
                last_reviewed TEXT,
                total_attempts INTEGER NOT NULL DEFAULT 0,
                total_correct INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS stats (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                streak INTEGER NOT NULL DEFAULT 0,
                last_active_date TEXT,
                total_reviews INTEGER NOT NULL DEFAULT 0,
                daily_new_words INTEGER NOT NULL DEFAULT 5,
                preferred_hsk INTEGER NOT NULL DEFAULT 1,
                knows_pinyin INTEGER NOT NULL DEFAULT 0,
                knows_tones INTEGER NOT NULL DEFAULT 0,
                onboarded INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS activity_log (
                day TEXT PRIMARY KEY,
                reviews_count INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS skills (
                name TEXT PRIMARY KEY
            );

            CREATE TABLE IF NOT EXISTS mastery (
                user_id INTEGER NOT NULL REFERENCES users(id),
                skill TEXT NOT NULL REFERENCES skills(name),
                score REAL NOT NULL DEFAULT 0,
                updated_at TEXT,
                PRIMARY KEY (user_id, skill)
            );

            CREATE TABLE IF NOT EXISTS modules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_index INTEGER NOT NULL,
                title TEXT NOT NULL,
                hsk_level INTEGER,
                category TEXT
            );

            CREATE TABLE IF NOT EXISTS lessons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                module_id INTEGER NOT NULL REFERENCES modules(id),
                order_index INTEGER NOT NULL,
                title TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                lesson_id INTEGER REFERENCES lessons(id),
                exercise_type TEXT NOT NULL,
                skill TEXT NOT NULL REFERENCES skills(name),
                content_item_id INTEGER REFERENCES words(id),
                correct INTEGER NOT NULL,
                response_ms INTEGER,
                created_at TEXT NOT NULL
            );

            -- Phase C: примеры как отдельная сущность — состав предложения
            -- (used_word_ids) хранится явно, не восстанавливается токенизацией
            -- на лету. Задел под будущие translation/dialogue: sentence_ru уже
            -- есть отдельно от sentence_cn, dialogue сможет группировать
            -- несколько examples по grammar_tag/новому полю позже, без
            -- изменения этой схемы.
            CREATE TABLE IF NOT EXISTS examples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_word_id INTEGER NOT NULL REFERENCES words(id),
                sentence_cn TEXT NOT NULL,
                sentence_ru TEXT NOT NULL,
                pinyin TEXT,
                used_word_ids TEXT NOT NULL,
                grammar_tag TEXT,
                difficulty INTEGER,
                source TEXT NOT NULL,
                needs_review INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_examples_target ON examples(target_word_id);

            -- Phase E: statistics/analytics layer — новые источники, ничего
            -- не дублирует existing progress/mastery/attempts.
            CREATE TABLE IF NOT EXISTS lesson_completions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                module_id INTEGER REFERENCES modules(id),
                started_at TEXT NOT NULL,
                completed_at TEXT NOT NULL,
                new_words_count INTEGER NOT NULL DEFAULT 0,
                review_words_count INTEGER NOT NULL DEFAULT 0,
                exercises_count INTEGER NOT NULL DEFAULT 0
            );

            -- Ежедневный снимок mastery (не на каждую попытку) — источник для
            -- тренда во времени, которого текущий mastery (только последнее
            -- значение) дать не может.
            CREATE TABLE IF NOT EXISTS mastery_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                skill TEXT NOT NULL REFERENCES skills(name),
                score REAL NOT NULL,
                snapshotted_at TEXT NOT NULL,
                UNIQUE(user_id, skill, snapshotted_at)
            );

            -- Review planned -> completed. Строка создаётся при каждом SRS-
            -- пересчёте (submit_review) на СЛЕДУЮЩий due_date; предыдущая
            -- ожидающая строка по этому слову (если была) помечается
            -- completed_at в этот же момент.
            CREATE TABLE IF NOT EXISTS review_schedule (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                word_id INTEGER NOT NULL REFERENCES words(id),
                scheduled_for TEXT NOT NULL,
                completed_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_review_schedule_pending
                ON review_schedule(user_id, word_id, completed_at);

            -- Мини-диалоги (2026-10): реплика A и подходящий ответ B; used_word_ids —
            -- слова обеих реплик (known-vocabulary guard проверяет весь диалог).
            CREATE TABLE IF NOT EXISTS dialogues (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_word_id INTEGER NOT NULL REFERENCES words(id),
                line_a_cn TEXT NOT NULL,
                line_a_ru TEXT NOT NULL,
                line_a_pinyin TEXT,
                line_b_cn TEXT NOT NULL,
                line_b_ru TEXT NOT NULL,
                line_b_pinyin TEXT,
                used_word_ids TEXT NOT NULL,
                difficulty INTEGER,
                source TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_dialogues_target ON dialogues(target_word_id);

            -- Сессия урока (2026-10): выданный план с верными ответами хранится
            -- на сервере; ответы проверяет сервер (engine.answer_check), счётчики
            -- ошибок по словам тоже серверные. state — JSON: ответы по шагам,
            -- попытки/ошибки по словам, результаты SRS, повторы ошибок, итог.
            CREATE TABLE IF NOT EXISTS lesson_sessions (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id),
                module_id INTEGER REFERENCES modules(id),
                kind TEXT NOT NULL,
                created_at TEXT NOT NULL,
                steps TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT '{}',
                completed_at TEXT
            );
            """
        )

        # Миграции для БД, созданных до появления новых полей/таблиц
        _add_column_if_missing(conn, "words", "frequency", "frequency INTEGER")
        _add_column_if_missing(conn, "words", "related", "related TEXT")
        _migrate_words_category_nullable(conn)
        # после пересборки words: _migrate_accounts пишет данные (открывает
        # транзакцию), а внутри транзакции PRAGMA foreign_keys = OFF не действует
        _migrate_accounts(conn)
        # Phase B: фундамент для нескольких стандартов HSK и будущих уровней 4-6 —
        # hsk_version живёт РЯДОМ с уже существующим hsk (который и есть level,
        # переименовывать не стал: слишком большой blast radius ради названия,
        # см. отчёт Phase B), а не хардкодится как предел системы.
        _add_column_if_missing(conn, "words", "hsk_version", "hsk_version TEXT")
        _add_column_if_missing(conn, "words", "traditional", "traditional TEXT")
        _add_column_if_missing(conn, "words", "part_of_speech", "part_of_speech TEXT")
        _add_column_if_missing(conn, "words", "pinyin_numeric", "pinyin_numeric TEXT")
        # Курс HSK1-3: модуль слова (тема × уровень, см. curriculum.plan_course_modules)
        # и происхождение перевода — у подключённых HSK-слов русский перевод
        # черновой ('draft_ru'), исходный английский сохранён в translation_en.
        _add_column_if_missing(conn, "words", "module_id", "module_id INTEGER REFERENCES modules(id)")
        _add_column_if_missing(conn, "words", "translation_en", "translation_en TEXT")
        _add_column_if_missing(conn, "words", "translation_source", "translation_source TEXT")
        _add_column_if_missing(conn, "progress", "total_attempts", "total_attempts INTEGER NOT NULL DEFAULT 0")
        _add_column_if_missing(conn, "progress", "total_correct", "total_correct INTEGER NOT NULL DEFAULT 0")
        # user_id — заготовка под многопользовательский режим (ARCHITECTURE
        # раздел 2/Phase 2). Пока не часть PRIMARY KEY и не используется для
        # фильтрации (пользователь всего один), поэтому это не breaking change.
        _add_column_if_missing(conn, "progress", "user_id", "user_id INTEGER NOT NULL DEFAULT 1")
        _add_column_if_missing(conn, "stats", "daily_new_words", "daily_new_words INTEGER NOT NULL DEFAULT 5")
        _add_column_if_missing(conn, "stats", "preferred_hsk", "preferred_hsk INTEGER NOT NULL DEFAULT 1")
        _add_column_if_missing(conn, "stats", "knows_pinyin", "knows_pinyin INTEGER NOT NULL DEFAULT 0")
        _add_column_if_missing(conn, "stats", "knows_tones", "knows_tones INTEGER NOT NULL DEFAULT 0")
        _add_column_if_missing(conn, "stats", "onboarded", "onboarded INTEGER NOT NULL DEFAULT 0")

        # Ровно один пользователь — первый INSERT с AUTOINCREMENT даёт id=1,
        # то же значение, что уже жёстко используется в stats.id.
        if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            # Владелец экземпляра — обычный аккаунт: public_id, early-access по
            # общим правилам, онбординг не пройден (покажется при первом входе).
            from .services import account_service

            account_service.create_user(conn)
        user_id = conn.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()["id"]

        # Сидируем словами при первом запуске (пусто) или если добавили новые в seed_data.json
        existing_hanzi = {r["hanzi"] for r in conn.execute("SELECT hanzi FROM words").fetchall()}
        data = json.loads(SEED_PATH.read_text(encoding="utf-8"))
        today = today_date().isoformat()
        for w in data:
            if w["hanzi"] in existing_hanzi:
                continue
            cur = conn.execute(
                """INSERT INTO words (hanzi, pinyin, translation, hsk, category, example_cn,
                   example_ru, components, strokes, frequency, related)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (w["hanzi"], w["pinyin"], w["translation"], w["hsk"],
                 w.get("category", "повседневная жизнь"), w.get("example_cn"), w.get("example_ru"),
                 w.get("components"), w.get("strokes"), w.get("frequency"),
                 json.dumps(w.get("related", []), ensure_ascii=False)),
            )
            word_id = cur.lastrowid
            conn.execute(
                """INSERT INTO progress (word_id, user_id, repetitions, ease_factor, interval_days, due_date)
                   VALUES (?, ?, 0, 2.5, 0, ?)""",
                (word_id, user_id, today),
            )

        # Phase C: разобрать состав старых example_cn на word_id по факту
        # рукописных 177 слов (только что досеянных выше) — один раз,
        # неидемпотентно повторный запуск не нужен: таблица examples пуста
        # только на первом старте.
        if conn.execute("SELECT COUNT(*) FROM examples").fetchone()[0] == 0:
            _migrate_legacy_examples(conn)

        if conn.execute("SELECT COUNT(*) FROM stats").fetchone()[0] == 0:
            conn.execute("INSERT INTO stats (id, streak, last_active_date, total_reviews) VALUES (1, 0, NULL, 0)")

        # --- Phase 2: skills / mastery / modules / lessons ---

        for skill in SKILLS:
            conn.execute("INSERT OR IGNORE INTO skills (name) VALUES (?)", (skill,))

        existing_mastery_skills = {
            r["skill"] for r in conn.execute(
                "SELECT skill FROM mastery WHERE user_id = ?", (user_id,)
            ).fetchall()
        }
        for skill in SKILLS:
            if skill not in existing_mastery_skills:
                conn.execute(
                    "INSERT INTO mastery (user_id, skill, score, updated_at) VALUES (?, ?, 0, ?)",
                    (user_id, skill, today),
                )

        # Модули — по одному на существующую категорию слов, отсортированы по
        # количеству слов (больше контента — раньше в пути). Ручного авторства
        # курса на этом этапе нет (см. PLAN_WB_v1.md, Phase 2) — это стартовая
        # раскладка поверх уже существующих данных, не финальный курс.
        if conn.execute("SELECT COUNT(*) FROM modules").fetchone()[0] == 0:
            categories = conn.execute(
                """SELECT category, COUNT(*) as cnt, MIN(hsk) as min_hsk
                   FROM words WHERE category IS NOT NULL
                   GROUP BY category ORDER BY cnt DESC"""
            ).fetchall()
            for order_index, cat in enumerate(categories, start=1):
                cur = conn.execute(
                    "INSERT INTO modules (order_index, title, hsk_level, category) VALUES (?, ?, ?, ?)",
                    (order_index, cat["category"].capitalize(), cat["min_hsk"], cat["category"]),
                )
                module_id = cur.lastrowid
                conn.execute(
                    "INSERT INTO lessons (module_id, order_index, title) VALUES (?, 1, ?)",
                    (module_id, cat["category"].capitalize()),
                )

        # Тема × уровень: исходные модули становятся модулями своего уровня,
        # недостающие уровни создаются; слова без module_id привязываются.
        from . import content_fixes
        from .repositories.modules_repo import sync_course_modules

        # Phase I: исправления контента для баз, созданных раньше (идемпотентно);
        # сменился уровень слова — раскладка по модулям пересчитывается
        level_changed = content_fixes.apply(conn)
        sync_course_modules(conn, reassign=level_changed)
