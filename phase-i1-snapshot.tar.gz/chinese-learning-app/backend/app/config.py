from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent  # backend/
DB_PATH = BASE_DIR / "app.db"
SEED_PATH = BASE_DIR / "seed_data.json"
FRONTEND_DIR = BASE_DIR.parent / "frontend"
AUDIO_DIR = BASE_DIR / "audio"
AUDIO_SUBDIRS = ("words", "sentences", "characters")

# Фиксированный набор навыков Adaptive Learning Engine (ARCHITECTURE_WB_v1.md,
# раздел 2/9). Список закрытый и меняется только явным архитектурным решением,
# не per-feature — отсюда константа, а не значения "как получится" в разных
# местах кода.
SKILLS = (
    "vocabulary",
    "characters",
    "pinyin",
    "tones",
    "listening",
    "grammar",
    "writing",
    "speaking",
)
