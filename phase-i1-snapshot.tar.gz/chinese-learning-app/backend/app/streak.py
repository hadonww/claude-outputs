"""
Серия занятий (streak) — чистая логика без SQL и FastAPI.

Единственный источник — `activity_log` (день → число ответов, один день = одна
строка): из него считаются и текущая серия, и рекорд. Поэтому:
  * серия всегда актуальна при чтении — пропущенный день виден сразу, без
    ожидания следующего ответа (раньше Home показывал сохранённое
    `stats.streak` до первого ответа после разрыва);
  * чтение ничего не пишет: GET /api/home, /api/profile, /api/statistics
    не меняют историю активности;
  * один календарный день никогда не считается дважды;
  * рекорд не может быть меньше текущей серии (тот же источник).
Даты — `utils.today_date()` (UTC), как и при записи activity_log.
"""

from collections.abc import Iterable
from datetime import date, timedelta
from itertools import pairwise


def _sorted_days(days: Iterable[date]) -> list[date]:
    return sorted(set(days))


def current_streak(days: Iterable[date], today: date) -> int:
    """
    Подряд идущие дни активности, заканчивающиеся сегодня — или вчера, если
    сегодня занятий ещё не было (серия ещё не прервана, день не закончился).
    Последний активный день раньше вчерашнего → серия 0.
    """
    active = set(days)
    if today in active:
        cursor = today
    elif today - timedelta(days=1) in active:
        cursor = today - timedelta(days=1)
    else:
        return 0
    streak = 0
    while cursor in active:
        streak += 1
        cursor -= timedelta(days=1)
    return streak


def longest_streak(days: Iterable[date]) -> int:
    """Самая длинная последовательность подряд идущих календарных дней."""
    ordered = _sorted_days(days)
    if not ordered:
        return 0
    longest = current = 1
    for prev, cur in pairwise(ordered):
        current = current + 1 if (cur - prev).days == 1 else 1
        longest = max(longest, current)
    return longest
