from datetime import datetime, timezone


def today_date():
    """Текущая дата в UTC (timezone-aware, не зависит от локали сервера)."""
    return datetime.now(timezone.utc).date()
