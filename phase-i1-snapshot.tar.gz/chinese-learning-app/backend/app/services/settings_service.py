from ..repositories import stats_repo, users_repo
from . import account_service


def get_settings(conn) -> dict:
    s = stats_repo.get_stats(conn)
    user_id = users_repo.get_current_user_id(conn)
    return {
        "daily_new_words": s["daily_new_words"],
        "preferred_hsk": s["preferred_hsk"],
        "knows_pinyin": bool(s["knows_pinyin"]),
        "knows_tones": bool(s["knows_tones"]),
        # источник истины — аккаунт (users.onboarding_completed_at), не stats.onboarded
        "onboarded": account_service.onboarding_status(conn, user_id)["completed"],
    }


def update_settings(conn, payload) -> dict:
    fields = {
        "daily_new_words": payload.daily_new_words,
        "preferred_hsk": payload.preferred_hsk,
        "knows_pinyin": None if payload.knows_pinyin is None else int(payload.knows_pinyin),
        "knows_tones": None if payload.knows_tones is None else int(payload.knows_tones),
    }
    updates = {k: v for k, v in fields.items() if v is not None}
    if not updates and payload.onboarded is None:
        return None
    if updates:
        stats_repo.update_settings_fields(conn, updates)
    if payload.onboarded:
        # совместимость со старым клиентом; onboarded=false онбординг не «распроходит»
        account_service.complete_onboarding(conn, users_repo.get_current_user_id(conn))
    return get_settings(conn)
