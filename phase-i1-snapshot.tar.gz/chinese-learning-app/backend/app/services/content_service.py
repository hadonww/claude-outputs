import csv
import unicodedata

from ..repositories import examples_repo, modules_repo, progress_repo, words_repo
from ..utils import today_date


def _plain_pinyin(text: str | None) -> str:
    """Пиньинь без тонов, пробелов и апострофов: 'nǐ hǎo' -> 'nihao', 'lǜ' -> 'lv'."""
    decomposed = unicodedata.normalize("NFD", (text or "").lower().replace("ü", "v"))
    return "".join(ch for ch in decomposed if ch.isascii() and ch.isalpha())


def search_words(conn, q: str, category: str, hsk: int, seen: bool = False, weak: bool = False) -> list[dict]:
    """
    Поиск по иероглифам, русскому переводу и пиньиню. Латинский запрос ищется и в
    пиньине без тонов: «nihao», «ni hao», «ni3hao3» находят 你好 (раньше подстрочный
    поиск требовал диакритики).
    """
    q = (q or "").strip()
    plain = _plain_pinyin(q) if q and all(ch.isascii() for ch in q) else ""
    if plain:
        rows = words_repo.search_words(conn, "", category, hsk, seen, weak)
        rows = [r for r in rows if plain in _plain_pinyin(r["pinyin"]) or q.lower() in (r["translation"] or "").lower()]
    else:
        rows = words_repo.search_words(conn, q, category, hsk, seen, weak)
    return [words_repo.word_row_to_dict(r) for r in rows]


def get_word(conn, word_id: int) -> dict | None:
    """Карточка слова для словаря: слово + модуль курса + прогресс + примеры."""
    row = words_repo.get_word_by_id(conn, word_id)
    if not row:
        return None
    word = words_repo.word_row_to_dict(row)
    detail = words_repo.progress_detail(conn, word_id)
    in_srs = bool(detail and ((detail["repetitions"] or 0) > 0 or (detail["total_attempts"] or 0) > 0))
    word["module"] = ({"id": detail["module_id"], "title": detail["module_title"], "hsk_level": detail["module_level"]}
                      if detail and detail["module_id"] else None)
    word["progress"] = {
        "attempts": detail["total_attempts"] if detail else 0,
        "correct": detail["total_correct"] if detail else 0,
        "last_reviewed": detail["last_reviewed"] if detail else None,
        "next_review": detail["due_date"] if in_srs else None,
    }
    word["examples"] = [{k: e[k] for k in ("sentence_cn", "sentence_ru", "pinyin")}
                        for e in examples_repo.get_examples_for_words(conn, [word_id]).get(word_id, [])]
    return word


def list_categories(conn) -> list[dict]:
    rows = words_repo.list_categories(conn)
    return [{"name": r["category"], "count": r["cnt"]} for r in rows]


def import_csv(conn, csv_text: str, user_id: int) -> dict:
    """
    Массовый импорт слов из CSV-строки — для расширения базы без изменения кода.
    Ожидаемые колонки: hanzi,pinyin,translation,hsk,category,example_cn,example_ru,components,strokes
    """
    reader = csv.DictReader(csv_text.splitlines())
    added, skipped = 0, 0
    today = today_date().isoformat()
    existing = words_repo.fetch_all_hanzi(conn)

    for row in reader:
        hanzi = (row.get("hanzi") or "").strip()
        if not hanzi or hanzi in existing:
            skipped += 1
            continue
        word_id = words_repo.insert_word(
            conn,
            hanzi=hanzi,
            pinyin=row.get("pinyin", ""),
            translation=row.get("translation", ""),
            hsk=int(row.get("hsk") or 1),
            category=row.get("category", "повседневная жизнь"),
            example_cn=row.get("example_cn"),
            example_ru=row.get("example_ru"),
            components=row.get("components"),
            strokes=int(row["strokes"]) if row.get("strokes") else None,
        )
        progress_repo.insert_progress_row(conn, word_id, user_id, today)
        existing.add(hanzi)
        added += 1

    if added:
        # новые слова сразу попадают в модуль своей темы/уровня (иначе они в
        # курсе, но ни в одном узле пути)
        modules_repo.sync_course_modules(conn)
    return {"added": added, "skipped": skipped}
