from ..repositories import progress_repo, stats_repo, users_repo
from ..utils import today_date
from . import account_service


def get_profile(conn) -> dict:
    today = today_date()

    by_level = progress_repo.profile_by_level(conn)
    weak = progress_repo.profile_weak_words(conn)
    agg = progress_repo.profile_accuracy_agg(conn)
    mastered = progress_repo.profile_mastered_count(conn)
    week_activity = progress_repo.week_activity_counts(conn, today)
    stats = stats_repo.get_stats(conn)
    total_words = progress_repo.home_counts(conn, today.isoformat())["total_words"]
    learned = progress_repo.profile_learned_count(conn)

    return {
        "account": account_service.get_account(conn, users_repo.get_current_user_id(conn)),
        "streak": stats_repo.current_streak(conn, today),
        "longest_streak": stats_repo.longest_streak(conn),
        "total_reviews": stats["total_reviews"],
        "total_words": total_words,
        "learned_count": learned,
        "mastered_count": mastered,
        "accuracy": round(100 * agg["cor"] / agg["att"], 1) if agg["att"] else None,
        "by_level": [
            {"hsk": r["hsk"], "total": r["total"], "learned": r["learned"]} for r in by_level
        ],
        "weak_words": [
            {
                "hanzi": r["hanzi"], "pinyin": r["pinyin"], "translation": r["translation"],
                "accuracy": round(100 * r["total_correct"] / r["total_attempts"], 1),
            }
            for r in weak
        ],
        "week_activity": week_activity,
    }
