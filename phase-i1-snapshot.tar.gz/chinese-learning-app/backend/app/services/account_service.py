"""
Аккаунт пользователя: публичный идентификатор, username, онбординг, права.

Внутренний ключ — users.id (наружу не отдаётся). Публичный — users.public_id
(CN-XXXXX: случайный, не последовательный, не раскрывает число пользователей,
стабилен). Права (Premium и т.п.) — строки entitlements с причиной выдачи
(grant_type) и временем; решение «есть ли Premium» принимает только сервер.

Аутентификации пока нет: «текущий пользователь» — users_repo.get_current_user_id.
Аккаунты создаются только серверным кодом (create_user), публичного эндпоинта
регистрации нет — иначе любой мог бы анонимно занять все места early-100.
"""

import re
import secrets
import sqlite3
from datetime import datetime, timezone

from ..repositories import entitlements_repo, users_repo
from ..utils import today_date

PUBLIC_ID_PREFIX = "CN-"
# без 0/O, 1/I/L — чтобы ID можно было продиктовать и переписать без ошибок
PUBLIC_ID_ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"
PUBLIC_ID_LENGTH = 5  # 31^5 ≈ 28,6 млн вариантов
PUBLIC_ID_ATTEMPTS = 20

EARLY_ACCESS_GRANT = "early_100"
EARLY_ACCESS_LIMIT = 100  # то же число зашито в CHECK таблицы entitlements (db.py)
PREMIUM = "premium"

USERNAME_RE = re.compile(r"^[a-z][a-z0-9_]{2,19}$")
RESERVED_USERNAMES = frozenset({
    "admin", "administrator", "root", "system", "support", "help", "moderator", "mod",
    "staff", "official", "premium", "api", "me", "null", "undefined", "anonymous",
    "telegram", "chinese", "trainer",
})


class UsernameError(ValueError):
    """Имя не проходит правила (сообщение — для пользователя)."""


class UsernameTaken(UsernameError):
    pass


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def generate_public_id() -> str:
    return PUBLIC_ID_PREFIX + "".join(secrets.choice(PUBLIC_ID_ALPHABET) for _ in range(PUBLIC_ID_LENGTH))


def create_user(conn) -> int:
    """
    Новый аккаунт: строка users с уникальным public_id (при совпадении —
    новая попытка; уникальность гарантирует индекс БД) и попытка выдать
    early-access. Онбординг не пройден. Возвращает внутренний id.
    """
    created = today_date().isoformat()
    for _ in range(PUBLIC_ID_ATTEMPTS):
        try:
            user_id = users_repo.insert_user(conn, created, generate_public_id())
            break
        except sqlite3.IntegrityError:
            continue
    else:  # pragma: no cover — 20 совпадений подряд при 28 млн вариантов
        raise RuntimeError("Не удалось подобрать уникальный public_id")
    grant_early_access(conn, user_id)
    return user_id


def ensure_public_id(conn, user_id: int) -> str:
    """Для аккаунтов, созданных до появления public_id (миграция). Идемпотентно."""
    row = users_repo.get_user(conn, user_id)
    if row["public_id"]:
        return row["public_id"]
    for _ in range(PUBLIC_ID_ATTEMPTS):
        try:
            users_repo.set_public_id_if_missing(conn, user_id, generate_public_id())
            return users_repo.get_user(conn, user_id)["public_id"]
        except sqlite3.IntegrityError:
            continue
    raise RuntimeError("Не удалось подобрать уникальный public_id")  # pragma: no cover


def grant_early_access(conn, user_id: int) -> bool:
    """Premium навсегда первым EARLY_ACCESS_LIMIT аккаунтам. Повтор безопасен."""
    return entitlements_repo.try_grant_limited(
        conn, user_id, PREMIUM, EARLY_ACCESS_GRANT, _now_iso(), EARLY_ACCESS_LIMIT)


def premium_status(conn, user_id: int) -> dict:
    grants = entitlements_repo.active_for_user(conn, user_id, PREMIUM, today_date().isoformat())
    if not grants:
        return {"active": False, "forever": False, "grant_type": None, "granted_at": None, "label": None}
    g = grants[0]
    forever = g["expires_at"] is None
    return {
        "active": True,
        "forever": forever,
        "grant_type": g["grant_type"],
        "granted_at": g["granted_at"],
        "label": "Premium · навсегда" if forever else "Premium",
    }


def normalize_username(raw: str) -> str:
    """Убирает пробелы по краям и ведущий @, приводит к нижнему регистру, проверяет правила."""
    name = (raw or "").strip().removeprefix("@").lower()
    if not 3 <= len(name) <= 20:
        raise UsernameError("Имя пользователя — от 3 до 20 символов")
    if not USERNAME_RE.match(name):
        raise UsernameError("Только латинские буквы, цифры и «_», первая — буква")
    if name in RESERVED_USERNAMES:
        raise UsernameError("Это имя зарезервировано")
    return name


def change_username(conn, user_id: int, raw: str) -> str:
    name = normalize_username(raw)
    current = users_repo.get_user(conn, user_id)["username"]
    if current == name:
        return name
    try:
        users_repo.set_username(conn, user_id, name)
    except sqlite3.IntegrityError as exc:
        raise UsernameTaken("Это имя уже занято") from exc
    return name


def complete_onboarding(conn, user_id: int) -> dict:
    users_repo.complete_onboarding(conn, user_id, today_date().isoformat())
    return onboarding_status(conn, user_id)


def onboarding_status(conn, user_id: int) -> dict:
    completed_at = users_repo.get_user(conn, user_id)["onboarding_completed_at"]
    return {"completed": completed_at is not None, "completed_at": completed_at}


def get_account(conn, user_id: int) -> dict:
    """Публичное представление аккаунта (без внутреннего id). Только чтение."""
    user = users_repo.get_user(conn, user_id)
    return {
        "public_id": user["public_id"],
        "username": user["username"],
        "created_at": user["created_at"],
        "premium": premium_status(conn, user_id),
        "onboarding": onboarding_status(conn, user_id),
    }
