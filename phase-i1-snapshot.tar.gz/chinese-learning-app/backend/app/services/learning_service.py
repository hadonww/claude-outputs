from srs import ReviewState
from srs import review as srs_review
from srs import word_state as srs_word_state

from ..repositories import (
    mastery_history_repo,
    progress_repo,
    review_schedule_repo,
    stats_repo,
    users_repo,
    words_repo,
)
from ..utils import today_date


def home_stats(conn) -> dict:
    today = today_date()
    counts = progress_repo.home_counts(conn, today.isoformat())
    total_words = counts["total_words"]
    learned_count = counts["learned_count"]
    return {
        "due_review_count": counts["due_count"],
        "new_words_available": counts["new_count"],
        "learned_count": learned_count,
        "total_words": total_words,
        "progress_percent": round(100 * learned_count / total_words, 1) if total_words else 0,
        # серия считается при чтении из activity_log: пропуск дня виден сразу
        "streak": stats_repo.current_streak(conn, today),
    }


def build_session(conn, limit: int | None) -> dict:
    """Слова на сегодня: сначала просроченные повторения, потом новые.
    Новые слова подбираются в первую очередь из уровня, выбранного при
    онбординге (preferred_hsk), а дневной объём — из daily_new_words,
    если явный limit не передан."""
    today_iso = today_date().isoformat()
    stats = stats_repo.get_stats(conn)
    effective_limit = limit if limit is not None else stats["daily_new_words"]
    preferred_hsk = stats["preferred_hsk"]

    due_rows = progress_repo.due_review_words(conn, today_iso)
    new_rows = progress_repo.new_words_for_session(conn, preferred_hsk, effective_limit)

    return {
        "review_words": [words_repo.word_row_to_dict(r) for r in due_rows],
        "new_words": [words_repo.word_row_to_dict(r) for r in new_rows],
    }


def submit_review(conn, word_id: int, quality: int) -> dict:
    today = today_date()
    user_id = users_repo.get_current_user_id(conn)
    row = progress_repo.get_progress_row(conn, word_id)
    if row is None:
        return None

    state = ReviewState(
        repetitions=row["repetitions"],
        ease_factor=row["ease_factor"],
        interval_days=row["interval_days"],
    )
    new_state, due_date = srs_review(state, quality, today)
    is_correct = 1 if quality >= 1 else 0

    progress_repo.update_progress_after_review(
        conn, word_id, new_state, due_date.isoformat(), today.isoformat(), is_correct
    )

    # Review planned -> completed (Phase E, п.7): закрываем ожидавшую запись
    # по этому слову (если была) и сразу же планируем следующую — на due_date,
    # который SRS только что посчитал.
    review_schedule_repo.complete_pending(conn, user_id, word_id, today.isoformat())
    review_schedule_repo.schedule_next(conn, user_id, word_id, due_date.isoformat())

    # Снимок mastery на сегодня (Phase E, п.8) — не на каждую попытку, а на
    # каждое финальное SRS-событие (уже реже, чем на каждый шаг урока);
    # идемпотентно в пределах дня (UNIQUE + ON CONFLICT UPDATE).
    mastery_history_repo.snapshot_today(conn, user_id, today.isoformat())

    # активность за день — для графика в профиле и источник серии
    stats_repo.increment_activity_log(conn, today.isoformat())
    # stats.streak — кэш той же величины (app/streak.py), не отдельная система:
    # после разрыва новый ответ даёт серию 1, повторный ответ в тот же день её не меняет
    stats_repo.update_streak_and_reviews(conn, stats_repo.current_streak(conn, today), today.isoformat())

    return {
        "next_due_date": due_date.isoformat(),
        "interval_days": new_state.interval_days,
        "state": srs_word_state(new_state.repetitions, new_state.interval_days),
    }


# «Я это уже знаю» (Phase H). Заявление само по себе SRS не меняет: слово
# проверяется одним объективным заданием в том же уроке. Если проверка пройдена,
# слово встаёт в SRS так, будто прошло первые два успешных повторения SM-2
# (интервал 6 дней), а не сразу в «освоено»: дальнейшие повторения по
# расписанию подтвердят или опровергнут знание. Не пройдена — submit_review(0).
KNOWN_REPETITIONS = 2
KNOWN_INTERVAL_DAYS = 6


def confirm_known(conn, word_id: int) -> dict | None:
    from datetime import timedelta

    today = today_date()
    user_id = users_repo.get_current_user_id(conn)
    row = progress_repo.get_progress_row(conn, word_id)
    if row is None:
        return None
    due = today + timedelta(days=KNOWN_INTERVAL_DAYS)
    progress_repo.set_known_verified(conn, word_id, max(row["repetitions"], KNOWN_REPETITIONS),
                                     max(row["interval_days"], KNOWN_INTERVAL_DAYS), max(row["ease_factor"], 2.5),
                                     due.isoformat(), today.isoformat())
    review_schedule_repo.complete_pending(conn, user_id, word_id, today.isoformat())
    review_schedule_repo.schedule_next(conn, user_id, word_id, due.isoformat())
    mastery_history_repo.snapshot_today(conn, user_id, today.isoformat())
    stats_repo.increment_activity_log(conn, today.isoformat())
    return {"next_due_date": due.isoformat(), "interval_days": KNOWN_INTERVAL_DAYS,
            "state": srs_word_state(KNOWN_REPETITIONS, KNOWN_INTERVAL_DAYS), "quality": 2, "known": True}
