"""
Phase E: единый statistics/analytics слой.

learning data (progress/attempts/mastery/activity_log/lesson_completions/
review_schedule/mastery_history) -> этот модуль -> profile_service/API -> UI.

UI (и даже profile_service) не считают цифры сами — только читают то, что
отдаёт этот слой. Ничего здесь не выдумывается: если данных недостаточно,
поле явно None/no_data, а не правдоподобный ноль.
"""

from ..repositories import (
    attempts_repo,
    lesson_completions_repo,
    mastery_history_repo,
    mastery_repo,
    progress_repo,
    review_schedule_repo,
    stats_repo,
    users_repo,
)
from ..utils import today_date


def get_statistics(conn, activity_days: int = 30) -> dict:
    user_id = users_repo.get_current_user_id(conn)
    today = today_date()

    return {
        "activity": progress_repo.week_activity_counts(conn, today, days=activity_days),
        "word_states": progress_repo.word_state_counts(conn),
        "skills": mastery_repo.get_mastery_with_stats(conn, user_id),
        "exercise_stats": {
            "by_type": attempts_repo.stats_by_exercise_type(conn, user_id),
            "by_skill": attempts_repo.stats_by_skill(conn, user_id),
            "total_attempts": attempts_repo.count_attempts(conn, user_id),
        },
        "study_time": attempts_repo.study_time_stats(conn, user_id),
        "streak": {
            "current": stats_repo.current_streak(conn, today),
            "longest": stats_repo.longest_streak(conn),
        },
        "review_consistency": review_schedule_repo.consistency(conn, user_id, today.isoformat()),
        "mastery_trend": mastery_history_repo.trend(conn, user_id),
        "lessons": {
            "completed_count": lesson_completions_repo.count_completions(conn, user_id),
            "recent": [
                {
                    "module_title": r["module_title"],
                    "completed_at": r["completed_at"],
                    "new_words_count": r["new_words_count"],
                    "review_words_count": r["review_words_count"],
                    "exercises_count": r["exercises_count"],
                }
                for r in lesson_completions_repo.recent_completions(conn, user_id)
            ],
        },
        "weak_words": [
            {
                "hanzi": r["hanzi"], "pinyin": r["pinyin"], "translation": r["translation"],
                "accuracy": round(100 * r["total_correct"] / r["total_attempts"], 1),
            }
            for r in progress_repo.profile_weak_words(conn)
        ],
    }
