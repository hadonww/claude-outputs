from collections.abc import Iterable

from ..curriculum import compute_statuses, module_description, route_order
from ..repositories import modules_repo


def _module_state(total_words: int, learned_words: int, introduced_words: int | None = None) -> str:
    """
    completed — все слова модуля уже пройдены (introduced): новых не осталось.
    Забытое потом слово модуль не «распройдёт» — оно вернётся через review
    из любого модуля, а маршрут не прыгает назад (раньше completed требовал
    repetitions > 0 у всех слов, и один провал откатывал current к старому
    модулю, где урок мог оказаться пустым).
    """
    introduced = learned_words if introduced_words is None else max(introduced_words, learned_words)
    if total_words == 0 or introduced == 0:
        return "not_started"
    if introduced >= total_words:
        return "completed"
    return "in_progress"


def get_learning_path(conn, unlocked_ids: Iterable[int] = ()) -> dict:
    """
    Путь обучения на реальных данных модулей/прогресса.

    Порядок и разделы задаёт маршрут курса (app/curriculum.py), а не
    modules.order_index. Рекомендуемый (current) модуль — первый по маршруту,
    который ещё не завершён. Правило по-прежнему детерминированное и простое;
    mastery-взвешенная рекомендация Adaptive Engine заменит его, не меняя форму
    ответа. unlocked_ids — точка расширения для placement / «Я это уже знаю».
    """
    rows = modules_repo.modules_with_progress(conn)

    modules = []
    for r in rows:
        total = r["total_words"] or 0
        if total == 0:
            continue  # модуль без слов (тема/уровень ещё не наполнены) — не узел пути
        learned = r["learned_words"] or 0
        introduced = r["introduced_words"] or 0
        modules.append({
            "id": r["id"],
            "order_index": r["order_index"],
            "title": r["title"],
            "hsk_level": r["hsk_level"],
            "category": r["category"],
            "description": module_description(r["category"]),
            "total_words": total,
            "learned_words": learned,
            "introduced_words": introduced,
            "progress_percent": round(100 * learned / total, 1) if total else 0,
            "state": _module_state(total, learned, introduced),
        })

    modules = route_order(modules)
    statuses, current_id = compute_statuses(modules, unlocked_ids)
    for m in modules:
        m["status"] = statuses[m["id"]]

    # Пояснения — полями модулей, верхний уровень ответа не меняется (контракт):
    # почему рекомендован текущий и почему закрыт закрытый.
    reason = recommendation_reason(modules, current_id)
    current_title = next((m["title"] for m in modules if m["id"] == current_id), None)
    for m in modules:
        m["recommendation_reason"] = reason if m["id"] == current_id else None
        m["locked_reason"] = (f"Откроется по порядку курса — сейчас идёт «{current_title}»"
                              if m["status"] == "locked" and current_title else None)
    return {"modules": modules, "recommended_module_id": current_id}


def _plural(n: int, one: str, few: str, many: str) -> str:
    if n % 10 == 1 and n % 100 != 11:
        return one
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return few
    return many


def recommendation_reason(modules: list[dict], current_id: int | None) -> str | None:
    """Почему рекомендован именно этот модуль — простым языком, по фактам маршрута."""
    current = next((m for m in modules if m["id"] == current_id), None)
    if current is None:
        return None
    index = next(i for i, m in enumerate(modules) if m["id"] == current_id)
    previous = modules[index - 1] if index > 0 else None
    if current["introduced_words"]:
        left = current["total_words"] - current["introduced_words"]
        reason = f"Вы уже начали этот модуль — осталось {left} {_plural(left, 'новое слово', 'новых слова', 'новых слов')}"
    elif previous is None:
        reason = "Первый модуль курса: с него начинается HSK 1"
    elif previous["hsk_level"] != current["hsk_level"]:
        reason = f"HSK {previous['hsk_level']} пройден — начинаем HSK {current['hsk_level']}"
    else:
        reason = f"Следующий по курсу после «{previous['title']}»"
    return reason
