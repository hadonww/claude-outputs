"""
Оценка произношения: провайдер распознавания + общая шкала из engine.pronunciation.

Контракт для урока:
    assess_pronunciation(audio_bytes, expected_text, expected_pinyin) -> PronunciationResult
    (overall 0–100, per_word, notes)

Провайдер — подключаемый объект с методом
    recognize(audio_bytes, expected: list[(слово, пиньинь)]) -> list[pinyin | None]
(что прозвучало в каждом ожидаемом слове). Выбирается переменной окружения
PRONUNCIATION_PROVIDER (по умолчанию не подключён). Без провайдера оценка
честно недоступна — PronunciationUnavailable, и урок говорит об этом прямо:
воспроизведение записи оценкой не выдаётся.
"""

import os
from typing import Protocol

from engine.pronunciation import PronunciationResult, score_utterance

MAX_AUDIO_BYTES = 2_000_000


class PronunciationUnavailable(RuntimeError):
    """Провайдер распознавания речи не подключён или недоступен."""


class PronunciationProvider(Protocol):
    name: str

    def recognize(self, audio_bytes: bytes, expected: list[tuple[str, str]]) -> list[str | None]: ...


_PROVIDERS: dict[str, PronunciationProvider] = {}
_override: PronunciationProvider | None = None


def register_provider(provider: PronunciationProvider) -> None:
    """Регистрирует провайдера под его name (выбор — PRONUNCIATION_PROVIDER)."""
    _PROVIDERS[provider.name] = provider


def set_provider(provider: PronunciationProvider | None) -> None:
    """Явная подмена (тесты, локальная отладка)."""
    global _override
    _override = provider


def get_provider() -> PronunciationProvider | None:
    if _override is not None:
        return _override
    return _PROVIDERS.get(os.environ.get("PRONUNCIATION_PROVIDER", "").strip())


def is_available() -> bool:
    return get_provider() is not None


def _split(value: str | list[str]) -> list[str]:
    if isinstance(value, list):
        return list(value)
    return [t for t in (value or "").split() if t]


def assess_pronunciation(audio_bytes: bytes, expected_text: str | list[str],
                         expected_pinyin: str | list[str]) -> PronunciationResult:
    """
    expected_text / expected_pinyin — слова фразы и их пиньинь по порядку (списки
    или строки через пробел). Провайдер распознаёт, движок ставит оценку.
    """
    provider = get_provider()
    if provider is None:
        raise PronunciationUnavailable("Оценка произношения не подключена")
    if not audio_bytes:
        raise ValueError("пустая запись")
    if len(audio_bytes) > MAX_AUDIO_BYTES:
        raise ValueError("запись слишком длинная")
    words, pinyin = _split(expected_text), _split(expected_pinyin)
    if len(words) != len(pinyin):
        raise ValueError("слов и пиньиня должно быть поровну")
    expected = list(zip(words, pinyin, strict=True))
    heard = provider.recognize(audio_bytes, expected)
    return score_utterance(expected, heard, provider=provider.name)
