def record_completion(conn, user_id: int, module_id: int | None, *, started_at: str, completed_at: str,
                       new_words_count: int, review_words_count: int, exercises_count: int) -> int:
    cur = conn.execute(
        """INSERT INTO lesson_completions (user_id, module_id, started_at, completed_at,
           new_words_count, review_words_count, exercises_count)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (user_id, module_id, started_at, completed_at, new_words_count, review_words_count, exercises_count),
    )
    return cur.lastrowid


def count_completions(conn, user_id: int) -> int:
    return conn.execute(
        "SELECT COUNT(*) FROM lesson_completions WHERE user_id = ?", (user_id,)
    ).fetchone()[0]


def recent_completions(conn, user_id: int, limit: int = 20):
    return conn.execute(
        """SELECT lc.*, m.title AS module_title FROM lesson_completions lc
           LEFT JOIN modules m ON m.id = lc.module_id
           WHERE lc.user_id = ? ORDER BY lc.completed_at DESC LIMIT ?""",
        (user_id, limit),
    ).fetchall()


def total_attempts_for_lesson(conn, lesson_id: int | None) -> int:
    """Все попытки по этому lesson_id за всё время — источник истины для
    exercises_count, не слова клиента."""
    if lesson_id is None:
        return 0
    return conn.execute(
        "SELECT COUNT(*) FROM attempts WHERE lesson_id = ?", (lesson_id,)
    ).fetchone()[0]


def already_counted_exercises(conn, module_id: int | None) -> int:
    """Сколько exercises уже вошло в предыдущие completion-записи этого
    модуля — чтобы считать ДЕЛЬТУ, не задвоить. attempts.created_at в схеме
    хранит только дату (не время), поэтому окно сессии по timestamp ненадёжно
    сравнивать напрямую со строковой датой — дельта от кумулятивного счёта
    надёжнее и не требует timestamp-сравнений вообще."""
    if module_id is None:
        return 0
    row = conn.execute(
        "SELECT COALESCE(SUM(exercises_count), 0) FROM lesson_completions WHERE module_id = ?",
        (module_id,),
    ).fetchone()
    return row[0]


def word_ids_with_any_attempt_for_lesson(conn, candidate_word_ids: list[int], lesson_id: int | None) -> set[int]:
    """Проверяет заявленные клиентом word_id против реальных attempts этого
    lesson_id (за всё время — не доверяем числам от фронтенда напрямую,
    Phase E, п.4)."""
    if not candidate_word_ids or lesson_id is None:
        return set()
    placeholders = ",".join("?" for _ in candidate_word_ids)
    rows = conn.execute(
        f"""SELECT DISTINCT content_item_id FROM attempts
           WHERE content_item_id IN ({placeholders}) AND lesson_id = ?""",
        (*candidate_word_ids, lesson_id),
    ).fetchall()
    return {r["content_item_id"] for r in rows}
