def get_current_user_id(conn) -> int:
    """
    Пользователь текущего запроса. Сейчас в приложении нет аутентификации,
    поэтому это владелец экземпляра (первый аккаунт). ЕДИНСТВЕННАЯ точка, где
    решается «кто это» — когда появится сессия/логин, меняется только она
    (и её вызовы в routers), а не сервисы.
    """
    row = conn.execute("SELECT id FROM users ORDER BY id LIMIT 1").fetchone()
    return row["id"]


def get_user(conn, user_id: int):
    return conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def insert_user(conn, created_at: str, public_id: str) -> int:
    """Бросает sqlite3.IntegrityError при совпадении public_id (вызывающий повторяет)."""
    cur = conn.execute("INSERT INTO users (created_at, public_id) VALUES (?, ?)", (created_at, public_id))
    return cur.lastrowid


def set_public_id_if_missing(conn, user_id: int, public_id: str) -> None:
    conn.execute("UPDATE users SET public_id = ? WHERE id = ? AND public_id IS NULL", (public_id, user_id))


def set_username(conn, user_id: int, username: str) -> None:
    """Бросает sqlite3.IntegrityError, если имя занято (UNIQUE-индекс)."""
    conn.execute("UPDATE users SET username = ? WHERE id = ?", (username, user_id))


def complete_onboarding(conn, user_id: int, completed_at: str) -> None:
    """Идемпотентно: дата первого завершения не перезаписывается."""
    conn.execute(
        "UPDATE users SET onboarding_completed_at = ? WHERE id = ? AND onboarding_completed_at IS NULL",
        (completed_at, user_id),
    )


def count_users(conn) -> int:
    return conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
