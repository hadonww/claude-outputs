import json


def _row(r) -> dict:
    return {"id": r["id"], "target_word_id": r["target_word_id"],
            "a_cn": r["line_a_cn"], "a_ru": r["line_a_ru"], "a_pinyin": r["line_a_pinyin"],
            "b_cn": r["line_b_cn"], "b_ru": r["line_b_ru"], "b_pinyin": r["line_b_pinyin"],
            "used_word_ids": json.loads(r["used_word_ids"])}


def get_dialogues_for_words(conn, word_ids: list[int]) -> dict[int, list[dict]]:
    if not word_ids:
        return {}
    marks = ",".join("?" for _ in word_ids)
    result: dict[int, list[dict]] = {}
    for r in conn.execute(f"SELECT * FROM dialogues WHERE target_word_id IN ({marks}) ORDER BY id", word_ids):
        result.setdefault(r["target_word_id"], []).append(_row(r))
    return result


def all_dialogues(conn) -> list[dict]:
    return [_row(r) for r in conn.execute("SELECT * FROM dialogues ORDER BY id")]
