"""Сессии урока: выданный план (с верными ответами) живёт на сервере, клиент
получает шаги без ответов и присылает только действия пользователя."""

import json


def create(conn, session_id: str, user_id: int, module_id: int | None, kind: str, created_at: str,
           steps: list[dict], state: dict) -> None:
    conn.execute(
        """INSERT INTO lesson_sessions (id, user_id, module_id, kind, created_at, steps, state)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (session_id, user_id, module_id, kind, created_at,
         json.dumps(steps, ensure_ascii=False), json.dumps(state, ensure_ascii=False)),
    )


def get(conn, session_id: str) -> dict | None:
    row = conn.execute("SELECT * FROM lesson_sessions WHERE id = ?", (session_id,)).fetchone()
    if row is None:
        return None
    data = dict(row)
    data["steps"] = json.loads(data["steps"])
    data["state"] = json.loads(data["state"])
    return data


def save(conn, session_id: str, steps: list[dict], state: dict) -> None:
    conn.execute("UPDATE lesson_sessions SET steps = ?, state = ? WHERE id = ?",
                 (json.dumps(steps, ensure_ascii=False), json.dumps(state, ensure_ascii=False), session_id))


def mark_completed(conn, session_id: str, completed_at: str) -> None:
    conn.execute("UPDATE lesson_sessions SET completed_at = ? WHERE id = ?", (completed_at, session_id))


def completed_script_keys(conn, user_id: int) -> set[str]:
    """Сценарии уроков (Phase H), которые пользователь уже прошёл до конца."""
    rows = conn.execute(
        """SELECT DISTINCT json_extract(state, '$.script_key') FROM lesson_sessions
           WHERE user_id = ? AND completed_at IS NOT NULL AND json_extract(state, '$.script_key') IS NOT NULL""",
        (user_id,)).fetchall()
    return {r[0] for r in rows}
