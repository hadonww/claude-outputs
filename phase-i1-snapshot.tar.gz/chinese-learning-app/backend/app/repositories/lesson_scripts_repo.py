"""Сценарии эталонных уроков (Phase H): авторский контент тем из data/lessons/*.json.

Файл — источник истины (как data/examples/*.tsv): правится и ревьюится как
текст, в БД не копируется. Разбор слов и выбор сценария — engine.lesson_script.
"""

import json
from functools import lru_cache
from pathlib import Path

LESSONS_DIR = Path(__file__).resolve().parent.parent.parent / "data" / "lessons"


@lru_cache(maxsize=1)
def _load_all() -> tuple:
    files = []
    for path in sorted(LESSONS_DIR.glob("*.json")):
        files.append(json.loads(path.read_text(encoding="utf-8")))
    return tuple(files)


def all_blueprints() -> list[dict]:
    return [lesson for f in _load_all() for lesson in f.get("lessons", [])]


def blueprints_for_module(module) -> list[dict]:
    """Сценарии темы модуля (по уровню и категории), в порядке прохождения."""
    if module is None:
        return []
    for f in _load_all():
        m = f.get("module") or {}
        if m.get("hsk_level") == module["hsk_level"] and m.get("category") == module["category"]:
            return list(f.get("lessons", []))
    return []
