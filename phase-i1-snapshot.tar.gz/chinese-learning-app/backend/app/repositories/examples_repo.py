import json


def get_examples_for_words(conn, word_ids: list[int]) -> dict[int, list[dict]]:
    """
    Только examples с needs_review=0 — единственные, которые движок вправе
    использовать (см. engine/exercise_types.py: used_word_ids — источник
    истины для fill_blank/sentence_order, а не токенизация на лету).
    """
    if not word_ids:
        return {}
    placeholders = ",".join("?" for _ in word_ids)
    rows = conn.execute(
        f"""SELECT id, target_word_id, sentence_cn, sentence_ru, pinyin, used_word_ids,
            grammar_tag, difficulty FROM examples
            WHERE target_word_id IN ({placeholders}) AND needs_review = 0
            ORDER BY id""",
        word_ids,
    ).fetchall()
    result: dict[int, list[dict]] = {}
    for r in rows:
        result.setdefault(r["target_word_id"], []).append({
            "id": r["id"],
            "sentence_cn": r["sentence_cn"],
            "sentence_ru": r["sentence_ru"],
            "pinyin": r["pinyin"],
            "used_word_ids": json.loads(r["used_word_ids"]),
            "grammar_tag": r["grammar_tag"],
            "difficulty": r["difficulty"],
        })
    return result


def insert_example(conn, target_word_id: int, sentence_cn: str, sentence_ru: str,
                    used_word_ids: list[int], *, pinyin: str | None = None,
                    grammar_tag: str | None = None, difficulty: int | None = None,
                    source: str, needs_review: bool = False) -> int:
    cur = conn.execute(
        """INSERT INTO examples (target_word_id, sentence_cn, sentence_ru, pinyin,
           used_word_ids, grammar_tag, difficulty, source, needs_review)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (target_word_id, sentence_cn, sentence_ru, pinyin, json.dumps(used_word_ids),
         grammar_tag, difficulty, source, int(needs_review)),
    )
    return cur.lastrowid


def count_by_source(conn) -> dict[str, int]:
    return {r["source"]: r["c"] for r in
            conn.execute("SELECT source, COUNT(*) c FROM examples GROUP BY source")}


def words_with_at_least_one_usable_example(conn) -> int:
    return conn.execute(
        "SELECT COUNT(DISTINCT target_word_id) FROM examples WHERE needs_review = 0"
    ).fetchone()[0]
