import json

from srs import word_state as srs_word_state

WORD_SELECT = """
    SELECT w.*, p.repetitions, p.interval_days, p.total_attempts, p.total_correct
    FROM words w LEFT JOIN progress p ON p.word_id = w.id
"""


def word_row_to_dict(row) -> dict:
    keys = row.keys()
    attempts = row["total_attempts"] if "total_attempts" in keys else 0
    correct = row["total_correct"] if "total_correct" in keys else 0
    repetitions = row["repetitions"] if "repetitions" in keys else 0
    interval_days = row["interval_days"] if "interval_days" in keys else 0
    return {
        "id": row["id"],
        "hanzi": row["hanzi"],
        "pinyin": row["pinyin"],
        "translation": row["translation"],
        "hsk": row["hsk"],
        "category": row["category"],
        "module_id": row["module_id"] if "module_id" in keys else None,
        "example_cn": row["example_cn"],
        "example_ru": row["example_ru"],
        "components": row["components"],
        "strokes": row["strokes"],
        "frequency": row["frequency"],
        "related": json.loads(row["related"]) if row["related"] else [],
        "state": srs_word_state(repetitions or 0, interval_days or 0),
        "accuracy": round(100 * correct / attempts, 1) if attempts else None,
    }


# «Слабое» слово — то же определение, что у очереди повторения (Phase D):
# не меньше 2 попыток и точность ниже 70%, либо забытое (repetitions сброшен).
WEAK_SQL = """((p.total_attempts >= 2 AND CAST(p.total_correct AS REAL) / p.total_attempts < 0.7)
               OR (p.repetitions = 0 AND p.total_attempts > 0))"""


def search_words(conn, q: str = "", category: str = "", hsk: int = 0, seen: bool = False, weak: bool = False):
    clauses, params = [], []
    if q:
        clauses.append("(w.hanzi LIKE ? OR w.pinyin LIKE ? OR w.translation LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like]
    if category:
        clauses.append("w.category = ?")
        params.append(category)
    if hsk:
        clauses.append("w.hsk = ?")
        params.append(hsk)
    if seen:  # слова, с которыми пользователь уже работал (недавние — первыми)
        clauses.append("(p.total_attempts > 0 OR p.repetitions > 0)")
    if weak:
        clauses.append(WEAK_SQL)
    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    order = ("COALESCE(p.last_reviewed, '') DESC, w.id" if seen or weak
             else "w.hsk, COALESCE(w.frequency, 999999), w.id")
    return conn.execute(f"{WORD_SELECT} {where} ORDER BY {order}", params).fetchall()


def progress_detail(conn, word_id: int):
    return conn.execute(
        """SELECT p.due_date, p.last_reviewed, p.total_attempts, p.total_correct, p.repetitions, p.interval_days,
                  m.id AS module_id, m.title AS module_title, m.hsk_level AS module_level
           FROM words w LEFT JOIN progress p ON p.word_id = w.id LEFT JOIN modules m ON m.id = w.module_id
           WHERE w.id = ?""", (word_id,)).fetchone()


def get_word_by_id(conn, word_id: int):
    return conn.execute(f"{WORD_SELECT} WHERE w.id = ?", (word_id,)).fetchone()


def list_categories(conn):
    return conn.execute(
        "SELECT category, COUNT(*) as cnt FROM words GROUP BY category ORDER BY cnt DESC"
    ).fetchall()


def fetch_all_hanzi(conn) -> set[str]:
    return {r["hanzi"] for r in conn.execute("SELECT hanzi FROM words").fetchall()}


def insert_word(conn, hanzi, pinyin, translation, hsk, category, example_cn, example_ru,
                 components, strokes) -> int:
    cur = conn.execute(
        """INSERT INTO words (hanzi, pinyin, translation, hsk, category, example_cn,
           example_ru, components, strokes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (hanzi, pinyin, translation, hsk, category, example_cn, example_ru, components, strokes),
    )
    return cur.lastrowid


def words_by_hanzi(conn, hanzi: set[str]) -> dict[str, dict]:
    """Слова базы по написанию (для разбора сценариев уроков)."""
    if not hanzi:
        return {}
    marks = ",".join("?" for _ in hanzi)
    rows = conn.execute(f"{WORD_SELECT} WHERE w.hanzi IN ({marks})", list(hanzi)).fetchall()
    return {r["hanzi"]: word_row_to_dict(r) for r in rows}
