def snapshot_today(conn, user_id: int, today_iso: str) -> int:
    """Один снимок в день на навык — UNIQUE(user_id, skill, snapshotted_at)
    в схеме гарантирует идемпотентность, здесь просто INSERT OR REPLACE
    (повторный запуск в тот же день обновляет, не дублирует)."""
    rows = conn.execute("SELECT skill, score FROM mastery WHERE user_id = ?", (user_id,)).fetchall()
    for r in rows:
        conn.execute(
            """INSERT INTO mastery_history (user_id, skill, score, snapshotted_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(user_id, skill, snapshotted_at) DO UPDATE SET score = excluded.score""",
            (user_id, r["skill"], r["score"], today_iso),
        )
    return len(rows)


def trend(conn, user_id: int, skill: str | None = None, limit_days: int = 30):
    if skill:
        return conn.execute(
            """SELECT skill, score, snapshotted_at FROM mastery_history
               WHERE user_id = ? AND skill = ? ORDER BY snapshotted_at DESC LIMIT ?""",
            (user_id, skill, limit_days),
        ).fetchall()
    return conn.execute(
        """SELECT skill, score, snapshotted_at FROM mastery_history
           WHERE user_id = ? ORDER BY snapshotted_at DESC LIMIT ?""",
        (user_id, limit_days * 8),  # 8 навыков в день
    ).fetchall()
