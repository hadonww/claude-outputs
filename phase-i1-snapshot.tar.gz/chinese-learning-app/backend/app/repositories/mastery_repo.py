from ..config import SKILLS


def get_all_mastery(conn, user_id: int) -> dict:
    """Возвращает {skill: score} для всех навыков пользователя (все 8 — таблица
    всегда полностью заполнена при сидировании, см. db.init_db)."""
    rows = conn.execute(
        "SELECT skill, score FROM mastery WHERE user_id = ?", (user_id,)
    ).fetchall()
    return {r["skill"]: r["score"] for r in rows}


def get_mastery_with_stats(conn, user_id: int) -> list[dict]:
    """
    Per-skill mastery для профиля (Phase E, п.2): score, число попыток,
    accuracy, последнее обновление. Если по навыку ещё не было ни одной
    попытки — score у него формально 0 (так сидируется), но это НЕ реальный
    результат, поэтому no_data=True и такой skill не должен подаваться как
    "0%" где-либо в UI.
    """
    att = {r["skill"]: r for r in conn.execute(
        """SELECT skill, COUNT(*) attempts, SUM(correct) correct
           FROM attempts WHERE user_id = ? GROUP BY skill""", (user_id,)
    ).fetchall()}
    rows = conn.execute(
        "SELECT skill, score, updated_at FROM mastery WHERE user_id = ? ORDER BY skill", (user_id,)
    ).fetchall()
    result = []
    for r in rows:
        a = att.get(r["skill"])
        n_attempts = a["attempts"] if a else 0
        result.append({
            "skill": r["skill"],
            "score": round(r["score"], 1) if n_attempts else None,
            "no_data": n_attempts == 0,
            "attempts": n_attempts,
            "accuracy": round(100 * a["correct"] / a["attempts"], 1) if a and a["attempts"] else None,
            "updated_at": r["updated_at"] if n_attempts else None,
        })
    return result


def get_mastery_score(conn, user_id: int, skill: str) -> float:
    row = conn.execute(
        "SELECT score FROM mastery WHERE user_id = ? AND skill = ?", (user_id, skill)
    ).fetchone()
    return row["score"] if row else 0.0


def set_mastery_score(conn, user_id: int, skill: str, score: float, updated_at_iso: str):
    if skill not in SKILLS:
        raise ValueError(f"Неизвестный навык: {skill!r}. Допустимые: {SKILLS}")
    conn.execute(
        """INSERT INTO mastery (user_id, skill, score, updated_at) VALUES (?, ?, ?, ?)
           ON CONFLICT(user_id, skill) DO UPDATE SET score = excluded.score, updated_at = excluded.updated_at""",
        (user_id, skill, score, updated_at_iso),
    )
