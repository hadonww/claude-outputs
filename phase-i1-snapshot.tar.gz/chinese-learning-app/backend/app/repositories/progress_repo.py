from datetime import timedelta

from .. import utils

DAILY_REVIEW_LIMIT = 30


def insert_progress_row(conn, word_id: int, user_id: int, due_date_iso: str):
    conn.execute(
        """INSERT INTO progress (word_id, user_id, repetitions, ease_factor, interval_days, due_date)
           VALUES (?, ?, 0, 2.5, 0, ?)""",
        (word_id, user_id, due_date_iso),
    )


def get_progress_row(conn, word_id: int):
    return conn.execute("SELECT * FROM progress WHERE word_id = ?", (word_id,)).fetchone()


def update_progress_after_review(conn, word_id: int, new_state, due_date_iso: str,
                                  reviewed_at_iso: str, is_correct: int):
    conn.execute(
        """UPDATE progress SET repetitions = ?, ease_factor = ?, interval_days = ?,
           due_date = ?, last_reviewed = ?, total_attempts = total_attempts + 1,
           total_correct = total_correct + ? WHERE word_id = ?""",
        (new_state.repetitions, new_state.ease_factor, new_state.interval_days,
         due_date_iso, reviewed_at_iso, is_correct, word_id),
    )


# Слово «в SRS» — уже проходилось: выучено (repetitions > 0) или забыто после
# прохождения (SM-2 сбросил repetitions в 0, но финальная попытка была).
# Забытое слово остаётся в очереди повторения (его due_date = завтра) и не
# возвращается в «новые» — иначе оно выпадало из review и всплывало только
# при возврате в свой модуль.
IN_SRS_SQL = "(p.repetitions > 0 OR p.total_attempts > 0)"
NEVER_SEEN_SQL = "(p.repetitions = 0 AND p.total_attempts = 0)"


def home_counts(conn, today_iso: str) -> dict:
    due_count = conn.execute(
        f"SELECT COUNT(*) FROM progress p WHERE p.due_date <= ? AND {IN_SRS_SQL}", (today_iso,)
    ).fetchone()[0]
    new_count = conn.execute(f"SELECT COUNT(*) FROM progress p WHERE {NEVER_SEEN_SQL}").fetchone()[0]
    learned_count = conn.execute("SELECT COUNT(*) FROM progress WHERE repetitions > 0").fetchone()[0]
    total_words = conn.execute("SELECT COUNT(*) FROM words").fetchone()[0]
    return {
        "due_count": due_count,
        "new_count": new_count,
        "learned_count": learned_count,
        "total_words": total_words,
    }


WEAK_ACCURACY_THRESHOLD = 0.7  # тот же порог, что у profile_weak_words — единое определение "слабое слово"
WEAK_MIN_ATTEMPTS = 2

# Просроченное СЛАБОЕ слово приоритетнее просроченного сильного (Phase D, п.2) —
# слабость по точности ответов (то, что уже есть в progress, а не выдуманная метрика).
# Забытое слово (repetitions = 0 после прохождения) — тоже слабое.
_WEAK_ORDER_SQL = f"""
    (CASE WHEN p.repetitions = 0
               OR (p.total_attempts >= {WEAK_MIN_ATTEMPTS}
                   AND CAST(p.total_correct AS REAL) / p.total_attempts < {WEAK_ACCURACY_THRESHOLD})
          THEN 0 ELSE 1 END), p.due_date ASC, w.id ASC
"""

_WORD_COLS = "w.*, p.repetitions, p.interval_days, p.total_attempts, p.total_correct"


def due_review_words(conn, today_iso: str, limit: int = DAILY_REVIEW_LIMIT):
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE p.due_date <= ? AND {IN_SRS_SQL}
           ORDER BY {_WEAK_ORDER_SQL} LIMIT ?""",
        (today_iso, limit),
    ).fetchall()


def count_due_review_words(conn, today_iso: str) -> int:
    return conn.execute(
        f"SELECT COUNT(*) FROM progress p WHERE p.due_date <= ? AND {IN_SRS_SQL}", (today_iso,)
    ).fetchone()[0]


def new_words_for_session(conn, preferred_hsk: int, limit: int):
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE {NEVER_SEEN_SQL}
           ORDER BY (CASE WHEN w.hsk = ? THEN 0 ELSE 1 END),
                    COALESCE(w.frequency, 999999) ASC, w.id ASC LIMIT ?""",
        (preferred_hsk, limit),
    ).fetchall()


def due_review_words_for_module(conn, module_id: int, today_iso: str, limit: int = DAILY_REVIEW_LIMIT):
    """Как due_review_words(), но только слова конкретного модуля."""
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE w.module_id = ? AND p.due_date <= ? AND {IN_SRS_SQL}
           ORDER BY {_WEAK_ORDER_SQL} LIMIT ?""",
        (module_id, today_iso, limit),
    ).fetchall()


def due_review_words_excluding_module(conn, module_id: int, today_iso: str, limit: int):
    """Просроченные повторения из ДРУГИХ модулей — чтобы старый материал
    возвращался и после того, как пользователь перешёл к следующему модулю."""
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE (w.module_id IS NULL OR w.module_id != ?) AND p.due_date <= ? AND {IN_SRS_SQL}
           ORDER BY {_WEAK_ORDER_SQL} LIMIT ?""",
        (module_id, today_iso, limit),
    ).fetchall()


def words_learned_today_not_due(conn, today_iso: str, limit: int):
    """Слова, прошедшие SRS сегодня (повтор — в будущем): кандидаты на
    закрепление в следующем уроке того же дня. Слабые первыми."""
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE p.last_reviewed = ? AND p.due_date > ? AND {IN_SRS_SQL}
           ORDER BY {_WEAK_ORDER_SQL} LIMIT ?""",
        (today_iso, today_iso, limit),
    ).fetchall()


def count_new_words_for_module(conn, module_id: int) -> int:
    return conn.execute(
        f"""SELECT COUNT(*) FROM words w JOIN progress p ON p.word_id = w.id
           WHERE w.module_id = ? AND {NEVER_SEEN_SQL}""", (module_id,)
    ).fetchone()[0]


def new_words_for_module(conn, module_id: int, limit: int):
    """Ни разу не проходившиеся слова модуля: частотные первыми."""
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE w.module_id = ? AND {NEVER_SEEN_SQL}
           ORDER BY COALESCE(w.frequency, 999999) ASC, w.id ASC LIMIT ?""",
        (module_id, limit),
    ).fetchall()


def profile_by_level(conn):
    return conn.execute(
        """SELECT w.hsk, COUNT(*) total, SUM(CASE WHEN p.repetitions > 0 THEN 1 ELSE 0 END) learned
           FROM words w JOIN progress p ON p.word_id = w.id GROUP BY w.hsk ORDER BY w.hsk"""
    ).fetchall()


def profile_weak_words(conn, limit: int = 5):
    return conn.execute(
        """SELECT w.hanzi, w.pinyin, w.translation, p.total_attempts, p.total_correct
           FROM words w JOIN progress p ON p.word_id = w.id
           WHERE p.total_attempts >= 2
           ORDER BY (CAST(p.total_correct AS REAL) / p.total_attempts) ASC, p.total_attempts DESC
           LIMIT ?""",
        (limit,),
    ).fetchall()


def profile_accuracy_agg(conn):
    return conn.execute("SELECT SUM(total_attempts) att, SUM(total_correct) cor FROM progress").fetchone()


def profile_mastered_count(conn) -> int:
    return conn.execute("SELECT COUNT(*) FROM progress WHERE interval_days >= 21").fetchone()[0]


def profile_learned_count(conn) -> int:
    return conn.execute("SELECT COUNT(*) FROM progress WHERE repetitions > 0").fetchone()[0]


def word_state_counts(conn) -> dict:
    """
    new/learning/review/mastered через ТУ ЖЕ функцию srs.word_state(), что
    использует весь остальной код (Phase E, п.3) — пороги не продублированы
    в SQL, нет риска разойтись. due — отдельный временной флаг, не состояние:
    слово due одновременно learning/review (никогда не new/mastered — SRS
    не ставит mastered-словам близкий due_date, а new никогда не due).
    """
    from srs import word_state as srs_word_state

    rows = conn.execute("SELECT repetitions, interval_days, due_date FROM progress").fetchall()
    today_iso = utils.today_date().isoformat()
    counts = {"new": 0, "learning": 0, "review": 0, "mastered": 0}
    due_now = 0
    for r in rows:
        state = srs_word_state(r["repetitions"], r["interval_days"])
        counts[state] += 1
        if r["repetitions"] > 0 and r["due_date"] <= today_iso:
            due_now += 1
    return {**counts, "due_now": due_now, "total_encountered": sum(counts.values())}


def week_activity_counts(conn, today, days: int = 7) -> list[dict]:
    period = [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]
    placeholders = ",".join("?" for _ in period)
    rows = conn.execute(
        f"SELECT day, reviews_count FROM activity_log WHERE day IN ({placeholders})", period
    ).fetchall()
    counts_by_day = {r["day"]: r["reviews_count"] for r in rows}
    return [{"day": d, "count": counts_by_day.get(d, 0)} for d in period]


# ---------------------------------------------------------------------------
# Phase H: подбор слов урока по приоритету weak → due → recent → mastered
# ---------------------------------------------------------------------------

def weak_words_not_due(conn, today_iso: str, limit: int):
    """Слабые слова, чей повтор по SRS ещё впереди: в уроке — закрепление (без SRS).
    Слабое — то же определение, что у очереди повторения."""
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE p.due_date > ? AND p.total_attempts >= {WEAK_MIN_ATTEMPTS}
             AND CAST(p.total_correct AS REAL) / p.total_attempts < {WEAK_ACCURACY_THRESHOLD}
           ORDER BY CAST(p.total_correct AS REAL) / p.total_attempts ASC, w.id ASC LIMIT ?""",
        (today_iso, limit),
    ).fetchall()


def retention_candidates(conn, today_iso: str, reviewed_before_iso: str, limit: int = 1):
    """Освоенные слова (интервал ≥ 21 дня), которые давно не встречались, — для
    редкой проверки удержания. Только не просроченные: просроченные и так в повторении.

    «Давно не встречались» — ни повторения по SRS, ни ответа в уроках с reviewed_before.
    Верная проверка удержания SRS не трогает (last_reviewed не меняется), поэтому без
    условия по attempts одно и то же слово проверялось в каждом уроке подряд."""
    return conn.execute(
        f"""SELECT {_WORD_COLS} FROM words w JOIN progress p ON p.word_id = w.id
           WHERE p.repetitions > 2 AND p.interval_days >= 21 AND p.due_date > ?
             AND p.last_reviewed IS NOT NULL AND p.last_reviewed <= ?
             AND NOT EXISTS (SELECT 1 FROM attempts a WHERE a.content_item_id = w.id AND a.created_at > ?)
           ORDER BY p.last_reviewed ASC, w.id ASC LIMIT ?""",
        (today_iso, reviewed_before_iso, reviewed_before_iso, limit),
    ).fetchall()


def seen_word_ids(conn) -> set[int]:
    return {r[0] for r in conn.execute(f"SELECT p.word_id FROM progress p WHERE {IN_SRS_SQL}")}


def set_known_verified(conn, word_id: int, repetitions: int, interval_days: int, ease_factor: float,
                       due_date_iso: str, reviewed_at_iso: str):
    """«Я это уже знаю» + проверка пройдена: слово встаёт в SRS так, будто
    прошло первые повторения (см. learning_service.confirm_known)."""
    conn.execute(
        """UPDATE progress SET repetitions = ?, ease_factor = ?, interval_days = ?, due_date = ?,
           last_reviewed = ?, total_attempts = total_attempts + 1, total_correct = total_correct + 1
           WHERE word_id = ?""",
        (repetitions, ease_factor, interval_days, due_date_iso, reviewed_at_iso, word_id),
    )
