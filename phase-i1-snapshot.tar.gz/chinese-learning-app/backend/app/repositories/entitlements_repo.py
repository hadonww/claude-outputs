def try_grant_limited(conn, user_id: int, entitlement: str, grant_type: str,
                      granted_at: str, limit: int) -> bool:
    """
    Выдаёт право с ограниченным числом мест ОДНИМ оператором INSERT … SELECT:
    номер места (slot) = MAX(slot) + 1 вычисляется и записывается атомарно
    (в SQLite записи сериализуются), а UNIQUE(grant_type, slot) и CHECK
    в схеме не дают появиться лишнему месту даже при гонке. Повторная выдача
    тому же пользователю невозможна (UNIQUE(user_id, grant_type)).
    Возвращает True, если право выдано этим вызовом.
    """
    import sqlite3

    try:
        cur = conn.execute(
            """INSERT INTO entitlements (user_id, entitlement, grant_type, granted_at, slot)
               SELECT ?, ?, ?, ?, taken + 1
               FROM (SELECT COALESCE(MAX(slot), 0) AS taken FROM entitlements WHERE grant_type = ?)
               WHERE taken < ?""",
            (user_id, entitlement, grant_type, granted_at, grant_type, limit),
        )
    except sqlite3.IntegrityError:
        return False  # уже выдано этому пользователю или место заняли параллельно
    return cur.rowcount == 1


def active_for_user(conn, user_id: int, entitlement: str, today_iso: str):
    """Действующие права пользователя (expires_at NULL = навсегда), самое раннее первым."""
    return conn.execute(
        """SELECT * FROM entitlements
           WHERE user_id = ? AND entitlement = ? AND (expires_at IS NULL OR expires_at > ?)
           ORDER BY granted_at, id""",
        (user_id, entitlement, today_iso),
    ).fetchall()


def count_grants(conn, grant_type: str) -> int:
    return conn.execute("SELECT COUNT(*) FROM entitlements WHERE grant_type = ?", (grant_type,)).fetchone()[0]
