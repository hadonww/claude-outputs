from ..curriculum import plan_course_modules


def list_modules(conn):
    return conn.execute("SELECT * FROM modules ORDER BY order_index").fetchall()


def get_module(conn, module_id: int):
    return conn.execute("SELECT * FROM modules WHERE id = ?", (module_id,)).fetchone()


def list_lessons_for_module(conn, module_id: int):
    return conn.execute(
        "SELECT * FROM lessons WHERE module_id = ? ORDER BY order_index", (module_id,)
    ).fetchall()


def get_lesson(conn, lesson_id: int):
    return conn.execute("SELECT * FROM lessons WHERE id = ?", (lesson_id,)).fetchone()


def modules_with_progress(conn):
    """
    Модули с реальным прогрессом по их словам (words.module_id) — источник
    для Learning Path.
      learned_words    — слова с repetitions > 0 (сейчас «выучены» по SRS);
      introduced_words — слова, которые уже проходились хотя бы раз
                         (repetitions > 0 ИЛИ была финальная попытка): забытое
                         слово остаётся пройденным и возвращается через review,
                         а не откатывает модуль назад.
    """
    return conn.execute(
        """
        SELECT
            m.id, m.order_index, m.title, m.hsk_level, m.category,
            COUNT(w.id) AS total_words,
            SUM(CASE WHEN p.repetitions > 0 THEN 1 ELSE 0 END) AS learned_words,
            SUM(CASE WHEN p.repetitions > 0 OR p.total_attempts > 0 THEN 1 ELSE 0 END) AS introduced_words
        FROM modules m
        LEFT JOIN words w ON w.module_id = m.id
        LEFT JOIN progress p ON p.word_id = w.id
        GROUP BY m.id
        ORDER BY m.order_index
        """
    ).fetchall()


def _create_module(conn, category: str, level: int) -> int:
    order_index = conn.execute("SELECT COALESCE(MAX(order_index), 0) + 1 FROM modules").fetchone()[0]
    title = category.capitalize()
    cur = conn.execute(
        "INSERT INTO modules (order_index, title, hsk_level, category) VALUES (?, ?, ?, ?)",
        (order_index, title, level, category),
    )
    module_id = cur.lastrowid
    conn.execute("INSERT INTO lessons (module_id, order_index, title) VALUES (?, 1, ?)", (module_id, title))
    return module_id


def sync_course_modules(conn, reassign: bool = False) -> dict[tuple[str, int], int]:
    """
    Привязывает слова курса (есть category и строка progress) к модулям
    тема × уровень по curriculum.plan_course_modules(). Модуль (category,
    hsk_level) переиспользуется, если уже есть; иначе переиспользуется модуль
    этой темы, у которого нет ни одного слова (так исходные 16 модулей
    становятся модулями своего уровня, их id не меняются), иначе создаётся
    новый (с уроком). modules.order_index не трогается — порядок курса живёт
    в curriculum.route_order.

    reassign=False — привязываются только слова без module_id (вызов на
    каждом старте, идемпотентен); reassign=True — пересчёт для всех слов
    курса (после массового подключения контента). Прогресс хранится по слову,
    поэтому перепривязка его не теряет.
    """
    words = [dict(r) for r in conn.execute(
        """SELECT w.id, w.category, w.hsk, w.module_id FROM words w
           JOIN progress p ON p.word_id = w.id WHERE w.category IS NOT NULL"""
    ).fetchall()]
    if not reassign and all(w["module_id"] is not None for w in words):
        return {}
    plan = plan_course_modules(words)

    modules = [dict(r) for r in conn.execute("SELECT id, category, hsk_level FROM modules ORDER BY id").fetchall()]
    by_key = {(m["category"], m["hsk_level"]): m["id"] for m in modules}
    used = {r[0] for r in conn.execute("SELECT DISTINCT module_id FROM words WHERE module_id IS NOT NULL")}
    planned_ids = {wid for ids in plan.values() for wid in ids}
    if reassign:
        # после пересчёта модуль «занят», только если в нём остаются слова вне плана
        used = {r[0] for r in conn.execute(
            f"""SELECT DISTINCT module_id FROM words WHERE module_id IS NOT NULL
                AND id NOT IN ({",".join("?" for _ in planned_ids) or "NULL"})""", list(planned_ids))}

    result: dict[tuple[str, int], int] = {}
    for (category, level) in sorted(plan, key=lambda k: (k[1], k[0])):
        module_id = by_key.get((category, level))
        if module_id is None:
            spare = next((m for m in modules if m["category"] == category and m["id"] not in used
                          and m["id"] not in result.values()
                          and (m["category"], m["hsk_level"]) not in plan), None)
            if spare is not None:
                conn.execute("UPDATE modules SET hsk_level = ? WHERE id = ?", (level, spare["id"]))
                module_id = spare["id"]
            else:
                module_id = _create_module(conn, category, level)
            by_key[(category, level)] = module_id
        result[(category, level)] = module_id

    for key, ids in plan.items():
        targets = ids if reassign else [w["id"] for w in words if w["id"] in set(ids) and w["module_id"] is None]
        if targets:
            conn.executemany("UPDATE words SET module_id = ? WHERE id = ?", [(result[key], wid) for wid in targets])
    return result
