def get_stats(conn):
    return conn.execute("SELECT * FROM stats WHERE id = 1").fetchone()


def update_streak_and_reviews(conn, streak: int, today_iso: str):
    conn.execute(
        "UPDATE stats SET streak = ?, last_active_date = ?, total_reviews = total_reviews + 1 WHERE id = 1",
        (streak, today_iso),
    )


def activity_days(conn) -> list:
    """Дни с активностью (date) из activity_log — источник серии (app/streak.py)."""
    from datetime import date as date_cls

    return [date_cls.fromisoformat(r["day"]) for r in conn.execute("SELECT day FROM activity_log")]


def longest_streak(conn) -> int:
    """Рекорд серии по истории activity_log (см. app/streak.py)."""
    from ..streak import longest_streak as _longest

    return _longest(activity_days(conn))


def current_streak(conn, today) -> int:
    """Текущая серия на дату today — считается при чтении, ничего не пишет."""
    from ..streak import current_streak as _current

    return _current(activity_days(conn), today)


def increment_activity_log(conn, today_iso: str):
    conn.execute(
        """INSERT INTO activity_log (day, reviews_count) VALUES (?, 1)
           ON CONFLICT(day) DO UPDATE SET reviews_count = reviews_count + 1""",
        (today_iso,),
    )


def update_settings_fields(conn, updates: dict):
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    conn.execute(f"UPDATE stats SET {set_clause} WHERE id = 1", list(updates.values()))
