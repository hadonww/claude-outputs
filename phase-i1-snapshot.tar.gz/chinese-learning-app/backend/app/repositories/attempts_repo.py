from ..config import SKILLS


def insert_attempt(conn, user_id: int, exercise_type: str, skill: str, content_item_id,
                    correct: bool, created_at_iso: str, lesson_id=None, response_ms=None) -> int:
    if skill not in SKILLS:
        raise ValueError(f"Неизвестный навык: {skill!r}. Допустимые: {SKILLS}")
    cur = conn.execute(
        """INSERT INTO attempts (user_id, lesson_id, exercise_type, skill, content_item_id,
           correct, response_ms, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (user_id, lesson_id, exercise_type, skill, content_item_id,
         1 if correct else 0, response_ms, created_at_iso),
    )
    return cur.lastrowid


def list_attempts_for_skill(conn, user_id: int, skill: str, limit: int = 50):
    return conn.execute(
        """SELECT * FROM attempts WHERE user_id = ? AND skill = ?
           ORDER BY created_at DESC, id DESC LIMIT ?""",
        (user_id, skill, limit),
    ).fetchall()


def count_attempts(conn, user_id: int) -> int:
    return conn.execute("SELECT COUNT(*) FROM attempts WHERE user_id = ?", (user_id,)).fetchone()[0]


def stats_by_exercise_type(conn, user_id: int) -> list[dict]:
    rows = conn.execute(
        """SELECT exercise_type, COUNT(*) attempts, SUM(correct) correct
           FROM attempts WHERE user_id = ? GROUP BY exercise_type ORDER BY exercise_type""",
        (user_id,),
    ).fetchall()
    return [
        {"exercise_type": r["exercise_type"], "attempts": r["attempts"],
         "accuracy": round(100 * r["correct"] / r["attempts"], 1) if r["attempts"] else None}
        for r in rows
    ]


def stats_by_skill(conn, user_id: int) -> list[dict]:
    rows = conn.execute(
        """SELECT skill, COUNT(*) attempts, SUM(correct) correct
           FROM attempts WHERE user_id = ? GROUP BY skill ORDER BY skill""",
        (user_id,),
    ).fetchall()
    return [
        {"skill": r["skill"], "attempts": r["attempts"],
         "accuracy": round(100 * r["correct"] / r["attempts"], 1) if r["attempts"] else None}
        for r in rows
    ]


def study_time_stats(conn, user_id: int) -> dict:
    """
    Честно: это время ОТВЕТА (response_ms на каждую попытку), не время
    сессии и не "общее время обучения" — так и называем в API (Phase E, п.6).
    measured_attempts может быть меньше total_attempts: старые/не присланные
    response_ms не притворяются измеренными.
    """
    row = conn.execute(
        """SELECT COUNT(*) total, COUNT(response_ms) measured,
                  SUM(response_ms) total_ms, AVG(response_ms) avg_ms
           FROM attempts WHERE user_id = ?""",
        (user_id,),
    ).fetchone()
    return {
        "total_attempts": row["total"],
        "measured_attempts": row["measured"],
        "total_answer_time_ms": row["total_ms"],
        "average_answer_time_ms": round(row["avg_ms"], 0) if row["avg_ms"] is not None else None,
    }


def recent_accuracy(conn, user_id: int, limit: int = 40, min_count: int = 15) -> float | None:
    """Доля верных среди последних limit оцениваемых ответов; None, если ответов
    меньше min_count (данных мало — норму новых слов не трогаем)."""
    rows = conn.execute(
        "SELECT correct FROM attempts WHERE user_id = ? ORDER BY id DESC LIMIT ?", (user_id, limit)
    ).fetchall()
    if len(rows) < min_count:
        return None
    return sum(r[0] for r in rows) / len(rows)
