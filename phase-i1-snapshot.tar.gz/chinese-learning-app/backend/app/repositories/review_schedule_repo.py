def complete_pending(conn, user_id: int, word_id: int, completed_at: str) -> None:
    """Закрывает самую раннюю ожидающую запись по этому слову (если была) —
    вызывается перед созданием новой при каждом submit_review."""
    conn.execute(
        """UPDATE review_schedule SET completed_at = ?
           WHERE id = (SELECT id FROM review_schedule
                       WHERE user_id = ? AND word_id = ? AND completed_at IS NULL
                       ORDER BY scheduled_for ASC LIMIT 1)""",
        (completed_at, user_id, word_id),
    )


def schedule_next(conn, user_id: int, word_id: int, scheduled_for: str) -> int:
    cur = conn.execute(
        "INSERT INTO review_schedule (user_id, word_id, scheduled_for) VALUES (?, ?, ?)",
        (user_id, word_id, scheduled_for),
    )
    return cur.lastrowid


def consistency(conn, user_id: int, today_iso: str) -> dict:
    """planned = записи, чей срок уже наступил (scheduled_for <= сегодня);
    completed = из них те, что реально закрыты; в процессе — те, что ещё не
    наступили, но уже запланированы (для честности, не смешиваем с planned)."""
    row = conn.execute(
        """SELECT
             SUM(CASE WHEN scheduled_for <= ? THEN 1 ELSE 0 END) AS planned,
             SUM(CASE WHEN scheduled_for <= ? AND completed_at IS NOT NULL THEN 1 ELSE 0 END) AS completed,
             SUM(CASE WHEN scheduled_for > ? THEN 1 ELSE 0 END) AS upcoming
           FROM review_schedule WHERE user_id = ?""",
        (today_iso, today_iso, today_iso, user_id),
    ).fetchone()
    planned = row["planned"] or 0
    completed = row["completed"] or 0
    return {
        "planned": planned,
        "completed": completed,
        "upcoming": row["upcoming"] or 0,
        "completion_rate": round(100 * completed / planned, 1) if planned else None,
    }
