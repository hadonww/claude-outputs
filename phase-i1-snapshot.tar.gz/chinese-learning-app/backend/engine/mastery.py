"""
Mastery по навыкам — чистая функция без БД и сети (ARCHITECTURE_WB_v1.md 3.1).

score 0..100, обновляется экспоненциальным скользящим средним по каждому
ответу: верный тянет к 100, неверный — к 0. k задаёт скорость обучения оценки.
"""

DEFAULT_K = 0.2
MIN_SCORE, MAX_SCORE = 0.0, 100.0


def update_mastery(old_score: float, correct: bool, k: float = DEFAULT_K) -> float:
    target = MAX_SCORE if correct else MIN_SCORE
    new_score = old_score + k * (target - old_score)
    return round(max(MIN_SCORE, min(MAX_SCORE, new_score)), 2)
