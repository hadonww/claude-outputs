"""
Оценка произношения — чистая логика сравнения (без звука, БД и сети).

Распознавание речи делает внешний провайдер (app/services/pronunciation_service):
он получает запись и ожидаемую фразу и возвращает, что прозвучало в каждом
слове — пиньинь с тонами (так устроены, например, Azure Pronunciation
Assessment, iFlytek ISE или собственная модель на CTC-фонемах). Здесь —
единая шкала 0–100 и объяснения, независимые от провайдера:

  слово совпало (слоги и тоны)           -> 100
  слоги верные, ошиблись тоны           -> 60  + заметка «тон»
  слоги частично похожи                  -> 0–50 по доле совпадения букв
  слово не распознано                    -> 0   + заметка «не прозвучало»

Итог — среднее по словам, взвешенное по числу слогов (длинное слово весит
больше). Это честная оценка «насколько услышанное совпало с ожидаемым», а не
воспроизведение аудио.
"""

from dataclasses import asdict, dataclass, field
from difflib import SequenceMatcher

from .answer_check import TONE_NAMES, pinyin_key

PASS_SCORE = 60  # с этого балла фраза засчитывается как произнесённая верно


@dataclass
class WordScore:
    text: str
    expected: str
    heard: str | None
    score: int
    issue: str | None = None   # "tone" | "sound" | "missing" | None


@dataclass
class PronunciationResult:
    overall: int
    per_word: list[WordScore] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    provider: str = ""

    @property
    def passed(self) -> bool:
        return self.overall >= PASS_SCORE

    def to_dict(self) -> dict:
        data = asdict(self)
        data["passed"] = self.passed
        return data


def _syllables(tones: tuple[int, ...], letters: str) -> int:
    return max(1, len(tones) or (1 if letters else 0))


def score_word(text: str, expected_pinyin: str, heard: str | None) -> WordScore:
    if not heard or not heard.strip():
        return WordScore(text, expected_pinyin, heard, 0, "missing")
    exp_letters, exp_tones = pinyin_key(expected_pinyin)
    got_letters, got_tones = pinyin_key(heard)
    if exp_letters == got_letters and exp_tones == got_tones:
        return WordScore(text, expected_pinyin, heard, 100)
    if exp_letters == got_letters:
        return WordScore(text, expected_pinyin, heard, 60, "tone")
    ratio = SequenceMatcher(None, exp_letters, got_letters).ratio()
    return WordScore(text, expected_pinyin, heard, round(50 * ratio), "sound")


def _note(w: WordScore) -> str | None:
    if w.issue == "missing":
        return f"{w.text}: слово не прозвучало или не распознано."
    if w.issue == "tone":
        exp = pinyin_key(w.expected)[1]
        got = pinyin_key(w.heard or "")[1]
        if len(exp) == 1 and len(got) == 1:
            return f"{w.text} ({w.expected}): нужен {TONE_NAMES[exp[0]]} тон, прозвучал {TONE_NAMES.get(got[0], str(got[0]))}."
        return f"{w.text} ({w.expected}): слоги верные, тоны — нет."
    if w.issue == "sound":
        return f"{w.text}: ожидалось {w.expected}, прозвучало ближе к {w.heard}."
    return None


def score_utterance(expected: list[tuple[str, str]], heard: list[str | None], provider: str = "") -> PronunciationResult:
    """
    expected — [(слово, пиньинь)] по порядку фразы, heard — что распознано в
    каждом слове (провайдер выравнивает по ожидаемым словам; None — пропуск).
    """
    heard = list(heard) + [None] * max(0, len(expected) - len(heard))
    words = [score_word(text, py, h) for (text, py), h in zip(expected, heard, strict=False)]
    if not words:
        return PronunciationResult(0, [], ["Нечего оценивать: пустая фраза."], provider)
    weights = [_syllables(*reversed(pinyin_key(w.expected))) for w in words]
    overall = round(sum(w.score * k for w, k in zip(words, weights, strict=True)) / sum(weights))
    notes = [n for n in (_note(w) for w in words) if n]
    if not notes:
        notes = ["Все слова и тоны прозвучали так, как ожидалось."]
    return PronunciationResult(overall, words, notes, provider)
