"""
Ошибка в пиньине (упражнение pinyin_error): найти запись с ошибкой.

  * слово из нескольких слогов — вариант на каждый иероглиф слова с его чтением
    (电 diàn · 子 zǐ · 邮 yóu · 件 qiàn), ровно один записан с ошибкой;
  * слово из одного слога — само слово и два других слова урока, каждое со своим
    пиньинем; ошибка — в одном из них (не обязательно в изучаемом слове).

Все варианты разные, поэтому ошибку не найти сравнением вариантов между собой —
нужно знать чтение. Ошибки — правдоподобные, как у учащихся: тон (чаще всего
путают 2↔3 и 1↔4), z/zh, c/ch, s/sh, j/q/x, придыхание (b/p, d/t, g/k), n/l,
-n/-ng, ü/u после n/l, знак тона у лёгкого слога. Ошибочный слог всегда —
существующий слог путунхуа и не совпадает с другим чтением того же иероглифа
(engine.polyphones): для 好 hǎo «hào» ошибкой не предлагается, это настоящее
чтение. Тон 一 и 不 не трогаем: его пишут и словарным (yī), и изменённым (yí).

Чистый модуль: без FastAPI/SQL; случайность — только через переданный rng.
"""

from dataclasses import dataclass
from functools import lru_cache
from random import Random

from .polyphones import READINGS
from .syllables import SYLLABLES, TONE_VOWELS, Syllable, split_syllables

DISTRACTORS = 2          # для слова из одного слога: само слово + столько других
MAX_DISTRACTOR_SYLLABLES = 2
# самые частые путаницы тонов — первыми (вес выше)
TONE_CONFUSIONS = {1: (4, 2), 2: (3, 1), 3: (2, 4), 4: (1, 3)}
SANDHI_CHARS = {"一", "不"}
INITIAL_SWAPS = {
    "zh": ("z", "ch"), "ch": ("c", "zh", "q"), "sh": ("s", "x"), "z": ("zh", "c"), "c": ("ch", "z"),
    "s": ("sh", "x"), "j": ("q", "zh"), "q": ("j", "ch"), "x": ("sh", "s"),
    "b": ("p",), "p": ("b",), "d": ("t",), "t": ("d",), "g": ("k",), "k": ("g",), "n": ("l",), "l": ("n",),
}
_INITIALS = ("zh", "ch", "sh", *"bpmfdtnlgkhjqxrzcsyw")
WEIGHTS = {"tone": 6, "tone_rare": 3, "neutral": 3, "initial": 2, "final": 2, "umlaut": 2}


@dataclass(frozen=True)
class Mistake:
    index: int            # номер слога
    kind: str             # tone | neutral | initial | final | umlaut
    base: str             # слог с ошибкой без тона
    tone: int | None
    text: str             # слог с ошибкой со знаком тона


def initial_of(base: str) -> str:
    return next((i for i in _INITIALS if base.startswith(i)), "")


def place_tone(base: str, tone: int | None) -> str:
    """Знак тона по правилам пиньиня: на a или e; в ou — на o; иначе на последнюю гласную."""
    if not tone:
        return base
    if "a" in base:
        i = base.index("a")
    elif "e" in base:
        i = base.index("e")
    elif "ou" in base:
        i = base.index("o")
    else:
        i = max(j for j, ch in enumerate(base) if ch in "iouü")
    return base[:i] + TONE_VOWELS[base[i]][tone - 1] + base[i + 1:]


def _is_other_reading(s: Syllable, text: str) -> bool:
    return bool(s.hanzi) and len(s.hanzi) == 1 and text in READINGS.get(s.hanzi, ())


def mistakes(syllables: list[Syllable]) -> list[tuple[int, Mistake]]:
    """Все допустимые ошибки слова с весами."""
    found: list[tuple[int, Mistake]] = []

    def add(weight: int, i: int, kind: str, base: str, tone: int | None, text: str) -> None:
        s = syllables[i]
        if text != s.text and not _is_other_reading(s, text):
            found.append((weight, Mistake(i, kind, base, tone, text)))

    for i, s in enumerate(syllables):
        if s.tone and s.hanzi not in SANDHI_CHARS:
            for rank, t in enumerate(TONE_CONFUSIONS[s.tone]):
                add(WEIGHTS["tone" if rank == 0 else "tone_rare"], i, "tone", s.base, t, s.with_tone(t))
        if not s.tone and i > 0 and not s.erhua:
            t = syllables[i - 1].tone or 4      # «xièxiè»: лёгкий слог с тоном предыдущего
            add(WEIGHTS["neutral"], i, "neutral", s.base, t, place_tone(s.base, t))
        if s.erhua or s.base not in SYLLABLES:
            continue
        ini = initial_of(s.base)
        letter_variants = [("initial", new + s.base[len(ini):]) for new in INITIAL_SWAPS.get(ini, ())]
        if s.base.endswith("ng"):
            letter_variants.append(("final", s.base[:-1]))
        elif s.base.endswith("n"):
            letter_variants.append(("final", s.base + "g"))
        if ini in ("n", "l"):
            swapped = s.base.replace("ü", "u") if "ü" in s.base else s.base.replace("u", "ü", 1)
            letter_variants.append(("umlaut", swapped))
        for kind, base in letter_variants:
            if base in SYLLABLES and base != s.base:
                add(WEIGHTS[kind], i, kind, base, s.tone, place_tone(base, s.tone))
    return found


@lru_cache(maxsize=4096)
def _syllables(pinyin: str, hanzi: str) -> tuple[Syllable, ...] | None:
    syllables = split_syllables(pinyin, hanzi)
    if not syllables or not all(x.hanzi for x in syllables) or not any(x.tone for x in syllables):
        return None   # без привязки к иероглифам вариант «иероглиф + слог» не построить
    return tuple(syllables)


def word_syllables(item: dict) -> tuple[Syllable, ...] | None:
    return _syllables(item.get("pinyin") or "", item.get("hanzi") or "")


def word_text(syllables, mistake: Mistake | None = None) -> str:
    """Пиньинь слова слитно, со знаками тонов (апостроф перед слогом на a/o/e)."""
    parts = [x.text for x in syllables]
    if mistake is not None:
        parts[mistake.index] = mistake.text
    out = parts[0]
    for part, x in zip(parts[1:], syllables[1:]):
        out += ("'" if x.base[0] in "aoe" else "") + part
    return out


def eligible_distractor(word: dict) -> bool:
    syllables = word_syllables(word)
    return bool(syllables) and len(syllables) <= MAX_DISTRACTOR_SYLLABLES


def _syllable_options(syllables) -> list[str]:
    return [f"{x.hanzi} {x.text}" for x in syllables]


def _multi_mistakes(syllables) -> list[tuple[int, Mistake]]:
    right = _syllable_options(syllables)
    if len(set(right)) < len(right):
        return []   # 常常 cháng · 常 cháng: два одинаковых варианта — не задание
    # ошибка не должна совпасть с другим вариантом (谢 xiè · 谢 xie -> «谢 xiè» дважды)
    return [(w, m) for w, m in mistakes(list(syllables)) if f"{syllables[m.index].hanzi} {m.text}" not in right]


def applicable(item: dict, distractors_available: int = 0) -> bool:
    syllables = word_syllables(item)
    if not syllables:
        return False
    if len(syllables) > 1:
        return bool(_multi_mistakes(syllables))
    return bool(mistakes(list(syllables))) and distractors_available >= DISTRACTORS


def _mistake_info(syllables, mistake: Mistake, option: str) -> dict:
    x = syllables[mistake.index]
    return {"kind": mistake.kind, "option": option, "hanzi": x.hanzi, "right": x.text, "wrong": mistake.text,
            "right_tone": x.tone, "wrong_tone": mistake.tone}


def _pick(found: list[tuple[int, Mistake]], rng: Random) -> Mistake:
    return rng.choices([m for _, m in found], weights=[w for w, _ in found])[0]


def build(item: dict, distractors: list[dict], rng: Random) -> dict:
    """
    options, answer_index (номер записи с ошибкой) и mistake (что за ошибка) —
    два последних клиенту не отдаются. distractors нужны только слову из одного
    слога (уже подходящие: eligible_distractor).
    """
    syllables = word_syllables(item)
    if len(syllables) > 1:
        mistake = _pick(_multi_mistakes(syllables), rng)
        options = _syllable_options(syllables)
        options[mistake.index] = f"{syllables[mistake.index].hanzi} {mistake.text}"
        return {"options": options, "answer_index": mistake.index,
                "mistake": _mistake_info(syllables, mistake, options[mistake.index])}

    words = [item, *distractors[:DISTRACTORS]]
    carriers = [w for w in words if mistakes(list(word_syllables(w)))]
    carrier = rng.choice(carriers)
    carrier_syllables = word_syllables(carrier)
    mistake = _pick(mistakes(list(carrier_syllables)), rng)
    options = [f"{w['hanzi']} {word_text(word_syllables(w), mistake if w is carrier else None)}" for w in words]
    wrong = options[words.index(carrier)]
    rng.shuffle(options)
    return {"options": options, "answer_index": options.index(wrong),
            "mistake": _mistake_info(carrier_syllables, mistake, wrong)}
