"""
Реестр типов упражнений (ARCHITECTURE_WB_v1.md, п.4).

Новый тип = новая запись в REGISTRY, без изменений в lesson_planner:
планировщик знает только про ExerciseType.skill / .requires / .build.

Чистый модуль: без FastAPI/SQL. Случайность — только через переданный rng
(random.Random с фиксированным seed), поэтому план воспроизводим в тестах.
"""

from collections.abc import Callable
from dataclasses import dataclass
from random import Random

# Таблицы знаков тонов живут в engine.syllables; здесь — реэкспорт (их импортирует answer_check)
from . import pinyin_errors
from .syllables import CHAR_TO_TONE, TONE_VOWELS, split_syllables


def tone_variants(pinyin: str):
    """4 варианта слога с разными тонами по первой toned-гласной; None,
    если в пиньине нет гласной с диакритикой (нейтральный тон)."""
    for i, ch in enumerate(pinyin):
        base = CHAR_TO_TONE.get(ch)
        if base:
            return [pinyin[:i] + t + pinyin[i + 1:] for t in TONE_VOWELS[base]]
    return None


SENTENCE_PUNCT = set("。？！，、；：（）() ")
MAX_TOKEN_LEN = 4


def tokenize(sentence: str, vocab: set[str]) -> list[str]:
    """Жадное разбиение предложения на слова базы (самое длинное совпадение),
    иначе — на отдельные иероглифы. Знаки препинания отбрасываются."""
    text = "".join(c for c in sentence if c not in SENTENCE_PUNCT)
    tokens, i = [], 0
    while i < len(text):
        for n in range(min(MAX_TOKEN_LEN, len(text) - i), 0, -1):
            if n == 1 or text[i:i + n] in vocab:
                tokens.append(text[i:i + n])
                i += n
                break
    return tokens


def _choices(correct: str, distractors: list[str], rng: Random) -> tuple[list[str], int]:
    options = [correct] + distractors
    rng.shuffle(options)
    return options, options.index(correct)


def _norm_pinyin(pinyin: str | None) -> str:
    """Сравнимая форма пиньиня: без регистра, пробелов и апострофов."""
    return "".join(ch for ch in (pinyin or "").lower() if ch not in " '’-")


def _meaning_parts(translation: str | None) -> set[str]:
    """Значения перевода без уточнений в скобках: 'дом, семья' -> {'дом', 'семья'}."""
    text, depth, clean = translation or "", 0, []
    for ch in text:
        if ch in "(（":
            depth += 1
        elif ch in ")）":
            depth = max(0, depth - 1)
        elif depth == 0:
            clean.append(ch)
    parts = "".join(clean).replace(";", ",").split(",")
    return {p.strip().lower() for p in parts if p.strip()}


def _conflicts(item: dict, other: dict, field: str) -> bool:
    """
    Дистрактор, который на самом деле тоже верный ответ, делает упражнение
    нечестным: синоним в recognition (家 «дом, семья» и 房子 «дом (здание)»),
    омофон в listening (他/她 — оба tā, по звуку не различить), тот же пиньинь
    в другой записи (shíhou / shí hou).
    """
    if field == "translation":
        return bool(_meaning_parts(item.get("translation")) & _meaning_parts(other.get("translation")))
    if field in ("hanzi", "pinyin"):
        return _norm_pinyin(item.get("pinyin")) == _norm_pinyin(other.get("pinyin"))
    return False


def _distractor_words(item: dict, pool: list[dict], field: str, rng: Random, n: int = 3,
                      conflict_field: str | None = None) -> list[dict]:
    """Слова-дистракторы: сначала той же категории (тематически близкие), затем
    остальные; внутри группы — случайно, но от заданного rng. Слово, которое
    тоже было бы верным ответом (_conflicts по conflict_field, по умолчанию —
    по самому полю), не берётся."""
    conflict_field = conflict_field or field
    seen, same, other = {item[field]}, [], []
    for w in pool:
        if w[field] in seen or w.get("id") == item.get("id") or _conflicts(item, w, conflict_field):
            continue
        seen.add(w[field])
        (same if w.get("category") == item.get("category") else other).append(w)
    rng.shuffle(same)
    rng.shuffle(other)
    return (same + other)[:n]


def _toneless(pinyin: str | None) -> str:
    """Пиньинь без тонов и пробелов: 'nǐ hǎo' -> 'nihao'."""
    return "".join(CHAR_TO_TONE.get(ch, ch) for ch in _norm_pinyin(pinyin) if not ch.isdigit())


def _sound_similarity(a: dict, b: dict) -> int:
    """
    Насколько похоже звучат слова (для аудирования «на различение»): одинаковые
    слоги с другим тоном (mā/mà) -> 3, общая начальная согласная и близкая
    длина -> 2, та же тема -> 1, иначе 0. Омофоны (тот же пиньинь с тонами)
    отсекаются раньше — по звуку их не различить.
    """
    pa, pb = _toneless(a.get("pinyin")), _toneless(b.get("pinyin"))
    if pa and pa == pb:
        return 3
    if pa and pb and pa[0] == pb[0] and abs(len(pa) - len(pb)) <= 1:
        return 2
    return 1 if a.get("category") == b.get("category") else 0


def _sound_distractors(item: dict, pool: list[dict], rng: Random, n: int = 3) -> list[dict]:
    """Дистракторы для аудирования: сначала похожие по звучанию (иначе задание
    решается по одному слогу), внутри группы — случайно от rng."""
    seen, buckets = {item["hanzi"]}, {}
    for w in pool:
        if w["hanzi"] in seen or w.get("id") == item.get("id") or _conflicts(item, w, "hanzi"):
            continue
        seen.add(w["hanzi"])
        buckets.setdefault(_sound_similarity(item, w), []).append(w)
    result = []
    for score in sorted(buckets, reverse=True):
        group = buckets[score]
        rng.shuffle(group)
        result.extend(group)
    return result[:n]


def _distractors(item: dict, pool: list[dict], field: str, rng: Random, n: int = 3) -> list[str]:
    """Неправильные варианты (значения поля field) — см. _distractor_words."""
    return [w[field] for w in _distractor_words(item, pool, field, rng, n)]


def _choice_payload(item: dict, words: list[dict], field: str, rng: Random) -> dict:
    """Варианты (значение field у item и дистракторов) + метаданные каждого
    варианта (иероглиф, пиньинь, перевод) в том же порядке — по ним сервер
    объясняет ошибку («вы выбрали 他 — tā, он»)."""
    entries = [item] + words
    order = list(range(len(entries)))
    rng.shuffle(order)
    ordered = [entries[i] for i in order]
    return {
        "options": [w[field] for w in ordered],
        "answer_index": order.index(0),
        "option_hanzi": [w.get("hanzi") for w in ordered],
        "option_pinyin": [w.get("pinyin") for w in ordered],
        "option_translation": [w.get("translation") for w in ordered],
    }


@dataclass(frozen=True)
class ExerciseType:
    name: str
    skill: str | None                                          # какой навык тренирует (None — не оценивается)
    requires: Callable[[dict, list[dict], dict | None], bool]        # применим ли к слову (pool, ctx с known_word_ids)
    build: Callable[[dict, list[dict], Random, dict | None], dict]  # payload для клиента (тот же ctx)


def _req_always(item, pool, ctx=None):
    return True


def _req_pool(min_distractors):
    def check(item, pool, ctx=None):
        return len({w["hanzi"] for w in pool if w["hanzi"] != item["hanzi"]}) >= min_distractors
    return check


def _build_introduction(item, pool, rng, ctx=None):
    """
    Карточка нового слова. Пример показывается, только если в нём нет
    незнакомых слов, кроме самого целевого (то же правило, что у
    fill_blank/sentence_order): раньше сюда шёл words.example_cn без
    проверки, и первое же знакомство со словом показывало предложение из
    будущих модулей. Без ctx (прямые вызовы) — прежнее поведение.
    """
    payload = {k: item.get(k) for k in ("hanzi", "pinyin", "translation", "components")}
    if item.get("note"):
        payload["note"] = item["note"]  # авторская подсказка сценария урока: как запомнить, как употреблять
    if ctx is None:
        payload["example_cn"], payload["example_ru"] = item.get("example_cn"), item.get("example_ru")
        return payload
    usable = _usable_examples(item, ctx) if item.get("examples") else []
    ex = usable[0] if usable else None
    payload["example_cn"] = ex["sentence_cn"] if ex else None
    payload["example_ru"] = ex["sentence_ru"] if ex else None
    payload["example_pinyin"] = ex.get("pinyin") if ex else None
    if ex:
        payload["used_word_ids"] = list(ex["used_word_ids"])
    return payload


def _build_recognition(item, pool, rng, ctx=None):
    choice = _choice_payload(item, _distractor_words(item, pool, "translation", rng), "translation", rng)
    return {"prompt": item["hanzi"], "question": "Что это значит?", **choice}


def _build_listening(item, pool, rng, ctx=None):
    choice = _choice_payload(item, _sound_distractors(item, pool, rng), "hanzi", rng)
    return {"prompt_audio": item["hanzi"], "question": "Прослушайте и выберите иероглиф", **choice}


def _build_pinyin_choice(item, pool, rng, ctx=None):
    """
    Чтение по иероглифу. Один неверный вариант — то же слово с другим тоном
    (если тон есть): так тренируется и чтение, и тон, а не только «узнать
    знакомые буквы». Остальные — пиньинь других слов урока/темы.
    """
    words = _distractor_words(item, pool, "pinyin", rng)
    variants = [v for v in (tone_variants(item["pinyin"]) or []) if v != item["pinyin"]]
    if variants and len(words) >= 3:
        words = [{"hanzi": None, "pinyin": rng.choice(variants), "translation": None}] + words[:2]
    choice = _choice_payload(item, words, "pinyin", rng)
    # имена собственные пишутся с заглавной (Běijīng): варианты — строчными, иначе
    # верный ответ узнаётся по заглавной букве, а не по чтению
    choice["options"] = [o.lower() for o in choice["options"]]
    return {"prompt": item["hanzi"], "question": "Выберите верный пиньинь", **choice}


def _build_pinyin_to_hanzi(item, pool, rng, ctx=None):
    """Пиньинь -> иероглиф: связь звучания и формы без опоры на значение;
    варианты — слова с похожим звучанием."""
    choice = _choice_payload(item, _sound_distractors(item, pool, rng), "hanzi", rng)
    return {"prompt_pinyin": item["pinyin"], "question": "Какой иероглиф так читается?", **choice}


def _req_word_choice(item, pool, ctx=None):
    return len(_distractor_words(item, pool, "hanzi", Random(0), 3, conflict_field="translation")) >= 3


def _build_word_choice(item, pool, rng, ctx=None):
    """Значение → иероглиф (RU → CN): обратное направление к recognition,
    воспроизведение формы слова по смыслу. Дистрактор с пересекающимся
    значением (синоним) не берётся — иначе верных ответов два."""
    words = _distractor_words(item, pool, "hanzi", rng, 3, conflict_field="translation")
    choice = _choice_payload(item, words, "hanzi", rng)
    return {"prompt": item["translation"], "question": "Как это по-китайски?", **choice}


def _build_pinyin_input(item, pool, rng, ctx=None):
    """Письменное воспроизведение чтения: пользователь набирает пиньинь
    (тон — цифрой или знаком). Проверяет сервер (engine.answer_check)."""
    return {"prompt": item["hanzi"], "translation": item["translation"],
            "question": "Напишите пиньинь", "hint": "Тон — цифрой (ni3) или знаком (nǐ)",
            "answer": item["pinyin"]}


def _req_tone(item, pool, ctx=None):
    syllables = split_syllables(item.get("pinyin") or "", item.get("hanzi"))
    return bool(syllables) and any(s.tone for s in syllables)


def _build_tone_choice(item, pool, rng, ctx=None):
    """
    Тон каждого слога слова, а не только первого. Для каждого слога со знаком
    тона клиент получает четыре формы этого слога (тоны 1–4, по порядку) и
    выбирает одну; слог без знака (лёгкий тон) показывается, но не проверяется.
    answers — верный тон каждого слога (None — лёгкий): поле ответа, клиенту не
    отдаётся (lesson_service.ANSWER_FIELDS), проверяет answer_check.
    """
    syllables = split_syllables(item["pinyin"], item.get("hanzi"))
    tested = sum(1 for s in syllables if s.tone)
    # слово звучит сразу: тон выбирают на слух, а не угадывают по памяти
    return {
        "prompt": item["hanzi"], "audio": item["hanzi"],
        "question": "Послушайте: какой тон?" if tested == 1 else "Послушайте: какие тоны?",
        "syllables": [{"hanzi": s.hanzi, "base": s.base, "tested": bool(s.tone),
                       "options": [s.with_tone(t) for t in (1, 2, 3, 4)] if s.tone else None}
                      for s in syllables],
        "answers": [s.tone for s in syllables],
    }


def _pinyin_error_distractors(item, pool, limit=None, ctx=None) -> list[dict]:
    """Другие слова для варианта «слово + пиньинь» (слово из одного слога): без
    того же иероглифа, с пиньинем, который разбирается на слоги. Ошибка может
    оказаться в любом из них, поэтому в уроке (есть known_word_ids) — только уже
    знакомые слова: задание не должно требовать знания неизученного слова."""
    known = (ctx or {}).get("known_word_ids")
    seen, result = {item["hanzi"]}, []
    for w in pool:
        if w["hanzi"] in seen or w.get("id") == item.get("id") or not pinyin_errors.eligible_distractor(w):
            continue
        if known is not None and w.get("id") not in known:
            continue
        seen.add(w["hanzi"])
        result.append(w)
        if limit is not None and len(result) >= limit:
            break
    return result


def _req_pinyin_error(item, pool, ctx=None):
    syllables = pinyin_errors.word_syllables(item)
    if syllables and len(syllables) > 1:
        return pinyin_errors.applicable(item)
    return pinyin_errors.applicable(item, len(_pinyin_error_distractors(item, pool, pinyin_errors.DISTRACTORS, ctx)))


def _build_pinyin_error(item, pool, rng, ctx=None):
    """
    Найти запись пиньиня с ошибкой (engine.pinyin_errors). Слово из нескольких
    слогов — вариант на каждый иероглиф, слово крупно и его значение; слово из
    одного слога — оно и два других слова (знакомые — в первую очередь), без
    крупного слова: ошибка может быть в любом из них. answer_index и answer (что
    за ошибка) клиенту не отдаются (lesson_service.ANSWER_FIELDS).
    """
    syllables = pinyin_errors.word_syllables(item)
    distractors = []
    if len(syllables) == 1:
        # сначала знакомые ученику слова, затем той же темы, внутри — случайно от rng
        known = set((ctx or {}).get("known_word_ids") or ())
        candidates = _pinyin_error_distractors(item, pool, ctx=ctx)
        rng.shuffle(candidates)
        candidates.sort(key=lambda w: (w.get("id") not in known, w.get("category") != item.get("category")))
        distractors = candidates[:pinyin_errors.DISTRACTORS]
    built = pinyin_errors.build(item, distractors, rng)
    multi = len(syllables) > 1
    return {"prompt": item["hanzi"] if multi else None, "hint": item.get("translation") if multi else None,
            "question": "Где ошибка в пиньине?", "options": built["options"],
            "answer_index": built["answer_index"], "answer": built["mistake"],
            "used_word_ids": sorted({item["id"], *(w["id"] for w in distractors)})}


MATCHING_PAIRS = 4        # слово урока + до трёх знакомых слов
MATCHING_MIN_OTHERS = 2   # меньше трёх пар — не сопоставление


def _matching_words(item, pool, ctx=None, rng: Random | None = None, limit: int | None = None) -> list[dict]:
    """
    Слова в пару к изучаемому — только уже знакомые ученику (known_word_ids):
    без того же иероглифа и без пересечения значений ни с одним уже выбранным
    словом (家 «дом, семья» и 房子 «дом (здание)» вместе не берутся) — у каждого
    иероглифа ровно один верный перевод. С rng — сначала слова той же темы, внутри
    случайно; без rng (проверка применимости) — в порядке pool.
    """
    known = (ctx or {}).get("known_word_ids")
    if known is None:
        return []
    candidates = [w for w in pool if w.get("id") in known and w.get("id") != item.get("id")
                  and w.get("translation") and "\n" not in w["translation"]]
    if rng is not None:
        rng.shuffle(candidates)
        candidates.sort(key=lambda w: w.get("category") != item.get("category"))
    chosen = [(item["hanzi"], item["translation"], _meaning_parts(item["translation"]))]
    result = []
    for w in candidates:
        parts = _meaning_parts(w["translation"])
        if any(w["hanzi"] == h or w["translation"] == t or parts & ps for h, t, ps in chosen):
            continue
        chosen.append((w["hanzi"], w["translation"], parts))
        result.append(w)
        if limit is not None and len(result) >= limit:
            break
    return result


def _req_matching(item, pool, ctx=None):
    return bool(item.get("translation")) and "\n" not in item["translation"] \
        and len(_matching_words(item, pool, ctx, limit=MATCHING_MIN_OTHERS)) >= MATCHING_MIN_OTHERS


def _derangement(n: int, rng: Random) -> list[int]:
    """Перестановка без неподвижных точек: ни один перевод не стоит напротив своего слова."""
    order = list(range(n))
    while any(i == v for i, v in enumerate(order)):
        rng.shuffle(order)
    return order


def _build_matching(item, pool, rng, ctx=None):
    """
    Сопоставить иероглифы с переводами: слово урока и до трёх знакомых слов.
    Слева — иероглифы (в случайном порядке), справа — переводы, переставленные
    так, что ни один не стоит напротив своего слова. answers[i] — номер верного
    перевода для i-го иероглифа: клиенту не отдаётся (lesson_service.ANSWER_FIELDS),
    проверяет answer_check.
    """
    words = [item, *_matching_words(item, pool, ctx, rng, limit=MATCHING_PAIRS - 1)]
    rng.shuffle(words)
    order = _derangement(len(words), rng)            # right[j] = перевод слова order[j]
    right = [words[k]["translation"] for k in order]
    return {"question": "Соедините слова с переводами",
            "left": [w["hanzi"] for w in words], "right": right,
            "answers": [order.index(i) for i in range(len(words))],
            "used_word_ids": sorted(w["id"] for w in words)}


def _vocab(pool):
    return {w["hanzi"] for w in pool}


def _usable_examples(item: dict, ctx: dict | None) -> list[dict]:
    """
    Примеры этого слова, где все слова предложения, кроме самого целевого,
    уже известны пользователю (known_word_ids из lesson_planner.known_vocabulary)
    — единственный источник истины теперь used_word_ids, явно сохранённый в
    БД (Phase C), а не токенизация свободного текста на лету.
    """
    examples = item.get("examples") or []
    known = (ctx or {}).get("known_word_ids")
    if known is None:  # ctx не передан (прямые вызовы в тестах) — не блокируем
        return examples
    target_id = item.get("id")
    return [ex for ex in examples
            if all(wid == target_id or wid in known for wid in ex["used_word_ids"])]


def _other_tokens_known(item, pool, ctx) -> bool:
    """Совместимость для мест, которые ещё используют старую сигнатуру
    (fallback на токенизацию, только если у слова вообще нет examples —
    например, старые прямые тесты без БД)."""
    known = (ctx or {}).get("known_hanzi")
    if known is None:
        return True
    tokens = tokenize(item.get("example_cn") or "", _vocab(pool))
    others = [t for t in tokens if t != item["hanzi"]]
    return all(t in known for t in others)


def _req_fill_blank(item, pool, ctx=None):
    return bool(_usable_examples(item, ctx)) and _req_pool(3)(item, pool, ctx)


def _build_fill_blank(item, pool, rng, ctx=None):
    ex = rng.choice(_usable_examples(item, ctx) or item.get("examples") or [{
        "sentence_cn": item.get("example_cn") or item["hanzi"], "sentence_ru": item.get("example_ru"),
    }])
    sentence = _blank_target(ex, item, pool)
    choice = _choice_payload(item, _distractor_words(item, pool, "hanzi", rng), "hanzi", rng)
    payload = {"prompt": sentence, "question": "Вставьте пропущенное слово", "hint": ex.get("sentence_ru"),
               **choice}
    if ex.get("used_word_ids"):
        payload["used_word_ids"] = list(ex["used_word_ids"])
    return payload


def _blank_target(ex: dict, item: dict, pool: list[dict]) -> str:
    """
    Пропуск ставится на позицию целевого слова по used_word_ids, а не на
    первое вхождение подстроки: в «我们的人» цель 人 не должна вырезаться из
    другого слова раньше по тексту. Если разбор не сходится с текстом —
    прежнее поведение (первое вхождение).
    """
    text = ex["sentence_cn"]
    ids = ex.get("used_word_ids") or []
    id_to_hanzi = {w["id"]: w["hanzi"] for w in pool}
    id_to_hanzi[item["id"]] = item["hanzi"]
    cursor = 0
    for wid in ids:
        token = id_to_hanzi.get(wid)
        if not token:
            break
        pos = text.find(token, cursor)
        if pos < 0 or any(ch not in SENTENCE_PUNCT for ch in text[cursor:pos]):
            break
        if wid == item["id"]:
            return text[:pos] + "＿＿" + text[pos + len(token):]
        cursor = pos + len(token)
    return text.replace(item["hanzi"], "＿＿", 1)


def _req_sentence_order(item, pool, ctx=None):
    usable = [ex for ex in _usable_examples(item, ctx) if 3 <= len(ex["used_word_ids"]) <= 9]
    return bool(usable)


def _build_sentence_order(item, pool, rng, ctx=None):
    usable = [ex for ex in _usable_examples(item, ctx) if 3 <= len(ex["used_word_ids"]) <= 9]
    ex = rng.choice(usable or _usable_examples(item, ctx) or item.get("examples") or [{}])
    id_to_hanzi = {w["id"]: w["hanzi"] for w in pool}
    answer = [id_to_hanzi.get(wid, "?") for wid in ex.get("used_word_ids", [])]
    tokens = answer[:]
    for _ in range(10):  # перемешиваем так, чтобы порядок не совпал с верным
        rng.shuffle(tokens)
        if tokens != answer:
            break
    return {"question": "Переведите на китайский: соберите фразу", "hint": ex.get("sentence_ru"),
            "tokens": tokens, "answer_tokens": answer, "pinyin": ex.get("pinyin"),
            "used_word_ids": list(ex.get("used_word_ids", []))}


def _sentence_bank(item: dict, ctx: dict | None) -> list[str]:
    """Русские переводы ДРУГИХ предложений — дистракторы для понимания фразы
    (ctx['sentence_bank'] собирает планировщик из примеров слов урока)."""
    own = {ex["sentence_ru"] for ex in item.get("examples") or []}
    seen, result = set(), []
    for ru in (ctx or {}).get("sentence_bank") or []:
        if ru and ru not in own and ru not in seen:
            seen.add(ru)
            result.append(ru)
    return result


def _req_sentence_meaning(item, pool, ctx=None):
    return bool(_usable_examples(item, ctx)) and len(_sentence_bank(item, ctx)) >= 2 \
        and (ctx or {}).get("known_word_ids") is not None


def _sentence_choice(item, pool, rng, ctx):
    ex = rng.choice(_usable_examples(item, ctx))
    bank = _sentence_bank(item, ctx)
    rng.shuffle(bank)
    options, idx = _choices(ex["sentence_ru"], bank[:2], rng)
    return ex, {"options": options, "answer_index": idx, "used_word_ids": list(ex["used_word_ids"]),
                "pinyin": ex.get("pinyin")}


def _build_sentence_meaning(item, pool, rng, ctx=None):
    """Понимание фразы (CN → RU): предложение со знакомыми словами, выбрать
    верный перевод из трёх. Перевод — естественный русский, а не дословный."""
    ex, choice = _sentence_choice(item, pool, rng, ctx)
    return {"prompt": ex["sentence_cn"], "question": "Что означает фраза?", **choice}


def _build_sentence_listening(item, pool, rng, ctx=None):
    """Аудирование фразы: звучит предложение (без текста), выбрать перевод."""
    ex, choice = _sentence_choice(item, pool, rng, ctx)
    return {"prompt_audio": ex["sentence_cn"], "transcript": ex["sentence_cn"],
            "question": "Прослушайте фразу и выберите перевод", **choice}


def _known_all(ids, item, ctx) -> bool:
    known = (ctx or {}).get("known_word_ids")
    return known is not None and all(w == item.get("id") or w in known for w in ids)


def _usable_dialogues(item: dict, ctx: dict | None) -> list[dict]:
    return [d for d in item.get("dialogues") or [] if _known_all(d["used_word_ids"], item, ctx)]


def _dialogue_bank(item: dict, ctx: dict | None, own: dict) -> list[dict]:
    """Ответы из ДРУГИХ диалогов, где все слова знакомы, — дистракторы."""
    seen, result = {own["b_cn"]}, []
    for d in (ctx or {}).get("dialogue_bank") or []:
        if d["b_cn"] in seen or not _known_all(d["used_word_ids"], item, ctx):
            continue
        seen.add(d["b_cn"])
        result.append(d)
    return result


def _req_dialogue(item, pool, ctx=None):
    return any(len(_dialogue_bank(item, ctx, d)) >= 2 for d in _usable_dialogues(item, ctx))


def _build_dialogue(item, pool, rng, ctx=None):
    """Мини-диалог: реплика собеседника (A) и выбор подходящего ответа (B) из трёх;
    дистракторы — ответы из других бытовых диалогов на знакомых словах."""
    candidates = [d for d in _usable_dialogues(item, ctx) if len(_dialogue_bank(item, ctx, d)) >= 2]
    own = rng.choice(candidates)
    others = _dialogue_bank(item, ctx, own)
    rng.shuffle(others)
    entries = [own] + others[:2]
    order = list(range(len(entries)))
    rng.shuffle(order)
    ordered = [entries[i] for i in order]
    return {"prompt": own["a_cn"], "prompt_pinyin": own.get("a_pinyin"), "prompt_ru": own["a_ru"],
            "question": "Выберите подходящий ответ", "options": [d["b_cn"] for d in ordered],
            "answer_index": order.index(0), "option_translation": [d["b_ru"] for d in ordered],
            "option_pinyin": [d.get("b_pinyin") for d in ordered],
            "used_word_ids": list(own["used_word_ids"])}


def _build_recall(item, pool, rng, ctx=None):
    """
    Вспомнить слово самому. Подсказки убираются по мере изучения: слово «в
    изучении» показывается с пиньинем (вспомнить значение), на повторении и
    освоенное — только иероглиф (вспомнить и чтение, и значение).
    """
    hint = item["pinyin"] if item.get("state") == "learning" else None
    return {"hanzi": item["hanzi"], "pinyin": item["pinyin"], "translation": item["translation"],
            "hint_pinyin": hint, "hint_level": 1 if hint else 2}


def _build_handwriting(item, pool, rng, ctx=None):
    return {"hanzi": item["hanzi"], "char": item["hanzi"][0], "pinyin": item["pinyin"],
            "translation": item["translation"]}


def _req_never(item, pool, ctx=None):
    """Тип строится только сценарием урока (engine/lesson_script), не по слову."""
    return False


def _build_scripted(item, pool, rng, ctx=None):
    raise ValueError("шаг сценария строит engine.lesson_script.build_steps")


REGISTRY: dict[str, ExerciseType] = {t.name: t for t in [
    ExerciseType("introduction", None, _req_always, _build_introduction),
    ExerciseType("recognition", "characters", _req_pool(3), _build_recognition),
    ExerciseType("listening", "listening", _req_pool(3), _build_listening),
    ExerciseType("pinyin_choice", "pinyin", _req_pool(3), _build_pinyin_choice),
    ExerciseType("tone_choice", "tones", _req_tone, _build_tone_choice),
    ExerciseType("fill_blank", "grammar", _req_fill_blank, _build_fill_blank),
    ExerciseType("sentence_order", "grammar", _req_sentence_order, _build_sentence_order),
    ExerciseType("recall", "vocabulary", _req_always, _build_recall),
    ExerciseType("handwriting", "writing", _req_always, _build_handwriting),
    # 2026-10: обратное направление, понимание и аудирование фраз, ввод пиньиня
    ExerciseType("word_choice", "vocabulary", _req_word_choice, _build_word_choice),
    ExerciseType("sentence_meaning", "grammar", _req_sentence_meaning, _build_sentence_meaning),
    ExerciseType("sentence_listening", "listening", _req_sentence_meaning, _build_sentence_listening),
    ExerciseType("pinyin_input", "pinyin", _req_always, _build_pinyin_input),
    ExerciseType("dialogue_reply", "grammar", _req_dialogue, _build_dialogue),
    # Phase H: звучание -> форма, и шаги сценария урока (фразы, перевод, диалог, речь)
    ExerciseType("pinyin_to_hanzi", "pinyin", _req_pool(3), _build_pinyin_to_hanzi),
    ExerciseType("translate_cn_ru", "grammar", _req_never, _build_scripted),
    ExerciseType("translation_build", "grammar", _req_never, _build_scripted),
    ExerciseType("dialogue_scene", "grammar", _req_never, _build_scripted),
    ExerciseType("speaking", "speaking", _req_never, _build_scripted),
    # Phase I: найти ошибку в записи пиньиня; сопоставить слова и переводы
    ExerciseType("pinyin_error", "pinyin", _req_pinyin_error, _build_pinyin_error),
    ExerciseType("matching", "characters", _req_matching, _build_matching),
]}

# Учебная фаза каждого типа — по ней планировщик выстраивает урок:
# 1 знакомство и значение → 2 звук и форма → 3 слово во фразе → 4 воспроизведение.
PHASES: dict[str, int] = {
    "introduction": 1, "recognition": 1,
    "listening": 2, "pinyin_choice": 2, "tone_choice": 2,
    "fill_blank": 3, "sentence_meaning": 3, "sentence_listening": 3, "sentence_order": 3, "dialogue_reply": 3,
    "word_choice": 4, "pinyin_input": 4, "handwriting": 4, "recall": 4,
    # Phase H
    "pinyin_to_hanzi": 2, "translate_cn_ru": 3, "dialogue_scene": 3, "translation_build": 5, "speaking": 6,
    # Phase I
    "pinyin_error": 2, "matching": 1,
}

# Этап урока для интерфейса («где я и зачем это упражнение»): по типу шага;
# шаги повторения (не новые слова урока) получают этап "review" в планировщике.
STAGES: dict[str, str] = {
    "introduction": "new",
    "recognition": "practice", "listening": "practice", "pinyin_choice": "practice", "tone_choice": "practice",
    "pinyin_to_hanzi": "practice", "pinyin_error": "practice", "matching": "practice",
    "fill_blank": "context", "sentence_meaning": "context", "sentence_listening": "context",
    "dialogue_reply": "context", "translate_cn_ru": "context", "dialogue_scene": "context",
    "word_choice": "recall", "pinyin_input": "recall", "handwriting": "recall", "recall": "recall",
    "sentence_order": "production", "translation_build": "production",
    "speaking": "speaking",
}


def stage(type_name: str) -> str:
    return STAGES.get(type_name, "practice")
# Диалог — первым: если у слова есть подходящий диалог, применение в живой
# ситуации полезнее ещё одной фразы (planner берёт тип по ротации из доступных).
CONTEXT_TYPES = ("dialogue_reply", "fill_blank", "sentence_meaning", "sentence_listening", "sentence_order")


def phase(type_name: str) -> int:
    return PHASES.get(type_name, 2)


def get(name: str) -> ExerciseType:
    return REGISTRY[name]


def types_for_skill(skill: str) -> list[ExerciseType]:
    return [t for t in REGISTRY.values() if t.skill == skill]
