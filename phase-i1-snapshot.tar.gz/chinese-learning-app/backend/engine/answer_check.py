"""
Серверная проверка ответа на шаг урока (чистая логика, без БД).

Клиент присылает только то, что сделал пользователь (индекс варианта, порядок
плиток, набранный пиньинь, самооценку), а верно ли это — решает этот модуль по
сохранённому на сервере шагу. Результат: correct, expected (верный ответ для
показа) и explanation — короткое объяснение ошибки по-русски.

Честные ограничения:
  * recall — самооценка пользователя (кнопки «Не знаю … Легко»): сервер её не
    может проверить, только принимает (correct = оценка ≥ 1);
  * handwriting — черты проверяет HanziWriter в браузере; сервер получает число
    неточностей и решает по порогу HANDWRITING_MAX_MISTAKES.
"""

import unicodedata

from .exercise_types import CHAR_TO_TONE, TONE_VOWELS

CHOICE_TYPES = {"recognition", "listening", "pinyin_choice", "fill_blank",
                "word_choice", "sentence_meaning", "sentence_listening", "dialogue_reply",
                "pinyin_to_hanzi", "translate_cn_ru", "dialogue_scene"}
HANDWRITING_MAX_MISTAKES = 2
TONE_NAMES = {1: "1-й (ровный)", 2: "2-й (восходящий)", 3: "3-й (нисходяще-восходящий)", 4: "4-й (нисходящий)"}


class AnswerError(ValueError):
    """Ответ не подходит к типу шага (а не «неверный ответ»)."""


# ---------- пиньинь ----------

def pinyin_key(text: str) -> tuple[str, tuple[int, ...]]:
    """
    Сравнимая форма пиньиня: (буквы без тонов, последовательность тонов 1–4).
    Понимает знаки (nǐ hǎo), цифры (ni3 hao3; 5/0 — лёгкий тон) и v / u: вместо ü;
    пробелы, апострофы и регистр не важны. Лёгкий тон в последовательность не входит.
    """
    text = unicodedata.normalize("NFC", (text or "").strip().lower())
    text = text.replace("u:", "ü").replace("v", "ü")
    letters, tones = [], []
    for ch in text:
        if ch in CHAR_TO_TONE:
            base = CHAR_TO_TONE[ch]
            letters.append(base)
            tones.append(TONE_VOWELS[base].index(ch) + 1)
        elif ch in "1234":
            tones.append(int(ch))
        elif ch.isalpha() or ch == "ü":
            letters.append(ch)
    return "".join(letters), tuple(tones)


# ---------- проверка ----------

def check_answer(step_type: str, payload: dict, answer) -> dict:
    """{'correct': bool, 'expected': str | None, 'explanation': str | None}."""
    payload = payload or {}
    if step_type == "introduction":
        return {"correct": True, "expected": None, "explanation": None}
    if step_type in CHOICE_TYPES:
        return _check_choice(step_type, payload, answer)
    if step_type == "tone_choice":
        return _check_tone_choice(payload, answer)
    if step_type == "pinyin_error":
        return _check_pinyin_error(payload, answer)
    if step_type == "matching":
        return _check_matching(payload, answer)
    if step_type == "sentence_order":
        return _check_order(payload, answer)
    if step_type == "pinyin_input":
        return _check_pinyin_input(payload, answer)
    if step_type == "translation_build":
        return _check_translation(payload, answer)
    if step_type == "speaking":
        # Оценку произношения ставит провайдер распознавания (lesson_service.assess_speaking);
        # сюда приходит только «пропустить» — без оценки и без влияния на навык.
        if not isinstance(answer, dict) or not answer.get("skipped"):
            raise AnswerError("speaking: запись оценивается через /speech, здесь — только пропуск")
        return {"correct": True, "expected": payload.get("text"), "explanation": None, "skipped": True}
    if step_type == "recall":
        if not isinstance(answer, int) or not 0 <= answer <= 3:
            raise AnswerError("recall: ожидается самооценка 0..3")
        return {"correct": answer >= 1, "expected": payload.get("translation"), "explanation": None,
                "self_assessed": True}
    if step_type == "handwriting":
        if not isinstance(answer, dict):
            raise AnswerError("handwriting: ожидается {mistakes, skipped}")
        skipped = bool(answer.get("skipped"))
        mistakes = int(answer.get("mistakes") or 0)
        correct = not skipped and mistakes <= HANDWRITING_MAX_MISTAKES
        explanation = None if correct else (
            "Иероглиф пропущен — он вернётся в следующих уроках." if skipped
            else f"Неточностей: {mistakes} — посмотрите порядок черт ещё раз.")
        return {"correct": correct, "expected": payload.get("hanzi"), "explanation": explanation,
                "client_evaluated": True}
    raise AnswerError(f"Неизвестный тип шага: {step_type}")


def _check_choice(step_type: str, p: dict, answer) -> dict:
    options = p.get("options") or []
    if not isinstance(answer, int) or isinstance(answer, bool) or not 0 <= answer < len(options):
        raise AnswerError("ожидается номер варианта")
    right = p["answer_index"]
    expected = options[right]
    if answer == right:
        return {"correct": True, "expected": expected, "explanation": None}

    def meta(key, i):
        values = p.get(key) or []
        return values[i] if i < len(values) else None

    chosen = options[answer]
    hanzi, pinyin, tr = meta("option_hanzi", right), meta("option_pinyin", right), meta("option_translation", right)
    c_hanzi, c_pinyin, c_tr = meta("option_hanzi", answer), meta("option_pinyin", answer), meta("option_translation", answer)
    explanation = None
    if step_type == "recognition" and c_hanzi:
        explanation = f"«{chosen}» — это {c_hanzi} ({c_pinyin}). {hanzi} значит «{expected}»."
    elif step_type == "listening" and c_pinyin:
        explanation = f"Вы выбрали {chosen} ({c_pinyin}) — «{c_tr}». Прозвучало {hanzi} ({pinyin}) — «{tr}»."
    elif step_type == "pinyin_choice" and c_hanzi:
        explanation = f"{chosen} — это чтение {c_hanzi}. {hanzi} читается {expected}."
    elif step_type == "pinyin_choice":
        explanation = f"Слог тот же, тон другой: правильно {expected}."
    elif step_type == "pinyin_to_hanzi" and c_pinyin:
        explanation = f"{chosen} читается {c_pinyin} — «{c_tr}». {expected} ({pinyin}) — «{tr}»."
    elif step_type == "translate_cn_ru":
        explanation = f"Фраза значит: «{expected}». Вы выбрали: «{chosen}»."
    elif step_type == "dialogue_scene":
        ru = meta("option_translation", right)
        c_ru = meta("option_translation", answer)
        explanation = f"Подходит: {expected} — «{ru}». Ваш вариант значит «{c_ru}»." if ru else None
    elif step_type == "tone_choice":
        tone = meta("option_tone", right)
        explanation = f"Правильно: {expected} — {TONE_NAMES.get(tone, f'{tone}-й')} тон." if tone else None
    elif step_type in ("fill_blank", "word_choice") and c_tr:
        explanation = f"{chosen} ({c_pinyin}) значит «{c_tr}». Здесь нужно {hanzi} ({pinyin}) — «{tr}»."
    elif step_type == "dialogue_reply":
        explanation = f"Подходящий ответ: {expected} — «{tr}». Вы выбрали ответ «{c_tr}»." if tr else None
    elif step_type in ("sentence_meaning", "sentence_listening"):
        explanation = f"Фраза значит: «{expected}»"
    return {"correct": False, "expected": expected, "explanation": explanation}


def _check_tone_choice(p: dict, answer) -> dict:
    """
    Тон каждого слога. Ответ — {"tones": [t, ...]}: по одному тону 1–4 на каждый
    проверяемый слог (слоги с tested), по порядку; для слова из одного такого
    слога можно прислать просто число. Ошибка называет каждый неверный слог и
    его правильный тон. Шаги старого формата (варианты целого слова, сессии,
    начатые до перехода на слоги) проверяются как обычный выбор.
    """
    syllables = p.get("syllables")
    if not syllables:
        return _check_choice("tone_choice", p, answer)
    expected_tones = p.get("answers") or []
    tested = [i for i, s in enumerate(syllables) if s.get("tested")]
    if isinstance(answer, dict):
        answer = answer.get("tones")
    if isinstance(answer, int) and not isinstance(answer, bool) and len(tested) == 1:
        answer = [answer]
    if (not isinstance(answer, list) or len(answer) != len(tested)
            or not all(isinstance(t, int) and not isinstance(t, bool) and 1 <= t <= 4 for t in answer)):
        raise AnswerError(f"tone_choice: ожидается тон 1–4 для каждого из {len(tested)} слогов")

    def form(i: int) -> str:
        s = syllables[i]
        return s["options"][expected_tones[i] - 1] if s.get("tested") else s["base"]

    details = [{"index": i, "chosen": got, "tone": expected_tones[i], "correct": got == expected_tones[i]}
               for i, got in zip(tested, answer)]
    expected = " ".join(form(i) for i in range(len(syllables)))
    wrong = [d for d in details if not d["correct"]]
    if not wrong:
        return {"correct": True, "expected": expected, "explanation": None, "syllables": details}
    if len(details) == 1:
        d = details[0]
        explanation = f"Правильно: {form(d['index'])} — {TONE_NAMES[d['tone']]} тон."
    else:
        parts = []
        for d in wrong:
            i = d["index"]
            label = " ".join(x for x in (syllables[i].get("hanzi"), form(i)) if x)
            parts.append(f"{label} — {TONE_NAMES[d['tone']]}, а не {d['chosen']}-й")
        head = "Неверный тон в слоге" if len(wrong) == 1 else "Неверные тоны в слогах"
        explanation = f"{head}: {'; '.join(parts)}."
        if len(wrong) < len(details):
            explanation += " Остальные слоги — верно."
    # 3-й тон перед 3-м звучит как 2-й (ни3 хао3 → ní hǎo), а записывается 3-м
    if any(d["tone"] == 3 and d["chosen"] == 2 and d["index"] + 1 < len(expected_tones)
           and expected_tones[d["index"] + 1] == 3 for d in wrong):
        explanation += " Перед другим 3-м тоном 3-й звучит почти как 2-й, но в записи остаётся 3-м."
    return {"correct": False, "expected": expected, "explanation": explanation, "syllables": details}


MISTAKE_NOTES = {
    "initial": "начальный согласный другой", "final": "конец слога: -n и -ng различаются",
    "umlaut": "после n и l ü и u — разные слоги",
}


def _check_pinyin_error(p: dict, answer) -> dict:
    """
    Найти запись с ошибкой. Верный ответ — номер ошибочной записи (answer_index);
    при промахе объяснение называет слог с ошибкой и его правильное чтение, а
    выбранный вариант — верным (он записан без ошибки).
    """
    options = p.get("options") or []
    if not isinstance(answer, int) or isinstance(answer, bool) or not 0 <= answer < len(options):
        raise AnswerError("ожидается номер варианта")
    right = p["answer_index"]
    expected = options[right]
    if answer == right:
        return {"correct": True, "expected": expected, "explanation": None}
    m = p.get("answer") or {}
    hanzi, right, wrong = m.get("hanzi") or "", m.get("right"), m.get("wrong")
    if m.get("kind") == "tone":
        detail = f"{hanzi} — {right}, {TONE_NAMES[m['right_tone']]} тон, а не {wrong}"
    elif m.get("kind") == "neutral":
        detail = f"{hanzi} здесь — лёгкий тон, {right} без знака, а не {wrong}"
    else:
        note = MISTAKE_NOTES.get(m.get("kind"))
        detail = f"{hanzi} читается {right}, а не {wrong}" + (f" ({note})" if note else "")
    explanation = f"Ошибка — в «{expected}»: {detail.strip()}. «{options[answer]}» записано верно."
    return {"correct": False, "expected": expected, "explanation": explanation}


def _check_matching(p: dict, answer) -> dict:
    """
    Сопоставление: ответ — {"pairs": [j, ...]}, для каждого иероглифа слева номер
    выбранного перевода справа; каждый перевод — ровно один раз. Верно, только если
    верны все пары; объяснение называет каждую неверную пару и её верный перевод.
    expected — верные пары построчно «иероглиф — перевод» в порядке иероглифов.
    """
    left, right, key = p.get("left") or [], p.get("right") or [], p.get("answers") or []
    pairs = answer.get("pairs") if isinstance(answer, dict) else answer
    n = len(left)
    if (not isinstance(pairs, list) or len(pairs) != n
            or not all(isinstance(j, int) and not isinstance(j, bool) and 0 <= j < len(right) for j in pairs)
            or len(set(pairs)) != n):
        raise AnswerError(f"matching: ожидается перевод для каждого из {n} слов, каждый перевод — один раз")
    details = [{"index": i, "chosen": pairs[i], "right": key[i], "correct": pairs[i] == key[i]} for i in range(n)]
    expected = "\n".join(f"{left[i]} — {right[key[i]]}" for i in range(n))
    wrong = [d for d in details if not d["correct"]]
    if not wrong:
        return {"correct": True, "expected": expected, "explanation": None, "pairs": details}
    parts = [f"{left[d['index']]} — «{right[d['right']]}», а не «{right[d['chosen']]}»" for d in wrong]
    explanation = f"Неверные пары ({len(wrong)} из {n}): {'; '.join(parts)}."
    return {"correct": False, "expected": expected, "explanation": explanation, "pairs": details}


def _check_order(p: dict, answer) -> dict:
    if not isinstance(answer, list) or not all(isinstance(t, str) for t in answer):
        raise AnswerError("sentence_order: ожидается список плиток по порядку")
    expected = "".join(p.get("answer_tokens") or [])
    if sorted(answer) != sorted(p.get("tokens") or []):
        raise AnswerError("sentence_order: плитки не совпадают с выданными")
    correct = "".join(answer) == expected
    explanation = None if correct else f"Правильный порядок: {' '.join(p.get('answer_tokens') or [])}."
    return {"correct": correct, "expected": expected, "explanation": explanation}


def _check_translation(p: dict, answer) -> dict:
    """
    Перевод RU → CN из плиток: верен любой из допустимых вариантов (answers —
    разный порядок или формулировки, заданные автором урока); лишние плитки
    можно не использовать, но брать можно только выданные плитки.
    """
    if not isinstance(answer, list) or not all(isinstance(t, str) for t in answer) or not answer:
        raise AnswerError("translation_build: ожидается список плиток по порядку")
    pool = list(p.get("tokens") or [])
    for t in answer:
        if t not in pool:
            raise AnswerError("translation_build: такой плитки не было")
        pool.remove(t)
    answers = [list(a) for a in p.get("answers") or []]
    expected = "".join(answers[0]) if answers else ""
    if list(answer) in answers:
        return {"correct": True, "expected": expected, "explanation": None}
    best = answers[0] if answers else []
    if sorted(answer) == sorted(best):
        explanation = f"Слова верные, порядок — нет: {' '.join(best)}."
    else:
        missing = [t for t in best if t not in answer]
        extra = [t for t in answer if t not in best]
        parts = []
        if missing:
            parts.append(f"не хватает: {' '.join(missing)}")
        if extra:
            parts.append(f"лишнее: {' '.join(extra)}")
        explanation = f"Правильно: {' '.join(best)}" + (f" ({'; '.join(parts)})." if parts else ".")
    return {"correct": False, "expected": expected, "explanation": explanation}


def _check_pinyin_input(p: dict, answer) -> dict:
    if not isinstance(answer, str) or not answer.strip():
        raise AnswerError("pinyin_input: ожидается строка")
    expected = p.get("answer") or ""
    got_letters, got_tones = pinyin_key(answer)
    exp_letters, exp_tones = pinyin_key(expected)
    if got_letters == exp_letters and got_tones == exp_tones:
        return {"correct": True, "expected": expected, "explanation": None}
    if got_letters == exp_letters:
        explanation = f"Слоги верные, а тоны — нет: правильно {expected}."
        if len(exp_tones) == 1:
            explanation = f"Слог верный, а тон — нет: правильно {expected}, {TONE_NAMES[exp_tones[0]]} тон."
    elif got_letters.replace("ü", "u") == exp_letters.replace("ü", "u"):
        explanation = f"Почти: здесь ü (набирается как v). Правильно {expected}."
    else:
        explanation = f"Правильно: {expected}."
    return {"correct": False, "expected": expected, "explanation": explanation}
