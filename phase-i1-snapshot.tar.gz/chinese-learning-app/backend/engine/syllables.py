"""
Разбор пиньиня слова на слоги с тонами (для tone_choice: тон каждого слога).

Чистый модуль: без FastAPI/SQL. Вход — словарный пиньинь со знаками тонов
(«diànzǐ yóujiàn», «nǚ'ér», «xièxie», «yìdiǎnr»). Слоги ищутся по таблице
допустимых слогов путунхуа; внутри слитной записи слог не начинается с a/o/e
(по правилам пиньиня там ставится апостроф), и в слоге не больше одного знака
тона — этого хватает, чтобы однозначно разрезать почти все слова. Если
вариантов несколько, берётся тот, у которого число слогов совпадает с числом
иероглифов. Слог без знака — лёгкий тон: он показывается, но не проверяется.
"""

import unicodedata
from dataclasses import dataclass

# Диакритики тонов: гласная -> 4 формы (тоны 1..4)
TONE_VOWELS = {
    "a": "āáǎà", "e": "ēéěè", "i": "īíǐì", "o": "ōóǒò", "u": "ūúǔù", "ü": "ǖǘǚǜ",
}
CHAR_TO_TONE = {ch: base for base, forms in TONE_VOWELS.items() for ch in forms}

# Слоги путунхуа без тонов (стандартная таблица пиньиня).
_SYLLABLE_TABLE = """
a ai an ang ao e ei en eng er o ou
yi ya yao ye you yan yang yin ying yo yong yu yue yuan yun
wu wa wo wai wei wan wen wang weng
ba bo bai bei bao ban ben bang beng bi biao bie bian bin bing bu
pa po pai pei pao pou pan pen pang peng pi piao pie pian pin ping pu
ma mo me mai mei mao mou man men mang meng mi miao mie miu mian min ming mu
fa fo fei fou fan fen fang feng fu
da de dai dei dao dou dan den dang deng dong di dia diao die diu dian ding du duo dui duan dun
ta te tai tei tao tou tan tang teng tong ti tiao tie tian ting tu tuo tui tuan tun
na ne nai nei nao nou nan nen nang neng nong ni niao nie niu nian nin niang ning nu nuo nuan nü nüe
la le lai lei lao lou lan lang leng long li lia liao lie liu lian lin liang ling lu luo luan lun lü lüe
ga ge gai gei gao gou gan gen gang geng gong gu gua guo guai gui guan gun guang
ka ke kai kei kao kou kan ken kang keng kong ku kua kuo kuai kui kuan kun kuang
ha he hai hei hao hou han hen hang heng hong hu hua huo huai hui huan hun huang
ji jia jiao jie jiu jian jin jiang jing jiong ju jue juan jun
qi qia qiao qie qiu qian qin qiang qing qiong qu que quan qun
xi xia xiao xie xiu xian xin xiang xing xiong xu xue xuan xun
zha zhe zhi zhai zhei zhao zhou zhan zhen zhang zheng zhong zhu zhua zhuo zhuai zhui zhuan zhun zhuang
cha che chi chai chao chou chan chen chang cheng chong chu chua chuo chuai chui chuan chun chuang
sha she shi shai shei shao shou shan shen shang sheng shu shua shuo shuai shui shuan shun shuang
re ri rao rou ran ren rang reng rong ru rua ruo rui ruan run
za ze zi zai zei zao zou zan zen zang zeng zong zu zuo zui zuan zun
ca ce ci cai cao cou can cen cang ceng cong cu cuo cui cuan cun
sa se si sai sao sou san sen sang seng song su suo sui suan sun
"""
SYLLABLES = frozenset(_SYLLABLE_TABLE.split())
_MAX_LEN = max(map(len, SYLLABLES)) + 1  # +1 — эризация («diǎnr»)
_LETTERS = set("abcdefghijklmnopqrstuvwxyzü")


@dataclass(frozen=True)
class Syllable:
    text: str               # как в словаре, со знаком тона: "diàn"
    base: str               # без тона: "dian"
    tone: int | None        # 1–4; None — лёгкий тон (знака нет)
    mark_index: int | None  # позиция гласной со знаком в text
    hanzi: str | None       # иероглиф(ы) слога, если число слогов совпало с иероглифами
    erhua: bool = False     # «-r» в конце слога (点儿 = diǎnr)

    def with_tone(self, tone: int) -> str:
        """Тот же слог с другим тоном (знак ставится на ту же гласную)."""
        if self.mark_index is None:
            return self.text
        vowel = CHAR_TO_TONE[self.text[self.mark_index]]
        i = self.mark_index
        return self.text[:i] + TONE_VOWELS[vowel][tone - 1] + self.text[i + 1:]


def _chunks(pinyin: str) -> list[str] | None:
    """Части записи между пробелами/апострофами/дефисами; None — посторонние символы."""
    text = unicodedata.normalize("NFC", pinyin or "").lower()
    chunks, cur = [], []
    for ch in text:
        if ch in _LETTERS or ch in CHAR_TO_TONE:
            cur.append(ch)
        elif ch.isspace() or ch in "'’‘-·,.，。!?！？…":
            if cur:
                chunks.append("".join(cur))
            cur = []
        else:
            return None
    if cur:
        chunks.append("".join(cur))
    return chunks


def _base(text: str) -> str:
    return "".join(CHAR_TO_TONE.get(ch, ch) for ch in text)


def _valid(piece: str, at_start: bool, at_end: bool, strict: bool) -> bool:
    base = _base(piece)
    if strict and not at_start and base[0] in "aoe":
        return False
    if sum(ch in CHAR_TO_TONE for ch in piece) > 1:
        return False
    if base in SYLLABLES:
        return True
    return at_end and len(base) > 1 and base.endswith("r") and base[:-1] in SYLLABLES


def _segment(chunk: str, strict: bool) -> list[list[str]]:
    """Все разбиения части записи на слоги; сначала — с самыми длинными слогами."""
    n, found = len(chunk), []

    def walk(i: int, acc: list[str]) -> None:
        if len(found) >= 8:
            return
        if i == n:
            found.append(acc)
            return
        for j in range(min(n, i + _MAX_LEN), i, -1):
            piece = chunk[i:j]
            if _valid(piece, i == 0, j == n, strict):
                walk(j, [*acc, piece])

    walk(0, [])
    return found


def _is_erhua(piece: str) -> bool:
    base = _base(piece)
    return base not in SYLLABLES and base.endswith("r")


def _hanzi_units(pieces: list[str]) -> int:
    return sum(2 if _is_erhua(p) else 1 for p in pieces)


def split_syllables(pinyin: str, hanzi: str | None = None) -> list[Syllable] | None:
    """Слоги слова по порядку; None — запись не разбирается на слоги путунхуа."""
    chunks = _chunks(pinyin)
    if not chunks:
        return None
    # «yī huì r» (эризация отдельной частью) — «r» приклеивается к предыдущему слогу
    for i in range(len(chunks) - 1, 0, -1):
        if chunks[i] == "r":
            chunks[i - 1] += chunks.pop(i)
    if chunks[0] == "r":
        return None
    chars = [c for c in (hanzi or "") if "一" <= c <= "鿿" or "㐀" <= c <= "䶿"]
    options: list[list[list[str]]] = []
    for chunk in chunks:
        found = _segment(chunk, strict=True) or _segment(chunk, strict=False)
        if not found:
            return None
        options.append(found)
    # число вариантов мало (обычно по одному на часть) — перебор полный
    combos: list[list[str]] = [[]]
    for found in options:
        combos = [[*c, *f] for c in combos for f in found][:64]
    pieces = next((c for c in combos if chars and _hanzi_units(c) == len(chars)), combos[0])
    aligned = bool(chars) and _hanzi_units(pieces) == len(chars)

    result, k = [], 0
    for piece in pieces:
        erhua = _is_erhua(piece)
        width = 2 if erhua else 1
        mark = next((i for i, ch in enumerate(piece) if ch in CHAR_TO_TONE), None)
        tone = TONE_VOWELS[CHAR_TO_TONE[piece[mark]]].index(piece[mark]) + 1 if mark is not None else None
        result.append(Syllable(piece, _base(piece), tone, mark,
                               "".join(chars[k:k + width]) if aligned else None, erhua))
        k += width
    return result
