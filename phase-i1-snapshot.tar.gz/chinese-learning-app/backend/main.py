"""
Backend приложения для изучения китайского языка.

Phase 1 (PLAN_WB_v1.md): main.py — тонкая точка входа, вся логика вынесена
в app/ (routers → services → repositories → db), см. ARCHITECTURE_WB_v1.md
раздел 1. Поведение и контракт API не изменились — это чистый рефакторинг
слоёв, не редизайн.

Реализовано (без изменений с предыдущей версии):
  1. Карточки (иероглиф → пиньинь → перевод, аудио)
  2. Режим изучения иероглифа (разбор компонентов + рисование на canvas)
  3. Тренировка пиньиня и тонов
  4. Интервальные повторения (SM-2 + состояния new/learning/review/mastered, srs.py)
  5. Категории слов, профиль с разбивкой по HSK и категориям, недельная активность
  6. Аудио: /audio/<words|sentences>/<id>.mp3 если есть файл, иначе браузерный TTS
     на фронтенде (см. frontend/app.js)

Стек: Python + FastAPI + SQLite (без Postgres/Docker — легко задеплоить на
простой хостинг).
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import AUDIO_DIR, AUDIO_SUBDIRS, FRONTEND_DIR
from app.db import init_db
from app.routers import (
    account,
    content,
    learning,
    learning_path,
    lessons,
    profile,
    settings,
)

for sub in AUDIO_SUBDIRS:
    (AUDIO_DIR / sub).mkdir(parents=True, exist_ok=True)

app = FastAPI(title="Chinese Learning App")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

app.include_router(learning.router)
app.include_router(learning_path.router)
app.include_router(lessons.router)
app.include_router(content.router)
app.include_router(profile.router)
app.include_router(settings.router)
app.include_router(account.router)

# Аудио: реальный файл, если есть (words/<id>.mp3, sentences/<id>.mp3), иначе
# фронтенд сам падает обратно на браузерный TTS (см. app.js -> playAudio()).
app.mount("/audio", StaticFiles(directory=AUDIO_DIR), name="audio")

# Статика фронтенда — с того же origin, чтобы не возиться с CORS при деплое.
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
