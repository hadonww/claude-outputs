// ---------------------------------------------------------------------------
// Конфигурация и утилиты
// ---------------------------------------------------------------------------

const API = ""; // тот же origin, что и фронтенд (backend отдаёт статику сам)

async function api(path, options) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`API ${path} -> ${res.status}`);
  return res.json();
}

// Запрос, ответ которого нужно разобрать и при ошибке (сообщение сервера в detail).
async function apiSend(path, options) {
  const res = await fetch(API + path, { headers: { "Content-Type": "application/json" }, ...options });
  let data = null;
  try { data = await res.json(); } catch (e) { /* пустое тело */ }
  return { ok: res.ok, status: res.status, data };
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = "zh-CN";
  const voices = speechSynthesis.getVoices();
  const zhVoice = voices.find((v) => v.lang && v.lang.toLowerCase().startsWith("zh"));
  if (zhVoice) utter.voice = zhVoice;
  utter.rate = 0.9;
  speechSynthesis.cancel();
  speechSynthesis.speak(utter);
}

// --- Аудио произношения: реальный файл (/audio/words/<id>.mp3), если он есть,
// иначе браузерный TTS. Показывает "проигрывание" на кнопке и не даёт двум
// звукам звучать одновременно.
let currentAudioEl = null;

function stopAllAudio() {
  if (currentAudioEl) {
    currentAudioEl.pause();
    currentAudioEl = null;
  }
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  document.querySelectorAll(".btn-audio.playing").forEach((b) => b.classList.remove("playing"));
}

function playAudio(text, wordId, btnEl) {
  stopAllAudio();
  if (btnEl) btnEl.classList.add("playing");
  const clearPlaying = () => btnEl && btnEl.classList.remove("playing");

  const fallbackToTTS = () => {
    if (!("speechSynthesis" in window)) {
      clearPlaying();
      return;
    }
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = "zh-CN";
    const zhVoice = speechSynthesis.getVoices().find((v) => v.lang?.toLowerCase().startsWith("zh"));
    if (zhVoice) utter.voice = zhVoice;
    utter.rate = 0.85;
    utter.onend = clearPlaying;
    utter.onerror = clearPlaying;
    speechSynthesis.speak(utter);
  };

  if (wordId) {
    const audio = new Audio(`/audio/words/${wordId}.mp3`);
    currentAudioEl = audio;
    audio.addEventListener("ended", clearPlaying);
    audio.addEventListener("error", fallbackToTTS);
    audio.play().catch(fallbackToTTS);
  } else {
    fallbackToTTS();
  }
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ---------------------------------------------------------------------------
// Тема (светлая/тёмная)
// ---------------------------------------------------------------------------

// Выбор хранится в localStorage только как удобство этого браузера; без него —
// тема системы. Обёрнуто в try: в приватном режиме хранилище может быть недоступно.
function storedTheme() {
  try { return localStorage.getItem("theme"); } catch (e) { return null; }
}

function systemTheme() {
  return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function currentEffectiveTheme() {
  return storedTheme() || systemTheme();
}

function applyTheme(choice) {
  try {
    if (choice === "system") localStorage.removeItem("theme");
    else if (choice) localStorage.setItem("theme", choice);
  } catch (e) { /* хранилище недоступно — тема действует до перезагрузки */ }
  const effective = choice && choice !== "system" ? choice : currentEffectiveTheme();
  document.documentElement.setAttribute("data-theme", effective);
  // строка состояния и панель браузера — цвета фона выбранной темы
  const paper = getComputedStyle(document.documentElement).getPropertyValue("--paper").trim();
  document.querySelectorAll('meta[name="theme-color"]').forEach((m) => m.setAttribute("content", paper));
  document.querySelectorAll("[data-theme-choice]").forEach((b) => {
    const active = b.dataset.themeChoice === (storedTheme() || "system");
    b.classList.toggle("active", active);
    b.setAttribute("aria-checked", String(active));
  });
}

applyTheme(null);
document.querySelectorAll("[data-theme-choice]").forEach((b) => {
  b.addEventListener("click", () => applyTheme(b.dataset.themeChoice));
});
if (window.matchMedia) {
  window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
    if (!storedTheme()) applyTheme(null);
  });
}

// ---------------------------------------------------------------------------
// Онбординг
// ---------------------------------------------------------------------------

const onboardingAnswers = { level: 0, knowsPinyin: 0, knowsTones: 0, minutes: 10 };
let onboardingStep = 0;
const ONBOARDING_STEPS = 6;  // приветствие, 4 вопроса, план

// Точки — только для четырёх вопросов (шаги 1–4), как и подпись «Шаг N из 4»;
// на приветствии и на итоговом плане их нет.
const ONBOARDING_QUESTIONS = 4;
function renderOnboardingDots() {
  const dots = document.getElementById("onboarding-dots");
  const isQuestion = onboardingStep >= 1 && onboardingStep <= ONBOARDING_QUESTIONS;
  dots.classList.toggle("invisible", !isQuestion);
  dots.innerHTML = Array.from({ length: ONBOARDING_QUESTIONS })
    .map((_, i) => `<span class="dot ${i + 1 === onboardingStep ? "active" : i + 1 < onboardingStep ? "done" : ""}"></span>`)
    .join("");
  document.getElementById("onboarding-back").classList.toggle("invisible", onboardingStep === 0);
}

function goToOnboardingStep(step) {
  onboardingStep = step;
  document.querySelectorAll(".onboarding-step").forEach((el) => {
    el.classList.toggle("hidden", Number(el.dataset.step) !== step);
  });
  renderOnboardingDots();
  if (step === ONBOARDING_STEPS - 1) buildPlanSummary();
  document.getElementById("onboarding").scrollTop = 0;
}

function setupOptionGroup(containerId, key) {
  const container = document.getElementById(containerId);
  container.querySelectorAll(".onboarding-option:not(.disabled)").forEach((btn) => {
    btn.addEventListener("click", () => {
      container.querySelectorAll(".onboarding-option").forEach((b) => {
        b.classList.toggle("selected", b === btn);
        b.setAttribute("aria-pressed", String(b === btn));
      });
      onboardingAnswers[key] = Number(btn.dataset.value);
    });
  });
}

setupOptionGroup("level-options", "level");
setupOptionGroup("pinyin-options", "knowsPinyin");
setupOptionGroup("tones-options", "knowsTones");
setupOptionGroup("goal-options", "minutes");

function buildPlanSummary() {
  const wordsPerDay = minutesToWordsPerDay(onboardingAnswers.minutes);
  const known = onboardingAnswers.level > 0
    ? " Знакомые слова пройдут быстро — при высокой точности новых слов в уроке станет больше."
    : "";
  document.getElementById("plan-summary").textContent =
    `Около ${wordsPerDay} новых слов за урок (${onboardingAnswers.minutes} мин) плюс повторение того, что пора вспомнить.${known}`;
}

function minutesToWordsPerDay(minutes) {
  return { 5: 3, 10: 5, 15: 8, 20: 10 }[minutes] || 5;
}

document.querySelectorAll("#onboarding [data-next]").forEach((btn) => {
  btn.addEventListener("click", () => goToOnboardingStep(Math.min(onboardingStep + 1, ONBOARDING_STEPS - 1)));
});

async function finishOnboarding(useDefaults) {
  const answers = useDefaults ? { level: 1, knowsPinyin: 0, knowsTones: 0, minutes: 10 } : onboardingAnswers;
  const errorEl = document.getElementById("onboarding-username-error");
  errorEl.textContent = "";
  const username = useDefaults ? "" : document.getElementById("onboarding-username").value.trim();
  if (username) {
    // имя проверяет сервер (формат, занятость); при ошибке остаёмся на шаге
    const res = await apiSend("/api/me/username", { method: "PUT", body: JSON.stringify({ username }) });
    if (!res.ok) {
      errorEl.textContent = (res.data && res.data.detail) || "Не удалось сохранить имя";
      return;
    }
  }
  try {
    await api("/api/settings", {
      method: "POST",
      body: JSON.stringify({
        preferred_hsk: Math.max(1, answers.level),
        knows_pinyin: !!answers.knowsPinyin,
        knows_tones: !!answers.knowsTones,
        daily_new_words: minutesToWordsPerDay(answers.minutes),
      }),
    });
    // факт прохождения хранит сервер (аккаунт), повтор безопасен
    await api("/api/me/onboarding/complete", { method: "POST" });
  } catch (e) {
    // офлайн/ошибка сети — не блокируем; сервер покажет онбординг ещё раз при следующем входе
  }
  document.getElementById("onboarding").classList.add("hidden");
  showView("home");
}

document.getElementById("onboarding-finish").addEventListener("click", () => finishOnboarding(false));
document.getElementById("onboarding-skip").addEventListener("click", () => finishOnboarding(true));
document.getElementById("onboarding-back").addEventListener("click", () => goToOnboardingStep(Math.max(onboardingStep - 1, 0)));

// Показывать ли онбординг, решает сервер (users.onboarding_completed_at), а не
// localStorage: новый аккаунт видит его один раз, после завершения — никогда.
async function maybeShowOnboarding() {
  let me;
  try {
    me = await api("/api/me");
  } catch (e) {
    return; // нет связи с сервером — не мешаем работе
  }
  if (me.onboarding && me.onboarding.completed) return;
  onboardingStep = 0;
  goToOnboardingStep(0);
  document.getElementById("onboarding").classList.remove("hidden");
}

// ---------------------------------------------------------------------------
// Навигация по вкладкам
// ---------------------------------------------------------------------------

// Навигация: у каждой вкладки своя позиция прокрутки (вернулись — там же, где
// были); повторное нажатие на активную вкладку прокручивает её наверх, как в iOS.
const scrollByView = {};
let currentView = null;

function prefersReducedMotion() {
  return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function showView(name) {
  if (currentView && currentView !== "lesson") scrollByView[currentView] = window.scrollY;
  document.body.classList.toggle("in-lesson", name === "lesson");
  document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
  document.getElementById(`view-${name}`).classList.add("active");
  document.querySelectorAll(".tab").forEach((t) => {
    const active = t.dataset.view === name;
    t.classList.toggle("active", active);
    if (active) t.setAttribute("aria-current", "page");
    else t.removeAttribute("aria-current");
  });
  currentView = name;

  if (name === "home") loadHome();
  if (name === "dict") loadDictionary(document.getElementById("dict-search").value.trim());
  if (name === "profile") loadProfile();
  window.scrollTo(0, name === "lesson" ? 0 : (scrollByView[name] || 0));
}

document.querySelectorAll(".tab[data-view]").forEach((el) => {
  el.addEventListener("click", () => {
    if (currentView === el.dataset.view) {
      window.scrollTo({ top: 0, behavior: prefersReducedMotion() ? "auto" : "smooth" });
      return;
    }
    showView(el.dataset.view);
  });
});

// ---------------------------------------------------------------------------
// Главная: learning path
// ---------------------------------------------------------------------------

function greetingText() {
  const hour = new Date().getHours();
  if (hour < 5) return "Доброй ночи";
  if (hour < 12) return "Доброе утро";
  if (hour < 18) return "Добрый день";
  return "Добрый вечер";
}

// Декоративная иконка модуля — один настоящий иероглиф на категорию,
// используется только как визуальный акцент, не как перевод названия.
const CATEGORY_ICON = {
  "люди": "人", "семья": "家", "еда": "食", "школа": "学", "работа": "工",
  "время": "时", "числа": "数", "путешествия": "行", "транспорт": "车",
  "покупки": "买", "дом": "房", "эмоции": "心", "действия": "动",
  "природа": "山", "технологии": "电", "повседневная жизнь": "常", "грамматика": "语",
  // темы HSK 4
  "изменения и процессы": "变", "характер": "性", "здоровье и спорт": "体", "культура и досуг": "艺",
  "общество": "社", "мнения и рассуждения": "想", "абстрактные понятия": "理",
  "качества и свойства": "形", "оценка и модальность": "评", "наречия времени": "渐", "союзы и связки": "连",
};

// Атмосферный фон focal card завязан на текущий раздел маршрута (реальные
// данные, не случайный декор) — один hue на секцию, светлота/насыщенность
// берутся из тем в CSS.
const SECTION_HUE = { basics: 220, everyday: 22, food: 12, study_work: 188, world: 258, society: 330, thinking: 160, extra: 220 };

function plural(n, one, few, many) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if ([2, 3, 4].includes(m10) && ![12, 13, 14].includes(m100)) return few;
  return many;
}

let homeLoadToken = 0;
let homeFirstPaintDone = false;

async function loadHome() {
  const token = ++homeLoadToken;
  document.getElementById("home-greeting").textContent = greetingText();

  let home, path;
  try {
    [home, path] = await Promise.all([api("/api/home"), api("/api/learning-path")]);
  } catch (e) {
    document.getElementById("home-path-loading").textContent = "Нет связи с сервером — попробуйте обновить страницу.";
    return;
  }
  if (token !== homeLoadToken) return;
  document.getElementById("home-streak-value").textContent = home.streak;

  const modules = path.modules.slice().sort((a, b) => a.route_index - b.route_index);
  const recommended = modules.find((m) => m.id === path.recommended_module_id);
  const hasRecommended = Boolean(recommended);

  document.getElementById("home-path-loading").classList.add("hidden");
  document.getElementById("home-continue").classList.toggle("hidden", !hasRecommended);
  document.getElementById("home-all-done").classList.toggle("hidden", hasRecommended);
  document.getElementById("home-path-section").classList.toggle("hidden", !hasRecommended);

  // Повторение — вторичное действие: главное всегда «продолжить урок» (в урок
  // повторение и так подмешивается); отдельная ссылка — когда слов много.
  const reviewLink = document.getElementById("home-review-link");
  const due = home.due_review_count;
  reviewLink.classList.toggle("hidden", !(hasRecommended && due > 0));
  reviewLink.textContent = `Только повторение · ${due} ${plural(due, "слово", "слова", "слов")} →`;

  if (!hasRecommended) {
    document.getElementById("home-today-row").classList.add("hidden");
    return;
  }

  if (renderResumeCard(recommended)) {
    renderPath(modules, recommended);
    return;
  }
  const pct = recommended.total_words ? Math.round((100 * recommended.introduced_words) / recommended.total_words) : 0;
  document.getElementById("continue-icon").textContent = CATEGORY_ICON[recommended.category] || "学";
  const zh = document.getElementById("continue-section-zh");
  zh.textContent = recommended.section_title_zh;
  // водяной знак — часть иллюстрации (SVG): размер в единицах сцены по длине названия
  zh.setAttribute("font-size", { 1: 130, 2: 120, 3: 90 }[[...recommended.section_title_zh].length] || 80);
  // Оттенок раздела — общий для focal card и начала пути (один источник света).
  document.getElementById("view-home").style.setProperty("--section-hue", SECTION_HUE[recommended.section_id] ?? 220);
  document.getElementById("continue-section-label").textContent = recommended.section_title;
  document.getElementById("continue-module-label").textContent = recommended.title;
  document.getElementById("continue-meta").textContent =
    `${recommended.introduced_words} из ${recommended.total_words} слов пройдено`;
  document.getElementById("continue-progress-fill").style.transform = `scaleX(${pct / 100})`;
  document.getElementById("continue-reason").textContent = recommended.recommendation_reason || "";
  const startBtn = document.getElementById("home-start-btn");
  startBtn.dataset.resume = "";
  startBtn.dataset.moduleTitle = recommended.title;
  startBtn.dataset.moduleId = recommended.id;
  startBtn.setAttribute("aria-label", `Продолжить: ${recommended.title}`);
  renderPath(modules, recommended);
  if (!homeFirstPaintDone) {
    // анимация появления — один раз за сессию
    homeFirstPaintDone = true;
    const view = document.getElementById("view-home");
    view.classList.add("first-paint");
    setTimeout(() => view.classList.remove("first-paint"), 800);
  }

  // «Сегодня» описывает урок, который реально откроется по кнопке (предпросмотр
  // плана без создания сессии); время — по числу шагов.
  try {
    const plan = await api(`/api/lessons/${recommended.id}/plan`);
    if (token !== homeLoadToken) return;
    const n = plan.new_words.length;
    document.getElementById("today-new-count").textContent = n;
    document.getElementById("today-new-label").textContent = plural(n, "новое", "новых", "новых");
    document.getElementById("today-review-count").textContent = plan.review_words.length;
    document.getElementById("today-minutes").textContent = `~${Math.max(1, Math.round(plan.steps.length * 0.35))}`;
    document.getElementById("home-today-row").classList.remove("hidden");
  } catch (e) { /* без предпросмотра Home всё равно работает */ }
}

// Путь = текущий уровень HSK подробно (главы → модули), пройденные уровни —
// одной строкой, будущие — по строке на уровень. Раньше путь показывал 15
// одинаковых заглушек «откроется позже» на весь курс.
function renderPath(modules, recommended) {
  const level = recommended.hsk_level;
  const byLevel = {};
  for (const m of modules) (byLevel[m.hsk_level ?? 99] ||= []).push(m);
  const levelMods = byLevel[level] || [];
  const done = levelMods.filter((m) => m.status === "completed").length;
  const introduced = levelMods.reduce((s, m) => s + m.introduced_words, 0);
  const total = levelMods.reduce((s, m) => s + m.total_words, 0);
  document.getElementById("path-level-head").innerHTML = `
    <p class="mark-label">Текущий уровень</p>
    <div class="level-head-row"><p class="level-title">HSK ${level}</p>
      <p class="level-frac">${done} из ${levelMods.length} модулей<br>${introduced} / ${total} слов</p></div>
    <div class="level-bar"><div class="level-bar-fill" style="width:${total ? Math.round((100 * introduced) / total) : 0}%"></div></div>`;
  renderChapters(levelMods);

  const ahead = Object.keys(byLevel).map(Number).filter((l) => l !== level).sort((a, b) => a - b);
  document.getElementById("path-levels-ahead").innerHTML = ahead.map((l) => {
    const mods = byLevel[l];
    const words = mods.reduce((s, m) => s + m.total_words, 0);
    const isDone = mods.every((m) => m.status === "completed");
    const label = l === 99 ? "Дополнительно" : `HSK ${l}`;
    const sub = isDone ? `пройден · ${words} слов на повторении`
      : l < level ? `${mods.filter((m) => m.status === "completed").length} из ${mods.length} модулей`
        : `${mods.length} ${plural(mods.length, "модуль", "модуля", "модулей")} · ${words} слов · откроется после HSK&nbsp;${l - 1}`;
    return `<div class="level-row ${isDone ? "done" : l > level ? "ahead" : ""}">
      <span class="level-row-mark">${isDone ? icon("check") : l === 99 ? "+" : l}</span>
      <span class="level-row-body"><b>${label}</b><span>${sub}</span></span></div>`;
  }).join("");
}

// Глава = раздел курса на этом уровне. Открытая глава показывает модули;
// главы целиком впереди — свёрнутой строкой.
function renderChapters(modules) {
  const bySection = [];
  for (const m of modules) {
    let section = bySection[bySection.length - 1];
    const key = m.section_key || m.section_id;
    if (!section || section.key !== key) {
      section = { key, id: m.section_id, zh: m.section_title_zh, title: m.section_title, modules: [] };
      bySection.push(section);
    }
    section.modules.push(m);
  }
  document.getElementById("path-sections").innerHTML = bySection.map((section, idx) => {
    const introduced = section.modules.reduce((s, m) => s + m.introduced_words, 0);
    const total = section.modules.reduce((s, m) => s + m.total_words, 0);
    const isReached = section.modules.some((m) => m.status !== "locked");
    const title = section.title.replace(/ · HSK \d+$/, "");
    const head = `<div class="chapter-head">
      <span class="chapter-zh">${section.zh}</span>
      <div class="chapter-heading">
        <p class="chapter-title">${title}</p>
        <p class="chapter-sub">${section.modules.length} ${plural(section.modules.length, "модуль", "модуля", "модулей")} · ${introduced} / ${total} слов</p>
      </div>
    </div>`;
    if (isReached) {
      return `<div class="chapter">${head}<div class="node-list">${section.modules.map(renderNode).join("")}</div></div>`;
    }
    const icons = section.modules.slice(0, 5).map((m) => `<span>${CATEGORY_ICON[m.category] || "学"}</span>`).join("");
    const prev = idx > 0 ? bySection[idx - 1].title.replace(/ · HSK \d+$/, "") : "";
    const when = prev ? `Откроется после главы «${prev}»` : "Откроется по порядку";
    return `<div class="chapter is-locked">${head}<button class="chapter-preview" type="button" data-locked-reason="${escapeAttr(section.modules[0].locked_reason || "")}">
      <span class="chapter-preview-icons">${icons}</span>
      <span class="chapter-preview-text">${when}</span>
      <span class="chapter-preview-count" aria-label="Закрыто">${icon("lock")}</span>
    </button></div>`;
  }).join("");
}

function escapeAttr(text) {
  return String(text).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}

function renderNode(m) {
  const nodeIcon = m.status === "completed" ? icon("check") : (CATEGORY_ICON[m.category] || "学");
  const lock = m.status === "locked" ? `<span class="node-lock-badge" aria-hidden="true">${icon("lock")}</span>` : "";
  const sub = m.status === "current" && m.description ? `<p class="node-desc">${m.description}</p>` : "";
  const label = { completed: "пройден", current: "текущий", available: "доступен", locked: "закрыт" }[m.status];
  return `<button class="node ${m.status}" type="button" data-module-id="${m.id}" data-module-title="${escapeAttr(m.title)}"
      data-locked-reason="${escapeAttr(m.locked_reason || "")}" aria-label="${escapeAttr(m.title)}, ${label}">
    <span class="node-dot-wrap"><span class="node-dot">${nodeIcon}</span>${lock}</span>
    <span class="node-body">
      <span class="node-title">${m.title}</span>
      ${sub}
      <span class="node-frac">${m.introduced_words} / ${m.total_words}</span>
    </span>
    <span class="node-chevron" aria-hidden="true">${icon("chevron")}</span>
  </button>`;
}

// Лёгкий параллакс сцены Главной: небо и дальний хребет при прокрутке отстают
// от ближних слоёв — глубина без теней. Только transform, через rAF, пассивный
// слушатель; при «уменьшить движение» сцена неподвижна.
(function homeSceneParallax() {
  const scene = document.getElementById("home-scene");
  if (!scene) return;
  const layers = [[scene.querySelector(".scene-sky"), 0.38], [scene.querySelector(".scene-far"), 0.2]];
  let ticking = false;
  const update = () => {
    ticking = false;
    const still = currentView !== "home" || prefersReducedMotion();
    const y = still ? 0 : Math.min(Math.max(window.scrollY, 0), 420);
    for (const [layer, k] of layers) layer.style.transform = y ? `translate3d(0, ${(y * k).toFixed(1)}px, 0)` : "";
  };
  window.addEventListener("scroll", () => {
    if (!ticking) { ticking = true; requestAnimationFrame(update); }
  }, { passive: true });
})();

// Незаконченный урок (вышли крестиком) — на Главной вместо следующего модуля:
// ответы уже на сервере, урок продолжается с того же шага. Только в памяти
// вкладки: после перезагрузки страницы место не восстанавливается.
function hasUnfinishedRun() {
  return Boolean(lessonRun && !lessonRun.finished && lessonRun.index < lessonRun.steps.length);
}

function renderResumeCard(recommended) {
  if (!hasUnfinishedRun()) return false;
  const run = lessonRun;
  document.getElementById("continue-icon").textContent = CATEGORY_ICON[recommended.category] || "学";
  document.getElementById("continue-section-label").textContent = "Незаконченный урок";
  document.getElementById("continue-module-label").textContent = run.title;
  document.getElementById("continue-meta").textContent = `шаг ${run.index + 1} из ${run.steps.length}`;
  document.getElementById("continue-progress-fill").style.transform = `scaleX(${run.index / run.steps.length})`;
  document.getElementById("continue-reason").textContent = "Ответы сохранены — продолжите с того же места";
  const btn = document.getElementById("home-start-btn");
  btn.dataset.resume = "1";
  btn.setAttribute("aria-label", `Продолжить урок: ${run.title}`);
  document.getElementById("home-today-row").classList.add("hidden");
  return true;
}

function resumeLesson() {
  showView("lesson");
  for (const id of ["lesson-empty", "lesson-summary"]) document.getElementById(id).classList.add("hidden");
  document.getElementById("lesson-title").textContent = lessonRun.title;
  document.getElementById("lesson-active").classList.remove("hidden");
  renderLessonStep();
}

document.getElementById("home-start-btn").addEventListener("click", (e) => {
  if (e.currentTarget.dataset.resume === "1" && hasUnfinishedRun()) return resumeLesson();
  openLesson(e.currentTarget.dataset.moduleId, e.currentTarget.dataset.moduleTitle);
});

// Узлы пути: текущий/доступный открывают урок; закрытый объясняет, почему закрыт
// (подпись под путём, без всплывающих окон).
let pathHintTimer;
document.getElementById("path-sections").addEventListener("click", (e) => {
  const node = e.target.closest(".node.current, .node.available, .node.completed");
  if (node) return openLesson(node.dataset.moduleId, node.dataset.moduleTitle);
  const locked = e.target.closest(".node.locked, .chapter-preview");
  if (locked) {
    const hint = document.getElementById("path-hint");
    hint.textContent = locked.dataset.lockedReason || "Модули открываются по порядку курса.";
    hint.classList.add("visible");
    clearTimeout(pathHintTimer);
    pathHintTimer = setTimeout(() => hint.classList.remove("visible"), 3500);
  }
});

document.getElementById("home-review-btn").addEventListener("click", () => openReview());
document.getElementById("home-review-link").addEventListener("click", () => openReview());

// --- HanziWriter: анимация порядка черт + проверка написания с допуском на
// неточность (встроенный quiz() считает верную/неверную черту по направлению
// и порядку, не требуя пиксельного совпадения). Если библиотека не
// загрузилась (например нет сети до CDN) — используем свободное рисование
// на canvas как более простой фолбэк.
// HanziWriter красит штрихи фиксированными цветами по умолчанию и не знает
// о наших CSS-темах — берём актуальные токены темы при каждом рендере,
// чтобы иероглиф оставался читаемым и в тёмной, и в светлой теме.
function hanziThemeColors() {
  const css = getComputedStyle(document.documentElement);
  return {
    strokeColor: css.getPropertyValue("--ink").trim(),
    outlineColor: css.getPropertyValue("--line-strong").trim(),
    radicalColor: css.getPropertyValue("--seal").trim(),
    highlightColor: css.getPropertyValue("--seal").trim(),
  };
}

// Данные о порядке черт (159 иероглифов из текущей базы слов) захардкожены
// локально в vendor/hanzi-writer-data/ — не требуют сети в продакшене. Для
// иероглифа, которого там нет (например слово добавили позже через
// /api/import-csv), автоматически падаем обратно на CDN.
function hanziCharDataLoader(char, onComplete) {
  fetch(`vendor/hanzi-writer-data/${encodeURIComponent(char)}.json`)
    .then((res) => {
      if (!res.ok) throw new Error("not found locally");
      return res.json();
    })
    .then(onComplete)
    .catch(() => {
      fetch(`https://cdn.jsdelivr.net/npm/hanzi-writer-data@latest/${encodeURIComponent(char)}.json`)
        .then((res) => res.json())
        .then(onComplete)
        .catch(() => {}); // ни локально, ни по сети — animateCharacter()/quiz() просто не покажет иероглиф
    });
}

// ---------------------------------------------------------------------------
// Словарь
// ---------------------------------------------------------------------------

// Словарь — инструмент для изученного: по умолчанию «Изучаю» (если уже есть
// изученные слова), поиск по иероглифам, русскому и пиньиню без тонов.
const STATE_LABELS = { new: "новое", learning: "учу", review: "закрепляю", mastered: "освоено" };
const DICT_PAGE = 60;
let dictFilter = null;
let dictWords = [];
let dictShown = 0;
let dictToken = 0;

function filterParams(filter) {
  if (filter === "seen") return { seen: "true" };
  if (filter === "weak") return { weak: "true" };
  if (filter && filter.startsWith("hsk")) return { hsk: filter.slice(3) };
  return {};
}

async function loadDictionary(query) {
  const token = ++dictToken;
  if (dictFilter === null) {
    // первый вход: если изученных слов ещё нет — показываем весь курс
    try {
      const seen = await api("/api/words?seen=true");
      dictFilter = seen.length ? "seen" : "all";
    } catch (e) { dictFilter = "all"; }
  }
  document.querySelectorAll("#dict-filters .chip").forEach((c) => {
    c.classList.toggle("active", c.dataset.filter === dictFilter);
    c.setAttribute("aria-pressed", String(c.dataset.filter === dictFilter));
  });
  const params = new URLSearchParams({ q: query, ...filterParams(dictFilter) });
  const listEl = document.getElementById("dict-list");
  listEl.setAttribute("aria-busy", "true");
  // приглушаем список, только если ответ задерживается (без мигания на быстрых ответах)
  const busyTimer = setTimeout(() => listEl.classList.add("is-loading"), 150);
  let words;
  try {
    words = await api(`/api/words?${params.toString()}`);
  } catch (e) {
    clearTimeout(busyTimer);
    listEl.classList.remove("is-loading");
    listEl.removeAttribute("aria-busy");
    document.getElementById("dict-list").innerHTML = `<p class="weak-empty">Нет связи с сервером.</p>`;
    return;
  }
  if (token !== dictToken) return; // пришёл ответ на устаревший запрос
  clearTimeout(busyTimer);
  listEl.classList.remove("is-loading");
  listEl.removeAttribute("aria-busy");
  // Без поиска список идёт группами по уровню HSK (заголовок вместо «HSK N» в
  // каждой строке); результаты поиска — одной группой в порядке сервера.
  dictGrouped = !query;
  dictWords = dictGrouped ? words.slice().sort((a, b) => (a.hsk ?? 99) - (b.hsk ?? 99)) : words;
  dictShown = 0;
  document.getElementById("dict-list").innerHTML = "";
  const emptyText = {
    seen: "Здесь появятся слова, которые вы уже проходили в уроках.",
    weak: "Слабых слов нет: сюда попадают слова, где часто бывают ошибки.",
  }[dictFilter] || "Ничего не найдено.";
  // при группировке счётчики стоят в заголовках групп — общий не дублируем
  document.getElementById("dict-count").textContent = words.length && !dictGrouped
    ? `${words.length} ${plural(words.length, "слово", "слова", "слов")}` : "";
  if (!words.length) {
    document.getElementById("dict-list").innerHTML = `<p class="weak-empty">${query ? "Ничего не найдено." : emptyText}</p>`;
    document.getElementById("dict-more").classList.add("hidden");
    return;
  }
  renderMoreWords();
}

// Слово, которое уже проходили, но SM-2 сбросил (забыто), — «повторить», а не пусто.
function dictStateChip(w) {
  if (w.state !== "new") return `<span class="dict-state state-${w.state}">${STATE_LABELS[w.state]}</span>`;
  if (w.accuracy !== null && w.accuracy !== undefined) return `<span class="dict-state state-forgotten">забыто</span>`;
  return "";
}

let dictGrouped = false;
function dictRow(w) {
  return `<button class="dict-item" type="button" data-word-id="${w.id}">
      <span class="dict-h" data-len="${Math.min([...w.hanzi].length, 4)}">${w.hanzi}</span>
      <span class="dict-mid"><span class="dict-p">${w.pinyin}</span><span class="dict-t">${w.translation}</span></span>
      <span class="dict-side">${dictGrouped ? "" : `<span class="dict-lvl">HSK ${w.hsk}</span>`}${dictStateChip(w)}</span>
    </button>`;
}

function renderMoreWords() {
  const list = document.getElementById("dict-list");
  const chunk = dictWords.slice(dictShown, dictShown + DICT_PAGE);
  for (const w of chunk) {
    const key = dictGrouped ? String(w.hsk ?? "–") : "all";
    let group = list.lastElementChild;
    if (!group || !group.classList.contains("dict-group") || group.dataset.key !== key) {
      const n = dictGrouped ? dictWords.filter((x) => String(x.hsk ?? "–") === key).length : 0;
      list.insertAdjacentHTML("beforeend", `<section class="dict-group" data-key="${key}">${dictGrouped
        ? `<h3 class="dict-group-head"><span class="dict-group-title">HSK ${key}</span><span class="dict-group-count">${n} ${plural(n, "слово", "слова", "слов")}</span></h3>` : ""}
        <div class="dict-rows"></div></section>`);
      group = list.lastElementChild;
    }
    group.querySelector(".dict-rows").insertAdjacentHTML("beforeend", dictRow(w));
  }
  dictShown += chunk.length;
  document.getElementById("dict-more").classList.toggle("hidden", dictShown >= dictWords.length);
}

document.getElementById("dict-more").addEventListener("click", renderMoreWords);
document.getElementById("dict-filters").addEventListener("click", (e) => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  dictFilter = chip.dataset.filter;
  loadDictionary(document.getElementById("dict-search").value.trim());
});
document.getElementById("dict-list").addEventListener("click", (e) => {
  const item = e.target.closest(".dict-item");
  if (item) openWordSheet(item.dataset.wordId);
});

let dictDebounce;
document.getElementById("dict-search").addEventListener("input", (e) => {
  clearTimeout(dictDebounce);
  dictDebounce = setTimeout(() => loadDictionary(e.target.value.trim()), 220);
});

// --- Карточка слова: нижний лист (детали, прогресс, примеры, звук)
async function openWordSheet(wordId) {
  let w;
  try { w = await api(`/api/words/${wordId}`); } catch (e) { return; }
  const body = document.getElementById("word-sheet-body");
  const pr = w.progress || {};
  const accuracy = pr.attempts ? `${Math.round((100 * pr.correct) / pr.attempts)}% верно из ${pr.attempts}` : "ещё не проходили";
  const next = pr.next_review ? formatDue(pr.next_review) : null;
  body.innerHTML = `
    <div class="sheet-head">
      <p class="sheet-hanzi" id="sheet-hanzi">${w.hanzi}</p>
      <div><p class="sheet-pinyin">${w.pinyin}</p><p class="sheet-tr">${w.translation}</p></div>
    </div>
    <div class="sheet-facts">
      <span>HSK ${w.hsk}${w.module ? ` · ${w.module.title}` : ""}</span>
      <span>${STATE_LABELS[w.state] || ""}${w.state !== "new" ? ` · ${accuracy}` : ""}</span>
      ${next ? `<span>Следующее повторение — ${next}</span>` : ""}
    </div>
    ${w.components ? `<p class="sheet-label">Состав</p><p class="sheet-text">${w.components}</p>` : ""}
    ${w.examples && w.examples.length ? `<p class="sheet-label">Примеры</p>${w.examples.slice(0, 3).map((ex) => `
      <div class="sheet-example"><p class="study-example-cn">${ex.sentence_cn}</p>
      ${ex.pinyin ? `<p class="study-example-py">${ex.pinyin}</p>` : ""}<p class="study-example-ru">${ex.sentence_ru}</p></div>`).join("")}` : ""}`;
  const audio = audioButton(w.hanzi, w.id);
  audio.classList.add("sheet-audio");
  body.querySelector(".sheet-head").appendChild(audio);
  showSheet(true);
}

// --- Нижний лист: выезжает снизу и уходит туда же (симметричный путь), страница
// под ним не прокручивается, фокус возвращается на то, что его открыло. Лист
// можно смахнуть вниз: он идёт за пальцем 1:1, вверх — с сопротивлением, а
// решение «закрыть или вернуть» принимается по скорости и пройденному пути.
let sheetReturnFocus = null;

function showSheet(open) {
  const sheet = document.getElementById("word-sheet");
  const backdrop = document.getElementById("word-sheet-backdrop");
  if (open) {
    sheetReturnFocus = document.activeElement;
    sheet.style.transform = "";
    sheet.classList.add("is-open");
    backdrop.classList.add("is-open");
    sheet.setAttribute("aria-hidden", "false");
    document.body.classList.add("sheet-open");
    document.getElementById("word-sheet-close").focus({ preventScroll: true });
  } else {
    if (!sheet.classList.contains("is-open")) return;
    sheet.classList.remove("is-open");
    backdrop.classList.remove("is-open");
    sheet.setAttribute("aria-hidden", "true");
    document.body.classList.remove("sheet-open");
    stopAllAudio();
    if (sheetReturnFocus && document.contains(sheetReturnFocus)) sheetReturnFocus.focus({ preventScroll: true });
  }
}

function closeWordSheet() {
  const sheet = document.getElementById("word-sheet");
  sheet.style.transform = ""; // уходит из текущего положения: переход стартует с него
  showSheet(false);
}
document.getElementById("word-sheet-close").addEventListener("click", closeWordSheet);
document.getElementById("word-sheet-backdrop").addEventListener("click", closeWordSheet);
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeWordSheet(); });

(function sheetDrag() {
  const sheet = document.getElementById("word-sheet");
  const handle = document.getElementById("word-sheet-handle");
  let startY = 0, lastY = 0, lastT = 0, velocity = 0, dragging = false, pointerId = null;
  // сопротивление при тяге вверх: чем дальше, тем меньше лист следует за пальцем
  const rubberband = (over, dim) => (over * dim * 0.55) / (dim + 0.55 * Math.abs(over));
  handle.addEventListener("pointerdown", (e) => {
    if (!sheet.classList.contains("is-open")) return;
    dragging = true;
    pointerId = e.pointerId;
    handle.setPointerCapture(pointerId);
    startY = lastY = e.clientY;
    lastT = performance.now();
    velocity = 0;
    sheet.classList.add("is-dragging");
  });
  handle.addEventListener("pointermove", (e) => {
    if (!dragging || e.pointerId !== pointerId) return;
    const now = performance.now();
    const dt = Math.max(1, now - lastT);
    velocity = 0.8 * ((e.clientY - lastY) / dt) + 0.2 * velocity; // px/ms, сглаженная
    lastY = e.clientY;
    lastT = now;
    const dy = e.clientY - startY;
    const offset = dy >= 0 ? dy : rubberband(dy, sheet.offsetHeight);
    sheet.style.transform = `translateY(${offset}px)`;
  });
  const end = (e) => {
    if (!dragging || e.pointerId !== pointerId) return;
    dragging = false;
    sheet.classList.remove("is-dragging");
    const dy = lastY - startY;
    // по направлению скорости, а не только по положению: быстрый короткий смах вниз закрывает
    const close = velocity > 0.45 || (velocity > -0.1 && dy > sheet.offsetHeight * 0.3);
    if (close) closeWordSheet();
    else sheet.style.transform = ""; // возврат из текущего положения
  };
  handle.addEventListener("pointerup", end);
  handle.addEventListener("pointercancel", end);
})();

// ---------------------------------------------------------------------------
// Профиль
// ---------------------------------------------------------------------------

const SKILL_GLYPH = {
  vocabulary: "词", characters: "字", pinyin: "拼", tones: "调",
  listening: "听", writing: "写", grammar: "语", speaking: "说",
};
const SKILL_NAME_RU = {
  vocabulary: "Словарь", characters: "Иероглифы", pinyin: "Пиньинь", tones: "Тоны",
  listening: "Аудирование", writing: "Письмо", grammar: "Грамматика", speaking: "Речь",
};

async function loadProfile() {
  let profile, stats;
  const errorBox = document.getElementById("profile-error");
  try {
    [profile, stats] = await Promise.all([api("/api/profile"), api("/api/statistics?activity_days=30")]);
  } catch (e) {
    errorBox.classList.remove("hidden");
    return;
  }
  errorBox.classList.add("hidden");

  renderAccount(profile.account);
  renderProfileStatusRow(profile);
  renderProfileOverall(profile);
  renderSkills(stats.skills);
  renderWordStates(stats.word_states, stats.lessons.completed_count);
  currentActivityFull = stats.activity;
  // Столбики из одного-двух дней ничего не говорят — до трёх активных дней только подпись.
  const activeDays = stats.activity.filter((d) => d.count > 0).length;
  const enoughActivity = activeDays >= 3;
  document.getElementById("week-chart").classList.toggle("hidden", !enoughActivity);
  document.getElementById("activity-period-toggle").classList.toggle("hidden", !enoughActivity);
  document.getElementById("activity-note").classList.toggle("hidden", enoughActivity);
  if (enoughActivity) renderActivityChart(stats.activity.slice(-7));
  renderTrend(stats.mastery_trend);
  renderReviewBlock(stats.word_states.due_now, stats.review_consistency);
  renderFocusBlock(stats.skills, stats.weak_words);
  renderRecentLessons(stats.lessons.recent);
}

const MONTHS_GEN = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля",
  "августа", "сентября", "октября", "ноября", "декабря"];

let currentAccount = null;

function renderAccount(acc) {
  currentAccount = acc;
  const nameEl = document.getElementById("account-name");
  nameEl.textContent = acc.username ? `@${acc.username}` : "Имя не задано";
  nameEl.classList.toggle("is-empty", !acc.username);
  document.getElementById("account-public-id").textContent = `ID ${acc.public_id}`;
  document.getElementById("account-edit").textContent = acc.username ? "Изменить" : "Задать имя";
  // статус Premium приходит с сервера как готовая подпись; клиент его не вычисляет
  const badge = document.getElementById("account-premium");
  badge.textContent = acc.premium.active ? acc.premium.label : "";
  badge.classList.toggle("hidden", !acc.premium.active);
  const [y, m, d] = (acc.created_at || "").split("-").map(Number);
  document.getElementById("account-meta").textContent =
    y ? `С нами с ${d} ${MONTHS_GEN[m - 1]} ${y}` : "";
}

function toggleUsernameForm(open) {
  document.getElementById("username-form").classList.toggle("hidden", !open);
  document.getElementById("account-edit").classList.toggle("hidden", open);
  document.getElementById("username-error").textContent = "";
  if (open) {
    const input = document.getElementById("username-input");
    input.value = (currentAccount && currentAccount.username) || "";
    input.focus();
  }
}

document.getElementById("account-edit").addEventListener("click", () => toggleUsernameForm(true));
document.getElementById("username-cancel").addEventListener("click", () => toggleUsernameForm(false));
document.getElementById("username-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const username = document.getElementById("username-input").value.trim();
  const res = await apiSend("/api/me/username", { method: "PUT", body: JSON.stringify({ username }) });
  if (!res.ok) {
    document.getElementById("username-error").textContent = (res.data && res.data.detail) || "Не удалось сохранить";
    return;
  }
  renderAccount(res.data);
  toggleUsernameForm(false);
});

document.getElementById("account-public-id").addEventListener("click", async (event) => {
  if (!currentAccount || !navigator.clipboard) return;
  try {
    await navigator.clipboard.writeText(currentAccount.public_id);
    event.currentTarget.textContent = "Скопировано";
    setTimeout(() => renderAccount(currentAccount), 1200);
  } catch (e) { /* нет доступа к буферу — ничего страшного */ }
});

function renderProfileStatusRow(p) {
  // Главный показатель профиля — прогресс текущего уровня HSK (первый
  // незавершённый): одна крупная цифра; серия и рекорд — вторичной строкой.
  const levels = p.by_level || [];
  const cur = levels.find((l) => l.learned < l.total) || levels[levels.length - 1];
  const pct = cur && cur.total ? Math.round((100 * cur.learned) / cur.total) : 0;
  const days = (n) => plural(n, "день", "дня", "дней");
  document.getElementById("profile-status-row").innerHTML = cur ? `
    <p class="mark-label">HSK ${cur.hsk} · прогресс уровня</p>
    <p class="profile-hero-value">${pct}<small>%</small></p>
    <p class="profile-hero-sub">${cur.learned} из ${cur.total} слов уровня изучено</p>
    <p class="profile-hero-streak">${icon("flame")}<span><b>${p.streak}</b> ${days(p.streak)} подряд</span>
      <span class="profile-hero-dot"></span><span>рекорд <b>${p.longest_streak}</b></span></p>` : "";
}

function renderProfileOverall(p) {
  const pct = p.total_words ? Math.round((100 * p.learned_count) / p.total_words) : 0;
  document.getElementById("profile-overall-frac").textContent = `${p.learned_count} / ${p.total_words} слов`;
  document.getElementById("profile-overall-fill").style.width = `${pct}%`;
  document.getElementById("profile-levels").innerHTML = p.by_level
    .map((lvl) => {
      const lvlPct = lvl.total ? Math.round((100 * lvl.learned) / lvl.total) : 0;
      return `<div class="profile-level-row">
        <b>HSK ${lvl.hsk}</b>
        <div class="level-bar"><div class="level-bar-fill" style="width:${lvlPct}%"></div></div>
        <span class="frac">${lvl.learned}/${lvl.total}</span>
      </div>`;
    })
    .join("");
}

// Навыки с данными — строками с полосой; без данных — одной строкой, а не
// восемью «пока недостаточно данных». «Речь» не показываем: упражнений на
// произношение пока нет (воспроизведение звука — не оценка произношения).
function renderSkills(skills) {
  const shown = skills.filter((s) => s.skill !== "speaking");
  const empty = shown.filter((s) => s.no_data).map((s) => SKILL_NAME_RU[s.skill] || s.skill);
  const withData = shown.filter((s) => !s.no_data);
  const emptyLine = empty.length
    ? `<p class="skill-empty-line">${withData.length ? "Ещё нет данных" : "Появятся после первых уроков"}: ${empty.join(", ").toLowerCase()}</p>` : "";
  document.getElementById("skills-list").innerHTML = withData
    .map((s) => {
      const glyph = SKILL_GLYPH[s.skill] || "字";
      const name = SKILL_NAME_RU[s.skill] || s.skill;
      if (s.no_data) {
        return `<div class="skill-row">
          <span class="skill-glyph">${glyph}</span>
          <div class="skill-body">
            <div class="skill-body-head"><span class="skill-name">${name}</span></div>
            <span class="skill-no-data">Пока недостаточно данных</span>
          </div>
        </div>`;
      }
      return `<div class="skill-row has-data">
        <span class="skill-glyph">${glyph}</span>
        <div class="skill-body">
          <div class="skill-body-head">
            <span class="skill-name">${name}</span>
            <span class="skill-meta">верно ${Math.round(s.accuracy)}% из ${s.attempts} ${plural(s.attempts, "ответа", "ответов", "ответов")}</span>
          </div>
          <div class="skill-bar"><div class="skill-bar-fill" style="width:${Math.round(s.accuracy)}%"></div></div>
        </div>
      </div>`;
    })
    .join("") + emptyLine;
}

function renderWordStates(ws, lessonsCompleted) {
  const total = ws.total_encountered || 1;
  const seg = (n) => Math.max(0, Math.round((100 * n) / total));
  document.getElementById("word-states-bar").innerHTML = `
    <span class="ws-new" style="width:${seg(ws.new)}%"></span>
    <span class="ws-learning" style="width:${seg(ws.learning)}%"></span>
    <span class="ws-review" style="width:${seg(ws.review)}%"></span>
    <span class="ws-mastered" style="width:${seg(ws.mastered)}%"></span>`;
  const legend = [
    ["ws-new", "Новые", ws.new], ["ws-learning", "Изучаются", ws.learning],
    ["ws-review", "Повторяются", ws.review], ["ws-mastered", "Освоены", ws.mastered],
  ];
  document.getElementById("word-states-legend").innerHTML = legend
    .map(([cls, label, n]) => `<span class="ws-legend-item"><span class="ws-legend-dot ${cls}"></span>${label} <b>${n}</b></span>`)
    .join("");
  document.getElementById("learning-inline-stats").innerHTML =
    `<span>На повторении сейчас: <b>${ws.due_now}</b></span><span>Уроков завершено: <b>${lessonsCompleted}</b></span>`;
}

function renderActivityChart(days) {
  const weekdayShort = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
  const maxCount = Math.max(1, ...days.map((d) => d.count));
  document.getElementById("week-chart").innerHTML = days
    .map((d) => {
      const dow = weekdayShort[new Date(d.day + "T00:00:00").getDay()];
      const heightPct = Math.max(6, Math.round((d.count / maxCount) * 100));
      return `<div class="week-bar-wrap">
        <div class="week-bar ${d.count > 0 ? "has-activity" : ""}" style="height:${heightPct}%" title="${d.count}"></div>
        <span class="week-bar-label">${dow}</span>
      </div>`;
    })
    .join("");
}

let currentActivityFull = [];
document.querySelectorAll("#activity-period-toggle .period-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#activity-period-toggle .period-btn").forEach((b) => {
      b.classList.toggle("active", b === btn);
      b.setAttribute("aria-pressed", String(b === btn));
    });
    const days = Number(btn.dataset.days);
    renderActivityChart(days === 30 ? currentActivityFull : currentActivityFull.slice(-7));
  });
});

function renderTrend(trend) {
  const note = document.getElementById("trend-note");
  const chart = document.getElementById("trend-chart");
  // средний mastery по дням — только по навыкам, у которых в этот день есть снимок
  const byDay = {};
  for (const r of trend) (byDay[r.snapshotted_at] ||= []).push(r.score);
  const days = Object.keys(byDay).sort();
  if (days.length === 0) {
    chart.innerHTML = "";
    note.textContent = "История появится по мере занятий — снимок делается при каждом повторении.";
    return;
  }
  if (days.length === 1) {
    chart.innerHTML = "";
    note.textContent = "Пока только один снимок — динамика станет видна после нескольких дней занятий.";
    return;
  }
  const avgs = days.map((d) => byDay[d].reduce((a, b) => a + b, 0) / byDay[d].length);
  const w = 300, h = 64, pad = 6;
  const min = Math.min(...avgs), max = Math.max(...avgs);
  const range = max - min || 1;
  const x = (i) => pad + (i * (w - 2 * pad)) / (days.length - 1);
  const y = (v) => h - pad - ((v - min) / range) * (h - 2 * pad);
  const pathD = avgs.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const dots = avgs.map((v, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(v).toFixed(1)}" r="2.5"></circle>`).join("");
  chart.innerHTML = `<svg class="trend-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><path class="line" d="${pathD}"/>${dots}</svg>`;
  note.textContent = `Средняя оценка навыков: ${Math.round(avgs[0])}% → ${Math.round(avgs[avgs.length - 1])}%`;
}

function renderReviewBlock(dueNow, consistency) {
  const root = document.getElementById("review-block");
  const dueRow = `<div class="review-row">
    <span class="review-row-label">Ждут повторения сейчас</span>
    ${dueNow > 0
      ? `<button class="review-cta" id="profile-review-cta">${dueNow} · повторить</button>`
      : `<span class="review-neutral">Ничего не просрочено</span>`}
  </div>`;
  const consistencyRow = consistency.planned > 0
    ? `<div class="review-row">
        <span class="review-row-label">Дисциплина повторения</span>
        <span class="review-row-value">${consistency.completed} / ${consistency.planned} (${consistency.completion_rate}%)</span>
      </div>`
    : "";  // нет данных — строку не показываем; общая подпись — в блоке фокуса
  root.innerHTML = dueRow + consistencyRow;
  const cta = document.getElementById("profile-review-cta");
  if (cta) cta.addEventListener("click", () => openReview());
}

function renderFocusBlock(skills, weakWords) {
  const root = document.getElementById("focus-block");
  const withData = skills.filter((s) => !s.no_data);
  const parts = [];
  if (withData.length >= 2) {
    const weakest = withData.reduce((a, b) => (a.score < b.score ? a : b));
    parts.push(`<div class="focus-item"><span class="focus-label">Стоит подтянуть</span>
      <span class="focus-value">${SKILL_NAME_RU[weakest.skill] || weakest.skill} — ${weakest.score}%</span></div>`);
  } else if (weakWords.length === 0) {
    parts.push(`<p class="focus-neutral">Что подтянуть и как идёт повторение — станет видно после нескольких уроков.</p>`);
  }
  // «N слов ждут повторения» уже есть строкой выше (renderReviewBlock) — не дублируем.
  if (weakWords.length > 0) {
    parts.push(`<div class="focus-item"><span class="focus-label">Слабые слова</span><div>${
      weakWords.slice(0, 5).map((w) =>
        `<button class="weak-word-item" type="button" data-hanzi="${w.hanzi}" aria-label="${w.hanzi}, верно ${w.accuracy}% — открыть в словаре">
          <span class="h">${w.hanzi}</span><span class="p">${w.pinyin}</span>
          <span class="t">${w.translation}</span><span class="acc">${w.accuracy}%</span>
        </button>`).join("")
    }</div></div>`);
  }
  root.innerHTML = parts.join("");
  root.querySelectorAll(".weak-word-item").forEach((el) => {
    el.addEventListener("click", () => {
      // значение в поле записываем ДО перехода: showView('dict') читает его (ловушка №9)
      document.getElementById("dict-search").value = el.dataset.hanzi;
      dictFilter = "all"; // фильтр «Изучаю/Слабые» мог бы скрыть слово
      showView("dict");
    });
  });
}

function renderRecentLessons(recent) {
  const section = document.getElementById("recent-lessons-section");
  const root = document.getElementById("recent-lessons-list");
  if (!recent.length) {
    section.classList.add("hidden");
    return;
  }
  section.classList.remove("hidden");
  root.innerHTML = recent.slice(0, 5)
    .map((r) => `<div class="recent-lesson-row">
      <span class="recent-lesson-title">${r.module_title || "Повторение"}</span>
      <span class="recent-lesson-meta">+${r.new_words_count} новых · ${r.review_words_count} повторено · ${r.exercises_count} упражнений</span>
    </div>`)
    .join("");
}

// ---------------------------------------------------------------------------
// Lesson Runner: один экран = одна задача.
// Шаги приходят с сервера (Planner) БЕЗ верных ответов; клиент присылает только
// действие пользователя (индекс варианта, плитки, набранный пиньинь, самооценку),
// а верно ли это — решает сервер (POST /api/sessions/{id}/attempts). Рендереры
// по типу шага зеркалят реестр backend/engine/exercise_types.py: новый тип
// упражнения = новая функция в STEP_RENDERERS.
// ---------------------------------------------------------------------------

const SKILL_LABELS = {
  characters: "иероглифы", listening: "аудирование", pinyin: "пиньинь",
  tones: "тоны", writing: "письмо", vocabulary: "слова", grammar: "фразы",
};
const HANDWRITING_MAX_MISTAKES = 2;

let lessonRun = null;

function openLesson(moduleId, moduleTitle) {
  return openRun(`/api/lessons/${moduleId}/start`, moduleTitle, "В этом модуле пока нет материала для урока.");
}

function openReview() {
  return openRun("/api/review/start", "Повторение", "Сейчас нечего повторять — загляните позже.");
}

// Защита от двойного запуска: два быстрых нажатия на карточку не создают две
// сессии урока (вторая подменила бы план уже идущего урока).
let runStarting = false;

async function openRun(startUrl, fallbackTitle, emptyText) {
  if (runStarting) return;
  runStarting = true;
  try {
    await startRun(startUrl, fallbackTitle, emptyText);
  } finally {
    runStarting = false;
  }
}

async function startRun(startUrl, fallbackTitle, emptyText) {
  showView("lesson");
  for (const id of ["lesson-empty", "lesson-summary"]) {
    document.getElementById(id).classList.add("hidden");
  }
  showLessonSkeleton(fallbackTitle);
  let plan;
  try {
    plan = await api(startUrl, { method: "POST" });
  } catch (e) {
    document.getElementById("lesson-active").classList.add("hidden");
    document.getElementById("lesson-empty-text").textContent = "Не удалось загрузить урок — проверьте соединение.";
    document.getElementById("lesson-empty").classList.remove("hidden");
    return;
  }
  if (!plan.steps.length) {
    document.getElementById("lesson-active").classList.add("hidden");
    document.getElementById("lesson-empty-text").textContent = emptyText;
    document.getElementById("lesson-empty").classList.remove("hidden");
    return;
  }
  lessonRun = {
    sessionId: plan.session_id, title: (plan.lesson && plan.lesson.title) || plan.module.title || fallbackTitle,
    steps: plan.steps, index: 0, busy: false, stepShownAt: 0, lesson: plan.lesson || null,
  };
  document.getElementById("lesson-title").textContent = lessonRun.title;
  document.getElementById("lesson-active").classList.remove("hidden");
  if (lessonRun.lesson) renderLessonIntro(lessonRun.lesson);
  else renderLessonStep();
}

// Начало урока со сценарием темы: что будем уметь после урока, короткое
// введение тренера и слова урока. Не шаг: ничего не оценивается.
function renderLessonIntro(lesson) {
  document.getElementById("lesson-active").removeAttribute("aria-busy");
  document.getElementById("lesson-fraction").textContent = `0 / ${lessonRun.steps.length}`;
  document.getElementById("lesson-progress-fill").style.transform = "scaleX(0)";
  const root = document.getElementById("lesson-step");
  root.innerHTML = "";
  resetFooter();
  const card = el("div", "lesson-topic");
  card.append(el("p", "mark-label", lesson.mode === "practice" ? "Практика темы" : "Тема урока"),
    el("h2", "topic-title", lesson.title), el("p", "topic-goal", lesson.goal));
  if (lesson.intro) card.append(el("p", "topic-intro", lesson.intro));
  if (lesson.words && lesson.words.length) {
    const list = el("div", "topic-words");
    lesson.words.forEach((w) => {
      const item = el("div", `topic-word${w.new ? "" : " is-known"}`);
      item.append(el("span", "topic-word-h", w.hanzi), el("span", "topic-word-p", w.pinyin), el("span", "topic-word-t", w.translation));
      list.appendChild(item);
    });
    card.append(el("p", "study-label", lesson.mode === "practice" ? "Слова уже знакомы — применяем их" : "Новые слова"), list);
  }
  if (lesson.can_do && lesson.can_do.length) {
    const ul = el("ul", "topic-cando");
    lesson.can_do.forEach((c) => ul.appendChild(el("li", "", c)));
    card.append(el("p", "study-label", "После урока вы сможете"), ul);
  }
  root.appendChild(card);
  card.setAttribute("tabindex", "-1");
  card.focus({ preventScroll: true });
  setAction("Начать урок", renderLessonStep);
}

const STAGE_LABELS = {
  new: "Новое слово", practice: "Практика", context: "Во фразе", recall: "По памяти",
  production: "Перевод", speaking: "Произношение", review: "Повторение",
};

// Пока сервер собирает урок — каркас экрана (шапка, карточка, кнопка) вместо
// пустоты; без мерцающей анимации.
function showLessonSkeleton(title) {
  document.getElementById("lesson-title").textContent = title || "Урок";
  document.getElementById("lesson-fraction").textContent = "";
  document.getElementById("lesson-progress-fill").style.transform = "scaleX(0)";
  document.getElementById("lesson-step").innerHTML = `<div class="card lesson-card lesson-skeleton" aria-hidden="true">
    <span class="sk sk-label"></span><span class="sk sk-hanzi"></span><span class="sk sk-line"></span>
    <span class="sk sk-option"></span><span class="sk sk-option"></span></div>`;
  resetFooter();
  document.getElementById("lesson-active").classList.remove("hidden");
  document.getElementById("lesson-active").setAttribute("aria-busy", "true");
}

function renderLessonStep() {
  document.getElementById("lesson-active").removeAttribute("aria-busy");
  const run = lessonRun;
  const step = run.steps[run.index];
  document.getElementById("lesson-fraction").textContent = `${run.index + 1} / ${run.steps.length}`;
  document.getElementById("lesson-progress-fill").style.transform = `scaleX(${run.index / run.steps.length})`;
  const bar = document.getElementById("lesson-progress");
  bar.setAttribute("aria-valuemax", String(run.steps.length));
  bar.setAttribute("aria-valuenow", String(run.index));
  bar.setAttribute("aria-valuetext", `шаг ${run.index + 1} из ${run.steps.length}`);
  const root = document.getElementById("lesson-step");
  root.innerHTML = "";
  resetFooter();
  run.stepShownAt = performance.now();
  stopAllAudio();
  window.scrollTo(0, 0);
  const renderer = STEP_RENDERERS[step.type];
  if (!renderer) return advanceLesson(); // неизвестный тип — не блокируем урок
  // где я в уроке и почему это задание: этап + причина (слабое слово, по расписанию…)
  if (step.stage && STAGE_LABELS[step.stage] && step.stage !== "new") {   // у карточки нового слова своя подпись
    const ctx = el("p", `step-context stage-${step.stage}`);
    ctx.appendChild(el("span", "step-stage", STAGE_LABELS[step.stage]));
    if (step.reason && step.stage !== "new") ctx.appendChild(el("span", "step-reason", step.reason));
    root.appendChild(ctx);
  }
  renderer(root, step);
  // размер главного иероглифа зависит от длины слова (см. style.css, data-len)
  root.querySelectorAll(".lesson-prompt:not(.lesson-prompt-sentence), .study-hanzi").forEach((n) => {
    n.dataset.len = Math.min([...n.textContent.trim()].length, 4);
  });
  // Фокус — на новый шаг: скринридер читает задание, клавиатура начинает с него
  // (иначе фокус остаётся на скрытой кнопке «Дальше» и теряется).
  const card = root.querySelector(".lesson-card") || root.firstElementChild;
  if (card) {
    card.setAttribute("tabindex", "-1");
    card.focus({ preventScroll: true });
  }
}

function advanceLesson() {
  lessonRun.index += 1;
  if (lessonRun.index >= lessonRun.steps.length) return finishLesson();
  renderLessonStep();
}

// --- Нижняя зона шага: обратная связь + одна главная кнопка. Высота
// зарезервирована заранее, поэтому ответ не сдвигает экран.
function resetFooter() {
  const footer = document.getElementById("lesson-footer");
  footer.className = "lesson-footer";
  document.getElementById("lesson-feedback-title").textContent = "";
  document.getElementById("lesson-feedback-text").textContent = "";
  const btn = document.getElementById("lesson-action");
  btn.textContent = "Дальше";
  btn.disabled = false;
  btn.classList.add("invisible");
  btn.classList.remove("is-quiet");
  btn.onclick = null;
}

function setAction(label, handler, { enabled = true } = {}) {
  const btn = document.getElementById("lesson-action");
  btn.textContent = label;
  btn.disabled = !enabled;
  btn.classList.remove("invisible");
  btn.onclick = handler;
  return btn;
}

function showFeedback(res, { correctTitle = "Верно", wrongTitle = "Не совсем" } = {}) {
  const footer = document.getElementById("lesson-footer");
  footer.className = `lesson-footer ${res.correct ? "is-ok" : "is-bad"}`;
  const title = document.getElementById("lesson-feedback-title");
  title.textContent = res.correct ? correctTitle : wrongTitle;
  if (res.correct) title.insertAdjacentHTML("afterbegin", icon("check"));
  const parts = [];
  if (!res.correct) parts.push(res.explanation || (res.expected ? `Правильно: ${res.expected}` : ""));
  if (res.appended_step) parts.push("Это слово ещё раз встретится в конце урока.");
  document.getElementById("lesson-feedback-text").textContent = parts.filter(Boolean).join(" ");
  setAction("Дальше", advanceLesson);
  document.getElementById("lesson-action").focus({ preventScroll: true });
}

// Ответ не дошёл до сервера — он не сохранён; шаг показывается заново.
function showNetworkError() {
  const footer = document.getElementById("lesson-footer");
  footer.className = "lesson-footer is-bad";
  document.getElementById("lesson-feedback-title").textContent = "Нет связи с сервером";
  document.getElementById("lesson-feedback-text").textContent = "Ответ не сохранён. Попробуйте ещё раз.";
  setAction("Повторить шаг", renderLessonStep);
}

// Ответ уходит на сервер; правильность и объяснение приходят оттуда.
async function sendAnswer(step, answer) {
  const run = lessonRun;
  if (run.busy) return null;
  run.busy = true;
  const response_ms = run.stepShownAt ? Math.round(performance.now() - run.stepShownAt) : null;
  try {
    const res = await apiSend(`/api/sessions/${run.sessionId}/attempts`, {
      method: "POST", body: JSON.stringify({ step_index: step.index, answer, response_ms }),
    });
    if (!res.ok) throw new Error(res.data && res.data.detail);
    if (res.data.appended_step && !run.steps.some((s) => s.index === res.data.appended_step.index)) {
      run.steps.push(res.data.appended_step);
      document.getElementById("lesson-fraction").textContent = `${run.index + 1} / ${run.steps.length}`;
    }
    return res.data;
  } catch (e) {
    showNetworkError();
    return null;
  } finally {
    run.busy = false;
  }
}

// Иконки: один набор линейных SVG вместо эмодзи (эмодзи рисуются по-разному на разных
// платформах и не красятся токенами). Цвет — currentColor, размер — 1em (.icon).
const ICON_PATHS = {
  speaker: '<path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/>',
  flame: '<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 0 1-10 0c0-2.2 1-3.6 2.2-4.8.3 1.5 1 2.6 2.3 3C11 9 11 6 12 3z"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  check: '<path d="M5 12.5 10 17.5 19 7"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  chevron: '<path d="M9 6l6 6-6 6"/>',
  back: '<path d="M15 6l-6 6 6 6"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
};
function icon(name) {
  return `<svg class="icon icon-${name}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ICON_PATHS[name]}</svg>`;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = text;
  return node;
}

function lessonCard(root, extraClass = "") {
  const card = el("div", `card lesson-card ${extraClass}`.trim());
  root.appendChild(card);
  return card;
}

function audioButton(text, wordId, big = false) {
  const b = el("button", big ? "btn-audio btn-audio-big" : "btn-audio");
  b.innerHTML = icon("speaker");
  b.type = "button";
  b.setAttribute("aria-label", "Прослушать");
  b.addEventListener("click", (e) => { e.stopPropagation(); playAudio(text, wordId, b); });
  return b;
}

// Пиньинь «по запросу»: в задании на чтение подсказка не показывается сразу.
function pinyinToggle(container, pinyin) {
  if (!pinyin) return;
  const line = el("p", "lesson-pinyin-line hidden", pinyin);
  const btn = el("button", "link-btn", "Показать пиньинь");
  btn.type = "button";
  btn.addEventListener("click", () => { line.classList.remove("hidden"); btn.remove(); });
  container.append(btn, line);
  return line;
}

const STEP_RENDERERS = {
  introduction(root, step) {
    const p = step.payload;
    const card = lessonCard(root, "intro-card");
    card.appendChild(el("p", "practice-prompt-label", "Новое слово"));
    const audio = audioButton(p.hanzi, step.word_id);
    card.append(audio, el("p", "study-hanzi", p.hanzi), el("p", "study-pinyin", p.pinyin),
      el("p", "study-translation", p.translation));
    if (p.note) {
      const b = el("div", "study-block");
      b.append(el("p", "study-label", "Как запомнить"), el("p", "study-note", p.note));
      card.appendChild(b);
    } else if (p.components) {
      const b = el("div", "study-block");
      b.append(el("p", "study-label", "Состав иероглифа"), el("p", "study-components", p.components));
      card.appendChild(b);
    }
    if (p.example_cn) {
      const b = el("div", "study-block");
      const ex = el("div", "study-example");
      const row = el("div", "study-example-row");
      row.append(el("p", "study-example-cn", p.example_cn), audioButton(p.example_cn, null));
      ex.append(row);
      if (p.example_pinyin) ex.append(el("p", "study-example-py", p.example_pinyin));
      ex.append(el("p", "study-example-ru", p.example_ru || ""));
      b.append(el("p", "study-label", "Пример"), ex);
      card.appendChild(b);
    }
    playAudio(p.hanzi, step.word_id, audio);
    // «Я это уже знаю»: не пропуск, а замена упражнений на слово одной проверкой
    if (step.role === "new") {
      const known = el("button", "link-btn known-btn", "Я это уже знаю");
      known.type = "button";
      known.addEventListener("click", () => claimKnown(step, known));
      card.appendChild(known);
    }
    setAction("Дальше", async () => {
      const res = await sendAnswer(step, null);
      if (res) advanceLesson();
    });
  },

  recall(root, step) {
    const p = step.payload;
    const card = lessonCard(root);
    card.appendChild(el("p", "practice-prompt-label", "Вспомните слово"));
    const face = el("button", "card-face");
    face.type = "button";
    const reveal = el("p", "card-reveal hidden");
    reveal.append(el("span", "card-pinyin", p.pinyin), el("span", "card-translation", p.translation));
    face.append(el("span", "card-hanzi", p.hanzi));
    // подсказка убирается по мере изучения: в изучении — с пиньинем, дальше — без
    if (p.hint_pinyin) face.append(el("span", "card-hint-pinyin", p.hint_pinyin));
    face.append(reveal, el("span", "card-hint", p.hint_pinyin ? "Вспомните значение и нажмите" : "Вспомните чтение и значение, затем нажмите"));
    const ratings = el("div", "rating-row hidden");
    [["Не помню", 0], ["С трудом", 1], ["Помню", 2], ["Легко", 3]].forEach(([label, q]) => {
      const b = el("button", `rate-btn rate-${q}`, label);
      b.type = "button";
      b.addEventListener("click", async () => {
        ratings.querySelectorAll("button").forEach((x) => (x.disabled = true));
        const res = await sendAnswer(step, q);
        if (res) advanceLesson();
        else ratings.querySelectorAll("button").forEach((x) => (x.disabled = false));
      });
      ratings.appendChild(b);
    });
    face.addEventListener("click", () => {
      if (!reveal.classList.contains("hidden")) return;
      reveal.classList.remove("hidden");
      face.querySelector(".card-hint").classList.add("hidden");
      ratings.classList.remove("hidden");
      playAudio(p.hanzi, step.word_id, null);
    });
    card.append(face, ratings);
  },

  handwriting(root, step) {
    const p = step.payload;
    if (typeof HanziWriter === "undefined") return advanceLesson(); // библиотека недоступна — шаг пропускаем
    const card = lessonCard(root);
    card.append(el("p", "practice-prompt-label", "Напишите иероглиф"),
      el("p", "study-translation", `${p.pinyin} — ${p.translation}`));
    if (p.hanzi.length > 1) card.appendChild(el("p", "lesson-hint", `Первый иероглиф слова ${p.hanzi}`));
    const box = el("div", "stroke-box");
    const target = el("div");
    box.appendChild(target);
    card.appendChild(box);
    let answered = false;
    const done = async (answer) => {
      if (answered) return;
      answered = true;
      const res = await sendAnswer(step, answer);
      if (res) showFeedback(res, { correctTitle: "Отлично", wrongTitle: answer.skipped ? "Пропущено" : "Есть неточности" });
      else answered = false;
    };
    setAction("Не помню — пропустить", () => done({ mistakes: 0, skipped: true }));
    document.getElementById("lesson-action").classList.add("is-quiet");
    const size = Math.min(260, Math.max(200, window.innerWidth - 120));
    const writer = HanziWriter.create(target, p.char, {
      width: size, height: size, padding: 12, showCharacter: false, showOutline: true,
      highlightOnComplete: true, charDataLoader: hanziCharDataLoader, ...hanziThemeColors(),
    });
    writer.quiz({
      onComplete: (s) => {
        document.getElementById("lesson-action").classList.remove("is-quiet");
        done({ mistakes: s.totalMistakes, skipped: false });
      },
    });
  },
};

// Варианты ответа: короткие — сеткой 2×2, длинные (фразы) — списком.
function optionsLayout(options) {
  return options.every((o) => o.length <= 8) ? "options-grid" : "options-list";
}

// Упражнения с выбором ответа — один рендерер; различаются подачей задания.
function renderChoiceStep(root, step) {
  const p = step.payload;
  const card = lessonCard(root, `choice-card type-${step.type}`);
  card.appendChild(el("p", "practice-prompt-label", p.question));
  const after = el("div", "lesson-after hidden");   // что раскрыть после ответа

  if (step.type === "dialogue_reply") {
    const bubble = el("div", "chat-bubble chat-them");
    bubble.append(el("p", "chat-cn", p.prompt));
    const ru = el("p", "chat-ru hidden", p.prompt_ru);
    bubble.append(ru);
    card.appendChild(bubble);
    pinyinToggle(bubble, p.prompt_pinyin);
    after.dataset.reveal = "dialogue";
    after.revealRu = ru;
  } else if (p.prompt_audio) {
    const wrap = el("div", "lesson-prompt-audio");
    const isSentence = step.type === "sentence_listening";
    const audio = audioButton(p.prompt_audio, isSentence ? null : step.word_id, true);
    wrap.appendChild(audio);
    card.appendChild(wrap);
    playAudio(p.prompt_audio, isSentence ? null : step.word_id, audio);
    if (isSentence && p.transcript) {
      after.append(el("p", "lesson-after-cn", p.transcript));
      if (p.pinyin) after.append(el("p", "lesson-after-py", p.pinyin));
    }
  } else if (step.type === "word_choice") {
    card.appendChild(el("p", "lesson-prompt-ru", p.prompt));
  } else if (p.prompt_pinyin) {
    card.appendChild(el("p", "lesson-prompt-pinyin", p.prompt_pinyin));
  } else if (step.type === "sentence_meaning" || step.type === "translate_cn_ru") {
    card.appendChild(el("p", "lesson-prompt lesson-prompt-sentence", p.prompt));
    const py = pinyinToggle(card, p.pinyin);
    after.pinyinLine = py;
  } else if (p.prompt) {   // без prompt (pinyin_error для слова из одного слога) — только варианты
    const long = p.prompt.length > 4;
    card.appendChild(el("p", long ? "lesson-prompt lesson-prompt-sentence" : "lesson-prompt", p.prompt));
    if (p.hint) card.appendChild(el("p", "lesson-hint", p.hint));
    if (p.audio) {   // тон — на слух: слово звучит сразу, кнопка — повторить
      const a = audioButton(p.audio, step.word_id);
      card.appendChild(a);
      playAudio(p.audio, step.word_id, a);
    }
  }
  const list = el("div", step.type === "dialogue_reply" ? "options-list" : optionsLayout(p.options));
  const optionText = (i) => p.options[i];
  const buttons = p.options.map((text, i) => {
    const b = el("button", step.type === "dialogue_reply" ? "option-btn option-reply" : "option-btn");
    b.type = "button";
    b.appendChild(el("span", "option-main", text));
    if (step.type === "dialogue_reply") {
      const sub = el("span", "option-sub hidden", p.option_translation ? p.option_translation[i] : "");
      b.appendChild(sub);
    }
    b.addEventListener("click", async () => {
      if (lessonRun.busy || b.disabled) return;
      buttons.forEach((x) => (x.disabled = true));
      b.classList.add("chosen");
      const res = await sendAnswer(step, i);
      if (!res) { buttons.forEach((x) => (x.disabled = false)); b.classList.remove("chosen"); return; }
      const right = p.options.findIndex((_, k) => optionText(k) === res.expected);
      b.classList.add(res.correct ? "correct" : "wrong");
      if (right >= 0) buttons[right].classList.add("correct");
      revealAfterAnswer(step, p, right, after, buttons);
      showFeedback(res);
    });
    list.appendChild(b);
    return b;
  });
  // раскрытие после ответа — под вариантами, место под него зарезервировано:
  // ни варианты, ни кнопка «Дальше» не сдвигаются после ответа
  if (REVEAL_TYPES.includes(step.type) || after.children.length) after.classList.add("reserve");
  card.append(list, after);
}

// После ответа — чтение и значение (в нужный учебный момент, не до ответа).
const REVEAL_TYPES = ["recognition", "pinyin_choice", "tone_choice", "listening", "word_choice", "fill_blank", "pinyin_to_hanzi"];

function revealAfterAnswer(step, p, right, after, buttons) {
  const meta = (key) => (p[key] && right >= 0 ? p[key][right] : null);
  if (REVEAL_TYPES.includes(step.type)) {
    const hanzi = meta("option_hanzi") || p.prompt;
    const line = [hanzi, meta("option_pinyin"), meta("option_translation")].filter(Boolean).join(" · ");
    if (line) after.append(el("p", "lesson-after-line", line));
  }
  if (step.type === "dialogue_reply") {
    if (after.revealRu) after.revealRu.classList.remove("hidden");
    buttons.forEach((b) => b.querySelector(".option-sub") && b.querySelector(".option-sub").classList.remove("hidden"));
  }
  if (after.pinyinLine) after.pinyinLine.classList.remove("hidden");
  if (after.children.length) after.classList.remove("hidden");
}

for (const type of ["recognition", "listening", "pinyin_choice", "fill_blank",
  "word_choice", "sentence_meaning", "sentence_listening", "dialogue_reply", "pinyin_to_hanzi", "translate_cn_ru",
  "pinyin_error"]) {
  STEP_RENDERERS[type] = renderChoiceStep;
}

// Тон каждого слога: строка на слог — иероглиф и четыре формы слога (тоны 1–4).
// Слог без знака (лёгкий тон) показан, но не выбирается. Один проверяемый слог —
// ответ сразу по нажатию; несколько — выбрать все и «Проверить». Шаг старого
// формата (варианты целого слова, без syllables) — обычный выбор.
STEP_RENDERERS.tone_choice = function (root, step) {
  const p = step.payload;
  if (!p.syllables) return renderChoiceStep(root, step);
  const card = lessonCard(root, `choice-card type-${step.type}`);
  card.append(el("p", "practice-prompt-label", p.question), el("p", "lesson-prompt", p.prompt));
  const audio = audioButton(p.audio, step.word_id);
  card.appendChild(audio);
  playAudio(p.audio, step.word_id, audio);
  const tested = p.syllables.map((s, i) => (s.tested ? i : -1)).filter((i) => i >= 0);
  const chosen = {};   // слог -> выбранный тон 1..4
  const buttons = {};  // слог -> четыре кнопки
  let locked = false;
  const ready = () => tested.every((i) => chosen[i]);
  const sync = () => setAction("Проверить", check, { enabled: ready() });
  const list = el("div", "tone-rows");
  p.syllables.forEach((s, i) => {
    const row = el("div", s.tested ? "tone-row" : "tone-row is-neutral");
    // у односложного слова иероглиф уже крупно сверху — подпись строки не нужна
    if (p.syllables.length === 1) row.classList.add("is-single");
    else row.appendChild(el("span", "tone-row-label", s.hanzi || ""));
    if (!s.tested) {
      row.appendChild(el("span", "tone-row-neutral", `${s.base} · лёгкий тон`));
      list.appendChild(row);
      return;
    }
    const group = el("div", "tone-options");
    group.setAttribute("role", "group");
    group.setAttribute("aria-label", `Слог ${i + 1}${s.hanzi ? `, ${s.hanzi}` : ""}`);
    buttons[i] = s.options.map((text, k) => {
      const b = el("button", "option-btn tone-btn");
      b.type = "button";
      b.appendChild(el("span", "option-main", text));
      b.setAttribute("aria-label", `${text}, ${k + 1}-й тон`);
      b.setAttribute("aria-pressed", "false");
      b.addEventListener("click", () => {
        if (locked || lessonRun.busy) return;
        chosen[i] = k + 1;
        buttons[i].forEach((x, m) => {
          x.classList.toggle("chosen", m === k);
          x.setAttribute("aria-pressed", String(m === k));
        });
        if (tested.length === 1) check(); else sync();
      });
      group.appendChild(b);
      return b;
    });
    row.appendChild(group);
    list.appendChild(row);
  });
  card.appendChild(list);
  async function check() {
    if (locked || !ready()) return;
    locked = true;
    const all = Object.values(buttons).flat();
    all.forEach((b) => (b.disabled = true));
    const res = await sendAnswer(step, { tones: tested.map((i) => chosen[i]) });
    if (!res) { locked = false; all.forEach((b) => (b.disabled = false)); return; }
    // expected — верные формы слогов через пробел: по ним отмечаем каждый слог
    const forms = (res.expected || "").split(" ");
    tested.forEach((i) => {
      const right = p.syllables[i].options.indexOf(forms[i]);
      if (right >= 0) buttons[i][right].classList.add("correct");
      if (chosen[i] - 1 !== right) buttons[i][chosen[i] - 1].classList.add("wrong");
    });
    showFeedback(res);
  }
  if (tested.length > 1) sync();
};

// Сопоставление: слева иероглифы, справа переводы. Нажать слово и перевод (в любом
// порядке) — пара получает общий номер; повторное нажатие разрывает пару. Когда все
// пары составлены — «Проверить». После ответа каждая пара отмечена верной/неверной,
// под сеткой — верные пары (expected: «иероглиф — перевод» построчно).
STEP_RENDERERS.matching = function (root, step) {
  const p = step.payload;
  const card = lessonCard(root, "match-card");
  card.appendChild(el("p", "practice-prompt-label", p.question));
  const n = p.left.length;
  const pairs = new Array(n).fill(null);   // слово -> перевод
  let sel = null;                          // {side: "left"|"right", index}
  let locked = false;
  const grid = el("div", "match-grid");
  const colL = el("div", "match-col");
  const colR = el("div", "match-col");
  const mk = (side, text, i) => {
    const b = el("button", `option-btn match-btn match-${side}`);
    b.type = "button";
    b.append(el("span", "match-badge"), el("span", "option-main", text));
    b.addEventListener("click", () => tap(side, i));
    return b;
  };
  const leftBtns = p.left.map((t, i) => mk("left", t, i));
  const rightBtns = p.right.map((t, j) => mk("right", t, j));
  colL.append(...leftBtns);
  colR.append(...rightBtns);
  grid.append(colL, colR);
  const after = el("div", "lesson-after hidden");
  card.append(grid, after);
  const ready = () => pairs.every((j) => j !== null);
  function paint() {
    leftBtns.forEach((b, i) => {
      b.classList.toggle("chosen", sel && sel.side === "left" && sel.index === i);
      b.classList.toggle("is-paired", pairs[i] !== null);
      b.querySelector(".match-badge").textContent = pairs[i] !== null ? String(i + 1) : "";
      b.setAttribute("aria-pressed", String(!!(sel && sel.side === "left" && sel.index === i)));
    });
    rightBtns.forEach((b, j) => {
      const i = pairs.indexOf(j);
      b.classList.toggle("chosen", sel && sel.side === "right" && sel.index === j);
      b.classList.toggle("is-paired", i >= 0);
      b.querySelector(".match-badge").textContent = i >= 0 ? String(i + 1) : "";
      b.setAttribute("aria-pressed", String(!!(sel && sel.side === "right" && sel.index === j)));
    });
    setAction("Проверить", check, { enabled: ready() });
  }
  function tap(side, idx) {
    if (locked || lessonRun.busy) return;
    // нажатие на уже составленную пару — разорвать её
    if (side === "left" && pairs[idx] !== null) pairs[idx] = null;
    if (side === "right" && pairs.indexOf(idx) >= 0) pairs[pairs.indexOf(idx)] = null;
    if (sel && sel.side === side && sel.index === idx) sel = null;
    else if (sel && sel.side !== side) {
      const i = side === "left" ? idx : sel.index;
      const j = side === "right" ? idx : sel.index;
      pairs[i] = j;
      sel = null;
    } else sel = { side, index: idx };
    paint();
  }
  async function check() {
    if (locked || !ready()) return;
    locked = true;
    [...leftBtns, ...rightBtns].forEach((b) => (b.disabled = true));
    const res = await sendAnswer(step, { pairs: pairs.slice() });
    if (!res) { locked = false; [...leftBtns, ...rightBtns].forEach((b) => (b.disabled = false)); return; }
    const lines = (res.expected || "").split("\n");
    lines.forEach((line, i) => {
      const rightText = line.slice(line.indexOf(" — ") + 3);
      const ok = p.right[pairs[i]] === rightText;
      leftBtns[i].classList.add(ok ? "correct" : "wrong");
      rightBtns[pairs[i]].classList.add(ok ? "correct" : "wrong");
    });
    lines.forEach((line) => after.append(el("p", "lesson-after-line", line)));
    after.classList.remove("hidden");
    showFeedback(res);
  }
  paint();
};

// Сборка фразы (перевод RU → CN): плитки из банка переносятся в строку ответа и обратно.
// translation_build — тот же механизм, но в банке могут быть лишние плитки
// (их не обязательно использовать) и верных вариантов может быть несколько.
STEP_RENDERERS.sentence_order = function (root, step) {
  const p = step.payload;
  const card = lessonCard(root);
  card.appendChild(el("p", "practice-prompt-label", p.question));
  if (p.hint) card.appendChild(el("p", "lesson-prompt-ru lesson-prompt-ru-sm", p.hint));
  if (p.extra_count) card.appendChild(el("p", "lesson-hint", "Одна плитка лишняя."));
  const answerRow = el("div", "token-row token-answer");
  answerRow.setAttribute("aria-label", "Ваш ответ");
  const bank = el("div", "token-row token-bank");
  const after = el("div", "lesson-after hidden");
  let locked = false;
  const sync = () => setAction("Проверить", check, {
    enabled: step.type === "translation_build" ? answerRow.children.length > 0 : bank.children.length === 0,
  });
  const makeToken = (text) => {
    const b = el("button", "token", text);
    b.type = "button";
    b.addEventListener("click", () => {
      if (locked) return;
      (b.parentElement === bank ? answerRow : bank).appendChild(b);
      sync();
    });
    return b;
  };
  p.tokens.forEach((t) => bank.appendChild(makeToken(t)));
  card.append(answerRow, bank, after);
  async function check() {
    if (locked) return;
    locked = true;
    const answer = [...answerRow.children].map((b) => b.textContent);
    const res = await sendAnswer(step, answer);
    if (!res) { locked = false; return; }
    answerRow.classList.add(res.correct ? "is-ok" : "is-bad");
    after.append(el("p", "lesson-after-cn", res.expected));
    if (p.pinyin) after.append(el("p", "lesson-after-py", p.pinyin));
    after.classList.remove("hidden");
    playAudio(res.expected, null, null);
    showFeedback(res);
  }
  sync();
};

STEP_RENDERERS.translation_build = STEP_RENDERERS.sentence_order;

// Диалог: реплики собеседника и ваши прошлые — пузырями, ваша следующая
// реплика — выбором из трёх; после ответа собеседник отвечает дальше.
STEP_RENDERERS.dialogue_scene = function (root, step) {
  const p = step.payload;
  const card = lessonCard(root, "dialogue-card");
  card.appendChild(el("p", "practice-prompt-label", p.title ? `Диалог · ${p.title}` : p.question));
  const chat = el("div", "chat");
  const bubble = (line) => {
    const b = el("div", `chat-bubble ${line.user ? "chat-me" : "chat-them"}`);
    b.append(el("p", "chat-cn", line.cn));
    const ru = el("p", "chat-ru", line.ru);
    b.append(ru);
    return b;
  };
  (p.context || []).forEach((line) => chat.appendChild(bubble(line)));
  const last = chat.lastElementChild;
  if (last) {
    const audio = audioButton(last.querySelector(".chat-cn").textContent, null);
    audio.classList.add("chat-audio");
    last.appendChild(audio);
    playAudio(last.querySelector(".chat-cn").textContent, null, audio);
  }
  card.append(chat, el("p", "dialogue-ask", "Что вы ответите?"));
  const list = el("div", "options-list");
  const buttons = p.options.map((text, i) => {
    const b = el("button", "option-btn option-reply");
    b.type = "button";
    b.append(el("span", "option-main", text), el("span", "option-sub hidden", p.option_translation[i] || ""));
    b.addEventListener("click", async () => {
      if (lessonRun.busy || b.disabled) return;
      buttons.forEach((x) => (x.disabled = true));
      b.classList.add("chosen");
      const res = await sendAnswer(step, i);
      if (!res) { buttons.forEach((x) => (x.disabled = false)); b.classList.remove("chosen"); return; }
      const right = p.options.indexOf(res.expected);
      b.classList.add(res.correct ? "correct" : "wrong");
      if (right >= 0) buttons[right].classList.add("correct");
      buttons.forEach((x) => x.querySelector(".option-sub").classList.remove("hidden"));
      if (p.follow) {   // собеседник продолжает — разговор, а не тест
        const next = bubble({ ...p.follow, user: false });
        chat.appendChild(next);
        playAudio(p.follow.cn, null, null);
      }
      showFeedback(res);
    });
    list.appendChild(b);
    return b;
  });
  card.appendChild(list);
};

// Произношение: послушать образец → записать себя → оценка 0–100 по словам
// от провайдера распознавания. Если оценка на сервере не подключена или нет
// микрофона — честно говорим об этом и не выдаём воспроизведение за оценку.
STEP_RENDERERS.speaking = function (root, step) {
  const p = step.payload;
  const card = lessonCard(root, "speaking-card");
  card.append(el("p", "practice-prompt-label", p.question), el("p", "lesson-prompt lesson-prompt-sentence", p.text),
    el("p", "lesson-pinyin-line", p.pinyin), el("p", "study-translation", p.ru));
  const sample = audioButton(p.text, null, true);
  sample.setAttribute("aria-label", "Послушать образец");
  const rec = el("button", "btn-record");
  rec.type = "button";
  rec.innerHTML = `${icon("mic")}<span>Записать</span>`;
  const controls = el("div", "speak-controls");
  controls.append(sample, rec);
  const result = el("div", "speak-result");
  card.append(controls, result);
  playAudio(p.text, null, sample);
  let recorder = null;
  let chunks = [];
  let done = false;
  const skip = async () => {
    const res = await sendAnswer(step, { skipped: true });
    if (res) advanceLesson();
  };
  setAction("Пропустить", skip);
  document.getElementById("lesson-action").classList.add("is-quiet");
  const unavailable = (text) => {
    rec.disabled = true;
    result.replaceChildren(el("p", "speak-note", text));
    setAction("Дальше", skip);
    document.getElementById("lesson-action").classList.remove("is-quiet");
  };
  if (!navigator.mediaDevices || typeof MediaRecorder === "undefined") {
    unavailable("Запись голоса в этом браузере недоступна. Послушайте образец и повторите вслух.");
    return;
  }
  rec.addEventListener("click", async () => {
    if (done) return;
    if (recorder && recorder.state === "recording") { recorder.stop(); return; }
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      unavailable("Нет доступа к микрофону. Послушайте образец и повторите вслух.");
      return;
    }
    chunks = [];
    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = (e) => chunks.push(e.data);
    recorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      rec.classList.remove("is-recording");
      rec.querySelector("span").textContent = "Оцениваем…";
      rec.disabled = true;
      const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
      let res;
      try {
        const r = await fetch(`${API}/api/sessions/${lessonRun.sessionId}/steps/${step.index}/speech`, { method: "POST", body: blob });
        res = await r.json();
        if (!r.ok) throw new Error(res && res.detail);
      } catch (e) {
        rec.disabled = false;
        rec.querySelector("span").textContent = "Записать ещё раз";
        result.replaceChildren(el("p", "speak-note", "Не удалось отправить запись — попробуйте ещё раз."));
        return;
      }
      if (!res.available) { unavailable(res.message); return; }
      done = true;
      renderSpeechResult(result, res.pronunciation);
      rec.querySelector("span").textContent = "Готово";
      showFeedback(res, { correctTitle: `Произношение: ${res.pronunciation.overall}/100`, wrongTitle: `Произношение: ${res.pronunciation.overall}/100` });
    };
    recorder.start();
    rec.classList.add("is-recording");
    rec.querySelector("span").textContent = "Остановить";
  });
};

function renderSpeechResult(box, r) {
  const words = el("div", "speak-words");
  r.per_word.forEach((w) => {
    const chip = el("span", `speak-word ${w.score >= 80 ? "is-good" : w.score >= 60 ? "is-mid" : "is-bad"}`);
    chip.append(el("b", "", w.text), el("span", "", String(w.score)));
    words.appendChild(chip);
  });
  box.replaceChildren(words);
  r.notes.forEach((n) => box.appendChild(el("p", "speak-note", n)));
}

// «Я это уже знаю»: сервер заменяет оставшиеся упражнения на слово одной
// проверкой; слово считается знакомым, только если проверка пройдена.
async function claimKnown(step, btn) {
  if (lessonRun.busy) return;
  lessonRun.busy = true;
  btn.disabled = true;
  try {
    const res = await apiSend(`/api/sessions/${lessonRun.sessionId}/known`, {
      method: "POST", body: JSON.stringify({ step_index: step.index }),
    });
    if (!res.ok) throw new Error(res.data && res.data.detail);
    lessonRun.steps = res.data.steps;
    lessonRun.index = res.data.next_index - 1;
  } catch (e) {
    btn.disabled = false;
    lessonRun.busy = false;
    showNetworkError();
    return;
  }
  lessonRun.busy = false;
  advanceLesson();
}

// Ввод пиньиня: письменное воспроизведение чтения. Тон — цифрой или знаком.
STEP_RENDERERS.pinyin_input = function (root, step) {
  const p = step.payload;
  const card = lessonCard(root);
  card.append(el("p", "practice-prompt-label", p.question), el("p", "lesson-prompt", p.prompt),
    el("p", "study-translation", p.translation));
  const form = el("form", "pinyin-form");
  const input = el("input", "text-input pinyin-input");
  Object.assign(input, { type: "text", autocomplete: "off", spellcheck: false, placeholder: "например, ni3" });
  input.setAttribute("autocapitalize", "none");
  input.setAttribute("autocorrect", "off");
  input.setAttribute("enterkeyhint", "done");
  input.setAttribute("aria-label", "Пиньинь");
  form.append(input, el("p", "form-hint", p.hint));
  card.appendChild(form);
  let locked = false;
  const sync = () => setAction("Проверить", check, { enabled: input.value.trim().length > 0 });
  input.addEventListener("input", sync);
  form.addEventListener("submit", (e) => { e.preventDefault(); if (input.value.trim()) check(); });
  async function check() {
    if (locked) return;
    locked = true;
    input.blur();
    const res = await sendAnswer(step, input.value.trim());
    if (!res) { locked = false; return; }
    input.readOnly = true;
    input.classList.add(res.correct ? "is-ok" : "is-bad");
    playAudio(p.prompt, step.word_id, null);
    showFeedback(res);
  }
  sync();
  setTimeout(() => input.focus({ preventScroll: true }), 50);
};

// --- Итог урока: по фактам сессии с сервера (не по счётчикам вкладки).
const RESULT_LABELS = {
  improved: ["закреплено", "ok"], ok: ["засчитано", "ok"],
  hard: ["повторим завтра", "warn"], again: ["пока не запомнилось", "bad"],
};

function formatDue(iso) {
  if (!iso) return null;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const d = new Date(`${iso}T00:00:00`);
  const days = Math.round((d - today) / 86400000);
  if (days <= 0) return "сегодня";
  if (days === 1) return "завтра";
  return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]}`;
}

function wordRow(w, chip) {
  const row = el("div", "sum-word");
  row.append(el("span", "sum-hanzi", w.hanzi));
  const mid = el("span", "sum-mid");
  mid.append(el("span", "sum-py", w.pinyin), el("span", "sum-tr", w.translation));
  row.append(mid);
  if (chip) row.append(el("span", `sum-chip sum-chip-${chip[1]}`, chip[0]));
  return row;
}

async function finishLesson() {
  const run = lessonRun;
  run.finished = true;
  document.getElementById("lesson-active").classList.add("hidden");
  const box = document.getElementById("lesson-summary");
  box.classList.remove("hidden");
  const body = document.getElementById("lesson-summary-body");
  body.innerHTML = `<p class="path-loading">Подводим итог…</p>`;
  let s;
  try {
    s = await api(`/api/sessions/${run.sessionId}/complete`, { method: "POST" });
  } catch (e) {
    body.innerHTML = `<p class="lesson-sum-note">Ответы сохранены, но итог сейчас недоступен — нет связи.</p>`;
    setSummaryActions(null);
    return;
  }
  body.innerHTML = "";
  document.getElementById("lesson-summary-title").textContent = s.title || run.title;
  const acc = s.accuracy;
  const stat = el("div", "sum-stats");
  const accEl = el("p", "sum-acc", acc.graded ? String(acc.percent) : "—");
  if (acc.graded) accEl.insertAdjacentHTML("beforeend", "<small>%</small>");
  stat.append(accEl,
    el("p", "sum-acc-label", acc.graded ? `верно ${acc.correct} из ${acc.graded} заданий` : "без оцениваемых заданий"));
  body.appendChild(stat);

  const section = (title, items) => {
    if (!items.length) return;
    const sec = el("div", "sum-section");
    sec.appendChild(el("p", "sum-section-title", title));
    items.forEach((n) => sec.appendChild(n));
    body.appendChild(sec);
  };
  // Что теперь получается сказать — цель темы урока (если урок по сценарию)
  if (s.can_do && s.can_do.length) {
    const sec = el("div", "sum-section sum-cando");
    sec.appendChild(el("p", "sum-section-title", "Теперь вы умеете"));
    const ul = el("ul", "topic-cando");
    s.can_do.forEach((c) => ul.appendChild(el("li", "", c)));
    sec.appendChild(ul);
    body.appendChild(sec);
  }
  section(`Изучено · ${s.new_words.length}`, s.new_words.map((w) => wordRow(w, RESULT_LABELS[w.result])));
  if (s.strong && s.strong.length) {
    section("Получается хорошо", s.strong.map((w) => {
      const row = wordRow(w, null);
      row.appendChild(el("span", "sum-why", w.why || ""));
      return row;
    }));
  }
  section(`Повторение · ${s.review_words.length}`, s.review_words.map((w) => wordRow(w, RESULT_LABELS[w.result])));
  if (s.pronunciation !== null && s.pronunciation !== undefined) {
    section("Произношение", [el("p", "sum-line", `Средняя оценка фраз: ${s.pronunciation}/100`)]);
  }
  // Ошибки — по слову (одна строка на слово, первое объяснение), не длинной лентой.
  const byWord = new Map();
  s.mistakes.forEach((m) => { if (!byWord.has(m.id)) byWord.set(m.id, []); byWord.get(m.id).push(m); });
  const groups = [...byWord.values()];
  const MAX_MISTAKE_WORDS = 6;
  const mistakeRows = groups.slice(0, MAX_MISTAKE_WORDS).map((list) => {
    const m = list[0];
    const wrap = el("div", "sum-mistake-wrap");
    wrap.append(wordRow(m, list.length > 1 ? [`${list.length} ${plural(list.length, "ошибка", "ошибки", "ошибок")}`, "bad"] : null));
    wrap.append(el("p", "sum-note", `${m.exercise}: ${m.explanation || `правильно — ${m.expected}`}`));
    return wrap;
  });
  if (groups.length > MAX_MISTAKE_WORDS) {
    mistakeRows.push(el("p", "sum-line sum-line-soft", `и ещё ${groups.length - MAX_MISTAKE_WORDS} ${plural(groups.length - MAX_MISTAKE_WORDS, "слово", "слова", "слов")} с ошибками`));
  }
  section(`Нужно потренировать · ${groups.length} ${plural(groups.length, "слово", "слова", "слов")}`, mistakeRows);
  const due = formatDue(s.next_review_date);
  const plan = el("div", "sum-section sum-plan");
  plan.appendChild(el("p", "sum-section-title", "Дальше"));
  if (s.next_message && s.next_message.length) {
    // сообщение тренера уже говорит, что повторим и когда
  } else if (s.to_repeat.length) {
    plan.appendChild(el("p", "sum-line", `Повторить: ${s.to_repeat.map((w) => w.hanzi).join(", ")} — вернутся ${due || "в ближайших уроках"}.`));
  } else if (due) {
    plan.appendChild(el("p", "sum-line", `Следующее повторение — ${due}. Слова вернутся сами, по расписанию.`));
  }
  (s.next_message || []).forEach((m) => plan.appendChild(el("p", "sum-line", m)));
  if (s.next) plan.appendChild(el("p", "sum-line sum-line-soft", s.next.reason));
  body.appendChild(plan);
  setSummaryActions(s.next);
}

function setSummaryActions(next) {
  const primary = document.getElementById("lesson-sum-next");
  if (next) {
    primary.textContent = next.kind === "review" ? "Начать повторение" : `Дальше: ${next.title}`;
    primary.onclick = () => (next.kind === "review" ? openReview() : openLesson(next.module_id, next.title));
    primary.classList.remove("hidden");
  } else {
    primary.classList.add("hidden");
  }
}

document.getElementById("lesson-back").addEventListener("click", () => showView("home"));
document.getElementById("lesson-empty-back").addEventListener("click", () => showView("home"));
document.getElementById("lesson-sum-home").addEventListener("click", () => showView("home"));

// ---------------------------------------------------------------------------
// Инициализация
// ---------------------------------------------------------------------------

if ("speechSynthesis" in window) {
  // некоторые браузеры грузят голоса асинхронно
  speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();
}

showView("home");
maybeShowOnboarding();
