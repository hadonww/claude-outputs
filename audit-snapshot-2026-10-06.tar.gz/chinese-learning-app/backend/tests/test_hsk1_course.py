"""
Phase I — HSK 1 как последовательный курс: сценарии уроков по всем темам, проверка
всего маршрута новым учеником (без неизвестных слов), четыре сценария ученика
(новый, слабый, долг повторений, сильный), «я это уже знаю» на реальном контенте.

База строится настоящим конвейером (scripts/build_course_db.py) из выборки датасета
уровней 1–2 (tests/fixtures/hsk12_dataset.json), поэтому раскладка модулей HSK 1
совпадает с полной базой.
"""

import json
import shutil
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine import lesson_script

BACKEND = Path(__file__).resolve().parent.parent
DATASET = BACKEND / "tests" / "fixtures" / "hsk12_dataset.json"
LESSONS = BACKEND / "data" / "lessons"
HSK1_THEMES = ["люди", "числа", "время", "действия", "грамматика", "семья", "дом", "эмоции",
               "повседневная жизнь", "еда", "покупки", "школа", "работа", "технологии", "транспорт",
               "путешествия", "природа"]


@pytest.fixture(autouse=True)
def _restore_globals():
    """Проверки подменяют сегодняшнюю дату и путь к базе — после теста всё возвращается."""
    import app.config as cfg
    import app.db as dbm
    import app.services.learning_service as ls
    import app.services.lesson_service as les
    import app.services.profile_service as ps
    import app.services.statistics_service as ss
    from app import utils

    mods = (utils, ls, les, ps, ss)
    saved = [m.today_date for m in mods], cfg.DB_PATH, dbm.DB_PATH
    yield
    for m, f in zip(mods, saved[0]):
        m.today_date = f
    cfg.DB_PATH, dbm.DB_PATH = saved[1], saved[2]


@pytest.fixture(scope="module")
def course_db():
    import app.config as cfg
    import app.db as dbm
    from scripts.build_course_db import build

    saved = cfg.DB_PATH, dbm.DB_PATH
    path = build(Path(tempfile.mkdtemp()) / "course.db", DATASET, "1-2")
    cfg.DB_PATH, dbm.DB_PATH = saved
    return path


def _copy(src: Path) -> Path:
    dst = Path(tempfile.mkdtemp()) / "copy.db"
    shutil.copy(src, dst)
    return dst


def _check_unknown_word_rule(report):
    """Правило неизвестных слов: содержание упражнений — только из доступного материала;
    незнакомые слова — только неверные варианты ответа (такие в курсе есть, это допустимо)."""
    assert report["content_violations"] == 0, report["content_violation_examples"]
    assert report["unknown_distractor_options"] > 0


def _route_lessons():
    files = {json.loads(p.read_text(encoding="utf-8"))["module"]["category"]: json.loads(p.read_text(encoding="utf-8"))
             for p in LESSONS.glob("hsk1_*.json")}
    return files, [(cat, b) for cat in HSK1_THEMES if cat in files for b in files[cat]["lessons"]]


# ---------------------------------------------------------------------------
# Контент: уроки по всем темам, каждое слово HSK 1 — новое ровно один раз
# ---------------------------------------------------------------------------

def test_every_hsk1_theme_has_lessons_with_a_goal(course_db):
    files, lessons = _route_lessons()
    assert set(files) == set(HSK1_THEMES)
    for cat in HSK1_THEMES:
        assert 1 <= len(files[cat]["lessons"]) <= 6, cat
        assert files[cat]["module"]["hsk_level"] == 1
    keys = [b["key"] for _, b in lessons]
    assert len(keys) == len(set(keys)) and len({b["title"] for _, b in lessons}) == len(keys)
    for _, b in lessons:
        assert b["goal"] and b["intro"] and len(b["can_do"]) >= 1, b["key"]
        assert set(b["notes"]) == set(b["new_words"]), (b["key"], "у каждого нового слова — подсказка")
        assert b["phrases"] and b["translations"] and b["dialogue"]["lines"] and b["speaking"], b["key"]


def test_lessons_cover_hsk1_once_and_never_use_future_words(course_db):
    import sqlite3

    conn = sqlite3.connect(course_db)
    hsk1 = {r[0] for r in conn.execute(
        "SELECT w.hanzi FROM words w JOIN modules m ON m.id = w.module_id WHERE m.hsk_level = 1")}
    words = {r[0]: {"id": r[1], "hanzi": r[0], "pinyin": r[2]} for r in conn.execute("SELECT hanzi, id, pinyin FROM words")}
    _, lessons = _route_lessons()
    learned: list[str] = []
    for _, b in lessons:
        assert 2 <= len(b["new_words"]) <= 5, b["key"]
        assert not set(b["new_words"]) & set(learned), (b["key"], "слово уже было новым раньше")
        learned += b["new_words"]
        future = lesson_script.blueprint_hanzi(b) - set(learned)
        assert not future, (b["key"], "слова из будущих уроков", future)
        lesson_script.resolve(b, words)          # все слова есть в базе
    assert set(learned) == hsk1                  # весь HSK 1, ни одного лишнего
    assert len(learned) == len(set(learned))


# ---------------------------------------------------------------------------
# Последовательная проверка маршрута (scripts/validate_hsk1_course.py)
# ---------------------------------------------------------------------------

def test_new_learner_goes_through_hsk1_without_unknown_words(course_db):
    from scripts.validate_hsk1_course import expected_script_keys, validate

    report = validate(course_db)
    assert report["ok"], report["problems"]
    assert report["violation_count"] == 0 and report["answer_mismatches"] == 0
    # каждый сценарий пройден как «новый» и по порядку; урок может делиться на два (Phase I.1),
    # но общих уроков без сценария в HSK 1 нет
    assert report["scripted_lessons"] == len(expected_script_keys(1))
    assert report["scripted_lesson_sessions"] >= report["scripted_lessons"]
    assert report["generic_lessons"] == 0 and report["unseen_hsk1_words"] == []
    _check_unknown_word_rule(report)
    assert report["max_new_per_lesson"] <= 5
    log = report["lesson_log"]
    assert log[0]["review"] == 0 and all(r["review"] > 0 for r in log[1:])   # повторение с каждым уроком
    # Phase I.1: обычный урок — 15–25 шагов (медиана), без длинных хвостов
    rng = report["steps_range"]
    assert 15 <= rng["median"] <= 25 and rng["max"] <= 30, rng
    # просроченное приходит понемногу: ни один урок не превращается в одно повторение
    assert all(r["new"] >= 1 for r in log if r["key"] and r["mode"] == "new")


def test_learner_with_mistakes_gets_every_exercise_type_on_real_content(course_db):
    """С ошибками в уроках появляются повторы, примеры и диалоги — все типы упражнений
    работают на контенте HSK 1, верный ответ всегда принимается, неизвестных слов нет."""
    from engine.lesson_planner import MAX_RETRIES_PER_LESSON
    from scripts.validate_hsk1_course import validate

    report = validate(course_db, accuracy=0.7, seed=5)
    assert report["ok"], report["problems"]
    _check_unknown_word_rule(report)
    # с ошибками урок немного длиннее, но повторы после ошибок ограничены
    log = report["lesson_log"]
    assert all(r["retries"] <= MAX_RETRIES_PER_LESSON for r in log)
    assert report["steps_range"]["median"] <= 28 and report["steps_range"]["max"] <= 36, report["steps_range"]
    types = set(report["step_types"])
    assert {"introduction", "recognition", "listening", "pinyin_choice", "tone_choice", "pinyin_error",
            "fill_blank", "sentence_order", "recall", "handwriting", "translate_cn_ru", "translation_build",
            "dialogue_scene", "speaking", "matching", "word_choice"} <= types


def test_forgotten_word_keeps_script_phrases_in_next_lesson(course_db):
    """Регрессия (Phase I): слово, на котором ошиблись (SM-2 сбросил repetitions), считалось
    незнакомым — следующий урок терял все фразы, диалог и перевод сценария."""
    from datetime import date
    from random import Random

    import app.config as cfg
    import app.db as dbm
    from scripts.simulate_course import _patch_today
    from scripts.simulate_users import _run, _start

    path = _copy(course_db)
    cfg.DB_PATH = dbm.DB_PATH = path
    _patch_today(date(2026, 1, 5))
    from app.db import get_db

    with get_db() as conn:
        plan = _start(conn)
        wo = next(w["id"] for w in plan["new_words"] if w["hanzi"] == "我")
        _run(conn, plan, Random(0), wrong_ids={wo})
        assert conn.execute("SELECT repetitions FROM progress WHERE word_id = ?", (wo,)).fetchone()[0] == 0
        nxt = _start(conn)
    assert nxt["lesson"]["key"] == "hsk1-people-2"
    script_types = {s["type"] for s in nxt["steps"] if s["role"] == "script"}
    assert {"translate_cn_ru", "translation_build", "dialogue_scene"} <= script_types


# ---------------------------------------------------------------------------
# Четыре ученика (scripts/simulate_users.py)
# ---------------------------------------------------------------------------

def test_user_a_new_learner_normal_lesson_length(course_db):
    from scripts.simulate_users import user_a

    r = user_a(course_db)
    assert all(r["checks"].values()), (r["checks"], r["steps"])


def test_user_b_weak_words_come_first_and_get_extra_practice(course_db):
    from scripts.simulate_users import user_b

    r = user_b(course_db)
    assert all(r["checks"].values()), r["checks"]


def test_user_c_due_backlog_gets_more_review_and_shrinks(course_db):
    from scripts.simulate_users import user_c

    r = user_c(course_db)
    assert all(r["checks"].values()), r["checks"]
    assert r["first_lesson"]["review"] > r["first_lesson"]["new"]


def test_user_d_strong_learner_moves_on_and_retention_does_not_loop(course_db):
    """Регрессия (Phase I): верная проверка удержания не меняла SRS, и одно и то же
    освоенное слово проверялось в каждом уроке подряд."""
    from scripts.simulate_users import user_d

    r = user_d(course_db)
    assert all(r["checks"].values()), r["checks"]
    assert len(r["retention_words"]) == len(set(r["retention_words"])) >= 2


# ---------------------------------------------------------------------------
# «Я это уже знаю» на контенте HSK 1
# ---------------------------------------------------------------------------

def _claim_first_word(course_db, correct: bool):
    from datetime import date

    import app.config as cfg
    import app.db as dbm
    from scripts.simulate_course import _answer, _patch_today
    from scripts.simulate_users import _start

    path = _copy(course_db)
    cfg.DB_PATH = dbm.DB_PATH = path
    _patch_today(date(2026, 1, 5))
    from app.db import get_db
    from app.repositories import lesson_sessions_repo
    from app.services import lesson_service

    with get_db() as conn:
        plan = _start(conn)
        sid = plan["session_id"]
        intro = next(i for i, s in enumerate(plan["steps"]) if s["type"] == "introduction")
        wid = plan["steps"][intro]["word_id"]
        for i in range(intro):
            lesson_service.record_session_attempt(conn, sid, i, _answer(plan["steps"][i], True))
        lesson_service.claim_known(conn, sid, intro)
        steps = lesson_sessions_repo.get(conn, sid)["steps"]
        verify = steps[intro + 1]
        res = lesson_service.record_session_attempt(conn, sid, intro + 1, _answer(verify, correct))
        i = intro + 2
        while i < len(lesson_sessions_repo.get(conn, sid)["steps"]):
            step = lesson_sessions_repo.get(conn, sid)["steps"][i]
            lesson_service.record_session_attempt(conn, sid, i, _answer(step, True))
            i += 1
        lesson_service.complete_session(conn, sid)
        row = conn.execute("SELECT * FROM progress WHERE word_id = ?", (wid,)).fetchone()
        own_steps = [s for s in steps if s["word_id"] == wid and s.get("role") not in ("script",)]
    return verify, res, row, own_steps


def test_i_already_know_confirmed_on_hsk1_lesson(course_db):
    verify, res, row, own = _claim_first_word(course_db, correct=True)
    assert verify["role"] == "verify" and res["correct"]
    # слово не новое и не освоенное: как после двух удачных повторений, срок — через 6 дней
    assert row["repetitions"] == 2 and row["interval_days"] == 6 and row["total_attempts"] >= 1
    # обычные упражнения на это слово заменены одной проверкой
    assert [s["type"] for s in own] == ["introduction", verify["type"]]


def test_i_already_know_refuted_returns_word_to_learning(course_db):
    _verify, res, row, _ = _claim_first_word(course_db, correct=False)
    assert not res["correct"] and res["appended_step"] is not None      # повтор в конце урока
    assert row["repetitions"] <= 1 and row["interval_days"] <= 1          # обычное изучение, повтор завтра
    assert row["total_attempts"] >= 1


# ---------------------------------------------------------------------------
# Примеры HSK 1 на реальной базе
# ---------------------------------------------------------------------------

def test_every_hsk1_word_has_an_example_of_its_own_level(course_db):
    import sqlite3

    conn = sqlite3.connect(course_db)
    level1 = {r[0] for r in conn.execute(
        "SELECT w.id FROM words w JOIN modules m ON m.id = w.module_id WHERE m.hsk_level = 1")}
    ok = set()
    for target, used in conn.execute("SELECT target_word_id, used_word_ids FROM examples WHERE needs_review = 0"):
        if target in level1 and set(json.loads(used)) <= level1:
            ok.add(target)
    assert level1 - ok == set()


def test_example_pinyin_follows_corrected_word_readings(course_db):
    """Регрессия (Phase I): пиньинь примеров собирался до исправления чтений многочтений
    («Tā lái liǎo», «Nǐ hǎo má?») и так и оставался; теперь пересобирается по словам."""
    import sqlite3

    conn = sqlite3.connect(course_db)
    pinyin = dict(conn.execute("SELECT sentence_cn, pinyin FROM examples WHERE needs_review = 0"))
    assert pinyin["他来了。"] == "Tā lái le."
    assert pinyin["你好吗？"] == "Nǐ hǎo ma?"
    assert pinyin["我想去北京。"] == "Wǒ xiǎng qù Běijīng."
    assert all(p for p in pinyin.values())                      # у каждого пригодного примера есть пиньинь


# ---------------------------------------------------------------------------
# Phase I.1, риск 1: одна норма новых слов для обычного и сценарного урока
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def mid_course_db(course_db):
    """Ученик прошёл 12 уроков HSK 1 без ошибок; возвращает (база, следующий день)."""
    from datetime import date, timedelta

    from scripts.validate_hsk1_course import validate

    path = Path(tempfile.mkdtemp()) / "mid.db"
    report = validate(course_db, max_lessons=12, keep=path)
    return path, date.fromisoformat(report["last_day"]) + timedelta(days=1)


def _budget_state(mid_course_db, monkeypatch, accuracy, due):
    """Копия базы ученика: due просроченных слов, точность последних ответов = accuracy.
    Возвращает (план сценарного урока HSK 1, план обычного урока HSK 2, число слов сценария)."""
    from datetime import timedelta

    import app.config as cfg
    import app.db as dbm
    from app.repositories import attempts_repo
    from scripts.simulate_course import _known_ids, _patch_today
    from scripts.simulate_users import _script_new_count

    src, day = mid_course_db
    path = _copy(src)
    cfg.DB_PATH = dbm.DB_PATH = path
    _patch_today(day)
    monkeypatch.setattr(attempts_repo, "recent_accuracy", lambda conn, uid: accuracy)
    from app.db import get_db
    from app.services import learning_path_service, lesson_service

    with get_db() as conn:
        seen = sorted(_known_ids(conn))
        conn.execute("UPDATE progress SET due_date = ?", ((day + timedelta(days=5)).isoformat(),))
        for wid in seen[:due]:
            conn.execute("UPDATE progress SET due_date = ? WHERE word_id = ?", (day.isoformat(), wid))
        hsk1 = learning_path_service.get_learning_path(conn)["recommended_module_id"]
        # обычный урок — модуль HSK 2 с большим запасом слов: правило хвоста модуля
        # (MODULE_TAIL — добрать последние 1–2 слова модуля) там не срабатывает
        hsk2 = conn.execute("""SELECT m.id FROM modules m JOIN words w ON w.module_id = m.id
                               WHERE m.hsk_level = 2 GROUP BY m.id ORDER BY COUNT(*) DESC, m.id LIMIT 1""").fetchone()[0]
        scripted = lesson_service.get_lesson_plan(conn, hsk1)
        generic = lesson_service.get_lesson_plan(conn, hsk2)
        portion = _script_new_count(conn)
    assert scripted["lesson"] is not None and generic["lesson"] is None
    return scripted, generic, portion


def test_same_state_gives_same_new_word_budget_to_scripted_and_generic_lesson(mid_course_db, monkeypatch):
    for accuracy, due in ((None, 0), (0.8, 6), (0.5, 0), (0.5, 20), (1.0, 40)):
        scripted, generic, _ = _budget_state(mid_course_db, monkeypatch, accuracy, due)
        budget = scripted["mix"]["new_word_budget"]
        assert budget == generic["mix"]["new_word_budget"], (accuracy, due)
        assert len(generic["new_words"]) == budget
        assert 1 <= len(scripted["new_words"]) <= budget        # сценарий норму не увеличивает


def test_low_accuracy_scripted_lesson_gets_no_more_new_words_than_generic(mid_course_db, monkeypatch):
    s_norm, _, portion = _budget_state(mid_course_db, monkeypatch, 0.8, 0)
    s_low, g_low, _ = _budget_state(mid_course_db, monkeypatch, 0.5, 0)
    assert portion == 5 and len(s_norm["new_words"]) == 5
    assert s_low["mix"]["reason"] == "low_accuracy"
    assert len(s_low["new_words"]) < len(s_norm["new_words"])
    assert len(s_low["new_words"]) <= len(g_low["new_words"])


def test_debt_and_low_accuracy_limits_apply_together(mid_course_db, monkeypatch):
    from engine.lesson_planner import BACKLOG_THRESHOLD, adaptive_daily_new, lesson_mix

    due = 2 * BACKLOG_THRESHOLD + 1
    only_low, _, _ = _budget_state(mid_course_db, monkeypatch, 0.5, 0)
    only_debt, _, _ = _budget_state(mid_course_db, monkeypatch, 0.8, due)
    both, g_both, _ = _budget_state(mid_course_db, monkeypatch, 0.5, due)
    daily = adaptive_daily_new(5, 0.5, due)[0]
    assert both["mix"]["new_word_budget"] == lesson_mix(daily, due)[0] == g_both["mix"]["new_word_budget"]
    assert both["mix"]["new_word_budget"] < min(only_low["mix"]["new_word_budget"],
                                                only_debt["mix"]["new_word_budget"])
    for plan in (both, g_both):                                  # урок всё равно не только повторение
        assert 1 <= len(plan["new_words"]) <= both["mix"]["new_word_budget"]
        assert len(plan["review_words"]) <= plan["mix"]["review_cap"]


def test_strong_learner_gets_full_script_portion_after_debt_is_cleared(mid_course_db, monkeypatch):
    in_debt, _, portion = _budget_state(mid_course_db, monkeypatch, 1.0, 40)
    cleared, generic, _ = _budget_state(mid_course_db, monkeypatch, 1.0, 0)
    assert len(in_debt["new_words"]) < portion
    assert [w["id"] for w in cleared["new_words"]] and len(cleared["new_words"]) == portion
    assert cleared["mix"]["new_word_budget"] >= portion == len(cleared["new_words"])
    assert len(generic["new_words"]) == cleared["mix"]["new_word_budget"]



# ---------------------------------------------------------------------------
# Разбиение темы при малой норме: первая часть — с содержанием сценария, где это возможно
# ---------------------------------------------------------------------------

def test_low_accuracy_course_never_leaves_an_avoidable_empty_first_part(course_db):
    """50% верных: норма новых слов 2–3. Все сценарии пройдены по порядку, новых слов в уроке
    не больше нормы, и урок без шагов сценария бывает только там, где в пределах нормы нет
    ни одного набора слов с фразой/диалогом/переводом (best_coverage == 0)."""
    from scripts.validate_hsk1_course import expected_script_keys, validate

    for seed in (1, 4):
        report = validate(course_db, accuracy=0.5, seed=seed)
        assert report["violation_count"] == 0 and report["content_violations"] == 0
        assert report["scripted_lessons"] == len(expected_script_keys(1)) and report["generic_lessons"] == 0
        assert all(r["new"] <= r["budget"] for r in report["lesson_log"] if r["key"])
        assert all(e["best_coverage"] == 0 for e in report["empty_script_parts"]), report["empty_script_parts"]
        assert report["empty_script_parts"] == [] and report["ok"], report["problems"]


def test_numbers_4_first_part_has_script_content_at_budget_two(course_db):
    """Найденный случай (50%, сиды 1, 3, 4): у «Числа-4» (零, 多少, 的, 电话, 这) каждая фраза
    требовала хотя бы трёх новых слов, и при норме 2 первая часть шла без сценария. Контент
    поправлен: фраза «你有我的电话吗？» — новые только 的 и 电话. Теперь при норме 2 урок
    берёт ровно эту пару (норма не растёт) и получает шаги сценария; остальное содержание
    темы — во второй части."""
    import app.config as cfg
    import app.db as dbm
    from app.repositories import lesson_scripts_repo, words_repo

    cfg.DB_PATH = dbm.DB_PATH = _copy(course_db)
    from app.db import get_db
    from scripts.validate_hsk1_course import expected_script_keys

    keys = expected_script_keys(1)
    blueprints = {b["key"]: b for b in lesson_scripts_repo.all_blueprints()}
    with get_db() as conn:
        words = {r["hanzi"]: words_repo.word_row_to_dict(r) for r in conn.execute("SELECT * FROM words")}
        seen = set()
        for key in keys[:keys.index("hsk1-numbers-4")]:
            seen |= set(lesson_script.try_resolve(blueprints[key], words)["new_word_ids"])
        script = lesson_script.try_resolve(blueprints["hsk1-numbers-4"], words)
        hz = {w["id"]: w["hanzi"] for w in words.values()}
        own = {w["id"] for w in words.values() if w["hanzi"] in ("零", "多少")}
    new = lesson_script.lesson_new_ids(script, seen)
    assert len(new) == 5
    covering = [{hz[a], hz[b]} for i, a in enumerate(new) for b in new[i + 1:]
                if lesson_script.script_coverage(script, seen | {a, b}) > 0]
    assert covering == [{"的", "电话"}]
    picked = lesson_script.split_new_words(script, seen, 2, own)
    assert {hz[w] for w in picked} == {"的", "电话"} and len(picked) == 2
    first = lesson_script.script_coverage(script, seen | set(picked))
    assert first > 0 and first == lesson_script.best_split_coverage(script, seen, 2, own)
    # вторая часть (零, 多少, 这) — всё остальное содержание темы
    assert lesson_script.script_coverage(script, seen | set(new)) > first
