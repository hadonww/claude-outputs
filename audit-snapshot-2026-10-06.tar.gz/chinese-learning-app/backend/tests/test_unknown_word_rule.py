"""
Правило неизвестных слов (Phase I.1, docs/ARCHITECTURE.md → «Правило неизвестных слов»):

  * незнакомые слова запрещены в содержании, которое ученик должен изучить, понять или
    использовать: задание, инструкция, фраза, пример, диалог, перевод, пары сопоставления;
  * незнакомое слово допустимо только как НЕВЕРНЫЙ вариант ответа (дистрактор);
  * верный ответ всегда из уже доступного материала;
  * дистрактор не нужен для понимания задания.

Проверка — scripts/validate_hsk1_course.content_rule_violations (по иероглифам каждого
текста шага). Здесь — на искусственных шагах (чтобы правило нельзя было случайно ослабить)
и на всём маршруте HSK 1.
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.validate_hsk1_course import content_rule_violations

KNOWN = set("你我好叫是")          # иероглифы знакомых слов
UNKNOWN = "猫"                     # незнакомое слово


def _fields(step):
    bad, _ = content_rule_violations(step, KNOWN)
    return {b["field"].split("[")[0].split(".")[0].split("(")[0] for b in bad}


def test_unknown_word_is_allowed_only_as_a_wrong_option():
    step = {"type": "word_choice", "payload": {"prompt": "ты", "question": "Как это по-китайски?",
                                               "options": [UNKNOWN, "你", "我"], "option_hanzi": [UNKNOWN, "你", "我"],
                                               "answer_index": 1}}
    bad, distractors = content_rule_violations(step, KNOWN)
    assert bad == [] and distractors == 2


def test_correct_answer_must_be_known():
    step = {"type": "word_choice", "payload": {"prompt": "кошка", "options": ["你", UNKNOWN],
                                               "option_hanzi": ["你", UNKNOWN], "answer_index": 1}}
    bad, _ = content_rule_violations(step, KNOWN)
    assert {b["field"] for b in bad} == {"options[1](верный)", "option_hanzi[1](верный)"}


def test_unknown_word_in_task_content_is_a_violation():
    cases = [
        {"type": "translate_cn_ru", "payload": {"prompt": f"我是{UNKNOWN}", "options": ["а", "б"], "answer_index": 0}},
        {"type": "recognition", "payload": {"prompt": "你", "question": f"Что значит {UNKNOWN}?",
                                            "options": ["ты"], "answer_index": 0}},
        {"type": "dialogue_scene", "payload": {"context": [{"cn": f"你{UNKNOWN}"}], "options": ["你好"],
                                               "answer_index": 0}},
        {"type": "matching", "payload": {"left": ["你", UNKNOWN], "right": ["ты", "кошка"], "answers": [0, 1]}},
        {"type": "translation_build", "payload": {"answers": [["我", UNKNOWN]], "tokens": ["我", UNKNOWN]}},
        {"type": "sentence_order", "payload": {"answer_tokens": ["我", UNKNOWN], "tokens": ["我", UNKNOWN]}},
        {"type": "speaking", "payload": {"text": f"我{UNKNOWN}", "tokens": ["我", UNKNOWN]}},
        {"type": "fill_blank", "payload": {"prompt": f"我___{UNKNOWN}", "options": ["是"], "answer_index": 0}},
    ]
    for step in cases:
        assert _fields(step), step["type"]
    # речь: плитки — сама фраза, они тоже содержание
    assert "tokens" in _fields(cases[6])


def test_extra_tiles_are_distractors_but_the_answer_is_content():
    step = {"type": "translation_build", "payload": {"answers": [["我", "是"]], "tokens": ["是", UNKNOWN, "我"]}}
    bad, distractors = content_rule_violations(step, KNOWN)
    assert bad == [] and distractors == 1


def test_introduction_may_name_parts_of_its_own_character_only():
    ok = {"type": "introduction", "payload": {"hanzi": "你", "components": "亻 (человек) + 尔",
                                              "note": "Слева ключ 亻 «человек»."}}
    assert content_rule_violations(ok, KNOWN | set("你"))[0] == []
    bad = {"type": "introduction", "payload": {"hanzi": "你", "components": "亻 + 尔", "note": f"你{UNKNOWN}"}}
    assert content_rule_violations(bad, KNOWN)[0]


# Подсказки карточек знакомства (note), исправленные в Phase I.1: раньше в них были ещё не
# пройденные слова (我叫…, 一本书, 回家, 说汉语, 中国菜…) или знаки, которых нет в составе
# слова (冫, 灬, 宀). Тест ниже проверяет ВСЕ подсказки; этот список — чтобы исправленные
# случаи были видны поимённо.
FIXED_INTRO_NOTES = {"好", "我", "叫", "她", "很", "二", "个", "有", "四", "十", "岁", "本", "些", "多", "少",
                     "星期一", "点", "去", "日", "在", "会", "说", "回", "家", "了", "怎么", "妈妈", "上",
                     "不客气", "没关系", "块", "菜", "字", "冷", "热"}


def _intro_note_violations():
    """Подсказка слова может использовать только: само слово, части его иероглифа (поле
    components в seed_data.json) и слова сценариев, пройденных ДО этого урока. Слова того же
    сценария не допускаются: при разбиении темы на две части они могут прийти позже."""
    from scripts.validate_hsk1_course import expected_script_keys, script_name_chars

    cjk = re.compile(r"[\u4e00-\u9fff]")
    root = Path(__file__).resolve().parent.parent
    components = {w["hanzi"]: w.get("components") or "" for w in
                  json.loads((root / "seed_data.json").read_text(encoding="utf-8"))}
    lessons = {}
    for p in (root / "data" / "lessons").glob("hsk1_*.json"):
        for lesson in json.loads(p.read_text(encoding="utf-8"))["lessons"]:
            lessons[lesson["key"]] = lesson
    names = script_name_chars()
    known, bad, checked = set(), {}, set()
    for key in expected_script_keys(1):
        b = lessons[key]
        for w, note in (b.get("notes") or {}).items():
            checked.add(w)
            allowed = known | set(w) | set(cjk.findall(components.get(w, ""))) | names
            unknown = set(cjk.findall(note)) - allowed
            if unknown:
                bad[w] = "".join(sorted(unknown))
        known |= set("".join(b["new_words"]))
    return bad, checked


def test_intro_notes_use_only_available_words():
    bad, checked = _intro_note_violations()
    assert bad == {}, bad
    assert FIXED_INTRO_NOTES <= checked          # исправленные подсказки на месте и проверены
