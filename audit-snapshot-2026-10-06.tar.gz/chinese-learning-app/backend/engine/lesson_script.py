"""
Сценарий эталонного урока (Phase H) — чистая логика, без БД и сети.

Сценарий (blueprint) — авторский контент темы: цель урока («что вы сможете
сказать после него»), короткое введение, несколько новых слов, фразы, перевод
RU → CN, диалог и фразы для произношения. Хранится в data/lessons/*.json как
текст; здесь он:
  * разрешается в слова базы (resolve): каждый токен фразы — слово из words
    или объявленное имя собственное (@安娜). Если хоть одного слова нет в базе,
    сценарий недоступен целиком (урок идёт обычным планировщиком) — фразы с
    «дырами» не показываются;
  * превращается в шаги урока (build_steps) — только те, где ВСЕ слова (включая
    неверные варианты и лишние плитки) уже знакомы к этому моменту урока
    (known-vocabulary guard): упражнение никогда не требует неизученного слова;
  * выбирается для модуля (choose_script): первый не пройденный сценарий по
    порядку. Если его слова уже знакомы, урок становится практическим — без
    знакомства со словами, но с фразами, переводом, диалогом и речью.

Что знает пользователь и что ему повторять, решают SRS/mastery и планировщик;
сценарий — только содержание темы.
"""

from random import Random

PUNCT_TO_LATIN = {"！": "!", "？": "?", "。": ".", "，": ",", "、": ",", "：": ":", "；": ";"}
PUNCT = set(PUNCT_TO_LATIN) | set("!?.,:;")
NAME_PREFIX = "@"

# Учебная фаза типов сценария (продолжает exercise_types.PHASES: 3 — фраза,
# 5 — перевод своими силами, 6 — произношение; см. lesson_planner).
SCRIPT_PHASES = {"translate_cn_ru": 3, "sentence_listening": 3, "dialogue_scene": 3,
                 "translation_build": 5, "speaking": 6}
SCRIPT_REASONS = {"translate_cn_ru": "Фразы темы — понимаем смысл", "sentence_listening": "Та же тема — на слух",
                  "dialogue_scene": "Применяем слова в разговоре", "translation_build": "Строим фразу сами",
                  "speaking": "Говорим вслух"}
SCRIPT_SKILLS = {"translate_cn_ru": "grammar", "sentence_listening": "listening", "dialogue_scene": "grammar",
                 "translation_build": "grammar", "speaking": "speaking"}
# Phase I.1: в уроке — по две фразы и два перевода, одна фраза вслух (было 3/3/2):
# этапы занятия те же (фразы → на слух → диалог → перевод → речь), урок короче.
MAX_PHRASES = 2
MAX_TRANSLATIONS = 2
MAX_SPEAKING = 1


class ScriptError(ValueError):
    """Сценарий ссылается на слово, которого нет в базе."""


def _tokens(text: str) -> list[str]:
    return [t for t in (text or "").split() if t]


def resolve_sentence(text: str, words_by_hanzi: dict[str, dict], names: dict[str, dict], ru: str | None = None) -> dict:
    """«你 好 ， 我 叫 @安娜 。» → текст, токены, id слов, пиньинь (из базы и имён)."""
    raw = _tokens(text)
    if not raw:
        raise ScriptError("пустая фраза")
    display, words, word_ids, pinyin_parts, token_pinyin = "", [], [], [], []
    for tok in raw:
        if tok in PUNCT:
            display += tok
            if pinyin_parts:
                pinyin_parts[-1] += PUNCT_TO_LATIN.get(tok, tok)
            continue
        if tok.startswith(NAME_PREFIX):
            name = tok[len(NAME_PREFIX):]
            info = names.get(name)
            if info is None:
                raise ScriptError(f"имя {name!r} не объявлено в names")
            display += name
            words.append(name)
            token_pinyin.append(info["pinyin"])
            pinyin_parts.append(info["pinyin"])
            continue
        word = words_by_hanzi.get(tok)
        if word is None:
            raise ScriptError(f"слова {tok!r} нет в базе")
        display += tok
        words.append(tok)
        word_ids.append(word["id"])
        token_pinyin.append(word["pinyin"])
        pinyin_parts.append(word["pinyin"])
    pinyin = " ".join(pinyin_parts)
    if pinyin:
        pinyin = pinyin[0].upper() + pinyin[1:]
    return {"cn": display, "tokens": words, "word_ids": word_ids, "pinyin": pinyin,
            "token_pinyin": token_pinyin, "ru": ru}


def resolve(blueprint: dict, words_by_hanzi: dict[str, dict]) -> dict:
    """Сценарий со словами базы вместо текста. ScriptError — если слова нет."""
    names = blueprint.get("names") or {}

    def sent(text, ru=None):
        return resolve_sentence(text, words_by_hanzi, names, ru)

    new_words = []
    for h in blueprint.get("new_words") or []:
        if h not in words_by_hanzi:
            raise ScriptError(f"нового слова {h!r} нет в базе")
        new_words.append(words_by_hanzi[h]["id"])

    def target_id(hanzi, fallback_ids):
        if hanzi and hanzi in words_by_hanzi:
            return words_by_hanzi[hanzi]["id"]
        return fallback_ids[0] if fallback_ids else None

    phrases = []
    for p in blueprint.get("phrases") or []:
        s = sent(p["cn"], p["ru"])
        phrases.append({**s, "ru_distractors": list(p.get("ru_distractors") or []),
                        "target": target_id(p.get("target"), s["word_ids"])})
    translations = []
    for t in blueprint.get("translations") or []:
        answers = [sent(a) for a in t["answers"]]
        extra = [sent(x) for x in t.get("extra") or []]
        all_ids = sorted({i for a in answers for i in a["word_ids"]} | {i for x in extra for i in x["word_ids"]})
        translations.append({"ru": t["ru"], "answers": [a["tokens"] for a in answers],
                             "cn": answers[0]["cn"], "pinyin": answers[0]["pinyin"],
                             "extra_tokens": [tok for x in extra for tok in x["tokens"]],
                             "word_ids": all_ids, "target": target_id(t.get("target"), answers[0]["word_ids"])})
    dialogue = None
    if blueprint.get("dialogue"):
        d = blueprint["dialogue"]
        lines = []
        for line in d["lines"]:
            s = sent(line["cn"], line["ru"])
            lines.append({**s, "who": line["who"], "user": bool(line.get("user")),
                          "distractors": [sent(x["cn"], x.get("ru")) for x in line.get("distractors") or []],
                          "target": target_id(line.get("target"), s["word_ids"])})
        dialogue = {"title": d.get("title"), "lines": lines}
    speaking = []
    for sp in blueprint.get("speaking") or []:
        s = sent(sp["cn"], sp["ru"])
        speaking.append({**s, "target": target_id(sp.get("target"), s["word_ids"])})
    notes = {words_by_hanzi[h]["id"]: n for h, n in (blueprint.get("notes") or {}).items() if h in words_by_hanzi}
    return {"key": blueprint["key"], "title": blueprint["title"], "goal": blueprint["goal"],
            "intro": blueprint.get("intro"), "can_do": list(blueprint.get("can_do") or []),
            "new_word_ids": new_words, "phrases": phrases, "translations": translations,
            "dialogue": dialogue, "speaking": speaking, "notes": notes}


def blueprint_hanzi(blueprint: dict) -> set[str]:
    """Все слова (не имена и не знаки), которые встречаются в сценарии."""
    texts = list(blueprint.get("new_words") or [])
    for p in blueprint.get("phrases") or []:
        texts.append(p["cn"])
    for t in blueprint.get("translations") or []:
        texts += list(t["answers"]) + list(t.get("extra") or [])
    for line in (blueprint.get("dialogue") or {}).get("lines") or []:
        texts.append(line["cn"])
        texts += [d["cn"] for d in line.get("distractors") or []]
    texts += [sp["cn"] for sp in blueprint.get("speaking") or []]
    return {t for text in texts for t in _tokens(text) if t not in PUNCT and not t.startswith(NAME_PREFIX)}


def try_resolve(blueprint: dict, words_by_hanzi: dict[str, dict]) -> dict | None:
    try:
        return resolve(blueprint, words_by_hanzi)
    except ScriptError:
        return None


def choose_script(scripts: list[dict | None], completed_keys: set[str]) -> dict | None:
    """
    Первый по порядку непройденный сценарий модуля. Неразрешимый сценарий
    (нет слова в базе) останавливает выбор: следующие уроки темы опираются на
    предыдущие, перескакивать через урок нельзя.
    """
    for s in scripts:
        if s is None:
            return None
        if s["key"] not in completed_keys:
            return s
    return None


def lesson_new_ids(script: dict, seen_ids: set[int]) -> list[int]:
    """Новые слова сценария, которых пользователь ещё не проходил (в порядке сценария)."""
    return [wid for wid in script["new_word_ids"] if wid not in seen_ids]


def script_coverage(script: dict, known: set[int]) -> int:
    """Сколько шагов сценария (фразы, на слух, диалог, перевод, речь) реально строится,
    если ученику знакомы known: те же условия, что в build_steps (все слова шага
    знакомы, есть варианты-ловушки)."""
    return len(build_steps(script, set(known), set(known), Random(0)))


def _split_candidates(script: dict, seen_ids: set[int], limit: int, own_ids: set[int] | None):
    """Допустимые наборы новых слов для урока: ровно limit слов сценария, и в остатке
    остаётся слово своего модуля (если оно есть) — иначе модуль закрылся бы по своим
    словам, а чужое слово (门 в «Действиях») не вошло бы ни в один урок по сценарию."""
    from itertools import combinations

    new = lesson_new_ids(script, seen_ids)
    own = set(new) if own_ids is None else set(own_ids)
    own_new = [w for w in new if w in own]
    combos = list(combinations(new, limit))
    ok = [c for c in combos if not own_new or any(w in own for w in new if w not in c)]
    return new, own, ok or combos


def split_new_words(script: dict, seen_ids: set[int], limit: int, own_ids: set[int] | None = None) -> list[int]:
    """
    Новые слова сценария для этого урока — не больше limit. limit — норма новых слов,
    уже рассчитанная движком для урока модуля (adaptive_daily_new → lesson_mix: точность
    ученика, долг повторений, хвост модуля), та же, что у обычного урока. Сценарий её не
    увеличивает: остальные слова — следующий урок того же сценария (Phase I.1, риск 1).

    Из допустимых наборов (_split_candidates) берётся тот, с которым в уроке строится
    больше всего шагов сценария (script_coverage: фразы, диалог, перевод, речь) — чтобы
    первая часть темы не осталась без сценарного содержания, когда это возможно в пределах
    нормы; при равенстве — с большим числом слов чужой темы (их лучше ввести раньше),
    затем в порядке сценария. Если ни один набор в пределах нормы не даёт ни одной фразы,
    урок остаётся без шагов сценария — норма не увеличивается, фразы не придумываются.
    """
    new = lesson_new_ids(script, seen_ids)
    if limit >= len(new):
        return new
    if limit <= 0:
        return []
    _, own, candidates = _split_candidates(script, seen_ids, limit, own_ids)
    seen = set(seen_ids)
    best = max(candidates, key=lambda c: (script_coverage(script, seen | set(c)),
                                          sum(1 for w in c if w not in own)))
    return [w for w in new if w in best]


def best_split_coverage(script: dict, seen_ids: set[int], limit: int, own_ids: set[int] | None = None) -> int:
    """Наибольшее число шагов сценария, достижимое в уроке при норме limit (для проверки:
    пустая первая часть допустима, только если это 0)."""
    new = lesson_new_ids(script, seen_ids)
    if limit >= len(new):
        return script_coverage(script, set(seen_ids) | set(new))
    if limit <= 0:
        return script_coverage(script, set(seen_ids))
    _, _, candidates = _split_candidates(script, seen_ids, limit, own_ids)
    return max(script_coverage(script, set(seen_ids) | set(c)) for c in candidates)


# ---------------------------------------------------------------------------
# Шаги урока из сценария
# ---------------------------------------------------------------------------

def _shuffled_choice(correct, distractors, rng: Random):
    options = [correct, *distractors]
    order = list(range(len(options)))
    rng.shuffle(order)
    return [options[i] for i in order], order.index(0), order


def _pick_target(candidate: int | None, ids: list[int], lesson_ids: set[int]) -> int | None:
    if candidate in lesson_ids:
        return candidate
    for wid in reversed(ids):
        if wid in lesson_ids:
            return wid
    return candidate if candidate is not None else (ids[0] if ids else None)


def build_steps(script: dict, known_ids: set[int], lesson_ids: set[int], rng: Random) -> list[dict]:
    """
    Шаги сценария (dict: type, skill, word_id, phase, payload) в учебном порядке:
    понимание фраз → фраза на слух → диалог → перевод RU → CN → произношение.
    Шаг попадает в урок, только если все его слова знакомы к концу этапа
    знакомства (known_ids) — иначе он пропускается, а не показывает новое слово.
    lesson_ids — слова урока (новые и повторение): к одному из них шаг
    привязан для mastery/SRS.
    """
    steps: list[dict] = []

    def ok(ids) -> bool:
        return all(i in known_ids for i in ids)

    def add(type_name, target, ids, payload):
        wid = _pick_target(target, ids, lesson_ids)
        if wid is None:
            return
        steps.append({"type": type_name, "skill": SCRIPT_SKILLS[type_name], "word_id": wid,
                      "phase": SCRIPT_PHASES[type_name], "reason": SCRIPT_REASONS[type_name],
                      "payload": {**payload, "used_word_ids": sorted(set(ids))}})

    usable_phrases = [p for p in script["phrases"] if ok(p["word_ids"]) and len(p["ru_distractors"]) >= 2]
    for p in usable_phrases[:MAX_PHRASES]:
        options, idx, _ = _shuffled_choice(p["ru"], p["ru_distractors"][:2], rng)
        add("translate_cn_ru", p["target"], p["word_ids"], {
            "prompt": p["cn"], "pinyin": p["pinyin"], "question": "Что означает фраза?",
            "options": options, "answer_index": idx})
    if usable_phrases:
        # одна фраза — на слух: та же тема, но без текста перед глазами
        p = usable_phrases[-1]
        options, idx, _ = _shuffled_choice(p["ru"], p["ru_distractors"][:2], rng)
        add("sentence_listening", p["target"], p["word_ids"], {
            "prompt_audio": p["cn"], "transcript": p["cn"], "pinyin": p["pinyin"],
            "question": "Прослушайте фразу и выберите перевод", "options": options, "answer_index": idx})

    dialogue = script.get("dialogue")
    if dialogue:
        lines = dialogue["lines"]
        for i, line in enumerate(lines):
            if not line["user"] or len(line["distractors"]) < 2:
                continue
            ids = [w for ln in lines[: i + 1] for w in ln["word_ids"]] + [w for d in line["distractors"] for w in d["word_ids"]]
            if not ok(ids):
                continue
            entries = [line, *line["distractors"][:2]]
            options, idx, order = _shuffled_choice(line, line["distractors"][:2], rng)
            context = [{"who": ln["who"], "cn": ln["cn"], "pinyin": ln["pinyin"], "ru": ln["ru"], "user": ln["user"]}
                       for ln in lines[:i]]
            follow = lines[i + 1] if i + 1 < len(lines) and not lines[i + 1]["user"] else None
            add("dialogue_scene", line["target"], ids, {
                "question": "Ваша реплика в диалоге", "title": dialogue.get("title"), "context": context,
                "options": [o["cn"] for o in options],
                "option_translation": [entries[k]["ru"] for k in order],
                "option_pinyin": [entries[k]["pinyin"] for k in order],
                "answer_index": idx, "reply_ru": line["ru"], "reply_pinyin": line["pinyin"],
                "follow": ({"who": follow["who"], "cn": follow["cn"], "pinyin": follow["pinyin"], "ru": follow["ru"]}
                           if follow and ok(follow["word_ids"]) else None)})

    for t in [t for t in script["translations"] if ok(t["word_ids"])][:MAX_TRANSLATIONS]:
        tiles = list(t["answers"][0]) + list(t["extra_tokens"])
        for _ in range(10):
            rng.shuffle(tiles)
            if tiles[: len(t["answers"][0])] != t["answers"][0]:
                break
        add("translation_build", t["target"], t["word_ids"], {
            "question": "Переведите на китайский", "hint": t["ru"], "tokens": tiles,
            "answers": t["answers"], "pinyin": t["pinyin"], "extra_count": len(t["extra_tokens"])})

    for sp in [s for s in script["speaking"] if ok(s["word_ids"])][:MAX_SPEAKING]:
        add("speaking", sp["target"], sp["word_ids"], {
            "question": "Произнесите фразу вслух", "text": sp["cn"], "tokens": sp["tokens"],
            "token_pinyin": sp["token_pinyin"], "pinyin": sp["pinyin"], "ru": sp["ru"]})
    return steps


def lesson_meta(script: dict, words_by_id: dict[int, dict], new_ids: list[int]) -> dict:
    """Карточка начала урока: тема, цель, введение, слова урока."""
    words = [words_by_id[w] for w in script["new_word_ids"] if w in words_by_id]
    return {"key": script["key"], "title": script["title"], "goal": script["goal"], "intro": script["intro"],
            "can_do": script["can_do"], "mode": "new" if new_ids else "practice",
            "words": [{"id": w["id"], "hanzi": w["hanzi"], "pinyin": w["pinyin"], "translation": w["translation"],
                       "new": w["id"] in new_ids} for w in words]}
