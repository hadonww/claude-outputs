# PLAN_WB_v1.md — Пошаговый план

> Исторический детальный план и журнал решений. Актуальный статус — `docs/CURRENT_STATE.md`,
> очередь работ — `docs/ROADMAP.md`. Читать нужный этап по номеру, не целиком.

Каждый этап — небольшой, самостоятельно проверяемый шаг. Ни один этап не
переписывает проект целиком. Платформенное решение (`ARCHITECTURE_WB_v1.md`,
раздел 0) уже принято — вариант C, веб-клиент как основной клиент MVP —
поэтому начиная с Phase 3 этапы ниже это и есть работа над реальным
клиентом, а не "заготовка до решения". Единственный этап, всё ещё
зависящий от отдельного будущего решения — Phase 14 (нативный iOS-клиент).

> **Replanning note (после Phase 2):** порядок этапов 3+ пересмотрен по
> запросу — продуктовый приоритет сейчас Product → UX → Adaptive Learning
> → Design System → Implementation, с фундаментом в порядке Design System
> → Information Architecture → Home + Learning Path → Lesson architecture
> → Adaptive Learning Engine. Старые Phase 3 (Adaptive Learning Engine
> core) и Phase 12 (Design system finalization) переставлены местами не
> буквально "как было, но в другом порядке" — часть этапов пришлось
> переосмыслить, чтобы избежать одноразовой UI-работы. Объяснение — сразу
> после этой заметки, до самого плана.


> **Replan #2 (Lesson-first, после Phase 5).** Продуктовое решение: приложение —
> персональный тренер, а не набор инструментов. Навигация: Главная | Словарь |
> Профиль; «Учить» и «Практика» больше не destinations — их упражнения стали
> типами в реестре движка, а повторение (Review) — тот же Lesson Runner с
> другим планом. Фактически выполнено вместо Phase 6–7 в исходной формулировке:
> - Step 1 — `GET /api/lessons/{module_id}/plan` отдаёт контент именно модуля;
> - Step 2 — `backend/engine/` (mastery EMA, ExerciseType registry, детерминированный
>   Planner), `POST /api/lessons/{id}/attempts` → Attempt → Mastery → SRS;
> - Step 3 — единый Lesson Runner (one screen = one action);
> - Step 4 — Review через тот же Runner (`/api/review/plan`, `/api/review/attempts`),
>   таббар на 3 вкладки, Словарь: фильтр «Встречались».
> - Route — порядок и разделы курса живут в `backend/app/curriculum.py` (не в `modules.order_index`);
>   статусы completed/current/available/locked — политика `compute_statuses` с точкой расширения `unlocked_ids`
>   для placement / «Я это уже знаю»; в `/api/learning-path` добавлены поля модуля `route_index`, `section_*`, `status`.
> - Step 5 — типы `sentence_order` и `fill_blank` (навык grammar) на существующих `example_cn`.
> Не сделано: онбординг (Phase 9, баг «не вызывается» всё ещё открыт), placement test,
> translation / matching, contextual word card,
> диалоги, оценка произношения, серверная валидация ответов.


> **Phase B (vocabulary foundation, после Content/Lesson/Review fixes).**
> Импортирован HSK 2.0 old-standard (drkameleon/complete-hsk-vocabulary, MIT) —
> 446 новых слов (177 рукописных не тронуты), 623 всего. Архитектурные решения:
> `words.hsk` не переименован в `hsk_level` (слишком большой blast radius ради
> названия) — вместо этого добавлен `hsk_version` рядом; `category` стал
> nullable (пересборка таблицы, FK временно off) — импортированные слова
> получили NULL, а не выдуманную категорию, и поэтому невидимы для planner
> (INNER JOIN по progress/category) и профильной статистики — видны только
> в Словаре. progress-строка для них намеренно не создаётся (создаётся Phase D
> при осознанном подключении). Скрипт и audit-отчёт — `backend/scripts/`.


> **Phase C (examples как отдельная сущность).** Таблица `examples`
> (target_word_id, sentence_cn, sentence_ru, used_word_ids, source,
> needs_review). Старые 177 примеров мигрированы: 142 разобраны (used_word_ids
> явный, не токенизация), 35 требуют ручной проверки — честно помечены, не
> используются движком. `reparse_examples_needing_review()` можно безопасно
> перезапускать при росте словаря (так и было сделано после HSK-импорта:
> 43 -> 142). 30 новых примеров для HSK-импорта — вручную, с проверкой перед
> вставкой (target реально в used_word_ids, длина 3-9, не дубль). fill_blank/
> sentence_order переключены на used_word_ids вместо runtime-токенизации;
> known_vocabulary теперь по word_id, не по hanzi. Попутно нашёл в Phase B
> данных: 没/吗/了 получили неверную омографическую форму (mò/má/liǎo вместо
> méi/ma/le) — исключены из seed, не исправлены в самой БД (вне объёма Phase C).


> **Phase D (адаптивный planner).** Приоритет review — weak+due, не только
> due_date (SQL: слабые слова, total_attempts>=2 и точность<70%, идут первыми
> среди просроченных, тот же порог что у profile_weak_words). Бюджет урока
> перенесён в engine (`compute_budget`, было в lesson_service — п.12 нарушение
> "planner — источник истины"), новое теперь получает бюджет ПЕРВЫМ (раньше
> review мог полностью заблокировать новое — подтверждено сравнением со
> старой версией на одних данных: 8 просроченных слов при бюджете 14 давали
> 0 introduction и 7 recall подряд). Форма урока — чередование
> NEW_CHUNK/REVIEW_CHUNK блоками, не "весь review, потом всё новое".
> Анти-повтор: `_diversify_consecutive_types` не даёт 3+ одинаковым типам
> подряд. Честная находка: "Я уже знаю" — фичи нет в коде вообще, только
> комментарии-заглушки; не стал её выдумывать в Phase D.


> **Phase E (statistics backend).** Три новые таблицы: `lesson_completions`
> (настоящее серверное событие завершения урока — exercises_count дельтой
> реальных attempts с прошлого completion, не со слов клиента),
> `mastery_history` (ежедневный снимок, идемпотентный в пределах дня),
> `review_schedule` (planned/completed review — строка создаётся/закрывается
> прямо в submit_review). Per-skill mastery теперь различает no_data (0
> попыток) от реального счёта — раньше оба выглядели как "0%". longest_streak
> считается из уже существующего activity_log, не новая таблица. response_ms
> теперь реально отправляется с фронта (замер performance.now() от показа
> шага до ответа) — раньше поле существовало в схеме, но фронтенд его не
> заполнял вообще (grep подтвердил 0 использований). Новый `/api/statistics`,
> `/api/profile` расширен (longest_streak), оба поля не ломают старый
> контракт. Честная находка в живом сценарии: due_now (progress.due_date) и
> review_consistency.planned (review_schedule) разошлись на 2 слова — оказался
> артефакт ручного SQL для имитации "прошедшего времени" в сценарии, не баг.


> **Phase F (Profile UI).** Полный редизайн по разделам A-G из статистики
> Phase E: статус-строка + разбивка по HSK (не одна слитная карточка),
> навыки — компактный список, не 8 карточек (честный "Пока недостаточно
> данных", не выдуманный 0%), сегментированный индикатор прогресса обучения,
> активность 7/30 дней (минимальное расширение API: week_activity_counts
> получила параметр days), тренд mastery (honest-сообщения при 0/1 снимке —
> не рисует график из одной точки), повторение, личный фокус (сравнивает
> только навыки с реальными данными, не "слабейший из одного"), недавние
> уроки. Переиспользует материал Home (node-sheen/node-depth), не копирует
> структуру. Найдены и исправлены вживую: (1) слипание названия навыка со
> статистикой — вёрстка; (2) настоящая гонка состояний — showView("dict")
> безусловно вызывал loadDictionary("") поверх прицельного поиска по слову
> из "Личного фокуса", фронтенд победителя гонки не контролировал; (3) старый
> активный фильтр категории мог скрыть результат точечного перехода. Отдельно
> зафиксирован, но НЕ исправлен (не Profile UI): чип категории "null · 446"
> в Словаре — следствие category=NULL у импортированных слов (Phase B).

## Почему не "просто поменять порядок 1:1"

Прямая перестановка (сначала вся Adaptive Learning Engine глубина в
конец, сначала все экраны) создаёт риск: главный элемент Home — это
персональный learning path, отвечающий "что мне сейчас изучать". Это
прямой **вывод** Adaptive Learning Engine (или на первое время — его
простой предшественник). Если отрисовать Home и Lesson-экраны против
заглушки/фейковых данных, а потом подключать реальный Engine — экраны
придётся частично переделывать, когда появится реальный контракт
данных (совсем не то же самое, что "перекрасить готовое" из
ARCHITECTURE раздела 11 про дизайн-токены, где риск именно такой —
только для внешнего вида, не для контракта данных).

**Предлагаемое решение (эволюционный мост, не рескоп):** Home и Lesson
UI строятся не против фейковых данных и не против глубокого Engine, а
против **простого, честного, детерминированного правила**, которое уже
можно построить прямо сейчас на данных Phase 2 (`modules`/`lessons`
существуют, `attempts` пока пуста): "следующий урок = первый модуль по
`order_index`, в котором пользователь ещё не отвечал ни на одно слово".
Это не фейковые данные — это настоящий, пусть пока примитивный, вывод
на реальном состоянии пользователя. API-контракт (`GET /learning-path`,
`GET /lessons/{id}/plan`) фиксируется сразу таким, каким он должен быть
и для сложной версии; Phase 7 (Adaptive Learning Engine core) заменяет
**реализацию** за тем же контрактом на mastery-взвешенную — фронтенд
это не заметит и переделывать не придётся.

Это позволяет буквально выполнить заявленный порядок (Design System →
IA → Home/Path → Lesson architecture → Adaptive Learning Engine) без
выбрасывания работы. Если для какого-то из этапов ниже эта логика не
сработает и придётся действительно "заглушить, потом переделать" — это
будет явно написано в самом этапе, а не молча.

---

### Phase 0 — Решения и фундамент (без кода фич) — ✅ DONE

**Goal.** Зафиксировать решения, без которых остальные этапы рискуют
переделками, и завести базовую гигиену репозитория.

**Files/modules.** `.git` (init), `backend/tests/` (новая директория),
`pyproject.toml` или `pytest.ini`, `AGENTS.md` (см. отдельный документ).

**Dependencies.** Решение по `ARCHITECTURE_WB_v1.md` разделу 0
(платформа) — принимается человеком, не мной.

**Tasks.**
1. `git init`, первый коммит текущего состояния as-is (baseline).
2. Добавить `pytest` в `requirements.txt` (dev-зависимость), создать
   `backend/tests/test_srs.py` с покрытием существующего `srs.py` —
   первый тест в проекте, независимо от остального плана.
3. Зафиксировать решение по платформе (A/B/C из ARCHITECTURE) письменно.

**Tests.** `pytest` зелёный, `srs.review()` покрыт кейсами: quality=0
сбрасывает repetitions, quality=3 растит interval по ease_factor,
`word_state()` — все 4 состояния.

**Acceptance criteria.** Репозиторий под git; `pytest` запускается и
проходит; платформенное решение записано (например в
`ARCHITECTURE_WB_v1.md` как "Decision: ...").

---

### Phase 1 — Backend: слои и users-заготовка — ✅ DONE

**Goal.** Разбить `main.py` на слои без изменения поведения API
(рефакторинг, не редизайн) и ввести таблицу `users` (пока с ровно одной
записью, дефолтный локальный пользователь) — чтобы дальше не тащить
"user_id=1 магию" по всему новому коду.

**Files/modules.** `backend/app/routers/*.py`, `backend/app/repositories/
*.py`, `backend/app/services/*.py`, `backend/main.py` (становится тонкой
точкой входа, собирающей routers).

**Dependencies.** Phase 0.

**Tasks.**
1. Вынести SQL-запросы каждой предметной области (words, progress/
   review, stats/profile) в отдельные repository-функции.
2. Роуты — в отдельные `APIRouter`, подключаемые в `main.py`.
3. Добавить таблицу `users` (id, created_at) с автосозданием ровно
   одной записи при пустой БД (аналог текущего `stats.id=1`, но как
   полноценная сущность). `stats`/`progress` получают `user_id` FK,
   пока всегда указывающий на единственного пользователя.
4. Existing frontend не меняется — контракт API идентичен предыдущему.

**Tests.** Существующие ручные curl-проверки формализовать в
`backend/tests/test_api_smoke.py` (FastAPI `TestClient`): `/api/home`,
`/api/session`, `/api/review`, `/api/profile`, `/api/settings` отвечают
как раньше.

**Acceptance criteria.** Текущий фронтенд продолжает работать без единой
правки на клиенте; `pytest` зелёный; `main.py` — не более ~80 строк
(сборка приложения), вся логика — в routers/services/repositories.

---

### Phase 2 — Domain model для Adaptive Learning Engine — ✅ DONE

**Goal.** Добавить таблицы `skills`(статичный enum-справочник),
`mastery`, `modules`, `lessons`, `attempts` — **аддитивно**, ничего не
удаляя из текущей схемы.

**Files/modules.** `backend/app/repositories/mastery.py`,
`.../modules.py`, `.../attempts.py`, миграции через существующий паттерн
`_add_column_if_missing`/`CREATE TABLE IF NOT EXISTS` (Alembic — по
решению, см. ARCHITECTURE п.9, не блокирует этот этап).

**Dependencies.** Phase 1 (таблица `users` существует).

**Tasks.**
1. `mastery(user_id, skill, score, updated_at)`.
2. `modules(id, order, title, hsk_level, category)`,
   `lessons(id, module_id, order, title)`.
3. `attempts(id, user_id, lesson_id, exercise_type, skill,
   content_item_id, correct, response_ms, created_at)`.
4. Наполнить `modules`/`lessons` на основе существующих `category` из
   `words` — 1 модуль на категорию как стартовая раскладка (16 модулей
   из текущих 16 категорий), без ручного авторства контента на этом
   шаге.

**Tests.** Repository-тесты: создание mastery-записи, инкрементальное
обновление, выборка due lessons.

**Acceptance criteria.** Новые таблицы существуют и населены на основе
текущих данных; ничего в существующем API/фронтенде не сломано (те же
smoke-тесты Phase 1 всё ещё зелёные).

---

### Phase 3 — Design System (Premium + Minimal, Light/Dark) — ✅ DONE

**Goal.** Единый источник дизайн-токенов для обеих тем — до того, как
перекрашивается хоть один реальный экран. Замена нынешней "тёплой рисовой
бумаги" (AUDIT п.9) на premium/minimal направление: много воздуха,
сильная типографическая иерархия, сдержанная китайская эстетика (без
драконов и фонарей), качественные карточки/progress/buttons и
microanimations — без превращения в детскую gamification-игру.

**Визуальный ориентир.** В этом сообщении новое изображение не
прикреплено — использую как ориентир мокапы "A. Минималистичный
премиум" / "D. Тёмный премиум", присланные ранее в этом диалоге (белый+
серый+чёрный+красный / тёмный фон+красный акцент), не копируя их
буквально. Если имелся в виду новый референс — пришлите отдельным
сообщением, тогда сверю токены с ним до следующего этапа.

**Files/modules.** `frontend/design-tokens.json` (новый — единый
источник: цвет, типографическая шкала, spacing, radius, shadow, motion),
`frontend/style.css` (токен-блок переписывается на основе tokens.json;
конкретные компоненты пока не трогаются — это буквально следующий этап).

**Dependencies.** Ничего технически (чистый UI), логически — после
Phase 2 просто по порядку заявленного приоритета.

**Tasks.**
1. Light: background/cards/text-hierarchy/accent/border/button/progress/
   states — полный набор, не "пусть наследует".
2. Dark: тот же полный набор как самостоятельная система, не инверсия
   (ARCHITECTURE раздел 11 требует именно так).
3. Типографическая шкала (display/heading/body/caption) + шкала
   spacing/radius/shadow + motion-токены (длительность/easing) для
   microanimations.
4. Один аккуратный, не декоративный китайский визуальный акцент
   (типографика/тонкая геометрия), не более.

**Tests.** Не unit-тестируемо (визуальный дизайн) — вместо теста
чек-лист: обе темы специфицируют 100% списка токенов из п.1/2 (ни один
канал не "наследуется от light по умолчанию"); открыть текущий
`index.html` с новым `style.css` — нет `var(--x)`, ссылающихся на
несуществующий токен (грубая проверка: grep всех `var(--...)` в CSS
против списка определённых токенов).

**Acceptance criteria.** `design-tokens.json` — единственный источник
истины; оба набора токенов полны; ни один существующий экран ещё не
перекрашен (это дисциплина скоупа, не недоработка — перекраска входит в
Phase 5/6 вместе с новой структурой экранов, чтобы не красить дважды).

---

### Phase 4 — Information Architecture — ✅ DONE (решение: состав вкладок не меняется, см. коммит)

**Goal.** Зафиксировать структуру навигации и инвентарь экранов под
новое направление (Home = обучение, не dashboard; отдельный HSK-раздел;
единый Lesson-раннер) — как спецификацию, до кода экранов.

**Files/modules.** Обновление `PRODUCT_SPEC_WB_v1.md` разделов 4–5
(Home, Learning Map) с конкретной картой навигации для веб-клиента;
минимальный код — только "skeleton"-роутинг во `frontend/app.js`
(`showView()` целями становятся новые разделы), без содержимого экранов.

**Dependencies.** Phase 3 (токены готовы стилизовать skeleton).

**Tasks.**
1. Зафиксировать вкладки/разделы: Home (путь), Курс/Path, HSK (отдельно
   от основного пути — PRODUCT_SPEC раздел 17), Словарь, Профиль.
   Решить явно: остаётся ли отдельная вкладка "Практика" или её
   функция полностью переезжает внутрь Lesson-раннера (Phase 6) —
   зафиксировать решение письменно в этом же обновлении PRODUCT_SPEC,
   не молча.
2. Развести `showView()`-цели под новую структуру, старые view-заглушки
   не удалять раньше времени — переключаются по мере готовности
   следующих фаз.

**Tests.** Смок-проверка: каждый пункт навигации рендерит непустой
(пусть временно пустой контентом) экран без ошибок в консоли.

**Acceptance criteria.** Карта навигации зафиксирована в
`PRODUCT_SPEC_WB_v1.md`; skeleton-переключение между разделами работает
на новых токенах Phase 3.

---

### Phase 5 — Home + Learning Path — ✅ DONE

**Goal.** Home отвечает на "что мне сейчас изучать" через реальный,
но пока простой (не mastery-взвешенный) Learning Path — честные данные
из Phase 2, не заглушка. Замена нынешнего dashboard-подобного Home.

**Files/modules.** `backend/app/repositories/modules_repo.py`
(расширение: выборка "первый модуль без активности пользователя"),
`backend/app/services/learning_path_service.py` (новый),
`backend/app/routers/learning_path.py` (новый: `GET /api/learning-path`,
`GET /api/learning-path/next`), фронтенд: новый Home (карточка
"сегодня" + путь по модулям, PRODUCT_SPEC разделы 4–5), на токенах
Phase 3.

**Dependencies.** Phase 2 (`modules`/`lessons`), Phase 3, Phase 4.

**Tasks.**
1. Простое правило "следующий урок": первый по `order_index` модуль,
   для которого нет ни одного слова этой категории с `progress.
   repetitions > 0` у пользователя. Явно документируется как временное
   правило — заменяется в Phase 7 на mastery-взвешенное, **без смены
   контракта эндпоинта**.
2. `GET /api/learning-path` — список модулей с прогрессом (сколько слов
   категории уже затронуто/выучено — переиспользует существующие
   `words`/`progress` запросы).
3. Home: минимальная карточка "сегодня" (без длинного описания целей,
   PRODUCT_SPEC раздел 4) + путь, визуально разбитый на тематические
   секции.

**Tests.** Backend fixture-тест правила: пустой прогресс → модуль 1;
прогресс есть только в словах модуля 1 → рекомендуется модуль 2; и т.д.

**Acceptance criteria.** Home использует реальные данные, не
хардкод/мок; открытие рекомендованного урока — не более 2 нажатий от
Home; Home не содержит текста длиннее пары строк на блок.

---

### Phase 6 — Lesson architecture (One Screen = One Action)

**Goal.** Урок как раннер по последовательности одиночных экранов,
опирающийся на минимальный, но настоящий серверный `ExerciseType`
registry — заменяет клиентскую генерацию упражнений
(`startPractice()`, AUDIT п.4.3) и наконец начинает писать в таблицу
`attempts` (Phase 2, до сих пор пустую).

**Files/modules.** `backend/engine/exercise_registry.py` (новый —
минимум 5 типов: vocab CN→RU/RU→CN, pinyin choice, tone choice,
listening choice; writing — отдельно через уже работающий HanziWriter-
поток, не через registry на этом этапе), `backend/app/services/
lesson_service.py`, `backend/app/routers/lessons.py` (`GET /api/lessons/
{id}/plan`, `POST /api/lessons/{id}/attempts`), фронтенд: Lesson-раннер
(один экран = одно действие) вместо текущего `card-flow`/`study-flow`.

**Dependencies.** Phase 2 (`attempts`, `skills`), Phase 5 (Home ведёт в
урок).

**Tasks.**
1. `plan_lesson()` на этом этапе — **простое фиксированное правило**
   (не mastery-взвешенное): например 60% новых слов модуля + 40% due-
   повторений, чередование типов упражнений без повторов подряд.
   Явно документируется как временное — Phase 7 подменяет реализацию
   за тем же контрактом.
2. `POST /lessons/{id}/attempts` — пишет реальную строку в `attempts`
   (впервые в проекте), обновляет `progress` через уже существующий
   `srs.review()` (переиспользуется, не дублируется).
3. Удалить клиентскую `startPractice()` после переключения (правило
   "не удалять без причины" — причина: прямая замена эквивалентным
   серверным путём, как и в исходном плане Phase 6).

**Tests.** Contract-тест: `plan` возвращает непустой список для
валидного урока; `attempts` персистит корректно; фикстура на
фиксированное правило распределения 60/40.

**Acceptance criteria.** Полный урок проходится через новый раннер
end-to-end; `attempts` реально наполняется; ни один тип упражнения не
генерируется в клиентском коде.

---

### Phase 7 — Adaptive Learning Engine core

**Goal.** То, что было отдельной Phase 3 в исходном плане — теперь
как замена **реализации** за уже существующими с Phase 5/6 контрактами
(`/api/learning-path`, `/api/lessons/{id}/plan`), без изменений на
фронтенде.

**Files/modules.** `backend/engine/mastery.py` (EMA-формула,
ARCHITECTURE п.3.1), `backend/engine/lesson_planner.py`
(mastery-взвешенный алгоритм, ARCHITECTURE п.3.2–3.3) — чистый пакет
без FastAPI/SQL-импортов; `learning_path_service.py`/`lesson_service.py`
(Phase 5/6) переключаются на вызов Engine вместо простых правил.

**Dependencies.** Phase 6 (реальные `attempts` уже пишутся — mastery
считается на настоящих данных, не с нуля на пустой таблице).

**Tasks.**
1. `update_mastery(old_score, outcome, k) -> new_score`.
2. Skill-взвешенное распределение упражнений (ARCHITECTURE п.3.2),
   реакция на ошибки внутри урока (п.3.3).
3. Заменить простое правило Phase 5 ("первый нетронутый модуль") на
   mastery-осведомлённую рекомендацию — тот же response shape.
4. Заменить фиксированное 60/40-правило Phase 6 на взвешенное по
   mastery — тот же response shape `ExerciseSpec[]`.

**Tests.** Таблица примеров для `update_mastery` (0/100/clamp).
Fixture-тесты `plan_lesson`: заданный mastery + пул контента →
ожидаемое распределение (с допуском, не точное число). Regression:
существующие Phase 5/6 contract-тесты продолжают проходить без правок
самих тестов (меняется только реализация под капотом).

**Acceptance criteria.** 100% покрытие веток `mastery.py`/
`lesson_planner.py`; пакет не импортирует `fastapi`/`sqlite3`; Home и
Lesson-план заметно по-разному ведут себя на разных mastery-фикстурах
без единой правки фронтенда.

---

### Phase 8 — Placement Test

**Goal.** Backend для короткого (10–15 заданий) placement test поверх
уже готового Exercise registry (Phase 6) и Engine (Phase 7).

**Files/modules.** `backend/app/routers/placement.py`,
`backend/engine/placement_scoring.py`, банк заданий —
`backend/content/placement_bank.json`.

**Dependencies.** Phase 7.

**Tasks.**
1. Banked-задания (10–15 шт, вручную проверенные, без "досыпания
   шумом").
2. `POST /placement-test/start`, `POST /placement-test/submit`.
3. Scoring (ARCHITECTURE п.3.5) → запись в `mastery` + рекомендованный
   стартовый уровень/модуль.

**Tests.** Fixture: заданные ответы (все верно / все неверно /
смешанно) → ожидаемый mastery/уровень.

**Acceptance criteria.** Полный прогон через API даёт предсказуемый
результат; ручной выбор HSK 1 в обход теста по-прежнему доступен.

---

### Phase 9 — Onboarding: починка и расширение

**Goal.** Исправить баг из AUDIT (onboarding не вызывается) и привести
onboarding в соответствие PRODUCT_SPEC разделу 3 (мотивация, placement
test), на токенах и структуре Phase 3–4.

**Files/modules.** Онбординг во `frontend/index.html`/`app.js`/
`style.css`, `backend/app/routers/settings.py` (+ поле `motivation`).

**Dependencies.** Phase 8 (placement test существует).

**Tasks.**
1. Подключить вызов `maybeShowOnboarding()` — починка бага.
2. Шаг "зачем вы учите китайский" перед текущим шагом уровня.
3. "Знаю немного"/"уже учил" → предложение placement test вместо
   прямого выбора уровня, с возможностью пропустить.

**Tests.** E2E прогон 5 путей (beginner, skip-test-manual-level, take-
test-pass, take-test-fail, skip-all-defaults).

**Acceptance criteria.** Онбординг реально показывается; все 5 путей
приводят к консистентному состоянию `users`/`mastery`/`settings`.

---

### Phase 10 — Streak/XP rework + End of Lesson

**Goal.** Починить ленивый пересчёт streak (AUDIT баг №2 — сгорает
после пропуска, без "save streak"), ввести XP как отвязанную от UI
величину, добавить компактный End of Lesson экран (PRODUCT_SPEC
разделы 13–15).

**Dependencies.** Phase 6 (Lesson-раннер уже существует — End of Lesson
встраивается в его конец).

**Tasks.** Streak пересчитывается при чтении (`GET /api/home`), не
только при записи. XP — отдельное поле/сервис, экраны читают готовое
число, не знают формулу начисления.

**Acceptance criteria.** Streak корректен сразу при открытии
приложения после пропуска дня; XP не виден более чем на 1 экране
(Profile); End of Lesson — компактная сводка без доминирующих
анимаций/XP.

---

### Phase 11 — Profile rework

**Goal.** PRODUCT_SPEC раздел 18 — premium/minimal профиль,
per-skill-осведомлённый (реальный mastery, не только per-word), XP не
доминирует.

**Dependencies.** Phase 7 (mastery), Phase 10 (XP).

**Acceptance criteria.** Профиль показывает per-skill прогресс;
achievements-заглушка присутствует архитектурно (сами achievements —
future).

---

### Phase 12 — Pronunciation v1

**Goal.** Интерфейс `assess_pronunciation()` (ARCHITECTURE п.7) —
сначала MVP-заглушка (запись голоса без реального скоринга, честно
помечено), затем реальный внешний speech-assessment API.

**Dependencies.** Phase 6.

**Acceptance criteria.** UI работает end-to-end хотя бы с заглушкой;
переключение на реальный провайдер не требует изменений в вызывающем
коде.

---

### Phase 13 — AI Dialogues v1

**Goal.** 1–2 сценария диалога с выбором из вариантов ответа
(PRODUCT_SPEC раздел 12), контентно ограниченный LLM.

**Dependencies.** Phase 7 (нужен allowed-vocab из mastery/введённых
слов).

**Acceptance criteria.** LLM не может ввести слово вне allowed-vocab;
результат диалога логируется как обычный `Attempt`.

---

### Phase 14 — Нативный клиент (если решение — переход к варианту B)

**Goal.** Полноценный SwiftUI-клиент к уже стабильному, протестированному
API. Design-токены (Phase 3) переносятся в `Color`-ассеты Xcode тем же
именованием.

**Dependencies.** Отдельное явное решение о переходе + все backend-этапы
выше.

**Замечание.** Реализуется и верифицируется вне текущей среды
разработки (Xcode) — см. ARCHITECTURE раздел 0.

