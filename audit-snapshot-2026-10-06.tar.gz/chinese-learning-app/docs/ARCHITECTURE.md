# ARCHITECTURE — как устроен код сейчас

Компактная карта фактического состояния. Обоснования и варианты, которые обсуждались
до реализации, — в `ARCHITECTURE_WB_v1.md` (читать нужный раздел, не целиком).
Правила изменений — `AGENTS.md`. Что работает/сломано — `docs/CURRENT_STATE.md`.

## Стек
FastAPI + SQLite (`backend/app.db`, в `.gitignore`) + чистые HTML/CSS/JS без сборки
(`frontend/`, раздаётся тем же сервером). Один локальный пользователь (`users.id = 1`),
авторизации нет; таблицы уже несут `user_id`.

## Слои (зависимости только сверху вниз)
```
frontend/app.js            рендер и вызовы API; learning-логики нет
backend/app/routers/       HTTP: content, learning (legacy), learning_path, lessons, profile, settings
backend/app/services/      оркестрация: lesson_service, learning_service, learning_path_service,
                           profile_service, statistics_service, content_service, settings_service
backend/app/repositories/  ЕДИНСТВЕННОЕ место с SQL (по таблице на файл)
backend/engine/            чистое ядро, без fastapi/sqlite (проверяется тестом):
                           exercise_types (реестр + PHASES + STAGES), lesson_planner, lesson_script
                           (сценарии тем, Phase H), answer_check (серверная проверка ответа),
                           pronunciation (шкала 0–100 по словам), mastery, scoring
backend/srs.py             SM-2 + word_state (new/learning/review/mastered)
backend/app/curriculum.py  маршрут курса, разделы, раскладка слов по модулям (чистый модуль)
backend/scripts/           build_course_db.py (вся база курса одной функцией), validate_hsk1_course.py
                           (весь HSK 1 новым учеником), simulate_users.py (4 ученика), simulate_course.py,
                           import_hsk_vocabulary.py, seed_hsk_examples.py, connect_hsk_course.py,
                           reports/*.json
backend/data/              hsk_course_map.tsv — тема/RU-перевод/исправленный пиньинь 446 HSK-слов;
                           lessons/hsk1_*.json — сценарии всех 17 тем HSK 1 (42 урока, Phase H/I)
backend/app/content_fixes.py исправления контента для старых баз (init_db, идемпотентно)
```

## Поток «урок» (с 2026-10 — через серверную сессию)
Home → `GET /api/learning-path` → `POST /api/lessons/{module_id}/start` (сервис собирает
new/review/mastery/examples/dialogues → `engine.plan_lesson` → шаги; шаги с ответами
сохраняются в `lesson_sessions`, клиенту — без `answer_index/answer_tokens/answer`) → на каждый
шаг `POST /api/sessions/{id}/attempts {step_index, answer}` (`engine.answer_check` решает
correct + объяснение; сервер ведёт счётчики слова, пишет `attempts`, mastery EMA; на
**финальном** шаге слова — SRS, `review_schedule`, `mastery_history`; при ошибке — один
`retry_step` в конец сессии) → `POST /api/sessions/{id}/complete` (итог урока +
`lesson_completions`). Review — `POST /api/review/start` и те же `/api/sessions/...`.
`GET /api/lessons/{id}/plan` — предпросмотр без сессии (Главная считает «сегодня»).
Phase H: в плане `lesson` (тема, цель, введение, слова, `mode` new|practice) — если у модуля
есть сценарий; у шагов `stage` (new/practice/context/recall/production/speaking/review),
`role` (new/weak/due/recent/retention/script/verify) и `reason`.
`POST /api/sessions/{id}/known {step_index}` — «я это уже знаю» (заменяет оставшиеся упражнения
на слово одной проверкой, отдаёт новый список шагов); `POST /api/sessions/{id}/steps/{i}/speech`
(тело — аудио) — оценка произношения или `{available:false}`; `GET /api/pronunciation/status`.
Легаси, фронтендом не используются: `POST /api/lessons/{id}/attempts|complete`,
`/api/review/plan|attempts|complete` (клиентский `correct`), `GET /api/session`, `POST /api/review`. Профиль: `GET /api/profile`, `GET /api/statistics?activity_days=N`.
Остальное: `/api/home`, `/api/words[?q&category&hsk&seen&weak]` (латинский `q` ищется и в
пиньине без тонов), `/api/words/{id}` (+ `module`, `progress`, `examples`), `/api/categories`,
`/api/settings` (GET/POST), `/api/import-csv`.

## Таблицы (17)
`users` (`public_id`, `username`, `onboarding_completed_at`; уникальные индексы), `entitlements`
(user_id, entitlement, grant_type, granted_at, expires_at, slot), `words`, `progress`, `stats` (одна строка id=1: streak, daily_new_words=5, …),
`activity_log` (день → число review), `skills` (8: vocabulary, characters, pinyin, tones,
listening, grammar, writing, speaking), `mastery` (user, skill, score 0–100), `modules`
(тема × уровень HSK: 35 на свежей БД, 77 на полной; исходные 16 id сохранены, у каждого урок
в `lessons`), `lessons`, `attempts`, `examples`, `lesson_completions`,
`mastery_history` (UNIQUE user+skill+день), `review_schedule`.
`words`: `hsk` = уровень (не переименован), рядом `hsk_version` (NULL у рукописных, `'2.0'`
у импортированных), `category` nullable, `traditional`, `part_of_speech`, `pinyin_numeric`,
`module_id` (модуль курса), `translation_en` (исходник датасета), `translation_source`
(`reviewed_ru` — проверенный, `draft_ru` — черновой/спорный русский перевод подключённых
HSK-слов по колонке `status` карты; NULL у рукописных).
`examples`: `target_word_id`, `sentence_cn/ru`, `pinyin`, `used_word_ids` (упорядоченный JSON id
слов), `difficulty` (макс. HSK слов), `source` (`migrated_legacy`|`seed_handwritten`|
`course_handwritten`), `needs_review`.
`dialogues`: `target_word_id`, реплики A/B (`line_*_cn/ru/pinyin`), `used_word_ids` обеих реплик.
`lesson_sessions`: `id` (uuid hex), `module_id` (NULL — повторение), `kind`, `steps` (JSON с
ответами), `state` (JSON: ответы по шагам, попытки/ошибки по словам, SRS-результаты, повторы,
итог), `completed_at`.

## Движок
- 21 тип в `REGISTRY` (Phase I: pinyin_error, matching): introduction, recognition, listening, pinyin_choice, tone_choice,
  fill_blank, sentence_order, recall, handwriting, word_choice, sentence_meaning,
  sentence_listening, pinyin_input, dialogue_reply, pinyin_to_hanzi (Phase H) и типы сценария
  translate_cn_ru, translation_build, dialogue_scene, speaking (`requires` = никогда: их строит
  только `lesson_script.build_steps`). Контракт:
  `requires(item, pool, ctx)` / `build(item, pool, rng, ctx)`,
  `ctx = {known_word_ids, sentence_bank, dialogue_bank}`. Новый тип = новая запись (+ фаза в
  `PHASES`, рендерер во фронтенде и ветка проверки в `answer_check`), не ветка в планировщике.
- `engine/syllables` — разбор пиньиня на слоги (`split_syllables`, таблицы знаков тонов);
  `tone_choice` строится и проверяется по слогам (`answer_check._check_tone_choice`).
- `engine/pinyin_errors` — правдоподобные ошибки в пиньине для `pinyin_error`; `engine/polyphones`
  (генерируется `scripts/build_polyphones.py` из датасета) не даёт выдать настоящее чтение за ошибку.
- Фазы урока (`PHASES`): 1 знакомство/значение, 2 звук/форма, 3 фраза, 4 воспроизведение.
  Новое слово: introduction → recognition → фокус по слабому навыку → (фраза, необяз.) →
  `word_choice` (финальный). Шаги фаз 3–4 новых слов переносятся в конец урока
  (`_defer_late_phases`), перестановка-антиповтор откатывается, если ставит шаг раньше
  знакомства со словом. `SKILL_CAPS = {"writing": 3}`.
- `adaptive_daily_new(daily, recent_accuracy, due)` → норма новых по точности последних 40
  ответов; затем `lesson_mix`. `retry_step(item, failed_type, …)` — повтор после ошибки.
- `plan_lesson(new, review, mastery, pool, budget, rng, review_cap, practice_items)` →
  `Step[]`; детерминирован. Новое получает бюджет первым; блоки new/review чередуются
  (`NEW_CHUNK=REVIEW_CHUNK=2`); проход-антиповтор старается не допускать 3 одинаковых типа
  подряд (локальная перестановка, откатывается, если вынесла бы предложение раньше
  знакомства со словом). Слово повторения со state `new` (забытое) идёт как learning.
- `lesson_mix(daily_new_words, due_count, module_remaining, low_accuracy)` → (новых, review_cap):
  долг ≤ `BACKLOG_THRESHOLD`(12) → все новые, cap `LESSON_REVIEW_CAP`(4); ≤ 24 → 2/3 новых, cap
  `BACKLOG_REVIEW_CAP`(6); больше → половина (≥ 1), cap 6; хвост модуля ≤ 2 слов добирается
  сразу — только без долга и без сниженной по точности нормы (долг и точность важнее хвоста).
  **Одна норма новых слов** (`mix.new_word_budget` = `adaptive_daily_new` → `lesson_mix`) для
  обычного и сценарного урока: сценарий получает её готовой и не может превысить —
  `lesson_script.split_new_words(script, seen, new_word_budget, own)` возвращает не больше
  нормы: из наборов ровно такого размера, после которых в остатке есть слово своего модуля,
  берётся набор с наибольшим числом реально строящихся шагов сценария (`script_coverage`),
  при равенстве — с большим числом слов чужой темы, затем в порядке сценария. Если ни один
  набор в пределах нормы не даёт фраз (`best_split_coverage` = 0), урок остаётся без шагов
  сценария — норма не растёт, фразы не придумываются; валидатор такой урок всё равно
  отмечает (с причиной). Отличается
  только число шагов на слово (в сценарии нет отдельного recognition). `compute_budget(new,
  review_cap, scripted)` = max(15, new × (3 со сценарием | 4) + 2 × review_cap).
  `plan_lesson(compact_review=True)` (уроки сервиса): не слабое просроченное слово — 1 шаг, слабое
  — 2; слабая практика всегда в уроке. Повторов после ошибок ≤ `MAX_RETRIES_PER_LESSON`(3).
- Закрепление в тот же день: до `PRACTICE_CAP=4` слов, выученных сегодня (повтор завтра),
  получают по одному объективному упражнению в свободные review-слоты; шаги не `final` →
  SRS не трогается.
- **Сценарий темы (Phase H, `lesson_script`)**: `data/lessons/*.json` (через
  `lesson_scripts_repo`) → `resolve` (каждый токен — слово базы или объявленное имя `@Имя`;
  нет слова — сценарий недоступен целиком) → `choose_script` (первый непройденный по порядку;
  пройденные — `lesson_sessions.state.script_key` завершённых сессий) → новые слова = его ещё
  не пройденные слова (0 → урок «практика»). `build_steps` строит фразы (CN → RU, на слух),
  диалог по репликам, перевод RU → CN из плиток (несколько допустимых ответов, лишние
  плитки) и речь — только если ВСЕ слова шага (с неверными вариантами и плитками) знакомы
  к концу знакомства. В плане они идут после всех знакомств, по фазам 3 → 5 → 6, порядок не
  перемешивается; у новых слов урока со сценарием общий шаг-фраза (фаза 3) не строится.
- Роли слов урока: new; из очереди повторения weak (точность < 70% или забыто) / due;
  закрепление без SRS — weak не по сроку (`WEAK_PRACTICE_CAP=2`), затем recent (выучено
  сегодня); retention — одно освоенное слово (интервал ≥ 21), не встречавшееся ≥ 14 дней:
  один объективный шаг, не финальный; ошибка → SRS «не помню». SRS — только для new и
  review, не на шаге речи.
- «Я это уже знаю» (`lesson_service.claim_known`): только на карточке нового слова; обычные
  шаги слова заменяет один проверочный (word_choice → recognition → listening), финальных
  шагов у слова не остаётся; верно → `learning_service.confirm_known` (repetitions 2,
  интервал 6 дней — не «освоено»), неверно → SRS 0 + повтор в конце урока.
- Произношение: `pronunciation_service.assess_pronunciation(audio, words, pinyin)` — провайдер
  (`recognize` → пиньинь по словам; выбор `PRONUNCIATION_PROVIDER`, по умолчанию нет) +
  `engine.pronunciation.score_utterance` (совпало → 100, тон → 60, похоже → 0–50, нет → 0;
  среднее по слогам; засчитано ≥ 60). Без провайдера шаг не оценивается и не пишет попытку.
- Mastery: EMA k=0.2 на каждую оцениваемую попытку. SRS-качество слова — по доле ошибок за
  все оцениваемые шаги слова в уроке (`derive_srs_quality`: 0 ошибок → 2/самооценка; ≤ половины
  → 1; больше → 0; «Не помню» → 0).
- Слабое слово: `total_attempts ≥ 2` и точность `< 70%`, либо забытое (repetitions сброшен
  в 0 после прохождения); очередь review: слабые первыми, затем по `due_date`; review берётся
  и из других модулей.
- Варианты ответа: дистрактор, который тоже верен, не берётся — синоним по значениям
  перевода (recognition, word_choice), омофон (listening), тот же пиньинь в другой записи
  (pinyin_choice). Пул дистракторов — слова не выше уровня урока или уже знакомые
  (`lesson_service._lesson_pool`). У вариантов есть `option_hanzi/pinyin/translation` — по ним
  сервер объясняет ошибку, клиент показывает чтение/значение после ответа.

- **Правило неизвестных слов** (Phase I.1, решение владельца):
  * незнакомые слова запрещены в содержании, которое ученик должен изучить, понять или
    использовать: задание и инструкция, фраза, пример, диалог, перевод, пары сопоставления,
    плитки сборки самой фразы, подсказка;
  * незнакомое слово допустимо только как **неверный** вариант ответа (дистрактор в
    options/option_hanzi, лишняя плитка в translation_build/sentence_order);
  * верный ответ всегда из уже доступного материала (знакомые слова, повторение урока,
    слова, уже представленные в этом уроке);
  * дистрактор не нужен для понимания задания (задание понятно без него).
  Проверка: `scripts/validate_hsk1_course.content_rule_violations` — по иероглифам каждого
  текста каждого шага на всём маршруте HSK 1 (+ `used_word_ids`); тесты —
  `tests/test_unknown_word_rule.py`. Подсказки карточек знакомства — без исключений: только
  само слово, части его иероглифа (`components`) и слова сценариев, пройденных до этого
  урока (слова того же сценария нельзя: при разбиении темы они могут прийти позже).

## Инварианты и ловушки (на них уже наступали)
1. **Свежая БД = 177 слов.** 1039 HSK-слов (уровни 1–4), примеры, диалоги и подключение к
   курсу — только скриптами (команды в `CLAUDE.md`). После `import_hsk_vocabulary.py` слова «спят»
   (`category = NULL`, нет `progress`, видит только Словарь); `connect_hsk_course.py` даёт им
   тему, RU-перевод, `progress` и модуль. Слово без `category`/`progress` в курс не попадает.
2. `examples.used_word_ids` — источник истины для fill_blank/sentence_order. `tokenize()`
   нужен только для миграции старых примеров (`reparse_examples_needing_review`). Пример с
   `needs_review=1` движок не использует. Предложение (fill_blank, sentence_order и пример
   в introduction) допустимо, только если все слова, кроме целевого, известны: state ≠ new,
   слова повторения или новые слова этого урока, введённые РАНЬШЕ целевого. Легаси
   `words.example_cn` движок в уроке не показывает.
3. `progress.total_attempts/total_correct` растут только на финальном шаге слова за урок,
   а не на каждом упражнении; SM-2 сбрасывает `repetitions` в 0 при quality 0.
4. Даты в БД — строки `YYYY-MM-DD` без времени (в т.ч. `attempts.created_at`): не
   сравнивать с timestamp. Поэтому `lesson_completions.exercises_count` — дельта попыток.
5. Порядок курса — `curriculum.route_order`: уровень HSK модуля → раздел `ROUTE_SECTIONS`
   (Люди → Числа → Время → Действия → Грамматика → …) → `order_index`. `modules.order_index`
   не меняется. Слово ↔ модуль — `words.module_id` (не категория!); раскладку считает
   `curriculum.plan_course_modules` (группа < 2 слов сливается со следующим уровнем темы),
   применяет `modules_repo.sync_course_modules` (на каждом `init_db` — только слова без
   модуля; `reassign=True` — после подключения контента). Модуль без слов в путь не попадает.
   Глава во фронтенде = `section_key` (раздел × уровень); `section_id` общий для оттенка.
   Статусы (`completed/current/available/locked`) — `compute_statuses`; `completed` = все слова
   модуля пройдены хотя бы раз (`introduced_words`), а не «все сейчас выучены» — забытое
   слово возвращается через review и не откатывает маршрут. `unlocked_ids` — точка
   расширения под placement / «Я это уже знаю».
6. `due` — временной фильтр (`due_date ≤ сегодня`), а не состояние слова. «В SRS» =
   `repetitions > 0 OR total_attempts > 0` (`progress_repo.IN_SRS_SQL`); «новое» = ни одной
   финальной попытки. Забытое слово (SM-2 сбросил repetitions) остаётся в review — и остаётся
   знакомым для фраз (`lesson_planner._base_known`: state ≠ new ИЛИ accuracy не None; в словаре
   слова `state` забытого снова `new`, по нему одному «знаком ли» не решать).
7. Решения о составе урока принимает только `engine/lesson_planner`; сервис лишь
   подбирает данные по константам движка.
8. Цвета — `frontend/design-tokens.json` ↔ `style.css`, паритет Light/Dark проверяет
   `tests/test_design_tokens.py` (новый цветовой токен нужно добавить в маппинг теста). Там же:
   контраст текстовых токенов (WCAG), `font-size` только из `typography.allowedSizes`, нет
   эмодзи-иконок (иконки — `ICON_PATHS`/`icon()` в `app.js`, линейные SVG на currentColor).
   Длительности и кривые анимаций — только `--duration-*`/`--easing-*`; у каждого движения есть
   вариант для `prefers-reduced-motion`. Поведение интерфейса (двойной запуск урока, продолжение,
   лист слова, фокус, зоны нажатия ≥44px) проверяет `scripts/ui_checks.py` (Playwright, на копии БД).
9. `showView('dict')` читает значение `#dict-search` — перед программным переходом сначала
   записать значение в поле (иначе гонка двух запросов, исправлено в Phase F).
10. Миграции: `_add_column_if_missing` + разовые пересборки в `db.py`
    (`_migrate_words_category_nullable`); бэкфилл `examples` идёт только при пустой таблице.
11. Нет данных → `null`/`no_data`, а не «0%» (навыки без попыток, дисциплина review
    без запланированных, тренд без снимков).
12. **Identity:** внутренний `users.id` наружу не отдаётся; публичный — `public_id`. «Кто
   делает запрос» решает только `users_repo.get_current_user_id` (сейчас — первый аккаунт,
   авторизации нет); учебные таблицы (`progress`, `stats`, `activity_log`) по пользователю пока
   НЕ разделены. Аккаунт создаётся только `account_service.create_user` (публичного
   эндпоинта регистрации нет).
13. **Premium:** только `entitlements` + `account_service.premium_status`; клиент получает
   готовый статус. Лимит early_100 держит схема (CHECK + UNIQUE), не только код.
   `entitlements.granted_at` — полный UTC timestamp (исключение из п.4, с датами не сравнивается).
14. **Streak:** текущая серия и рекорд — из `activity_log` (`app/streak.py`), при чтении;
   GET-эндпоинты не пишут. `stats.streak` — кэш, обновляется только при ответе.
15. **Ответы — на сервере.** Правильность шага решает `engine.answer_check` по шагу из
   `lesson_sessions`; клиенту ответы не отдаются (кроме легаси-предпросмотра `GET …/plan`).
   recall — самооценка (сервер её принимает), handwriting — число неточностей от HanziWriter.
16. **Примеры и диалоги — из пословной разметки** (`data/examples`, `data/dialogues.tsv`):
   токен = слово базы; проверки `scripts/example_checks.py` (уровень ≤ цели, цель один раз,
   3–12 слов, русский перевод); жадная токенизация — только для старых `example_cn`.
17. **Сценарии HSK 1 — один курс.** Слова, выученные в темах раньше по маршруту, знакомы и дальше;
   слово новое ровно в одном уроке (можно в «чужой» теме, если оно там нужно: 不 в «Людях»).
   Любая правка `data/lessons` — прогнать `scripts/validate_hsk1_course.py` (и тесты
   `test_hsk1_course.py`): он проходит маршрут учеником и ловит слово из будущего урока.
18. **Пиньинь имён собственных — с заглавной** (Běijīng, Zhōngguó); сравнения пиньиня —
   без регистра, варианты `pinyin_choice` — строчными (иначе ответ выдаёт заглавная буква).
19. **Проверка удержания** берёт освоенное слово, если по нему не было ни SRS, ни ответов в
   уроках 14 дней (`attempts`): верная проверка SRS не трогает.
