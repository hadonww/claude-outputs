"""
Phase I — HSK 1 как последовательный курс: сценарии уроков по всем темам, проверка
всего маршрута новым учеником (без неизвестных слов), четыре сценария ученика
(новый, слабый, долг повторений, сильный), «я это уже знаю» на реальном контенте.

База строится настоящим конвейером (scripts/build_course_db.py) из выборки датасета
уровней 1–2 (tests/fixtures/hsk12_dataset.json), поэтому раскладка модулей HSK 1
совпадает с полной базой.
"""

import json
import shutil
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from engine import lesson_script

BACKEND = Path(__file__).resolve().parent.parent
DATASET = BACKEND / "tests" / "fixtures" / "hsk12_dataset.json"
LESSONS = BACKEND / "data" / "lessons"
HSK1_THEMES = ["люди", "числа", "время", "действия", "грамматика", "семья", "дом", "эмоции",
               "повседневная жизнь", "еда", "покупки", "школа", "работа", "технологии", "транспорт",
               "путешествия", "природа"]


@pytest.fixture(autouse=True)
def _restore_globals():
    """Проверки подменяют сегодняшнюю дату и путь к базе — после теста всё возвращается."""
    import app.config as cfg
    import app.db as dbm
    import app.services.learning_service as ls
    import app.services.lesson_service as les
    import app.services.profile_service as ps
    import app.services.statistics_service as ss
    from app import utils

    mods = (utils, ls, les, ps, ss)
    saved = [m.today_date for m in mods], cfg.DB_PATH, dbm.DB_PATH
    yield
    for m, f in zip(mods, saved[0]):
        m.today_date = f
    cfg.DB_PATH, dbm.DB_PATH = saved[1], saved[2]


@pytest.fixture(scope="module")
def course_db():
    import app.config as cfg
    import app.db as dbm
    from scripts.build_course_db import build

    saved = cfg.DB_PATH, dbm.DB_PATH
    path = build(Path(tempfile.mkdtemp()) / "course.db", DATASET, "1-2")
    cfg.DB_PATH, dbm.DB_PATH = saved
    return path


def _copy(src: Path) -> Path:
    dst = Path(tempfile.mkdtemp()) / "copy.db"
    shutil.copy(src, dst)
    return dst


def _route_lessons():
    files = {json.loads(p.read_text(encoding="utf-8"))["module"]["category"]: json.loads(p.read_text(encoding="utf-8"))
             for p in LESSONS.glob("hsk1_*.json")}
    return files, [(cat, b) for cat in HSK1_THEMES if cat in files for b in files[cat]["lessons"]]


# ---------------------------------------------------------------------------
# Контент: уроки по всем темам, каждое слово HSK 1 — новое ровно один раз
# ---------------------------------------------------------------------------

def test_every_hsk1_theme_has_lessons_with_a_goal(course_db):
    files, lessons = _route_lessons()
    assert set(files) == set(HSK1_THEMES)
    for cat in HSK1_THEMES:
        assert 1 <= len(files[cat]["lessons"]) <= 6, cat
        assert files[cat]["module"]["hsk_level"] == 1
    keys = [b["key"] for _, b in lessons]
    assert len(keys) == len(set(keys)) and len({b["title"] for _, b in lessons}) == len(keys)
    for _, b in lessons:
        assert b["goal"] and b["intro"] and len(b["can_do"]) >= 1, b["key"]
        assert set(b["notes"]) == set(b["new_words"]), (b["key"], "у каждого нового слова — подсказка")
        assert b["phrases"] and b["translations"] and b["dialogue"]["lines"] and b["speaking"], b["key"]


def test_lessons_cover_hsk1_once_and_never_use_future_words(course_db):
    import sqlite3

    conn = sqlite3.connect(course_db)
    hsk1 = {r[0] for r in conn.execute(
        "SELECT w.hanzi FROM words w JOIN modules m ON m.id = w.module_id WHERE m.hsk_level = 1")}
    words = {r[0]: {"id": r[1], "hanzi": r[0], "pinyin": r[2]} for r in conn.execute("SELECT hanzi, id, pinyin FROM words")}
    _, lessons = _route_lessons()
    learned: list[str] = []
    for _, b in lessons:
        assert 2 <= len(b["new_words"]) <= 5, b["key"]
        assert not set(b["new_words"]) & set(learned), (b["key"], "слово уже было новым раньше")
        learned += b["new_words"]
        future = lesson_script.blueprint_hanzi(b) - set(learned)
        assert not future, (b["key"], "слова из будущих уроков", future)
        lesson_script.resolve(b, words)          # все слова есть в базе
    assert set(learned) == hsk1                  # весь HSK 1, ни одного лишнего
    assert len(learned) == len(set(learned))


# ---------------------------------------------------------------------------
# Последовательная проверка маршрута (scripts/validate_hsk1_course.py)
# ---------------------------------------------------------------------------

def test_new_learner_goes_through_hsk1_without_unknown_words(course_db):
    from scripts.validate_hsk1_course import expected_script_keys, validate

    report = validate(course_db)
    assert report["ok"], report["problems"]
    assert report["violation_count"] == 0 and report["answer_mismatches"] == 0
    assert report["scripted_lessons"] == len(expected_script_keys(1)) == report["lessons"]
    assert report["generic_lessons"] == 0 and report["unseen_hsk1_words"] == []
    assert report["max_new_per_lesson"] <= 5
    log = report["lesson_log"]
    assert log[0]["review"] == 0 and all(r["review"] > 0 for r in log[1:])   # повторение с каждым уроком


def test_learner_with_mistakes_gets_every_exercise_type_on_real_content(course_db):
    """С ошибками в уроках появляются повторы, примеры и диалоги — все типы упражнений
    работают на контенте HSK 1, верный ответ всегда принимается, неизвестных слов нет."""
    from scripts.validate_hsk1_course import validate

    report = validate(course_db, accuracy=0.7, seed=5)
    assert report["ok"], report["problems"]
    types = set(report["step_types"])
    assert {"introduction", "recognition", "listening", "pinyin_choice", "tone_choice", "pinyin_error",
            "fill_blank", "sentence_order", "recall", "handwriting", "translate_cn_ru", "translation_build",
            "dialogue_scene", "speaking", "matching", "word_choice"} <= types


def test_forgotten_word_keeps_script_phrases_in_next_lesson(course_db):
    """Регрессия (Phase I): слово, на котором ошиблись (SM-2 сбросил repetitions), считалось
    незнакомым — следующий урок терял все фразы, диалог и перевод сценария."""
    from datetime import date
    from random import Random

    import app.config as cfg
    import app.db as dbm
    from scripts.simulate_course import _patch_today
    from scripts.simulate_users import _run, _start

    path = _copy(course_db)
    cfg.DB_PATH = dbm.DB_PATH = path
    _patch_today(date(2026, 1, 5))
    from app.db import get_db

    with get_db() as conn:
        plan = _start(conn)
        wo = next(w["id"] for w in plan["new_words"] if w["hanzi"] == "我")
        _run(conn, plan, Random(0), wrong_ids={wo})
        assert conn.execute("SELECT repetitions FROM progress WHERE word_id = ?", (wo,)).fetchone()[0] == 0
        nxt = _start(conn)
    assert nxt["lesson"]["key"] == "hsk1-people-2"
    script_types = {s["type"] for s in nxt["steps"] if s["role"] == "script"}
    assert {"translate_cn_ru", "translation_build", "dialogue_scene"} <= script_types


# ---------------------------------------------------------------------------
# Четыре ученика (scripts/simulate_users.py)
# ---------------------------------------------------------------------------

def test_user_b_weak_words_come_first_and_get_extra_practice(course_db):
    from scripts.simulate_users import user_b

    r = user_b(course_db)
    assert all(r["checks"].values()), r["checks"]


def test_user_c_due_backlog_gets_more_review_and_shrinks(course_db):
    from scripts.simulate_users import user_c

    r = user_c(course_db)
    assert all(r["checks"].values()), r["checks"]
    assert r["first_lesson"]["review"] > r["first_lesson"]["new"]


def test_user_d_strong_learner_moves_on_and_retention_does_not_loop(course_db):
    """Регрессия (Phase I): верная проверка удержания не меняла SRS, и одно и то же
    освоенное слово проверялось в каждом уроке подряд."""
    from scripts.simulate_users import user_d

    r = user_d(course_db)
    assert all(r["checks"].values()), r["checks"]
    assert len(r["retention_words"]) == len(set(r["retention_words"])) >= 2


# ---------------------------------------------------------------------------
# «Я это уже знаю» на контенте HSK 1
# ---------------------------------------------------------------------------

def _claim_first_word(course_db, correct: bool):
    from datetime import date

    import app.config as cfg
    import app.db as dbm
    from scripts.simulate_course import _answer, _patch_today
    from scripts.simulate_users import _start

    path = _copy(course_db)
    cfg.DB_PATH = dbm.DB_PATH = path
    _patch_today(date(2026, 1, 5))
    from app.db import get_db
    from app.repositories import lesson_sessions_repo
    from app.services import lesson_service

    with get_db() as conn:
        plan = _start(conn)
        sid = plan["session_id"]
        intro = next(i for i, s in enumerate(plan["steps"]) if s["type"] == "introduction")
        wid = plan["steps"][intro]["word_id"]
        for i in range(intro):
            lesson_service.record_session_attempt(conn, sid, i, _answer(plan["steps"][i], True))
        lesson_service.claim_known(conn, sid, intro)
        steps = lesson_sessions_repo.get(conn, sid)["steps"]
        verify = steps[intro + 1]
        res = lesson_service.record_session_attempt(conn, sid, intro + 1, _answer(verify, correct))
        i = intro + 2
        while i < len(lesson_sessions_repo.get(conn, sid)["steps"]):
            step = lesson_sessions_repo.get(conn, sid)["steps"][i]
            lesson_service.record_session_attempt(conn, sid, i, _answer(step, True))
            i += 1
        lesson_service.complete_session(conn, sid)
        row = conn.execute("SELECT * FROM progress WHERE word_id = ?", (wid,)).fetchone()
        own_steps = [s for s in steps if s["word_id"] == wid and s.get("role") not in ("script",)]
    return verify, res, row, own_steps


def test_i_already_know_confirmed_on_hsk1_lesson(course_db):
    verify, res, row, own = _claim_first_word(course_db, correct=True)
    assert verify["role"] == "verify" and res["correct"]
    # слово не новое и не освоенное: как после двух удачных повторений, срок — через 6 дней
    assert row["repetitions"] == 2 and row["interval_days"] == 6 and row["total_attempts"] >= 1
    # обычные упражнения на это слово заменены одной проверкой
    assert [s["type"] for s in own] == ["introduction", verify["type"]]


def test_i_already_know_refuted_returns_word_to_learning(course_db):
    _verify, res, row, _ = _claim_first_word(course_db, correct=False)
    assert not res["correct"] and res["appended_step"] is not None      # повтор в конце урока
    assert row["repetitions"] <= 1 and row["interval_days"] <= 1          # обычное изучение, повтор завтра
    assert row["total_attempts"] >= 1


# ---------------------------------------------------------------------------
# Примеры HSK 1 на реальной базе
# ---------------------------------------------------------------------------

def test_every_hsk1_word_has_an_example_of_its_own_level(course_db):
    import sqlite3

    conn = sqlite3.connect(course_db)
    level1 = {r[0] for r in conn.execute(
        "SELECT w.id FROM words w JOIN modules m ON m.id = w.module_id WHERE m.hsk_level = 1")}
    ok = set()
    for target, used in conn.execute("SELECT target_word_id, used_word_ids FROM examples WHERE needs_review = 0"):
        if target in level1 and set(json.loads(used)) <= level1:
            ok.add(target)
    assert level1 - ok == set()


def test_example_pinyin_follows_corrected_word_readings(course_db):
    """Регрессия (Phase I): пиньинь примеров собирался до исправления чтений многочтений
    («Tā lái liǎo», «Nǐ hǎo má?») и так и оставался; теперь пересобирается по словам."""
    import sqlite3

    conn = sqlite3.connect(course_db)
    pinyin = dict(conn.execute("SELECT sentence_cn, pinyin FROM examples WHERE needs_review = 0"))
    assert pinyin["他来了。"] == "Tā lái le."
    assert pinyin["你好吗？"] == "Nǐ hǎo ma?"
    assert pinyin["我想去北京。"] == "Wǒ xiǎng qù Běijīng."
    assert all(p for p in pinyin.values())                      # у каждого пригодного примера есть пиньинь
