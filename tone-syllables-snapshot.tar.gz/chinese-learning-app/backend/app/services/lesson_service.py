import uuid
import zlib
from datetime import timedelta
from random import Random

from engine import exercise_types, lesson_script
from engine.answer_check import AnswerError, check_answer
from engine.lesson_planner import (
    PRACTICE_CAP,
    Step,
    adaptive_daily_new,
    compute_budget,
    lesson_mix,
    plan_lesson,
    retry_step,
)
from engine.mastery import update_mastery
from engine.scoring import derive_srs_quality

from ..repositories import (
    attempts_repo,
    dialogues_repo,
    examples_repo,
    lesson_completions_repo,
    lesson_scripts_repo,
    lesson_sessions_repo,
    mastery_repo,
    modules_repo,
    progress_repo,
    stats_repo,
    users_repo,
    words_repo,
)
from ..utils import today_date
from . import learning_service, pronunciation_service

# Проверка удержания: освоенное слово, не встречавшееся столько дней, иногда
# возвращается в урок одним объективным упражнением.
RETENTION_AFTER_DAYS = 14
WEAK_PRACTICE_CAP = 2


class LessonError(ValueError):
    pass


def _lesson_pool(conn, level: int | None) -> list[dict]:
    """
    Пул слов для дистракторов и разбора фраз: слова не выше уровня урока или уже
    знакомые. Раньше пулом была вся база, и в уроке HSK 1 вариантом ответа могло
    оказаться «согласно» (按照, HSK 4) — незнакомое слово без учебной причины.
    """
    words = [words_repo.word_row_to_dict(r) for r in words_repo.search_words(conn)]
    if level is None:
        return words
    return [w for w in words if w["hsk"] <= level or w["state"] != "new" or w["accuracy"] is not None]


def _attach_examples(conn, items: list[dict]) -> list[dict]:
    """Прикрепляет к каждому слову его examples (Phase C) — used_word_ids
    оттуда, не токенизация на лету, служит источником истины для
    fill_blank/sentence_order (см. engine/exercise_types._usable_examples)."""
    by_word = examples_repo.get_examples_for_words(conn, [w["id"] for w in items])
    dialogues = dialogues_repo.get_dialogues_for_words(conn, [w["id"] for w in items])
    for w in items:
        w["examples"] = by_word.get(w["id"], [])
        w["dialogues"] = dialogues.get(w["id"], [])
    return items


def _review_role(item: dict) -> tuple[str, str]:
    """Почему слово из очереди повторения попало в урок (для интерфейса)."""
    acc = item.get("accuracy")
    if item.get("state") == "new":
        return "weak", "Забытое слово — возвращаем в работу"
    if acc is not None and acc < 70:
        return "weak", f"Слабое слово: верно {round(acc)}% ответов"
    return "due", "Пора повторить по расписанию"


def _mark_roles(items: list[dict], role: str | None = None, reason: str | None = None) -> list[dict]:
    for it in items:
        if role is None:
            it["role"], it["reason"] = _review_role(it)
        else:
            it["role"], it["reason"] = role, reason
    return items


def _practice_items(conn, today_iso: str) -> list[dict]:
    """Закрепление без SRS: сначала слабые слова, чей повтор ещё не наступил, затем
    выученные сегодня (приоритет weak → recent)."""
    weak = [words_repo.word_row_to_dict(r) for r in progress_repo.weak_words_not_due(conn, today_iso, WEAK_PRACTICE_CAP)]
    for w in weak:
        w["role"], w["reason"] = "weak", f"Слабое слово: верно {round(w['accuracy'] or 0)}% ответов"
    recent = [words_repo.word_row_to_dict(r) for r in
              progress_repo.words_learned_today_not_due(conn, today_iso, PRACTICE_CAP)]
    seen = {w["id"] for w in weak}
    for w in recent:
        w["role"], w["reason"] = "recent", "Изучено сегодня — закрепляем"
    return weak + [w for w in recent if w["id"] not in seen]


def _retention_items(conn, today) -> list[dict]:
    before = (today - timedelta(days=RETENTION_AFTER_DAYS)).isoformat()
    return [words_repo.word_row_to_dict(r) for r in
            progress_repo.retention_candidates(conn, today.isoformat(), before, 1)]


def _module_script(conn, module, user_id: int) -> tuple[dict | None, dict[str, dict]]:
    """Сценарий темы для этого урока модуля (Phase H) и словарь его слов."""
    blueprints = lesson_scripts_repo.blueprints_for_module(module)
    if not blueprints:
        return None, {}
    hanzi = set().union(*(lesson_script.blueprint_hanzi(b) for b in blueprints))
    words_map = words_repo.words_by_hanzi(conn, hanzi)
    resolved = [lesson_script.try_resolve(b, words_map) for b in blueprints]
    script = lesson_script.choose_script(resolved, lesson_sessions_repo.completed_script_keys(conn, user_id))
    return script, words_map


def get_lesson_plan(conn, module_id: int):
    """
    План урока модуля: контент строго этого модуля (Step 1) + последовательность
    шагов от детерминированного Planner (Step 2). Ключи new_words/review_words
    сохранены для обратной совместимости.

    Review не ограничен категорией этого модуля: слова, отложенные в других
    модулях, тоже подмешиваются (до review_cap суммарно, свои — в приоритете) —
    иначе старый материал переставал бы возвращаться, как только пользователь
    уходит к следующему модулю (аудит, п.2).
    """
    module = modules_repo.get_module(conn, module_id)
    if module is None:
        return None

    today = today_date()
    stats = stats_repo.get_stats(conn)
    user_id = users_repo.get_current_user_id(conn)

    # Сколько нового и сколько повторения — решает движок по долгу повторений
    # (lesson_mix): при большой очереди review новое уступает место.
    due_total = progress_repo.count_due_review_words(conn, today.isoformat())
    remaining = progress_repo.count_new_words_for_module(conn, module_id)
    # норма новых слов от истории ответов (точность последних ответов), затем
    # поправка на долг повторений — обе решает движок
    accuracy = attempts_repo.recent_accuracy(conn, user_id)
    daily, mix_reason = adaptive_daily_new(stats["daily_new_words"], accuracy, due_total)
    new_limit, review_cap = lesson_mix(daily, due_total, remaining)

    own_review = [words_repo.word_row_to_dict(r) for r in
                  progress_repo.due_review_words_for_module(conn, module_id, today.isoformat(), review_cap)]
    other_slots = max(0, review_cap - len(own_review))
    other_review = [words_repo.word_row_to_dict(r) for r in
                    progress_repo.due_review_words_excluding_module(
                        conn, module_id, today.isoformat(), other_slots)] if other_slots else []
    review = own_review + other_review
    # Урок темы со сценарием (Phase H): новые слова и содержание задаёт сценарий
    # (его ещё не изученные слова — их немного, 3–5); если все слова уже знакомы,
    # урок становится практическим — фразы, диалог, перевод, речь.
    script, words_map = _module_script(conn, module, user_id)
    if script is not None:
        seen = progress_repo.seen_word_ids(conn)
        by_id = {w["id"]: w for w in words_map.values()}
        new = [dict(by_id[wid]) for wid in lesson_script.lesson_new_ids(script, seen)]
        for w in new:
            if script["notes"].get(w["id"]):
                w["note"] = script["notes"][w["id"]]
        new_limit = len(new)
    else:
        new = [words_repo.word_row_to_dict(r) for r in
               progress_repo.new_words_for_module(conn, module_id, new_limit)] if new_limit else []
    _mark_roles(review)
    practice = _practice_items(conn, today.isoformat())
    retention = _retention_items(conn, today)
    _attach_examples(conn, new)
    _attach_examples(conn, review)
    _attach_examples(conn, practice)
    _attach_examples(conn, retention)

    # Пул — слова до уровня модуля и уже знакомые: из него берутся дистракторы
    # (та же категория предпочитается) и словарь для фраз.
    pool = _lesson_pool(conn, module["hsk_level"])

    mastery = mastery_repo.get_all_mastery(conn, user_id)
    rng = Random(module_id * 100003 + today.toordinal())  # воспроизводимо в пределах дня
    budget = compute_budget(new_limit, review_cap)
    if script is not None:
        budget += len(lesson_script.build_steps(script, set(), set(), Random(0))) or 12  # место под сценарий
    steps = plan_lesson(new, review, mastery, pool, budget=budget,
                        rng=rng, review_cap=review_cap, practice_items=practice,
                        dialogue_bank=dialogues_repo.all_dialogues(conn),
                        script=script, retention_items=retention)
    used_ids = {s.word_id for s in steps}
    lesson = None
    if script is not None:
        lesson = lesson_script.lesson_meta(script, {w["id"]: w for w in words_map.values()},
                                           [w["id"] for w in new])

    return {
        "module": {"id": module["id"], "title": module["title"],
                   "category": module["category"], "hsk_level": module["hsk_level"]},
        "steps": [s.to_dict() for s in steps],
        "new_words": new,
        "review_words": review,
        # почему урок такой: норма новых, поправка по точности, долг повторений
        "mix": {"daily_new_words": stats["daily_new_words"], "new_limit": new_limit,
                "review_cap": review_cap, "due_total": due_total, "reason": mix_reason,
                "recent_accuracy": round(100 * accuracy) if accuracy is not None else None,
                "module_remaining": remaining},
        # выученные сегодня слова, попавшие в урок на закрепление (без SRS)
        "practice_words": [w for w in practice if w["id"] in used_ids
                           and w["id"] not in {x["id"] for x in new + review}],
        # Phase H: тема урока (цель, введение, слова) — если у модуля есть сценарий
        "lesson": lesson,
    }


def get_review_plan(conn):
    """
    Review = тот же Lesson Runner, но другой план: просроченные повторения
    по всем модулям, без новых слов. Тот же Planner, тот же реестр упражнений —
    отдельного "движка практики" нет.
    """
    today = today_date()
    user_id = users_repo.get_current_user_id(conn)
    review = _mark_roles([words_repo.word_row_to_dict(r) for r in
                          progress_repo.due_review_words(conn, today.isoformat())])
    _attach_examples(conn, review)
    pool = _lesson_pool(conn, max((w["hsk"] for w in review), default=None))
    mastery = mastery_repo.get_all_mastery(conn, user_id)
    steps = plan_lesson([], review, mastery, pool, rng=Random(7919 + today.toordinal()),
                        dialogue_bank=dialogues_repo.all_dialogues(conn))
    return {
        "module": {"id": None, "title": "Повторение", "category": None, "hsk_level": None},
        "steps": [s.to_dict() for s in steps],
        "new_words": [],
        "review_words": review,
        "lesson": None,
    }


def record_attempt(conn, module_id: int | None, *, word_id: int, exercise_type: str, correct: bool,
                   final: bool = False, mistakes: int = 0, attempts_total: int = 1,
                   recall_quality: int | None = None,
                   response_ms: int | None = None, trusted: bool = False) -> dict:
    """
    Ответ пользователя на шаг урока: Attempt -> Mastery (по навыку типа
    упражнения) -> SRS (один раз на слово, на его финальном шаге).
    """
    module = None
    if module_id is not None:
        module = modules_repo.get_module(conn, module_id)
        if module is None:
            raise LookupError("module")
    if exercise_type not in exercise_types.REGISTRY:
        raise LessonError(f"Неизвестный тип упражнения: {exercise_type}")
    word = words_repo.get_word_by_id(conn, word_id)
    if word is None:
        raise LessonError("Слово не найдено")
    # trusted — шаг выдал сам сервер в сессии урока (слово темы может быть из
    # другого модуля: сценарий «Знакомство» учит 好 и 什么); легаси-эндпоинт
    # с клиентским word_id по-прежнему проверяется.
    if module is not None and word["module_id"] != module["id"] and not trusted:
        # Не свой модуль — допустимо только как легитимное cross-module
        # повторение (слово уже проходилось, в т.ч. забытое), а не подмена.
        progress_row = progress_repo.get_progress_row(conn, word_id)
        if not progress_row or (progress_row["repetitions"] == 0 and progress_row["total_attempts"] == 0):
            raise LessonError("Слово не принадлежит этому модулю")

    ex_type = exercise_types.get(exercise_type)
    user_id = users_repo.get_current_user_id(conn)
    today = today_date().isoformat()
    lessons = modules_repo.list_lessons_for_module(conn, module_id) if module else []
    lesson_id = lessons[0]["id"] if lessons else None

    new_mastery = None
    if ex_type.skill:
        attempts_repo.insert_attempt(
            conn, user_id, exercise_type, ex_type.skill, word_id, correct,
            created_at_iso=today, lesson_id=lesson_id, response_ms=response_ms)
        old = mastery_repo.get_mastery_score(conn, user_id, ex_type.skill)
        new_mastery = update_mastery(old, correct)
        mastery_repo.set_mastery_score(conn, user_id, ex_type.skill, new_mastery, today)

    srs = None
    if final:
        quality = derive_srs_quality(mistakes, attempts_total, recall_quality)
        srs = learning_service.submit_review(conn, word_id, quality)
        if srs is not None:
            srs["quality"] = quality

    return {"skill": ex_type.skill, "mastery": new_mastery, "srs": srs}


def complete_lesson(conn, module_id: int | None, *, new_word_ids: list[int], review_word_ids: list[int]) -> dict:
    """
    Phase E, п.4: настоящее серверное событие завершения урока — не со
    слов фронтенда. exercises_count — дельта реальных attempts этого
    lesson_id с прошлого completion (без timestamp-сравнений, см. отчёт).
    new/review counts — только те word_id из присланных клиентом списков,
    у которых реально есть хотя бы одна попытка по этому lesson_id
    (неидеальная, но настоящая проверка против attempts, не слепое доверие).
    """
    user_id = users_repo.get_current_user_id(conn)
    lesson_id = None
    if module_id is not None:
        module = modules_repo.get_module(conn, module_id)
        if module is None:
            raise LookupError("module")
        lessons = modules_repo.list_lessons_for_module(conn, module_id)
        lesson_id = lessons[0]["id"] if lessons else None

    total_now = lesson_completions_repo.total_attempts_for_lesson(conn, lesson_id)
    already = lesson_completions_repo.already_counted_exercises(conn, module_id)
    exercises_count = max(0, total_now - already)

    verified = lesson_completions_repo.word_ids_with_any_attempt_for_lesson(
        conn, list(set(new_word_ids) | set(review_word_ids)), lesson_id)
    new_count = len(set(new_word_ids) & verified)
    review_count = len(set(review_word_ids) & verified)

    now = f"{today_date().isoformat()}T00:00:00"
    completion_id = lesson_completions_repo.record_completion(
        conn, user_id, module_id, started_at=now, completed_at=now,
        new_words_count=new_count, review_words_count=review_count, exercises_count=exercises_count)
    return {"id": completion_id, "exercises_count": exercises_count,
            "new_words_count": new_count, "review_words_count": review_count}


# ---------------------------------------------------------------------------
# Сессии урока: серверная проверка ответов (2026-10)
# ---------------------------------------------------------------------------

# Поля payload, по которым видно верный ответ: клиент их не получает — ответ
# проверяет сервер (engine.answer_check) по сохранённому в сессии шагу.
ANSWER_FIELDS = ("answer_index", "answer_tokens", "answer", "answers")
EXERCISE_LABELS = {
    "recognition": "значение слова", "listening": "аудирование", "pinyin_choice": "пиньинь",
    "tone_choice": "тон", "fill_blank": "пропуск во фразе", "sentence_order": "сборка фразы",
    "recall": "вспомнить слово", "handwriting": "написание", "word_choice": "слово по значению",
    "sentence_meaning": "понимание фразы", "sentence_listening": "аудирование фразы",
    "pinyin_input": "ввод пиньиня", "dialogue_reply": "мини-диалог",
    "pinyin_to_hanzi": "иероглиф по пиньиню", "translate_cn_ru": "перевод фразы",
    "translation_build": "перевод на китайский", "dialogue_scene": "диалог", "speaking": "произношение",
    "pinyin_error": "ошибка в пиньине", "matching": "сопоставление",
}


def client_step(step: dict, index: int) -> dict:
    payload = {k: v for k, v in (step.get("payload") or {}).items() if k not in ANSWER_FIELDS}
    return {**step, "payload": payload, "index": index}


def _new_session(conn, plan: dict, module_id: int | None, kind: str) -> dict:
    user_id = users_repo.get_current_user_id(conn)
    session_id = uuid.uuid4().hex
    word_ids = sorted({s["word_id"] for s in plan["steps"]})
    before = {}
    for wid in word_ids:
        row = progress_repo.get_progress_row(conn, wid)
        if row is not None:
            before[str(wid)] = {"repetitions": row["repetitions"], "interval_days": row["interval_days"]}
    state = {
        "answered": {}, "attempts": {}, "mistakes": {}, "recall": {}, "srs": {}, "retried": [],
        "errors": [], "graded": 0, "correct": 0, "before": before,
        "new_word_ids": [w["id"] for w in plan["new_words"]],
        "review_word_ids": [w["id"] for w in plan["review_words"]],
        # Phase H: сценарий урока, «я это уже знаю», произношение
        "script_key": (plan.get("lesson") or {}).get("key"),
        "can_do": (plan.get("lesson") or {}).get("can_do") or [],
        "lesson_title": (plan.get("lesson") or {}).get("title"),
        "claimed_known": {}, "speech": {},
    }
    lesson_sessions_repo.create(conn, session_id, user_id, module_id, kind, today_date().isoformat(),
                                plan["steps"], state)
    return {**plan, "session_id": session_id,
            "steps": [client_step(s, i) for i, s in enumerate(plan["steps"])]}


def start_lesson(conn, module_id: int) -> dict | None:
    """План урока модуля + серверная сессия (ответы остаются на сервере)."""
    plan = get_lesson_plan(conn, module_id)
    if plan is None:
        return None
    return _new_session(conn, plan, module_id, "lesson")


def start_review(conn) -> dict:
    return _new_session(conn, get_review_plan(conn), None, "review")


def _word_item(conn, word_id: int) -> dict:
    item = words_repo.word_row_to_dict(words_repo.get_word_by_id(conn, word_id))
    return _attach_examples(conn, [item])[0]


def record_session_attempt(conn, session_id: str, step_index: int, answer, response_ms: int | None = None) -> dict:
    """
    Ответ на шаг сессии: сервер проверяет ответ по сохранённому шагу, сам ведёт
    счётчики попыток/ошибок слова (клиенту не доверяем), пишет Attempt → Mastery
    → SRS (на финальном шаге слова) через record_attempt. После ошибки в конец
    урока добавляется один повтор слова (retry_step) — его клиент получает в
    appended_step. Повторная отправка того же шага возвращает прежний результат.
    """
    session = lesson_sessions_repo.get(conn, session_id)
    if session is None:
        raise LookupError("session")
    if session["completed_at"]:
        raise LessonError("Урок уже завершён")
    steps, state = session["steps"], session["state"]
    if not 0 <= step_index < len(steps):
        raise LessonError("Нет такого шага в уроке")
    key = str(step_index)
    if key in state["answered"]:
        return {**state["answered"][key], "repeated": True}

    step = steps[step_index]
    try:
        result = check_answer(step["type"], step.get("payload") or {}, answer)
    except AnswerError as e:
        raise LessonError(str(e)) from None

    wid, correct = step["word_id"], bool(result["correct"])
    w = str(wid)
    if step["graded"]:
        state["attempts"][w] = state["attempts"].get(w, 0) + 1
        state["graded"] += 1
        if correct:
            state["correct"] += 1
        else:
            state["mistakes"][w] = state["mistakes"].get(w, 0) + 1
    if step["type"] == "recall":
        state["recall"][w] = answer

    record = {"skill": step.get("skill"), "mastery": None, "srs": None}
    skipped = bool(result.get("skipped"))  # речь без оценки — не попытка навыка
    if (step["type"] != "introduction" or step["final"]) and not skipped:
        record = record_attempt(
            conn, session["module_id"], word_id=wid, exercise_type=step["type"], correct=correct,
            final=bool(step["final"]), mistakes=state["mistakes"].get(w, 0),
            attempts_total=state["attempts"].get(w, 0),
            recall_quality=state["recall"].get(w) if step["final"] else None, response_ms=response_ms,
            trusted=True)
    if step.get("role") == "verify":
        # «Я это уже знаю»: проверка решает судьбу слова в SRS — подтвердилось —
        # слово встаёт как после двух успешных повторений; нет — изучаем как новое.
        if correct:
            record["srs"] = learning_service.confirm_known(conn, wid)
            state["claimed_known"][w] = "confirmed"
        else:
            record["srs"] = learning_service.submit_review(conn, wid, 0)
            state["claimed_known"][w] = "refuted"
    elif step.get("role") == "retention" and not correct:
        # освоенное слово не вспомнилось — возвращаем его в повторение (SRS: «не помню»)
        record["srs"] = learning_service.submit_review(conn, wid, 0)
    if record.get("srs"):
        state["srs"][w] = {**record["srs"], "quality": record["srs"].get("quality", 0 if not correct else 2)}

    appended = None
    if not correct and step["graded"]:
        state["errors"].append({"word_id": wid, "type": step["type"], "expected": result.get("expected"),
                                "explanation": result.get("explanation")})
        if not step.get("retry") and wid not in state["retried"]:
            known = {r[0] for r in conn.execute(
                "SELECT word_id FROM progress WHERE repetitions > 0 OR total_attempts > 0")} | {wid}
            module = modules_repo.get_module(conn, session["module_id"]) if session["module_id"] else None
            item_level = words_repo.get_word_by_id(conn, wid)["hsk"]
            pool = _lesson_pool(conn, max(item_level, module["hsk_level"] or 0) if module else item_level)
            rng = Random(zlib.crc32(f"{session_id}:{step_index}".encode()))
            extra = retry_step(_word_item(conn, wid), step["type"], pool, rng, {"known_word_ids": known})
            if extra is not None:
                steps.append(extra.to_dict())
                state["retried"].append(wid)
                appended = client_step(steps[-1], len(steps) - 1)

    response = {"correct": correct, "expected": result.get("expected"), "explanation": result.get("explanation"),
                "skill": record.get("skill"), "mastery": record.get("mastery"), "srs": record.get("srs"),
                "self_assessed": bool(result.get("self_assessed")), "appended_step": appended}
    state["answered"][key] = response
    lesson_sessions_repo.save(conn, session_id, steps, state)
    return response


VERIFY_PREFERENCE = ("word_choice", "recognition", "listening")


def _due_label(iso: str | None) -> str | None:
    if not iso:
        return None
    from datetime import date

    days = (date.fromisoformat(iso) - today_date()).days
    return "сегодня" if days <= 0 else "завтра" if days == 1 else f"через {days} дн."


def claim_known(conn, session_id: str, step_index: int) -> dict:
    """
    «Я это уже знаю» на карточке нового слова. Безопасная модель:
      1) заявление не делает слово выученным — оно лишь заменяет оставшиеся
         упражнения на это слово одним проверочным (значение → иероглиф);
      2) проверку оценивает сервер: верно — слово встаёт в SRS как после двух
         успешных повторений (интервал 6 дней, learning_service.confirm_known),
         неверно — изучается как обычное (SRS «не помню» + повтор в конце урока);
      3) дальнейшие повторения по расписанию подтверждают или опровергают знание.
    Фразы сценария со словом остаются (они про тему, а не про слово), но SRS по
    слову решает только проверка.
    """
    session = lesson_sessions_repo.get(conn, session_id)
    if session is None:
        raise LookupError("session")
    if session["completed_at"]:
        raise LessonError("Урок уже завершён")
    steps, state = session["steps"], session["state"]
    if not 0 <= step_index < len(steps):
        raise LessonError("Нет такого шага в уроке")
    step = steps[step_index]
    wid = step["word_id"]
    if step["type"] != "introduction" or wid not in state["new_word_ids"]:
        raise LessonError("«Я это уже знаю» — только на карточке нового слова")
    if str(step_index) in state["answered"] or str(wid) in state["claimed_known"]:
        raise LessonError("Это слово уже отмечено")

    item = _word_item(conn, wid)
    module = modules_repo.get_module(conn, session["module_id"]) if session["module_id"] else None
    pool = _lesson_pool(conn, max(item["hsk"], (module["hsk_level"] if module else 0) or 0))
    known = progress_repo.seen_word_ids(conn) | {wid}
    rng = Random(zlib.crc32(f"{session_id}:known:{wid}".encode()))
    verify = None
    for name in VERIFY_PREFERENCE:
        t = exercise_types.get(name)
        if t.requires(item, pool, {"known_word_ids": known}):
            verify = Step(t.name, t.skill, wid, graded=True, mandatory=True, final=False,
                          payload=t.build(item, pool, rng, {"known_word_ids": known}), phase=exercise_types.phase(t.name),
                          stage="recall", role="verify",
                          reason="Вы отметили, что знаете это слово — проверим одним вопросом").to_dict()
            break
    if verify is None:
        raise LessonError("Для этого слова нет проверочного задания")

    state["answered"][str(step_index)] = {"correct": True, "expected": None, "explanation": None, "skill": None,
                                          "mastery": None, "srs": None, "self_assessed": False,
                                          "appended_step": None, "known_claimed": True}
    tail = []
    for s_ in steps[step_index + 1:]:
        if s_["word_id"] == wid and s_.get("role") != "script":
            continue  # обычные упражнения на это слово заменяет проверка
        if s_["word_id"] == wid:
            s_["final"] = False
        tail.append(s_)
    steps[:] = steps[: step_index + 1] + [verify] + tail
    state["claimed_known"][str(wid)] = "pending"
    lesson_sessions_repo.save(conn, session_id, steps, state)
    return {"steps": [client_step(x, i) for i, x in enumerate(steps)], "next_index": step_index + 1}


def assess_speaking(conn, session_id: str, step_index: int, audio: bytes) -> dict:
    """
    Запись фразы на шаге «Произнесите вслух»: провайдер распознаёт, движок
    ставит 0–100 по словам. Без провайдера — {"available": False}: шаг не
    засчитывается и не оценивается (воспроизведение записи — не оценка).
    """
    session = lesson_sessions_repo.get(conn, session_id)
    if session is None:
        raise LookupError("session")
    if session["completed_at"]:
        raise LessonError("Урок уже завершён")
    steps, state = session["steps"], session["state"]
    if not 0 <= step_index < len(steps) or steps[step_index]["type"] != "speaking":
        raise LessonError("Это не шаг произношения")
    key = str(step_index)
    if key in state["answered"]:
        return {**state["answered"][key], "repeated": True}
    step = steps[step_index]
    p = step["payload"]
    try:
        result = pronunciation_service.assess_pronunciation(audio, p["tokens"], p["token_pinyin"])
    except pronunciation_service.PronunciationUnavailable:
        return {"available": False,
                "message": "Оценка произношения пока не подключена: запись не проверяется. "
                           "Послушайте образец и повторите вслух."}
    except ValueError as e:
        raise LessonError(str(e)) from None

    wid, correct = step["word_id"], result.passed
    state["graded"] += 1
    state["correct"] += int(correct)
    record = record_attempt(conn, session["module_id"], word_id=wid, exercise_type="speaking", correct=correct,
                            final=False, trusted=True)
    explanation = " ".join(result.notes) if not correct else None
    if not correct:
        state["errors"].append({"word_id": wid, "type": "speaking", "expected": p["text"],
                                "explanation": explanation})
    state["speech"][key] = result.overall
    response = {"available": True, "correct": correct, "expected": p["text"], "explanation": explanation,
                "skill": "speaking", "mastery": record.get("mastery"), "srs": None, "self_assessed": False,
                "appended_step": None, "pronunciation": result.to_dict()}
    state["answered"][key] = response
    lesson_sessions_repo.save(conn, session_id, steps, state)
    return response


def _word_outcomes(state: dict, steps: list[dict], words: dict, brief) -> tuple[list, list]:
    """
    Что получается и что нет — по фактам сессии: число оценённых заданий и
    ошибок на слово, результат SRS и проверка «я это уже знаю».
    """
    strong, weak = [], []
    first_error = {}
    for e in state["errors"]:
        first_error.setdefault(e["word_id"], e)
    graded_by_word: dict[int, int] = {}
    for i, s_ in enumerate(steps):
        if s_.get("graded") and str(i) in state["answered"]:
            graded_by_word[s_["word_id"]] = graded_by_word.get(s_["word_id"], 0) + 1
    for wid in words:
        w = str(wid)
        mistakes = state["mistakes"].get(w, 0)
        claim = state["claimed_known"].get(w)
        srs = state["srs"].get(w) or {}
        quality = srs.get("quality")
        if claim == "confirmed":
            strong.append({**brief(wid), "why": "знали заранее — проверка подтвердила"})
        elif claim == "refuted" or mistakes or quality in (0, 1):
            err = first_error.get(wid)
            weak.append({**brief(wid), "mistakes": mistakes, "next_review": srs.get("next_due_date"),
                         "note": (err or {}).get("explanation") or (f"правильно — {err['expected']}" if err else None),
                         "why": "проверка «знаю» не подтвердилась" if claim == "refuted" else None})
        elif graded_by_word.get(wid, 0) >= 2:
            strong.append({**brief(wid), "why": f"без ошибок в {graded_by_word[wid]} заданиях"})
    return strong, weak


def _next_message(strong: list, weak: list, next_title: str | None, due_label: str | None) -> list[str]:
    """Две-три фразы тренера: что получается, что повторим и когда, что дальше."""
    msgs = []
    if strong:
        hz = ", ".join(w["hanzi"] for w in strong[:4])
        msgs.append(f"Уверенно: {hz}.")
    if weak:
        hz = ", ".join(w["hanzi"] for w in weak[:4])
        when = due_label or "в ближайших уроках"
        msgs.append(f"Пока путается: {hz} — проверим снова {when}, в новых фразах.")
    if next_title:
        msgs.append(f"Следующий урок: «{next_title}».")
    return msgs


def complete_session(conn, session_id: str) -> dict:
    """
    Итог урока по фактам сессии (а не по словам клиента): что изучено, что
    улучшилось, какие ошибки, что повторить и когда, какой урок следующий.
    Точность — «верно из оцениваемых заданий», без округления вверх; слово после
    одного урока — «в изучении», не «выучено». Повторный вызов отдаёт тот же итог.
    """
    from .learning_path_service import get_learning_path

    session = lesson_sessions_repo.get(conn, session_id)
    if session is None:
        raise LookupError("session")
    state = session["state"]
    if session["completed_at"] and state.get("summary"):
        return state["summary"]

    steps = session["steps"]
    order = list(dict.fromkeys(s["word_id"] for s in steps))
    words = {wid: dict(words_repo.get_word_by_id(conn, wid)) for wid in order}

    def brief(wid):
        w = words[wid]
        return {"id": wid, "hanzi": w["hanzi"], "pinyin": w["pinyin"], "translation": w["translation"]}

    srs, before = state["srs"], state["before"]
    new_ids = [wid for wid in order if wid in set(state["new_word_ids"])]
    review_ids = [wid for wid in order if wid in set(state["review_word_ids"])]

    def result_of(wid):
        r = srs.get(str(wid))
        if r is None:
            return None
        if r.get("quality", 2) == 0:
            return "again"            # не вспомнил: вернётся завтра как новое
        if r.get("quality", 2) == 1:
            return "hard"             # засчитано с ошибками: повтор завтра
        prev = before.get(str(wid), {})
        return "improved" if r["interval_days"] > prev.get("interval_days", 0) else "ok"

    new_words = [{**brief(wid), "result": result_of(wid), "state": (srs.get(str(wid)) or {}).get("state"),
                  "next_review": (srs.get(str(wid)) or {}).get("next_due_date")} for wid in new_ids]
    review_words = [{**brief(wid), "result": result_of(wid), "state": (srs.get(str(wid)) or {}).get("state"),
                     "next_review": (srs.get(str(wid)) or {}).get("next_due_date")} for wid in review_ids]

    seen, mistakes = set(), []
    for e in state["errors"]:
        k = (e["word_id"], e["type"])
        if k in seen or e["word_id"] not in words:
            continue
        seen.add(k)
        mistakes.append({**brief(e["word_id"]), "exercise": EXERCISE_LABELS.get(e["type"], e["type"]),
                         "expected": e["expected"], "explanation": e["explanation"]})

    to_repeat = [brief(wid) for wid in order if result_of(wid) in ("again", "hard")]
    dues = [r["next_due_date"] for r in srs.values() if r.get("next_due_date")]
    graded, correct = state["graded"], state["correct"]

    path = get_learning_path(conn)
    rec = next((m for m in path["modules"] if m["id"] == path["recommended_module_id"]), None)
    due_now = progress_repo.count_due_review_words(conn, today_date().isoformat())
    next_step = None
    if rec is not None:
        next_step = {"module_id": rec["id"], "title": rec["title"], "section_title": rec["section_title"],
                     "kind": "lesson", "reason": "Следующий модуль по курсу" if rec["id"] != session["module_id"]
                     else "Продолжение этого модуля"}
    if due_now > 12:
        next_step = {"module_id": None, "title": "Повторение", "section_title": None, "kind": "review",
                     "reason": f"Сначала повторение: {due_now} слов ждут"}

    module = modules_repo.get_module(conn, session["module_id"]) if session["module_id"] else None
    # Phase H: сильное / требует практики / что дальше — по фактам сессии
    script_words = [wid for wid in order if wid in set(state["new_word_ids"]) | set(state["review_word_ids"])]
    strong, needs_practice = _word_outcomes(state, steps, {wid: words[wid] for wid in script_words}, brief)
    next_lesson_title = None
    if state.get("script_key") and module is not None:
        user_id_ = users_repo.get_current_user_id(conn)
        script, _ = _module_script(conn, module, user_id_)
        if script is not None and script["key"] == state["script_key"]:
            done = lesson_sessions_repo.completed_script_keys(conn, user_id_) | {state["script_key"]}
            blueprints = lesson_scripts_repo.blueprints_for_module(module)
            nxt = next((b for b in blueprints if b["key"] not in done), None)
            next_lesson_title = nxt["title"] if nxt else None
    if next_lesson_title is not None and next_step is not None and next_step["kind"] == "lesson" \
            and next_step["module_id"] == session["module_id"]:
        next_step = {**next_step, "title": next_lesson_title, "reason": "Следующий урок этой темы"}
    if next_lesson_title is None and next_step is not None and next_step["kind"] == "lesson":
        next_lesson_title = next_step["title"]
    weak_due = min((w["next_review"] for w in needs_practice if w.get("next_review")), default=None)
    speech = list(state.get("speech", {}).values())
    summary = {
        "title": state.get("lesson_title") or (module["title"] if module else "Повторение"),
        "exercises": len(state["answered"]),
        "accuracy": {"correct": correct, "graded": graded,
                     "percent": round(100 * correct / graded) if graded else None},
        "new_words": new_words,
        "review_words": review_words,
        "mistakes": mistakes,
        "to_repeat": to_repeat,
        "next_review_date": min(dues) if dues else None,
        "next": next_step,
        # Phase H
        "can_do": state.get("can_do") or [],
        "strong": strong,
        "needs_practice": needs_practice,
        "pronunciation": round(sum(speech) / len(speech)) if speech else None,
        "next_message": _next_message(strong, needs_practice, next_lesson_title, _due_label(weak_due)),
    }
    user_id = users_repo.get_current_user_id(conn)
    now = f"{today_date().isoformat()}T00:00:00"
    lesson_completions_repo.record_completion(
        conn, user_id, session["module_id"], started_at=f"{session['created_at']}T00:00:00", completed_at=now,
        new_words_count=sum(1 for w in new_words if w["result"] in ("improved", "ok", "hard")),
        review_words_count=sum(1 for w in review_words if w["result"] is not None),
        exercises_count=summary["exercises"])
    state["summary"] = summary
    lesson_sessions_repo.save(conn, session_id, steps, state)
    lesson_sessions_repo.mark_completed(conn, session_id, now)
    return summary
