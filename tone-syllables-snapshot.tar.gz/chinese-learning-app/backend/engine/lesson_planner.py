"""
Lesson Planner — детерминированный, без LLM, БД и сети (ARCHITECTURE_WB_v1.md 3.2).

Вход: новые слова модуля, слова на повторение, mastery по навыкам, пул слов
для дистракторов. Выход: упорядоченный список шагов (Step).

Правила (не random ради random — любая вариативность объяснима состоянием):
  * новое слово  -> introduction -> recognition -> "фокусный" шаг по самому
    слабому навыку -> (опционально) доп. шаг по следующему слабому навыку;
  * знакомое слово (learning/review) -> recall + фокусный шаг по слабому навыку;
  * освоенное (mastered) -> только recall, без бесконечных карточек;
  * characters уже сильный (>= STRONG) -> recognition пропускается;
  * ничья по mastery (например, у нового пользователя все навыки = 0)
    разрешается ротацией по номеру слова в уроке, а не случайностью;
  * бюджет: новое получает его первым (review не должен блокировать новый
    материал — Phase D, п.4), сам бюджет считается с запасом на оба
    источника (compute_budget), поэтому review почти всегда всё равно влезает;
    при нехватке сначала отбрасываются необязательные шаги, затем слова с конца;
  * форма урока: новое и review чередуются блоками по NEW_CHUNK/REVIEW_CHUNK
    ("новое -> закрепление -> старое -> новое -> повторение..." — Phase D, п.3),
    а не "сначала весь review, потом всё новое";
  * после сборки — проход, не дающий трём одинаковым типам упражнений идти
    подряд (Phase D, п.10), детерминированная локальная перестановка.

Методика (2026-10): урок идёт по учебным фазам (exercise_types.PHASES):
  1 знакомство и значение (introduction, recognition) и 2 звук/форма (listening,
    pinyin, tones) — небольшими группами новых слов вперемешку с повторением;
  3 слово во фразе (fill_blank, понимание/аудирование фразы, сборка перевода) и
  4 воспроизведение по памяти (значение → иероглиф, ввод пиньиня, письмо) — для
    новых слов урока вынесены в конец: сначала все слова урока введены, потом
    применяются во фразах и вспоминаются. Финальный шаг слова (по нему SRS)
    поэтому почти всегда — воспроизведение, а не узнавание.
  Ошибка в сессии добавляет в конец урока один повтор слова (retry_step) — без
  второго SRS-обновления.
"""

from dataclasses import asdict, dataclass
from random import Random

from . import exercise_types as ex
from . import lesson_script

# Приоритет продукта (при равном mastery): Characters > Pronunciation(listening)
# > Pinyin > Tones > Writing > Vocabulary
SKILL_PRIORITY = ["characters", "listening", "pinyin", "tones", "writing", "vocabulary"]
WEAK_THRESHOLD = 50
STRONG_THRESHOLD = 85
DEFAULT_BUDGET = 24
REVIEW_CAP = 8
NEW_CHUNK = 2      # сколько новых слов подряд перед блоком повторения (Phase D, п.3)
REVIEW_CHUNK = 2   # сколько повторений подряд перед возвратом к новому


# Потолок фокуса на навык за урок (сверх общего focus_cap): письмо самое
# долгое и на телефоне самое утомительное упражнение — не больше трёх за урок.
SKILL_CAPS = {"writing": 3}


@dataclass
class Step:
    type: str
    skill: str | None
    word_id: int
    graded: bool
    mandatory: bool
    final: bool = False
    payload: dict | None = None
    phase: int = 0
    retry: bool = False
    # Phase H: где этот шаг в уроке и почему он появился (для интерфейса и итога)
    stage: str = ""
    role: str | None = None      # new | weak | due | recent | retention | script
    reason: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def _skill_types(item, pool, exclude_skills, ctx):
    """Применимые типы упражнений, сгруппированные по навыкам (кроме recall/introduction)."""
    result: dict[str, list] = {}
    for t in ex.REGISTRY.values():
        if t.skill and t.name != "recall" and t.skill not in exclude_skills and t.requires(item, pool, ctx):
            result.setdefault(t.skill, []).append(t)
    return result


def _priority(skill: str) -> int:
    # навык вне списка (новый тип упражнений) — самый низкий приоритет, без падения
    return SKILL_PRIORITY.index(skill) if skill in SKILL_PRIORITY else len(SKILL_PRIORITY)


def _ranked_skills(available_skills, mastery):
    return sorted(available_skills, key=lambda s: (mastery.get(s, 0), _priority(s)))


def _pick_focus(available_skills, mastery, rotation, counts=None, cap=None):
    """
    Самый слабый навык; при ничьей — ротация по номеру слова. Один и тот же
    навык не может быть фокусом больше, чем у cap слов урока: слабый навык
    получает больше упражнений, но урок не сводится к одному шаблону.
    """
    ranked = _ranked_skills(available_skills, mastery)
    if not ranked:
        return None
    lowest = mastery.get(ranked[0], 0)
    tied = [s for s in ranked if mastery.get(s, 0) == lowest]
    shift = rotation % len(tied)
    ordered = tied[shift:] + tied[:shift] + ranked[len(tied):]
    # слабые и средние навыки — раньше уже сильных
    ordered = ([s for s in ordered if mastery.get(s, 0) < STRONG_THRESHOLD]
               + [s for s in ordered if mastery.get(s, 0) >= STRONG_THRESHOLD])
    if counts is not None and cap is not None:
        for skill in ordered:
            if counts.get(skill, 0) < min(cap, SKILL_CAPS.get(skill, cap)):
                return skill
        capped = [sk for sk in ordered if sk not in SKILL_CAPS]
        return capped[0] if capped else None
    return ordered[0]


def _item_path(item, index, mastery, pool, rng, focus_counts=None, focus_cap=None, ctx=None) -> list[Step]:
    is_new = item.get("state", "new") == "new"
    state = item.get("state", "new")
    path: list[Step] = []
    used: set[str] = set()

    def add(type_name, mandatory):
        t = ex.get(type_name)
        path.append(Step(t.name, t.skill, item["id"], graded=t.skill is not None,
                         mandatory=mandatory, payload=t.build(item, pool, rng, ctx), phase=ex.phase(t.name)))
        if t.skill:
            used.add(t.skill)

    if is_new:
        add("introduction", True)
        recog = ex.get("recognition")
        if mastery.get("characters", 0) < STRONG_THRESHOLD and recog.requires(item, pool, ctx):
            add("recognition", True)
    else:
        add("recall", True)
        used.add("vocabulary")

    if state == "mastered":
        return path

    available = _skill_types(item, pool, exclude_skills=used | {"vocabulary"}, ctx=ctx)
    focus = _pick_focus(list(available), mastery, index, focus_counts, focus_cap)
    if focus:
        if focus_counts is not None:
            focus_counts[focus] = focus_counts.get(focus, 0) + 1
        variants = available[focus]  # несколько типов на навык — по ротации, не случайно
        add(variants[index % len(variants)].name, mandatory=(state in ("new", "learning")))
        available.pop(focus)
        weak_left = [s for s in _ranked_skills(list(available), mastery)
                     if mastery.get(s, 0) < WEAK_THRESHOLD
                     and (focus_counts is None or focus_cap is None
                          or focus_counts.get(s, 0) < min(focus_cap, SKILL_CAPS.get(s, focus_cap)))]
        if is_new and weak_left:
            add(available[weak_left[0]][0].name, mandatory=False)
            if focus_counts is not None:
                focus_counts[weak_left[0]] = focus_counts.get(weak_left[0], 0) + 1

    if is_new:
        # фаза 3: слово во фразе — только если есть пример из знакомых слов
        # (в уроке со сценарием фразы, диалог и перевод даёт сценарий темы)
        used_types = {st.type for st in path}
        context = [ex.get(n) for n in ex.CONTEXT_TYPES
                   if n in ex.REGISTRY and n not in used_types and ex.get(n).requires(item, pool, ctx)]
        if context and not (ctx or {}).get("scripted") and not any(ex.phase(t) == 3 for t in used_types):
            add(context[index % len(context)].name, mandatory=False)
        # фаза 4: воспроизведение по смыслу (RU → CN) — финальный шаг нового слова
        if ex.get("word_choice").requires(item, pool, ctx):
            add("word_choice", mandatory=True)
    return path


# Долг повторений: сколько просроченных слов допустимо, прежде чем новое
# начинает уступать место review (новое не должно расти быстрее, чем
# пользователь успевает повторять).
BACKLOG_REVIEW_CAP = 12


# Закрепление в тот же день: слова, выученные сегодня в прошлом уроке (их
# SRS-повтор только завтра), получают по одному упражнению в следующем уроке,
# если очередь повторения не заполнена. Без SRS-обновления (шаги не final) —
# интервалы SM-2 не раздуваются.
PRACTICE_CAP = 4

MODULE_TAIL = 2  # хвост модуля до стольких слов добирается в текущий урок


def lesson_mix(daily_new_words: int, due_count: int, module_remaining: int | None = None) -> tuple[int, int]:
    """
    Сколько новых слов и сколько повторений взять в урок модуля при данном
    числе просроченных слов (due_count, по всем модулям):
      долг <= REVIEW_CAP        -> daily_new_words новых, REVIEW_CAP повторений;
      долг <= 2 * REVIEW_CAP    -> половина новых (с округлением вверх), BACKLOG_REVIEW_CAP;
      долг больше               -> 1 новое слово (курс не встаёт), BACKLOG_REVIEW_CAP.
    Новые слова не вытесняют повторение: при долге урок смещается в review,
    а не продолжает добавлять по 5 слов поверх растущей очереди.
    Если после урока в модуле осталось бы не больше MODULE_TAIL новых слов
    (module_remaining), они добираются сейчас — иначе следующий урок модуля
    состоит из одного-двух шагов.
    """
    daily = max(0, daily_new_words or 0)
    if due_count <= REVIEW_CAP:
        new, cap = daily, REVIEW_CAP
    elif due_count <= 2 * REVIEW_CAP:
        new, cap = min(daily, -(-daily // 2)), BACKLOG_REVIEW_CAP
    else:
        new, cap = min(daily, 1), BACKLOG_REVIEW_CAP
    if module_remaining is not None and new > 0 and 0 < module_remaining - new <= MODULE_TAIL:
        new = module_remaining
    return new, cap


def compute_budget(daily_new_words: int, review_cap: int = REVIEW_CAP) -> int:
    """
    Размер урока в шагах — решение планировщика (Phase D, п.12: перенесено из
    app/services/lesson_service.py, там жила логика, которая должна быть
    в engine). Формула даёт new_words достаточно места на полный путь
    (introduction+recognition+фокус) и не даёт review_cap словам съесть весь
    бюджет раньше, чем до них дойдёт очередь (см. _fit_paths_to_budget —
    новое получает бюджет первым, но сам бюджет уже считается с запасом
    на оба источника, а не только на новое).
    """
    if not daily_new_words:
        return DEFAULT_BUDGET
    return max(15, daily_new_words * 4 + review_cap * 2)


def _fit_paths_to_budget(paths: list[list[Step]], budget: int) -> tuple[list[list[Step]], int]:
    """Оставляет пути, чей обязательный минимум влезает в budget (по порядку,
    отбрасывая с конца при нехватке), затем обрезает необязательные шаги.
    Возвращает (оставшиеся пути, сколько шагов они реально заняли)."""
    kept, running = [], 0
    for p in paths:
        need = sum(1 for s in p if s.mandatory)
        if kept and running + need > budget:
            break
        kept.append(p)
        running += need
    kept = _trim_to_budget(kept, budget)
    return kept, sum(len(p) for p in kept)


def _diversify_consecutive_types(steps: list[Step], window: int = 4) -> list[Step]:
    """Не даёt трём одинаковым типам упражнений идти подряд (Phase D, п.10:
    'recognition -> recognition -> recognition' только потому, что это
    самый доступный тип). Детерминированная локальная перестановка в
    пределах небольшого окна — не новый источник случайности."""
    steps = steps[:]
    for i in range(2, len(steps)):
        if steps[i].role == "script":
            continue  # сценарий темы идёт в авторском порядке (фразы → диалог → перевод → речь)
        if steps[i].type == steps[i - 1].type == steps[i - 2].type:
            for j in range(i + 1, min(i + 1 + window, len(steps))):
                if steps[j].type != steps[i].type and steps[j].role != "script":
                    steps[i], steps[j] = steps[j], steps[i]
                    break
    return steps


def _trim_to_budget(paths: list[list[Step]], budget: int) -> list[list[Step]]:
    def total():
        return sum(len(p) for p in paths)

    while total() > budget:
        candidates = [p for p in paths if any(not s.mandatory for s in p)]
        if not candidates:
            break
        longest = max(candidates, key=lambda p: sum(1 for s in p if not s.mandatory))
        for i in range(len(longest) - 1, -1, -1):
            if not longest[i].mandatory:
                del longest[i]
                break

    while total() > budget and len(paths) > 1:
        paths.pop()
    return paths


def _interleave(paths: list[list[Step]]) -> list[Step]:
    out: list[Step] = []
    for r in range(max((len(p) for p in paths), default=0)):
        for p in paths:
            if r < len(p):
                out.append(p[r])
    return out


def known_vocabulary(new_items: list[dict], review_items: list[dict], pool: list[dict]) -> set[int]:
    """
    Все слова, которые могут считаться знакомыми к концу урока: уже не новые
    где-либо в базе (реальное SRS-состояние), слова повторения и новые слова
    урока. plan_lesson для выбора примеров строже: новое слово урока знакомо
    только тем словам, что вводятся ПОСЛЕ него (порядок урока).
    """
    known = {w["id"] for w in pool if w.get("state") not in (None, "new")}
    known |= {w["id"] for w in new_items}
    known |= {w["id"] for w in review_items}
    return known


def _base_known(review_items: list[dict], pool: list[dict]) -> set[int]:
    """Слова, которые ученик уже видел: в SRS (state не new) или с ответами (accuracy не
    None). Забытое слово (SM-2 сбросил repetitions — state снова new) тоже знакомо:
    раньше оно выпадало, и после одной ошибки в уроке следующий урок терял все фразы,
    диалог и перевод сценария, где оно встречалось."""
    known = {w["id"] for w in pool if w.get("state") not in (None, "new") or w.get("accuracy") is not None}
    known |= {w["id"] for w in review_items}
    return known


def _sentence_order_ok(steps: list[Step], lesson_new_ids: set[int]) -> bool:
    """В каждом шаге с предложением все НОВЫЕ слова урока уже были введены раньше."""
    introduced: set[int] = set()
    for s in steps:
        used = (s.payload or {}).get("used_word_ids") or []
        if any(wid in lesson_new_ids and wid not in introduced and wid != s.word_id for wid in used):
            return False
        if s.type == "introduction":
            introduced.add(s.word_id)
    return True


def _defer_late_phases(steps: list[Step], new_ids: set[int]) -> list[Step]:
    """Шаги фаз 3 (фраза) и 4 (воспроизведение) НОВЫХ слов — в конец урока,
    по фазам, с сохранением относительного порядка (стабильно)."""
    head = [s for s in steps if not (s.word_id in new_ids and s.phase >= 3)]
    late = [s for s in steps if s.word_id in new_ids and s.phase >= 3]
    return head + sorted(late, key=lambda s: s.phase)


def _intro_first_ok(steps: list[Step]) -> bool:
    """Ни один шаг слова не стоит раньше его знакомства (если оно есть в уроке)."""
    intro_at = {s.word_id: i for i, s in enumerate(steps) if s.type == "introduction"}
    return all(i >= intro_at.get(s.word_id, -1) for i, s in enumerate(steps))


def _sentence_bank(items: list[dict]) -> list[str]:
    return [e["sentence_ru"] for it in items for e in it.get("examples") or [] if e.get("sentence_ru")]


RETRY_PREFERENCE = ("word_choice", "recognition", "listening", "pinyin_choice", "tone_choice")


def retry_step(item: dict, failed_type: str, pool: list[dict], rng: Random, ctx: dict | None = None) -> Step | None:
    """
    Повтор слова в конце урока после ошибки: другой тип упражнения того же
    навыка, если есть, иначе первый применимый из RETRY_PREFERENCE (кроме
    провалившегося). Не final (SRS уже учёл ошибку) и не обязателен.
    """
    failed = ex.REGISTRY.get(failed_type)
    same_skill = [t.name for t in ex.REGISTRY.values()
                  if failed and t.skill == failed.skill and t.name not in (failed_type, "recall", "introduction")]
    for name in [*same_skill, *RETRY_PREFERENCE]:
        if name == failed_type or name not in ex.REGISTRY:
            continue
        t = ex.get(name)
        if t.skill and t.requires(item, pool, ctx):
            return Step(t.name, t.skill, item["id"], graded=True, mandatory=False, final=False,
                        payload=t.build(item, pool, rng, ctx), phase=ex.phase(t.name), retry=True)
    return None


def adaptive_daily_new(daily_new_words: int, recent_accuracy: float | None, due_count: int) -> tuple[int, str]:
    """
    Новые слова от истории ответов, а не одинаково для всех: точность последних
    оцениваемых ответов (None — данных мало) сдвигает дневную норму.
      < 60%  -> на 2 меньше (не меньше 1);   < 75% -> на 1 меньше;
      ≥ 92% и долг повторений ≤ REVIEW_CAP -> на 1 больше (не больше 10).
    Возвращает (норма, причина для интерфейса).
    """
    daily = max(0, daily_new_words or 0)
    if recent_accuracy is None or daily == 0:
        return daily, "norm"
    if recent_accuracy < 0.6:
        return max(1, daily - 2), "low_accuracy"
    if recent_accuracy < 0.75:
        return max(1, daily - 1), "low_accuracy"
    if recent_accuracy >= 0.92 and due_count <= REVIEW_CAP:
        return min(10, daily + 1), "high_accuracy"
    return daily, "norm"


# Почему шаг в уроке — короткая подпись для интерфейса (рядом с этапом урока).
ROLE_REASONS = {
    "new": "Новое слово урока",
    "weak": "Слабое слово — здесь часто бывают ошибки",
    "due": "Пора повторить по расписанию",
    "recent": "Изучено недавно — закрепляем",
    "retention": "Давно освоенное слово — проверяем, не забылось ли",
    "script": "Тема урока",
}
STAGE_ORDER = ("new", "practice", "context", "recall", "production", "speaking")
RETENTION_PREFERENCE = ("word_choice", "recognition", "listening")


def _retention_step(item: dict, pool: list[dict], rng: Random, ctx: dict) -> Step | None:
    """Проверка долговременного удержания освоенного слова: одно объективное
    упражнение (не самооценка), не финальное — SRS трогается только при ошибке
    (это решает сервис: забытое освоенное слово возвращается в повторение)."""
    for name in RETENTION_PREFERENCE:
        t = ex.get(name)
        if t.requires(item, pool, ctx):
            return Step(t.name, t.skill, item["id"], graded=True, mandatory=False,
                        payload=t.build(item, pool, rng, ctx), phase=ex.phase(t.name))
    return None


def _annotate(steps: list[Step], roles: dict[int, str], reasons: dict[int, str]) -> None:
    """Этап и причина каждого шага: новые слова — по учебному этапу типа
    упражнения, слова из повторения — этап «повторение» с причиной (слабое,
    по расписанию, недавнее, проверка удержания)."""
    for s in steps:
        if s.role == "script":
            s.stage = ex.stage(s.type)
            s.reason = s.reason or ROLE_REASONS["script"]
            continue
        role = "retry" if s.retry else roles.get(s.word_id, "due")
        s.role = role
        if role in ("new", "retry"):
            s.stage = ex.stage(s.type)
            s.reason = ("Ещё раз — после ошибки" if role == "retry"
                        else ROLE_REASONS["new"] if s.type == "introduction" else None)
        else:
            s.stage = "review"
            s.reason = reasons.get(s.word_id) or ROLE_REASONS.get(role)


def plan_lesson(new_items: list[dict], review_items: list[dict], mastery: dict[str, float],
                pool: list[dict], *, budget: int = DEFAULT_BUDGET, rng: Random | None = None,
                review_cap: int = REVIEW_CAP, practice_items: list[dict] = (),
                sentence_bank: list[str] = (), dialogue_bank: list[dict] = (),
                script: dict | None = None, retention_items: list[dict] = ()) -> list[Step]:
    """
    Phase H: script — разрешённый сценарий темы (engine.lesson_script): его
    фразы, диалог, перевод и речь встают после знакомства со всеми новыми
    словами, по учебным фазам; шаги, где есть незнакомое слово, не строятся.
    retention_items — освоенные слова для редкой проверки удержания (по одному
    шагу, не финальные).
    """
    rng = rng or Random(0)
    # Слово в повторении по определению уже проходилось. Забытое (SM-2
    # сбросил repetitions в 0, srs.word_state говорит "new") повторяется как
    # learning — recall + фокусный шаг, — а не заново через introduction
    # (иначе после пары провалов урок повторения превращался в ленту карточек).
    reviews = [{**it, "state": "learning"} if it.get("state", "new") == "new" else it
               for it in review_items[:review_cap]]

    # Known-vocabulary guard по порядку урока: в предложениях i-го нового слова
    # могут быть только слова, уже знакомые до урока, слова повторения и
    # новые слова, введённые РАНЬШЕ него (new_items[:i]). Раньше все новые
    # слова урока считались известными сразу — пример первого слова мог
    # содержать слово, которое появится только в конце урока.
    base_known = _base_known(reviews, pool)
    new_ids = [it["id"] for it in new_items]
    # переводы фраз слов урока — дистракторы для «что означает фраза»
    bank = _sentence_bank([*new_items, *reviews, *practice_items]) + list(sentence_bank)

    scripted = script is not None
    focus_counts: dict[str, int] = {}
    focus_cap = max(2, -(-(len(new_items) + len(reviews)) // 2))  # не больше половины слов на один навык

    # Новое строится и получает бюджет ПЕРВЫМ (Phase D, п.4: review не должен
    # блокировать изучение нового материала) — но сам budget уже расширен
    # (см. compute_budget) с запасом и на review, поэтому на практике оба
    # источника помещаются; при долге повторений число новых заранее урезает
    # lesson_mix().
    new_paths_all = [_item_path(it, i, mastery, pool, rng, focus_counts, focus_cap,
                                {"known_word_ids": base_known | set(new_ids[:i]), "sentence_bank": bank,
                                 "dialogue_bank": dialogue_bank, "scripted": scripted})
                     for i, it in enumerate(new_items)]
    new_paths, used = _fit_paths_to_budget(new_paths_all, budget)

    review_ctx = {"known_word_ids": base_known, "sentence_bank": bank, "dialogue_bank": dialogue_bank}
    review_paths_all = [_item_path(it, i, mastery, pool, rng, focus_counts, focus_cap, review_ctx)
                        for i, it in enumerate(reviews)]
    review_paths, used_review = _fit_paths_to_budget(review_paths_all, max(0, budget - used))

    # Закрепление сегодняшних слов — только в свободные слоты повторения и
    # остаток бюджета; одно объективное упражнение (не recall), не final.
    practice_ids: set[int] = set()
    free_slots = max(0, min(PRACTICE_CAP, review_cap - len(review_paths)))
    review_ids = {it["id"] for it in reviews} | set(new_ids)
    practice = [{**it, "state": "learning"} for it in practice_items
                if it["id"] not in review_ids][:free_slots]
    left = max(0, budget - used - used_review)
    for i, it in enumerate(practice):
        if left <= 0:
            break
        steps_ = [st for st in _item_path(it, i, mastery, pool, rng, focus_counts, focus_cap, review_ctx | {
            "known_word_ids": base_known | {it["id"]}}) if st.type != "recall"][:1]
        if not steps_:
            continue
        for st in steps_:
            st.mandatory = False
        review_paths.append(steps_)
        practice_ids.add(it["id"])
        left -= len(steps_)

    # Форма урока (Phase D, п.3): новое и старое чередуются блоками —
    # "новое -> закрепление -> старое -> новое -> повторение -> применение",
    # а не "сначала весь review, потом всё новое".
    groups: list[list[Step]]
    # Проверка удержания освоенных слов — по одному шагу, в блок повторения.
    retention_ids: set[int] = set()
    taken = {it["id"] for it in reviews} | set(new_ids) | practice_ids
    for it in [r for r in retention_items if r["id"] not in taken][:1]:
        st = _retention_step(it, pool, rng, review_ctx | {"known_word_ids": base_known | {it["id"]}})
        if st is not None:
            review_paths.append([st])
            retention_ids.add(it["id"])

    groups = []
    ni, ri, take_new = 0, 0, True
    while ni < len(new_paths) or ri < len(review_paths):
        if take_new and ni < len(new_paths):
            groups.append(new_paths[ni:ni + NEW_CHUNK])
            ni += NEW_CHUNK
        elif ri < len(review_paths):
            groups.append(review_paths[ri:ri + REVIEW_CHUNK])
            ri += REVIEW_CHUNK
        elif ni < len(new_paths):
            groups.append(new_paths[ni:ni + NEW_CHUNK])
            ni += NEW_CHUNK
        take_new = not take_new

    interleaved: list[Step] = []
    for g in groups:
        interleaved.extend(_interleave(g))
    ordered = _defer_late_phases(interleaved, {it["id"] for it in new_items})
    if scripted:
        # Сценарий темы — после знакомства со всеми новыми словами: знакомыми
        # к этому моменту считаются слова до урока, повторения и все новые слова.
        known_after_intro = base_known | set(new_ids)
        lesson_word_ids = set(new_ids) | {it["id"] for it in reviews}
        specs = lesson_script.build_steps(script, known_after_intro, lesson_word_ids, rng)
        script_steps = [Step(sp["type"], sp["skill"], sp["word_id"], graded=sp["skill"] is not None
                             and sp["type"] != "speaking", mandatory=True, payload=sp["payload"],
                             phase=sp["phase"], role="script", reason=sp.get("reason")) for sp in specs]
        head = [s for s in ordered if not (s.word_id in set(new_ids) and s.phase >= 3)]
        late = [s for s in ordered if s.word_id in set(new_ids) and s.phase >= 3]
        ordered = head + sorted(late + script_steps, key=lambda s: s.phase)
    steps = _diversify_consecutive_types(ordered)
    lesson_new = set(new_ids) - base_known
    if not (_sentence_order_ok(steps, lesson_new) and _intro_first_ok(steps)):
        steps = ordered  # перестановка не должна выносить шаг раньше знакомства со словом

    # SRS обновляется один раз на слово — на его последнем шаге, и только для
    # новых слов и слов повторения (не для закрепления, проверки удержания и
    # знакомых слов, которые встретились лишь во фразах сценария).
    srs_ids = set(new_ids) | {it["id"] for it in reviews}
    last_index: dict[int, int] = {}
    for i, s in enumerate(steps):
        if s.type != "speaking":  # речь может остаться без оценки — SRS решают другие шаги
            last_index[s.word_id] = i
    for i, s in enumerate(steps):
        s.final = (last_index.get(s.word_id) == i and s.word_id in srs_ids
                   and s.word_id not in practice_ids and s.word_id not in retention_ids)

    roles = {wid: "new" for wid in new_ids}
    reasons: dict[int, str] = {}
    for it in reviews:
        roles[it["id"]] = it.get("role") or "due"
        if it.get("reason"):
            reasons[it["id"]] = it["reason"]
    for it in practice:
        roles.setdefault(it["id"], it.get("role") or "recent")
        if it.get("reason"):
            reasons.setdefault(it["id"], it["reason"])
    for wid in retention_ids:
        roles[wid] = "retention"
    _annotate(steps, roles, reasons)
    return steps
